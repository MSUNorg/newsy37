-- -----------------------------
-- Think MySQL Data Transfer 
-- 
-- Host     : 127.0.0.1
-- Port     : 3306
-- Database : 37
-- 
-- Part : #1
-- Date : 2016-08-12 18:42:59
-- -----------------------------

SET FOREIGN_KEY_CHECKS = 0;


-- -----------------------------
-- Table structure for `sys_action`
-- -----------------------------
DROP TABLE IF EXISTS `sys_action`;
CREATE TABLE `sys_action` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `name` char(30) NOT NULL DEFAULT '' COMMENT '行为唯一标识',
  `title` char(80) NOT NULL DEFAULT '' COMMENT '行为说明',
  `remark` char(140) NOT NULL DEFAULT '' COMMENT '行为描述',
  `rule` text COMMENT '行为规则',
  `log` text COMMENT '日志规则',
  `type` tinyint(2) unsigned NOT NULL DEFAULT '1' COMMENT '类型',
  `status` tinyint(2) NOT NULL DEFAULT '0' COMMENT '状态',
  `update_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '修改时间',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='系统行为表';

-- -----------------------------
-- Records of `sys_action`
-- -----------------------------
INSERT INTO `sys_action` VALUES ('1', 'user_login', '用户登录', '积分+10，每天一次', 'table:member|field:score|condition:uid={$self} AND status>-1|rule:score+10|cycle:24|max:1;', '[user|get_nickname]在[time|time_format]登录了后台', '1', '1', '1387181220');
INSERT INTO `sys_action` VALUES ('2', 'add_article', '发布文章', '积分+5，每天上限5次', 'table:member|field:score|condition:uid={$self}|rule:score+5|cycle:24|max:5', '', '2', '0', '1380173180');
INSERT INTO `sys_action` VALUES ('3', 'review', '评论', '评论积分+1，无限制', 'table:member|field:score|condition:uid={$self}|rule:score+1', '', '2', '1', '1383285646');
INSERT INTO `sys_action` VALUES ('4', 'add_document', '发表文档', '积分+10，每天上限5次', 'table:member|field:score|condition:uid={$self}|rule:score+10|cycle:24|max:5', '[user|get_nickname]在[time|time_format]发表了一篇文章。\r\n表[model]，记录编号[record]。', '2', '0', '1386139726');
INSERT INTO `sys_action` VALUES ('5', 'add_document_topic', '发表讨论', '积分+5，每天上限10次', 'table:member|field:score|condition:uid={$self}|rule:score+5|cycle:24|max:10', '', '2', '0', '1383285551');
INSERT INTO `sys_action` VALUES ('6', 'update_config', '更新配置', '新增或修改或删除配置', '', '', '1', '1', '1383294988');
INSERT INTO `sys_action` VALUES ('7', 'update_model', '更新模型', '新增或修改模型', '', '', '1', '1', '1383295057');
INSERT INTO `sys_action` VALUES ('8', 'update_attribute', '更新属性', '新增或更新或删除属性', '', '', '1', '1', '1383295963');
INSERT INTO `sys_action` VALUES ('9', 'update_channel', '更新导航', '新增或修改或删除导航', '', '', '1', '1', '1383296301');
INSERT INTO `sys_action` VALUES ('10', 'update_menu', '更新菜单', '新增或修改或删除菜单', '', '', '1', '1', '1383296392');
INSERT INTO `sys_action` VALUES ('11', 'update_category', '更新分类', '新增或修改或删除分类', '', '', '1', '1', '1383296765');
INSERT INTO `sys_action` VALUES ('12', 'asasasaas', '212121', '1212112', '', '', '2', '-1', '1464665704');

-- -----------------------------
-- Table structure for `sys_action_log`
-- -----------------------------
DROP TABLE IF EXISTS `sys_action_log`;
CREATE TABLE `sys_action_log` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `action_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '行为id',
  `user_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '执行用户id',
  `action_ip` bigint(20) NOT NULL COMMENT '执行行为者ip',
  `model` varchar(50) NOT NULL DEFAULT '' COMMENT '触发行为的表',
  `record_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '触发行为的数据id',
  `remark` varchar(255) NOT NULL DEFAULT '' COMMENT '日志备注',
  `status` tinyint(2) NOT NULL DEFAULT '1' COMMENT '状态',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '执行行为的时间',
  PRIMARY KEY (`id`),
  KEY `action_ip_ix` (`action_ip`),
  KEY `action_id_ix` (`action_id`),
  KEY `user_id_ix` (`user_id`)
) ENGINE=MyISAM AUTO_INCREMENT=31 DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED COMMENT='行为日志表';

-- -----------------------------
-- Records of `sys_action_log`
-- -----------------------------
INSERT INTO `sys_action_log` VALUES ('1', '1', '1', '-1725676337', 'member', '1', 'admin在2016-08-08 18:04登录了后台', '1', '1470650678');
INSERT INTO `sys_action_log` VALUES ('2', '1', '1', '-1725676337', 'member', '1', 'admin在2016-08-08 18:20登录了后台', '1', '1470651631');
INSERT INTO `sys_action_log` VALUES ('3', '1', '1', '1022946991', 'member', '1', 'admin在2016-08-08 20:22登录了后台', '1', '1470658926');
INSERT INTO `sys_action_log` VALUES ('4', '1', '1', '-1725676337', 'member', '1', 'admin在2016-08-08 20:39登录了后台', '1', '1470659944');
INSERT INTO `sys_action_log` VALUES ('5', '1', '1', '-1725652556', 'member', '1', 'admin在2016-08-09 10:23登录了后台', '1', '1470709422');
INSERT INTO `sys_action_log` VALUES ('6', '1', '1', '1022946991', 'member', '1', 'admin在2016-08-09 13:05登录了后台', '1', '1470719125');
INSERT INTO `sys_action_log` VALUES ('7', '1', '1', '-1725652556', 'member', '1', 'admin在2016-08-09 17:14登录了后台', '1', '1470734076');
INSERT INTO `sys_action_log` VALUES ('8', '1', '1', '-1725651962', 'member', '1', 'admin在2016-08-10 09:06登录了后台', '1', '1470791193');
INSERT INTO `sys_action_log` VALUES ('9', '1', '1', '-1725651962', 'member', '1', 'admin在2016-08-10 10:19登录了后台', '1', '1470795555');
INSERT INTO `sys_action_log` VALUES ('10', '1', '1', '1022946991', 'member', '1', 'admin在2016-08-10 14:06登录了后台', '1', '1470809217');
INSERT INTO `sys_action_log` VALUES ('11', '1', '1', '-1725651962', 'member', '1', 'admin在2016-08-10 15:14登录了后台', '1', '1470813249');
INSERT INTO `sys_action_log` VALUES ('12', '1', '1', '1022946991', 'member', '1', 'admin在2016-08-11 00:02登录了后台', '1', '1470844979');
INSERT INTO `sys_action_log` VALUES ('13', '1', '1', '1022946991', 'member', '1', 'admin在2016-08-11 14:07登录了后台', '1', '1470895676');
INSERT INTO `sys_action_log` VALUES ('14', '1', '11', '1022946991', 'member', '11', 'mhxy在2016-08-11 14:19登录了后台', '1', '1470896358');
INSERT INTO `sys_action_log` VALUES ('15', '1', '1', '1022946991', 'member', '1', 'admin在2016-08-11 14:19登录了后台', '1', '1470896399');
INSERT INTO `sys_action_log` VALUES ('16', '1', '11', '1022946991', 'member', '11', 'mhxy在2016-08-11 14:20登录了后台', '1', '1470896427');
INSERT INTO `sys_action_log` VALUES ('17', '1', '1', '1022946991', 'member', '1', 'admin在2016-08-11 14:20登录了后台', '1', '1470896458');
INSERT INTO `sys_action_log` VALUES ('18', '1', '11', '1022946991', 'member', '11', 'mhxy在2016-08-11 14:21登录了后台', '1', '1470896516');
INSERT INTO `sys_action_log` VALUES ('19', '1', '1', '-1660886456', 'member', '1', 'admin在2016-08-11 14:22登录了后台', '1', '1470896528');
INSERT INTO `sys_action_log` VALUES ('20', '1', '11', '-636254089', 'member', '11', 'mhxy在2016-08-11 14:23登录了后台', '1', '1470896583');
INSERT INTO `sys_action_log` VALUES ('21', '1', '1', '-1660886456', 'member', '1', 'admin在2016-08-11 14:25登录了后台', '1', '1470896710');
INSERT INTO `sys_action_log` VALUES ('22', '1', '1', '1022946991', 'member', '1', 'admin在2016-08-11 14:25登录了后台', '1', '1470896752');
INSERT INTO `sys_action_log` VALUES ('23', '1', '1', '-1660886456', 'member', '1', 'admin在2016-08-11 20:00登录了后台', '1', '1470916826');
INSERT INTO `sys_action_log` VALUES ('24', '1', '1', '987364170', 'member', '1', 'admin在2016-08-11 21:19登录了后台', '1', '1470921548');
INSERT INTO `sys_action_log` VALUES ('25', '1', '1', '1022946991', 'member', '1', 'admin在2016-08-12 10:00登录了后台', '1', '1470967239');
INSERT INTO `sys_action_log` VALUES ('26', '1', '1', '-1725676389', 'member', '1', 'admin在2016-08-12 10:00登录了后台', '1', '1470967241');
INSERT INTO `sys_action_log` VALUES ('27', '1', '11', '-636253559', 'member', '11', 'mhxy在2016-08-12 14:18登录了后台', '1', '1470982737');
INSERT INTO `sys_action_log` VALUES ('28', '1', '1', '1022946991', 'member', '1', 'admin在2016-08-12 16:54登录了后台', '1', '1470992089');
INSERT INTO `sys_action_log` VALUES ('29', '1', '11', '-898783568', 'member', '11', 'mhxy在2016-08-12 17:22登录了后台', '1', '1470993751');
INSERT INTO `sys_action_log` VALUES ('30', '1', '11', '-898783574', 'member', '11', 'mhxy在2016-08-12 17:23登录了后台', '1', '1470993780');

-- -----------------------------
-- Table structure for `sys_addons`
-- -----------------------------
DROP TABLE IF EXISTS `sys_addons`;
CREATE TABLE `sys_addons` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `name` varchar(40) NOT NULL COMMENT '插件名或标识',
  `title` varchar(20) NOT NULL DEFAULT '' COMMENT '中文名',
  `description` text COMMENT '插件描述',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '状态',
  `config` text COMMENT '配置',
  `author` varchar(40) DEFAULT '' COMMENT '作者',
  `version` varchar(20) DEFAULT '' COMMENT '版本号',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '安装时间',
  `has_adminlist` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '是否有后台列表',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=17 DEFAULT CHARSET=utf8 COMMENT='插件表';

-- -----------------------------
-- Records of `sys_addons`
-- -----------------------------
INSERT INTO `sys_addons` VALUES ('15', 'EditorForAdmin', '后台编辑器', '用于增强整站长文本的输入和显示', '1', '{\"editor_type\":\"2\",\"editor_wysiwyg\":\"1\",\"editor_height\":\"500px\",\"editor_resize_type\":\"1\"}', 'thinkphp', '0.1', '1383126253', '0');
INSERT INTO `sys_addons` VALUES ('2', 'SiteStat', '站点统计信息', '统计站点的基础信息', '1', '{\"title\":\"\\u7cfb\\u7edf\\u4fe1\\u606f\",\"width\":\"1\",\"display\":\"1\",\"status\":\"0\"}', 'thinkphp', '0.1', '1379512015', '0');
INSERT INTO `sys_addons` VALUES ('3', 'DevTeam', '开发团队信息', '开发团队成员信息', '1', '{\"title\":\"OneThink\\u5f00\\u53d1\\u56e2\\u961f\",\"width\":\"2\",\"display\":\"1\"}', 'thinkphp', '0.1', '1379512022', '0');
INSERT INTO `sys_addons` VALUES ('4', 'SystemInfo', '系统环境信息', '用于显示一些服务器的信息', '1', '{\"title\":\"\\u7cfb\\u7edf\\u4fe1\\u606f\",\"width\":\"2\",\"display\":\"1\"}', 'thinkphp', '0.1', '1379512036', '0');
INSERT INTO `sys_addons` VALUES ('5', 'Editor', '前台编辑器', '用于增强整站长文本的输入和显示', '1', '{\"editor_type\":\"2\",\"editor_wysiwyg\":\"1\",\"editor_height\":\"300px\",\"editor_resize_type\":\"1\"}', 'thinkphp', '0.1', '1379830910', '0');
INSERT INTO `sys_addons` VALUES ('6', 'Attachment', '附件', '用于文档模型上传附件', '1', 'null', 'thinkphp', '0.1', '1379842319', '1');
INSERT INTO `sys_addons` VALUES ('9', 'SocialComment', '通用社交化评论', '集成了各种社交化评论插件，轻松集成到系统中。', '1', '{\"comment_type\":\"1\",\"comment_uid_youyan\":\"\",\"comment_short_name_duoshuo\":\"\",\"comment_data_list_duoshuo\":\"\"}', 'thinkphp', '0.1', '1380273962', '0');
INSERT INTO `sys_addons` VALUES ('16', 'UploadImages', '多图上传', '多图上传', '1', 'null', '木梁大囧', '1.2', '1465726636', '0');

-- -----------------------------
-- Table structure for `sys_attachment`
-- -----------------------------
DROP TABLE IF EXISTS `sys_attachment`;
CREATE TABLE `sys_attachment` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '用户ID',
  `title` char(30) NOT NULL DEFAULT '' COMMENT '附件显示名',
  `type` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '附件类型',
  `source` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '资源ID',
  `record_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '关联记录ID',
  `download` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '下载次数',
  `size` bigint(20) unsigned NOT NULL DEFAULT '0' COMMENT '附件大小',
  `dir` int(12) unsigned NOT NULL DEFAULT '0' COMMENT '上级目录ID',
  `sort` int(8) unsigned NOT NULL DEFAULT '0' COMMENT '排序',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `status` tinyint(1) NOT NULL DEFAULT '0' COMMENT '状态',
  PRIMARY KEY (`id`),
  KEY `idx_record_status` (`record_id`,`status`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='附件表';


-- -----------------------------
-- Table structure for `sys_attribute`
-- -----------------------------
DROP TABLE IF EXISTS `sys_attribute`;
CREATE TABLE `sys_attribute` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(30) NOT NULL DEFAULT '' COMMENT '字段名',
  `title` varchar(100) NOT NULL DEFAULT '' COMMENT '字段注释',
  `field` varchar(100) NOT NULL DEFAULT '' COMMENT '字段定义',
  `type` varchar(20) NOT NULL DEFAULT '' COMMENT '数据类型',
  `value` varchar(100) NOT NULL DEFAULT '' COMMENT '字段默认值',
  `remark` varchar(100) NOT NULL DEFAULT '' COMMENT '备注',
  `is_show` tinyint(1) unsigned NOT NULL DEFAULT '1' COMMENT '是否显示',
  `extra` varchar(255) NOT NULL DEFAULT '' COMMENT '参数',
  `model_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '模型id',
  `is_must` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '是否必填',
  `status` tinyint(2) NOT NULL DEFAULT '0' COMMENT '状态',
  `update_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `create_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `validate_rule` varchar(255) NOT NULL DEFAULT '',
  `validate_time` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `error_info` varchar(100) NOT NULL DEFAULT '',
  `validate_type` varchar(25) NOT NULL DEFAULT '',
  `auto_rule` varchar(100) NOT NULL DEFAULT '',
  `auto_time` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `auto_type` varchar(25) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `model_id` (`model_id`)
) ENGINE=MyISAM AUTO_INCREMENT=403 DEFAULT CHARSET=utf8 COMMENT='模型属性表';

-- -----------------------------
-- Records of `sys_attribute`
-- -----------------------------
INSERT INTO `sys_attribute` VALUES ('1', 'uid', '用户ID', 'int(10) unsigned NOT NULL ', 'num', '0', '', '0', '', '1', '0', '1', '1384508362', '1383891233', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('2', 'name', '标识', 'char(40) NOT NULL ', 'string', '', '同一根节点下标识不重复', '1', '', '1', '0', '1', '1383894743', '1383891233', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('3', 'title', '标题', 'char(80) NOT NULL ', 'string', '', '文档标题', '1', '', '1', '0', '1', '1383894778', '1383891233', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('4', 'category_id', '所属分类', 'int(10) unsigned NOT NULL ', 'string', '', '', '0', '', '1', '0', '1', '1384508336', '1383891233', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('5', 'description', '描述', 'char(140) NOT NULL ', 'textarea', '', '', '1', '', '1', '0', '1', '1383894927', '1383891233', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('6', 'root', '根节点', 'int(10) unsigned NOT NULL ', 'num', '0', '该文档的顶级文档编号', '0', '', '1', '0', '1', '1384508323', '1383891233', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('7', 'pid', '所属ID', 'int(10) unsigned NOT NULL ', 'num', '0', '父文档编号', '0', '', '1', '0', '1', '1384508543', '1383891233', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('8', 'model_id', '内容模型ID', 'tinyint(3) unsigned NOT NULL ', 'num', '0', '该文档所对应的模型', '0', '', '1', '0', '1', '1384508350', '1383891233', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('9', 'type', '内容类型', 'tinyint(3) unsigned NOT NULL ', 'select', '2', '', '1', '1:目录\r\n2:主题\r\n3:段落', '1', '0', '1', '1384511157', '1383891233', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('10', 'position', '推荐位', 'smallint(5) unsigned NOT NULL ', 'checkbox', '0', '多个推荐则将其推荐值相加', '1', '[DOCUMENT_POSITION]', '1', '0', '1', '1383895640', '1383891233', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('11', 'link_id', '外链', 'int(10) unsigned NOT NULL ', 'num', '0', '0-非外链，大于0-外链ID,需要函数进行链接与编号的转换', '1', '', '1', '0', '1', '1383895757', '1383891233', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('12', 'cover_id', '封面', 'int(10) unsigned NOT NULL ', 'picture', '0', '0-无封面，大于0-封面图片ID，需要函数处理', '1', '', '1', '0', '1', '1384147827', '1383891233', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('13', 'display', '可见性', 'tinyint(3) unsigned NOT NULL ', 'radio', '1', '', '1', '0:不可见\r\n1:所有人可见', '1', '0', '1', '1386662271', '1383891233', '', '0', '', 'regex', '', '0', 'function');
INSERT INTO `sys_attribute` VALUES ('14', 'deadline', '截至时间', 'int(10) unsigned NOT NULL ', 'datetime', '0', '0-永久有效', '1', '', '1', '0', '1', '1387163248', '1383891233', '', '0', '', 'regex', '', '0', 'function');
INSERT INTO `sys_attribute` VALUES ('15', 'attach', '附件数量', 'tinyint(3) unsigned NOT NULL ', 'num', '0', '', '0', '', '1', '0', '1', '1387260355', '1383891233', '', '0', '', 'regex', '', '0', 'function');
INSERT INTO `sys_attribute` VALUES ('16', 'view', '浏览量', 'int(10) unsigned NOT NULL ', 'num', '0', '', '1', '', '1', '0', '1', '1383895835', '1383891233', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('17', 'comment', '评论数', 'int(10) unsigned NOT NULL ', 'num', '0', '', '1', '', '1', '0', '1', '1383895846', '1383891233', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('18', 'extend', '扩展统计字段', 'int(10) unsigned NOT NULL ', 'num', '0', '根据需求自行使用', '0', '', '1', '0', '1', '1384508264', '1383891233', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('19', 'level', '优先级', 'int(10) unsigned NOT NULL ', 'num', '0', '越高排序越靠前', '1', '', '1', '0', '1', '1383895894', '1383891233', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('20', 'create_time', '创建时间', 'int(10) unsigned NOT NULL ', 'datetime', '0', '', '1', '', '1', '0', '1', '1383895903', '1383891233', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('21', 'update_time', '更新时间', 'int(10) unsigned NOT NULL ', 'datetime', '0', '', '0', '', '1', '0', '1', '1384508277', '1383891233', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('22', 'status', '数据状态', 'tinyint(4) NOT NULL ', 'radio', '0', '', '0', '-1:删除\r\n0:禁用\r\n1:正常\r\n2:待审核\r\n3:草稿', '1', '0', '1', '1384508496', '1383891233', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('23', 'parse', '内容解析类型', 'tinyint(3) unsigned NOT NULL ', 'select', '0', '', '0', '0:html\r\n1:ubb\r\n2:markdown', '2', '0', '1', '1384511049', '1383891243', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('24', 'content', '文章内容', 'text NOT NULL ', 'editor', '', '', '1', '', '2', '0', '1', '1383896225', '1383891243', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('25', 'template', '详情页显示模板', 'varchar(100) NOT NULL ', 'string', '', '参照display方法参数的定义', '1', '', '2', '0', '1', '1383896190', '1383891243', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('26', 'bookmark', '收藏数', 'int(10) unsigned NOT NULL ', 'num', '0', '', '1', '', '2', '0', '1', '1383896103', '1383891243', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('27', 'parse', '内容解析类型', 'tinyint(3) unsigned NOT NULL ', 'select', '0', '', '0', '0:html\r\n1:ubb\r\n2:markdown', '3', '0', '1', '1387260461', '1383891252', '', '0', '', 'regex', '', '0', 'function');
INSERT INTO `sys_attribute` VALUES ('28', 'content', '下载详细描述', 'text NOT NULL ', 'editor', '', '', '1', '', '3', '0', '1', '1383896438', '1383891252', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('29', 'template', '详情页显示模板', 'varchar(100) NOT NULL ', 'string', '', '', '1', '', '3', '0', '1', '1383896429', '1383891252', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('30', 'file_id', '文件ID', 'int(10) unsigned NOT NULL ', 'file', '0', '需要函数处理', '1', '', '3', '0', '1', '1383896415', '1383891252', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('31', 'download', '下载次数', 'int(10) unsigned NOT NULL ', 'num', '0', '', '1', '', '3', '0', '1', '1383896380', '1383891252', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('32', 'size', '文件大小', 'bigint(20) unsigned NOT NULL ', 'num', '0', '单位bit', '1', '', '3', '0', '1', '1383896371', '1383891252', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('33', 'game_name', '游戏名称', 'varchar(30) NULL ', 'string', '', '', '1', '', '4', '0', '1', '1463664513', '1463664513', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('34', 'sort', '排序', 'int(10) unsigned NULL ', 'string', '1', '', '1', '', '4', '0', '1', '1463664513', '1463664513', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('35', 'short', '游戏简写', 'varchar(20) NULL ', 'string', '', '', '1', '', '4', '0', '1', '1463664513', '1463664513', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('36', 'game_type_id', '游戏类型id', 'int(10) NULL ', 'string', '', '', '1', '', '4', '0', '1', '1463664513', '1463664513', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('37', 'game_type_name', '游戏类型名称', 'varchar(20) NULL ', 'string', '', '', '1', '', '4', '0', '1', '1463664513', '1463664513', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('38', 'game_score', '游戏评分', 'double(3,0) NULL ', 'string', '', '', '1', '', '4', '0', '1', '1463664513', '1463664513', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('39', 'features', '游戏特征', 'varchar(50) NULL ', 'string', '', '', '1', '', '4', '0', '1', '1463664513', '1463664513', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('40', 'recommend_level', '', 'double(3,0) NULL ', 'string', '', '', '1', '', '4', '0', '1', '1463664513', '1463664513', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('41', 'version', '版本号', 'varchar(10) NULL ', 'string', '', '', '1', '', '4', '0', '1', '1463664513', '1463664513', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('42', 'game_size', '游戏大小', 'varchar(10) NULL ', 'string', '0', '', '1', '', '4', '0', '1', '1463664513', '1463664513', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('43', 'icon', '游戏图标', 'int(11) NULL ', 'string', '', '', '1', '', '4', '0', '1', '1463664513', '1463664513', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('44', 'cover', '游戏封面', 'int(11) NULL ', 'string', '', '', '1', '', '4', '0', '1', '1463664513', '1463664513', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('45', 'screenshot', '游戏截图', 'varchar(255) NULL ', 'string', '', '', '1', '', '4', '0', '1', '1463664513', '1463664513', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('46', 'introduction', '游戏简介', 'varchar(300) NULL ', 'string', '', '', '1', '', '4', '0', '1', '1463664513', '1463664513', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('47', 'and_dow_address', '安卓游戏下载地址', 'varchar(255) NULL ', 'string', '', '', '1', '', '4', '0', '1', '1463664513', '1463664513', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('48', 'ios_dow_address', 'ios游戏下载地址', 'varchar(255) NULL ', 'string', '', '', '1', '', '4', '0', '1', '1463664513', '1463664513', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('49', 'game_address', '外部链接游戏地址', 'varchar(255) NULL ', 'string', '', '', '1', '', '4', '0', '1', '1463664513', '1463664513', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('50', 'dow_num', '游戏下载数量', 'int(10) NULL ', 'string', '0', '', '1', '', '4', '0', '1', '1463664513', '1463664513', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('51', 'game_status', '游戏状态(0:关闭,1:开启)', 'tinyint(2) NULL ', 'string', '', '', '1', '', '4', '0', '1', '1463664513', '1463664513', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('52', 'recommend_status', '推荐状态(0:否,1是)', 'tinyint(2) NULL ', 'string', '1', '', '1', '', '4', '0', '1', '1463664513', '1463664513', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('53', 'pay_status', '充值状态(0:关闭,1:开启)', 'tinyint(2) NULL ', 'string', '1', '', '1', '', '4', '0', '1', '1463664513', '1463664513', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('54', 'dow_status', '下载状态(0:关闭,1:开启)', 'tinyint(2) NULL ', 'string', '1', '', '1', '', '4', '0', '1', '1463664513', '1463664513', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('55', 'developers', '开发商', 'varchar(30) NULL ', 'string', '', '', '1', '', '4', '0', '1', '1463664513', '1463664513', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('56', 'create_time', '创建时间', 'int(11) NULL ', 'string', '', '', '1', '', '4', '0', '1', '1463664513', '1463664513', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('57', 'discount', '折扣', 'int(3) NULL ', 'string', '', '', '1', '', '4', '0', '1', '1463664513', '1463664513', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('58', 'language', '语言', 'varchar(10) NULL ', 'string', '', '', '1', '', '4', '0', '1', '1463664513', '1463664513', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('59', 'game_appid', '游戏appid', 'varchar(32) NULL ', 'string', '', '', '1', '', '4', '0', '1', '1463664513', '1463664513', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('60', 'game_coin_name', '游戏币名称', 'varchar(10) NULL ', 'string', '', '', '1', '', '4', '0', '1', '1463664513', '1463664513', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('61', 'game_coin_ration', '游戏币比例', 'varchar(10) NULL ', 'string', '', '', '1', '', '4', '0', '1', '1463664513', '1463664513', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('62', 'type_name', '游戏类型名称', 'varchar(20) NULL ', 'string', '', '', '1', '', '5', '0', '1', '1463968087', '1463968087', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('63', 'status', '状态(-1:删除,1:正常)', 'tinyint(2) NULL ', 'string', '1', '', '1', '', '5', '0', '1', '1463968087', '1463968087', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('64', 'status_show', '显示状态(0:不显示,1:显示)', 'tinyint(2) NULL ', 'string', '1', '', '1', '', '5', '0', '1', '1463968087', '1463968087', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('65', 'op_id', '操作人id', 'int(11) NULL ', 'string', '', '', '1', '', '5', '0', '1', '1463968087', '1463968087', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('66', 'op_nickname', '操作人昵称', 'varchar(30) NULL ', 'string', '', '', '1', '', '5', '0', '1', '1463968087', '1463968087', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('67', 'create_time', '添加时间', 'int(11) NULL ', 'string', '', '', '1', '', '5', '0', '1', '1463968087', '1463968087', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('68', 'game_id', '游戏id', 'int(11) NOT NULL ', 'string', '', '', '1', '', '6', '0', '1', '1463982983', '1463982983', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('69', 'game_name', '游戏名称', 'varchar(30) NULL ', 'string', '', '', '1', '', '6', '0', '1', '1463982983', '1463982983', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('70', 'server_name', '区服名称', 'varchar(30) NULL ', 'string', '', '', '1', '', '6', '0', '1', '1463982983', '1463982983', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('71', 'server_num', '对接区服id', 'int(11) NULL ', 'string', '', '', '1', '', '6', '0', '1', '1463982983', '1463982983', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('72', 'recommend_status', '推荐状态(0:否,1:是)', 'tinyint(2) NULL ', 'string', '1', '', '1', '', '6', '0', '1', '1463982983', '1463982983', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('73', 'show_status', '显示状态(0:否,1:是)', 'tinyint(2) NULL ', 'string', '1', '', '1', '', '6', '0', '1', '1463982983', '1463982983', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('74', 'stop_status', '是否停服(0:否,1:是)', 'tinyint(2) NULL ', 'string', '0', '', '1', '', '6', '0', '1', '1463982983', '1463982983', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('75', 'area_status', '区服状态(0:正常,1拥挤,2爆满)', 'tinyint(2) NULL ', 'string', '0', '', '1', '', '6', '0', '1', '1463982983', '1463982983', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('76', 'icon', '区服图标', 'int(11) NULL ', 'string', '', '', '1', '', '6', '0', '1', '1463982983', '1463982983', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('77', 'start_time', '开始时间', 'int(11) NULL ', 'string', '', '', '1', '', '6', '0', '1', '1463982983', '1463982983', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('78', 'desride', '描述', 'varchar(300) NULL ', 'string', '', '', '1', '', '6', '0', '1', '1463982983', '1463982983', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('79', 'prompt', '停服提示', 'varchar(300) NULL ', 'string', '', '', '1', '', '6', '0', '1', '1463982983', '1463982983', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('80', 'parent_id', '父类id', 'int(11) NULL ', 'string', '', '', '1', '', '6', '0', '1', '1463982983', '1463982983', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('81', 'create_time', '创建时间', 'int(11) NULL ', 'string', '', '', '1', '', '6', '0', '1', '1463982983', '1463982983', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('82', 'game_id', '游戏id', 'int(11) NULL ', 'string', '', '', '1', '', '7', '0', '1', '1463985936', '1463985936', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('83', 'game_name', '游戏名称', 'varchar(30) NULL ', 'string', '', '', '1', '', '7', '0', '1', '1463985936', '1463985936', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('84', 'server_id', '区服id', 'int(11) NULL ', 'string', '', '', '1', '', '7', '0', '1', '1463985936', '1463985936', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('85', 'server_name', '区服名称', 'int(30) NULL ', 'string', '', '', '1', '', '7', '0', '1', '1463985936', '1463985936', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('86', 'giftbag_name', '礼包名称', 'varchar(30) NULL ', 'string', '', '', '1', '', '7', '0', '1', '1463985936', '1463985936', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('87', 'giftbag_type', '礼包类型', 'tinyint(2) NULL ', 'string', '', '', '1', '', '7', '0', '1', '1463985936', '1463985936', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('88', 'level', '领取等级', 'int(3) NULL ', 'string', '', '', '1', '', '7', '0', '1', '1463985936', '1463985936', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('89', 'sort', '排序', 'int(10) NULL ', 'string', '0', '', '1', '', '7', '0', '1', '1463985936', '1463985936', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('90', 'status', '状态', 'tinyint(2) NULL ', 'string', '1', '', '1', '', '7', '0', '1', '1463985936', '1463985936', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('91', 'call_api', '调用接口', 'tinyint(2) NULL ', 'string', '0', '', '1', '', '7', '0', '1', '1463985936', '1463985936', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('92', 'tong_server', '是否通服', 'tinyint(2) NULL ', 'string', '0', '', '1', '', '7', '0', '1', '1463985936', '1463985936', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('93', 'novice', '激活码', 'varchar(3000) NULL ', 'string', '', '', '1', '', '7', '0', '1', '1463985936', '1463985936', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('94', 'digest', '摘要', 'varchar(300) NULL ', 'string', '', '', '1', '', '7', '0', '1', '1463985936', '1463985936', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('95', 'desribe', '描述', 'varchar(300) NULL ', 'string', '', '', '1', '', '7', '0', '1', '1463985936', '1463985936', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('96', 'start_time', '开始时间', 'int(11) NULL ', 'string', '', '', '1', '', '7', '0', '1', '1463985936', '1463985936', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('97', 'end_time', '结束时间', 'int(11) NULL ', 'string', '', '', '1', '', '7', '0', '1', '1463985936', '1463985936', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('98', 'create_time', '创建时间', 'int(11) NULL ', 'string', '', '', '1', '', '7', '0', '1', '1463985936', '1463985936', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('99', 'game_id', '游戏id', 'int(11) NULL ', 'string', '', '', '1', '', '8', '0', '1', '1463987676', '1463987676', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('100', 'game_name', '游戏名称', 'varchar(30) NULL ', 'string', '', '', '1', '', '8', '0', '1', '1463987676', '1463987676', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('101', 'server_id', '区服id', 'int(11) NULL ', 'string', '', '', '1', '', '8', '0', '1', '1463987676', '1463987676', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('102', 'server_name', '区服名称', 'varchar(30) NULL ', 'string', '', '', '1', '', '8', '0', '1', '1463987676', '1463987676', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('103', 'gift_id', '礼包id', 'int(11) NULL ', 'string', '', '', '1', '', '8', '0', '1', '1463987676', '1463987676', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('104', 'gift_name', '礼包名称', 'varchar(30) NULL ', 'string', '', '', '1', '', '8', '0', '1', '1463987676', '1463987676', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('105', 'status', '状态(0:未使用,1:已使用)', 'tinyint(2) NULL ', 'string', '1', '', '1', '', '8', '0', '1', '1463987676', '1463987676', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('106', 'novice', '激活码', 'varchar(30) NULL ', 'string', '', '', '1', '', '8', '0', '1', '1463987676', '1463987676', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('107', 'user_id', '用户id', 'int(11) NULL ', 'string', '', '', '1', '', '8', '0', '1', '1463987676', '1463987676', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('108', 'user_account', '用户昵称', 'varchar(30) NULL ', 'string', '', '', '1', '', '8', '0', '1', '1463987676', '1463987676', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('109', 'user_nickname', '用户昵称', 'varchar(30) NULL ', 'string', '', '', '1', '', '8', '0', '1', '1463987676', '1463987676', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('110', 'create_time', '创建时间', 'int(11) NULL ', 'string', '', '', '1', '', '8', '0', '1', '1463987676', '1463987676', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('111', 'account', '账号', 'varchar(30) NULL ', 'string', '', '', '1', '', '9', '0', '1', '1463989240', '1463989240', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('112', 'password', '密码', 'varchar(32) NULL ', 'string', '', '', '1', '', '9', '0', '1', '1463989240', '1463989240', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('113', 'second_pwd', '二级密码', 'varchar(32) NULL ', 'string', '', '', '1', '', '9', '0', '1', '1463989240', '1463989240', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('114', 'nickname', '昵称', 'varchar(30) NULL ', 'string', '', '', '1', '', '9', '0', '1', '1463989240', '1463989240', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('115', 'mobile_phone', '手机号', 'varchar(11) NULL ', 'string', '', '', '1', '', '9', '0', '1', '1463989240', '1463989240', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('116', 'email', '邮箱', 'varchar(50) NULL ', 'string', '', '', '1', '', '9', '0', '1', '1463989240', '1463989240', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('117', 'real_name', '真实姓名', 'varchar(10) NULL ', 'string', '', '', '1', '', '9', '0', '1', '1463989240', '1463989240', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('118', 'bank_name', '银行', 'varchar(50) NULL ', 'string', '', '', '1', '', '9', '0', '1', '1463989240', '1463989240', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('119', 'bank_card', '银行卡', 'varchar(20) NULL ', 'string', '', '', '1', '', '9', '0', '1', '1463989240', '1463989240', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('120', 'money', '金额', 'double(10,2) NULL ', 'string', '0.00', '', '1', '', '9', '0', '1', '1463989240', '1463989240', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('121', 'total_money', '总金额', 'double(10,2) NULL ', 'string', '0.00', '', '1', '', '9', '0', '1', '1463989240', '1463989240', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('122', 'balance_coin', '平台币', 'double(10,2) NULL ', 'string', '0.00', '', '1', '', '9', '0', '1', '1463989240', '1463989240', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('123', 'promote_type', '推广员类型', 'int(2) NULL ', 'string', '1', '', '1', '', '9', '0', '1', '1463989240', '1463989240', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('124', 'status', '状态', 'int(11) NULL ', 'string', '1', '', '1', '', '9', '0', '1', '1463989240', '1463989240', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('125', 'parent_id', '父类ID', 'int(11) NULL ', 'string', '0', '', '1', '', '9', '0', '1', '1463989240', '1463989240', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('126', 'referee_id', '推荐人ID', 'int(11) NULL ', 'string', '0', '', '1', '', '9', '0', '1', '1463989240', '1463989240', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('127', 'create_time', '添加时间', 'int(11) NULL ', 'string', '', '', '1', '', '9', '0', '1', '1463989240', '1463989240', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('128', 'admin_id', '管理员id', 'int(11) NOT NULL ', 'string', '', '', '1', '', '9', '0', '1', '1463989240', '1463989240', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('129', 'user_id', '用户id', 'int(11) NOT NULL ', 'string', '', '', '1', '', '10', '0', '1', '1463997570', '1463997570', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('130', 'user_account', '用户账号', 'varchar(30) NULL ', 'string', '', '', '1', '', '10', '0', '1', '1463997570', '1463997570', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('131', 'user_nickname', '用户昵称', 'varchar(30) NULL ', 'string', '', '', '1', '', '10', '0', '1', '1463997570', '1463997570', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('132', 'promote_id', '推广员id', 'int(11) NULL ', 'string', '', '', '1', '', '10', '0', '1', '1463997570', '1463997570', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('133', 'promote_account', '推广员账号', 'varchar(30) NULL ', 'string', '', '', '1', '', '10', '0', '1', '1463997570', '1463997570', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('134', 'prmoote_id_to', '修改后推广员id', 'int(11) NULL ', 'string', '', '', '1', '', '10', '0', '1', '1463997570', '1463997570', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('135', 'promot_account_to', '修改后推广员账号', 'varchar(30) NULL ', 'string', '', '', '1', '', '10', '0', '1', '1463997570', '1463997570', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('136', 'remark', '备注', 'varchar(100) NULL ', 'string', '', '', '1', '', '10', '0', '1', '1463997570', '1463997570', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('137', 'create_time', '创建时间', 'int(11) NULL ', 'string', '', '', '1', '', '10', '0', '1', '1463997570', '1463997570', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('138', 'op_id', '操作人id', 'int(11) NULL ', 'string', '', '', '1', '', '10', '0', '1', '1463997570', '1463997570', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('139', 'op_account', '操作人账号', 'varchar(30) NULL ', 'string', '', '', '1', '', '10', '0', '1', '1463997570', '1463997570', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('140', 'account', '登陆账号', 'varchar(30) NULL ', 'string', '', '', '1', '', '11', '0', '1', '1463997820', '1463997820', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('141', 'password', '登陆密码', 'varchar(32) NULL ', 'string', '', '', '1', '', '11', '0', '1', '1463997820', '1463997820', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('142', 'nickname', '昵称', 'varchar(30) NULL ', 'string', '', '', '1', '', '11', '0', '1', '1463997820', '1463997820', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('143', 'email', '邮箱', 'varchar(50) NULL ', 'string', '', '', '1', '', '11', '0', '1', '1463997820', '1463997820', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('144', 'phone', '手机号码', 'varchar(15) NULL ', 'string', '', '', '1', '', '11', '0', '1', '1463997820', '1463997820', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('145', 'real_name', '真实姓名', 'varchar(20) NULL ', 'string', '', '', '1', '', '11', '0', '1', '1463997820', '1463997820', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('146', 'idcard', '身份证', 'varchar(20) NULL ', 'string', '', '', '1', '', '11', '0', '1', '1463997820', '1463997820', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('147', 'vip_level', 'vip等级', 'tinyint(2) NULL ', 'string', '0', '', '1', '', '11', '0', '1', '1463997820', '1463997820', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('148', 'cumulative', '累计充值', 'double(10,2) NULL ', 'string', '0.00', '', '1', '', '11', '0', '1', '1463997820', '1463997820', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('149', 'balance', '余额', 'double(10,2) NULL ', 'string', '0.00', '', '1', '', '11', '0', '1', '1463997820', '1463997820', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('150', 'anti_addiction', '防沉迷', 'tinyint(2) NULL ', 'string', '0', '', '1', '', '11', '0', '1', '1463997820', '1463997820', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('151', 'lock_status', '锁定状态', 'tinyint(2) NULL ', 'string', '1', '', '1', '', '11', '0', '1', '1463997820', '1463997820', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('152', 'register_way', '注册方式', 'tinyint(2) NULL ', 'string', '0', '', '1', '', '11', '0', '1', '1463997820', '1463997820', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('153', 'register_time', '注册时间', 'int(11) NULL ', 'string', '', '', '1', '', '11', '0', '1', '1463997820', '1463997820', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('154', 'login_time', '登陆时间', 'int(11) NULL ', 'string', '', '', '1', '', '11', '0', '1', '1463997820', '1463997820', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('155', 'register_ip', '注册ip', 'varchar(16) NOT NULL ', 'string', '', '', '1', '', '11', '0', '1', '1463997820', '1463997820', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('156', 'login_ip', '登陆ip', 'varchar(16) NOT NULL ', 'string', '', '', '1', '', '11', '0', '1', '1463997820', '1463997820', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('157', 'promote_id', '推广id', 'int(11) NOT NULL ', 'string', '0', '', '1', '', '11', '0', '1', '1463997820', '1463997820', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('158', 'promote_account', '推广员账号', 'varchar(30) NULL ', 'string', '', '', '1', '', '11', '0', '1', '1463997820', '1463997820', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('159', 'user_id', '用户ID', 'int(11) NULL ', 'string', '', '', '1', '', '12', '0', '1', '1463997856', '1463997856', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('160', 'user_account', '用户账号', 'varchar(30) NULL ', 'string', '', '', '1', '', '12', '0', '1', '1463997856', '1463997856', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('161', 'user_nickname', '用户昵称', 'varchar(30) NULL ', 'string', '', '', '1', '', '12', '0', '1', '1463997856', '1463997856', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('162', 'game_id', '游戏id', 'int(11) NOT NULL ', 'string', '', '', '1', '', '12', '0', '1', '1463997856', '1463997856', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('163', 'game_name', '游戏名称', 'varchar(30) NULL ', 'string', '', '', '1', '', '12', '0', '1', '1463997856', '1463997856', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('164', 'game_appid', '游戏appid', 'varchar(32) NULL ', 'string', '', '', '1', '', '12', '0', '1', '1463997856', '1463997856', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('165', 'server_id', '区服id', 'int(11) NOT NULL ', 'string', '', '', '1', '', '12', '0', '1', '1463997856', '1463997856', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('166', 'server_name', '区服名称', 'varchar(30) NULL ', 'string', '', '', '1', '', '12', '0', '1', '1463997856', '1463997856', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('167', 'role_id', '角色', 'int(11) NULL ', 'string', '0', '', '1', '', '12', '0', '1', '1463997856', '1463997856', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('168', 'bind_balance', '绑定平台币', 'double NULL ', 'string', '0', '', '1', '', '12', '0', '1', '1463997856', '1463997856', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('169', 'role_name', '角色名称', 'varchar(20) NULL ', 'string', '', '', '1', '', '12', '0', '1', '1463997856', '1463997856', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('170', 'role_level', '等级', 'int(3) NULL ', 'string', '0', '', '1', '', '12', '0', '1', '1463997856', '1463997856', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('171', 'promote_id', '推广员id', 'int(11) NULL ', 'string', '0', '', '1', '', '12', '0', '1', '1463997856', '1463997856', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('172', 'promote_account', '推广员账号', 'varchar(30) NULL ', 'string', '', '', '1', '', '12', '0', '1', '1463997856', '1463997856', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('173', 'game_id', '游戏id', 'int(11) NULL ', 'string', '', '', '1', '', '13', '0', '1', '1463997904', '1463997904', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('174', 'game_name', ' 游戏名称', 'varchar(30) NULL ', 'string', '', '', '1', '', '13', '0', '1', '1463997904', '1463997904', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('175', 'server_id', '区服id', 'int(11) NULL ', 'string', '', '', '1', '', '13', '0', '1', '1463997904', '1463997904', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('176', 'server_name', '区服名称', 'varchar(30) NULL ', 'string', '', '', '1', '', '13', '0', '1', '1463997904', '1463997904', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('177', 'user_id', '用户ID', 'int(11) NULL ', 'string', '', '', '1', '', '13', '0', '1', '1463997904', '1463997904', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('178', 'user_account', '用户账号', 'varchar(30) NULL ', 'string', '', '', '1', '', '13', '0', '1', '1463997904', '1463997904', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('179', 'user_nickname', '用户昵称', 'varchar(30) NULL ', 'string', '', '', '1', '', '13', '0', '1', '1463997904', '1463997904', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('180', 'login_time', '登陆时间', 'int(11) NULL ', 'string', '', '', '1', '', '13', '0', '1', '1463997904', '1463997904', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('181', 'login_ip', '登陆ip', 'varchar(20) NULL ', 'string', '', '', '1', '', '13', '0', '1', '1463997904', '1463997904', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('182', 'type', '类型(1:游戏登陆,2:PC登陆)', 'tinyint(2) NULL ', 'string', '1', '', '1', '', '13', '0', '1', '1463997904', '1463997904', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('183', 'user_id', ' 用户ID', 'int(11) NOT NULL ', 'string', '', '', '1', '', '14', '0', '1', '1464012355', '1464012355', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('184', 'user_account', '用户账号', 'varchar(30) NULL ', 'string', '', '', '1', '', '14', '0', '1', '1464012355', '1464012355', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('185', 'user_nickname', '用户昵称', 'varchar(30) NULL ', 'string', '', '', '1', '', '14', '0', '1', '1464012355', '1464012355', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('186', 'game_id', '游戏id', 'int(11) NULL ', 'string', '', '', '1', '', '14', '0', '1', '1464012355', '1464012355', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('187', 'game_appid', '游戏appid', 'varchar(32) NULL ', 'string', '', '', '1', '', '14', '0', '1', '1464012355', '1464012355', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('188', 'game_name', '游戏名称', 'varchar(30) NULL ', 'string', '', '', '1', '', '14', '0', '1', '1464012355', '1464012355', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('189', 'server_id', '区服id', 'int(11) NULL ', 'string', '', '', '1', '', '14', '0', '1', '1464012355', '1464012355', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('190', 'server_name', '区服名称', 'varchar(30) NULL ', 'string', '', '', '1', '', '14', '0', '1', '1464012355', '1464012355', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('191', 'promote_id', '推广员id', 'int(11) NULL ', 'string', '', '', '1', '', '14', '0', '1', '1464012355', '1464012355', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('192', 'promote_account', '推广员账号', 'varchar(30) NULL ', 'string', '', '', '1', '', '14', '0', '1', '1464012355', '1464012355', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('193', 'order_number', '订单号', 'varchar(30) NULL ', 'string', '', '', '1', '', '14', '0', '1', '1464012355', '1464012355', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('194', 'pay_order_number', '支付订单号', 'varchar(30) NULL ', 'string', '', '', '1', '', '14', '0', '1', '1464012355', '1464012355', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('195', 'props_name', '道具名称', 'varchar(30) NULL ', 'string', '', '', '1', '', '14', '0', '1', '1464012355', '1464012355', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('196', 'pay_amount', '支付金额', 'double(10,2) NULL ', 'string', '', '', '1', '', '14', '0', '1', '1464012355', '1464012355', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('197', 'pay_time', '支付时间', 'int(11) NULL ', 'string', '', '', '1', '', '14', '0', '1', '1464012355', '1464012355', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('198', 'pay_status', '支付状态', 'tinyint(2) NULL ', 'string', '', '', '1', '', '14', '0', '1', '1464012355', '1464012355', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('199', 'pay_game_status', '游戏支付状态', 'tinyint(2) NULL ', 'string', '', '', '1', '', '14', '0', '1', '1464012355', '1464012355', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('200', 'pay_way', '支付方式', 'tinyint(2) NULL ', 'string', '', '', '1', '', '14', '0', '1', '1464012355', '1464012355', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('201', 'spend_ip', '支付IP', 'varchar(20) NULL ', 'string', '', '', '1', '', '14', '0', '1', '1464012355', '1464012355', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('202', 'title', '广告名称', 'char(80) NOT NULL ', 'string', '', '', '1', '', '15', '0', '1', '1464083427', '1464083427', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('203', 'pos_id', '广告位置', 'int(11) NOT NULL ', 'string', '', '', '1', '', '15', '0', '1', '1464083427', '1464083427', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('204', 'data', '图片地址', 'text NOT NULL ', 'string', '', '', '1', '', '15', '0', '1', '1464083427', '1464083427', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('205', 'click_count', '点击量', 'int(11) NOT NULL ', 'string', '', '', '1', '', '15', '0', '1', '1464083427', '1464083427', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('206', 'url', '链接地址', 'varchar(500) NOT NULL ', 'string', '', '', '1', '', '15', '0', '1', '1464083427', '1464083427', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('207', 'sort', '排序', 'int(3) unsigned NOT NULL ', 'string', '0', '', '1', '', '15', '0', '1', '1464083427', '1464083427', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('208', 'status', '状态（0：禁用，1：正常）', 'tinyint(2) NOT NULL ', 'string', '1', '', '1', '', '15', '0', '1', '1464083427', '1464083427', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('209', 'create_time', '开始时间', 'int(11) unsigned NOT NULL ', 'string', '0', '', '1', '', '15', '0', '1', '1464083427', '1464083427', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('210', 'start_time', '', 'int(11) NULL ', 'string', '', '', '1', '', '15', '0', '1', '1464083427', '1464083427', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('211', 'end_time', '结束时间', 'int(11) unsigned NULL ', 'string', '0', '', '1', '', '15', '0', '1', '1464083427', '1464083427', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('212', 'target', '', 'varchar(20) NULL ', 'string', '_blank', '', '1', '', '15', '0', '1', '1464083427', '1464083427', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('213', 'name', '', 'varchar(50) NOT NULL ', 'string', '', '', '1', '', '16', '0', '1', '1464084894', '1464084894', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('214', 'title', '广告位置名称', 'char(80) NOT NULL ', 'string', '', '', '1', '', '16', '0', '1', '1464084894', '1464084894', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('215', 'module', '所在模块 模块/控制器/方法', 'varchar(100) NOT NULL ', 'string', '', '', '1', '', '16', '0', '1', '1464084894', '1464084894', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('216', 'type', '广告位类型 \r\n1.单图\r\n2.多图\r\n3.文字链接\r\n4.代码', 'int(11) unsigned NOT NULL ', 'string', '1', '', '1', '', '16', '0', '1', '1464084894', '1464084894', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('217', 'status', '状态（0：禁用，1：正常）', 'tinyint(2) NOT NULL ', 'string', '1', '', '1', '', '16', '0', '1', '1464084894', '1464084894', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('218', 'data', '额外的数据', 'varchar(500) NOT NULL ', 'string', '', '', '1', '', '16', '0', '1', '1464084894', '1464084894', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('219', 'width', '广告位置宽度', 'char(20) NOT NULL ', 'string', '', '', '1', '', '16', '0', '1', '1464084894', '1464084894', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('220', 'height', '广告位置高度', 'char(20) NOT NULL ', 'string', '', '', '1', '', '16', '0', '1', '1464084894', '1464084894', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('221', 'margin', '边缘', 'varchar(50) NOT NULL ', 'string', '', '', '1', '', '16', '0', '1', '1464084894', '1464084894', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('222', 'padding', '留白', 'varchar(50) NOT NULL ', 'string', '', '', '1', '', '16', '0', '1', '1464084894', '1464084894', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('223', 'theme', '适用主题，默认为all，通用', 'varchar(50) NOT NULL ', 'string', 'all', '', '1', '', '16', '0', '1', '1464084894', '1464084894', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('224', 'order_number', '订单号', 'varchar(30) NULL ', 'string', '', '', '1', '', '17', '0', '1', '1464233084', '1464233084', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('225', 'pay_order_number', '支付订单号', 'varchar(30) NULL ', 'string', '', '', '1', '', '17', '0', '1', '1464233084', '1464233084', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('226', 'user_id', '用户id', 'int(11) NULL ', 'string', '', '', '1', '', '17', '0', '1', '1464233084', '1464233084', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('227', 'user_account', '用户账号', 'varchar(30) NULL ', 'string', '', '', '1', '', '17', '0', '1', '1464233084', '1464233084', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('228', 'user_nickname', '用户昵称', 'varchar(30) NULL ', 'string', '', '', '1', '', '17', '0', '1', '1464233084', '1464233084', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('229', 'promote_id', '推广员ID', 'int(11) NULL ', 'string', '', '', '1', '', '17', '0', '1', '1464233084', '1464233084', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('230', 'promote_account', '推广账号', 'varchar(30) NULL ', 'string', '', '', '1', '', '17', '0', '1', '1464233084', '1464233084', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('231', 'pay_amount', '充值金额', 'double(10,2) NULL ', 'string', '0.00', '', '1', '', '17', '0', '1', '1464233084', '1464233084', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('232', 'pay_status', '充值状态', 'tinyint(2) NULL ', 'string', '0', '', '1', '', '17', '0', '1', '1464233084', '1464233084', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('233', 'pay_way', '支付方式', 'tinyint(2) NULL ', 'string', '0', '', '1', '', '17', '0', '1', '1464233084', '1464233084', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('234', 'pay_source', '支付来源', 'tinyint(2) NULL ', 'string', '0', '', '1', '', '17', '0', '1', '1464233084', '1464233084', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('235', 'pay_ip', '充值IP', 'varchar(20) NULL ', 'string', '', '', '1', '', '17', '0', '1', '1464233084', '1464233084', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('236', 'create_time', '支付时间', 'int(11) NULL ', 'string', '', '', '1', '', '17', '0', '1', '1464233085', '1464233085', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('237', 'order_number', '订单号', 'varchar(30) NULL ', 'string', '', '', '1', '', '18', '0', '1', '1464233863', '1464233863', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('238', 'pay_order_number', '商户订单号', 'varchar(30) NULL ', 'string', '', '', '1', '', '18', '0', '1', '1464233863', '1464233863', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('239', 'user_id', '用户ID', 'int(11) NULL ', 'string', '', '', '1', '', '18', '0', '1', '1464233863', '1464233863', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('240', 'user_account', '用户账号', 'varchar(30) NULL ', 'string', '', '', '1', '', '18', '0', '1', '1464233864', '1464233864', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('241', 'user_nickname', '用户昵称', 'varchar(30) NULL ', 'string', '', '', '1', '', '18', '0', '1', '1464233864', '1464233864', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('242', 'game_id', '游戏id', 'int(11) NULL ', 'string', '', '', '1', '', '18', '0', '1', '1464233864', '1464233864', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('243', 'game_name', '游戏名称', 'varchar(30) NULL ', 'string', '', '', '1', '', '18', '0', '1', '1464233864', '1464233864', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('244', 'server_id', '区服id', 'int(11) NULL ', 'string', '', '', '1', '', '18', '0', '1', '1464233864', '1464233864', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('245', 'server_name', '区服名称', 'varchar(30) NULL ', 'string', '', '', '1', '', '18', '0', '1', '1464233864', '1464233864', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('246', 'amount', '充值金额', 'double(10,2) NULL ', 'string', '', '', '1', '', '18', '0', '1', '1464233864', '1464233864', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('247', 'remark', '备注', 'varchar(100) NULL ', 'string', '', '', '1', '', '18', '0', '1', '1464233864', '1464233864', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('248', 'status', '状态', 'tinyint(2) NULL ', 'string', '0', '', '1', '', '18', '0', '1', '1464233864', '1464233864', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('249', 'op_id', '操作人id', 'int(11) NULL ', 'string', '', '', '1', '', '18', '0', '1', '1464233864', '1464233864', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('250', 'op_account', '操作人账号', 'varchar(30) NULL ', 'string', '', '', '1', '', '18', '0', '1', '1464233864', '1464233864', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('251', 'create_time', '时间', 'int(11) NULL ', 'string', '', '', '1', '', '18', '0', '1', '1464233864', '1464233864', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('252', 'user_id', '用户id', 'int(11) NOT NULL ', 'string', '', '', '1', '', '19', '0', '1', '1464234376', '1464234376', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('253', 'user_account', '用户账号', 'varchar(30) NOT NULL ', 'string', '', '', '1', '', '19', '0', '1', '1464234376', '1464234376', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('254', 'user_nickname', '用户昵称', 'varchar(30) NOT NULL ', 'string', '', '', '1', '', '19', '0', '1', '1464234376', '1464234376', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('255', 'game_id', '游戏id', 'int(11) NOT NULL ', 'string', '', '', '1', '', '19', '0', '1', '1464234376', '1464234376', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('256', 'game_appid', '游戏appid', 'varchar(30) NOT NULL ', 'string', '', '', '1', '', '19', '0', '1', '1464234376', '1464234376', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('257', 'game_name', '游戏名称', 'varchar(30) NOT NULL ', 'string', '', '', '1', '', '19', '0', '1', '1464234376', '1464234376', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('258', 'order_number', '订单号', 'varchar(30) NOT NULL ', 'string', '', '', '1', '', '19', '0', '1', '1464234376', '1464234376', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('259', 'pay_order_number', '商户订单号', 'varchar(30) NOT NULL ', 'string', '', '', '1', '', '19', '0', '1', '1464234376', '1464234376', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('260', 'props_name', '道具名称', 'varchar(30) NOT NULL ', 'string', '', '', '1', '', '19', '0', '1', '1464234376', '1464234376', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('261', 'pay_amount', '金额', 'double(10,2) NOT NULL ', 'string', '0.00', '', '1', '', '19', '0', '1', '1464234376', '1464234376', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('262', 'pay_time', '支付时间', 'int(11) NOT NULL ', 'string', '', '', '1', '', '19', '0', '1', '1464234376', '1464234376', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('263', 'pay_status', '支付状态', 'tinyint(2) NOT NULL ', 'string', '0', '', '1', '', '19', '0', '1', '1464234376', '1464234376', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('264', 'pay_game_status', '游戏支付状态', 'tinyint(2) NOT NULL ', 'string', '0', '', '1', '', '19', '0', '1', '1464234376', '1464234376', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('265', 'pay_way', '支付方式', 'tinyint(2) NOT NULL ', 'string', '0', '', '1', '', '19', '0', '1', '1464234376', '1464234376', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('266', 'pay_source', '支付来源', 'tinyint(2) NOT NULL ', 'string', '0', '', '1', '', '19', '0', '1', '1464234376', '1464234376', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('267', 'spend_ip', '支付ip', 'varchar(16) NOT NULL ', 'string', '', '', '1', '', '19', '0', '1', '1464234376', '1464234376', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('268', 'game_id', '游戏id', 'int(11) NULL ', 'string', '', '', '1', '', '20', '0', '1', '1464235301', '1464235301', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('269', 'game_name', '游戏名称', 'varchar(30) NULL ', 'string', '', '', '1', '', '20', '0', '1', '1464235301', '1464235301', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('270', 'file_id', '文件id', 'int(11) NULL ', 'string', '', '', '1', '', '20', '0', '1', '1464235301', '1464235301', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('271', 'file_name', '文件名称', 'varchar(30) NULL ', 'string', '', '', '1', '', '20', '0', '1', '1464235301', '1464235301', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('272', 'file_url', '文件路径', 'varchar(255) NULL ', 'string', '', '', '1', '', '20', '0', '1', '1464235301', '1464235301', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('273', 'file_size', '文件大小', 'int(11) NOT NULL ', 'string', '', '', '1', '', '20', '0', '1', '1464235301', '1464235301', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('274', 'file_type', '原包类型', 'tinyint(2) NULL ', 'string', '', '', '1', '', '20', '0', '1', '1464235301', '1464235301', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('275', 'op_id', '操作人id', 'int(11) NULL ', 'string', '', '', '1', '', '20', '0', '1', '1464235301', '1464235301', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('276', 'op_account', '操作人名称', 'varchar(30) NULL ', 'string', '', '', '1', '', '20', '0', '1', '1464235301', '1464235301', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('277', 'remark', '备注', 'varchar(100) NULL ', 'string', '', '', '1', '', '20', '0', '1', '1464235301', '1464235301', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('278', 'create_time', '时间', 'int(11) NULL ', 'string', '', '', '1', '', '20', '0', '1', '1464235301', '1464235301', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('279', 'game_id', '游戏ID', 'int(11) NULL ', 'string', '', '', '1', '', '21', '0', '1', '1464356213', '1464356213', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('280', 'game_name', '游戏名称', 'varchar(30) NULL ', 'string', '', '', '1', '', '21', '0', '1', '1464356213', '1464356213', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('281', 'promote_id', '推广员ID', 'int(11) NULL ', 'string', '', '', '1', '', '21', '0', '1', '1464356213', '1464356213', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('282', 'promote_account', '推广账号', 'varchar(30) NULL ', 'string', '', '', '1', '', '21', '0', '1', '1464356213', '1464356213', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('283', 'ratio', '分成比例', 'int(3) NULL ', 'string', '0', '', '1', '', '21', '0', '1', '1464356213', '1464356213', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('284', 'apply_time', '申请时间', 'int(11) NULL ', 'string', '', '', '1', '', '21', '0', '1', '1464356213', '1464356213', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('285', 'status', '审核状态', 'tinyint(2) NULL ', 'string', '', '', '1', '', '21', '0', '1', '1464356213', '1464356213', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('286', 'enable_status', '操作状态', 'tinyint(2) NULL ', 'string', '', '', '1', '', '21', '0', '1', '1464356213', '1464356213', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('287', 'pack_url', '游戏包地址', 'varchar(255) NULL ', 'string', '', '', '1', '', '21', '0', '1', '1464356213', '1464356213', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('288', 'dow_url', '下载地址', 'varchar(255) NULL ', 'string', '', '', '1', '', '21', '0', '1', '1464356213', '1464356213', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('289', 'dispose_id', '操作人', 'int(11) NULL ', 'string', '', '', '1', '', '21', '0', '1', '1464356213', '1464356213', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('290', 'dispose_time', '操作时间', 'int(11) NULL ', 'string', '', '', '1', '', '21', '0', '1', '1464356213', '1464356213', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('291', 'order_number', '订单号', 'varchar(30) NULL ', 'string', '', '', '1', '', '22', '0', '1', '1464772695', '1464772695', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('292', 'pay_order_number', '支付订单号 ', 'varchar(30) NOT NULL ', 'string', '', '', '1', '', '22', '0', '1', '1464772695', '1464772695', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('293', 'game_id', '游戏ID', 'int(11) NULL ', 'string', '', '', '1', '', '22', '0', '1', '1464772695', '1464772695', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('294', 'game_appid', '游戏APPID', 'varchar(32) NULL ', 'string', '', '', '1', '', '22', '0', '1', '1464772695', '1464772695', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('295', 'game_name', '游戏名称', 'varchar(30) NULL ', 'string', '', '', '1', '', '22', '0', '1', '1464772695', '1464772695', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('296', 'promote_id', '推广员ID', 'int(11) NULL ', 'string', '0', '', '1', '', '22', '0', '1', '1464772695', '1464772695', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('297', 'promote_account', '推广员账号', 'varchar(30) NULL ', 'string', '', '', '1', '', '22', '0', '1', '1464772695', '1464772695', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('298', 'user_id', '用户ID', 'int(11) NULL ', 'string', '', '', '1', '', '22', '0', '1', '1464772695', '1464772695', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('299', 'user_account', '玩家账号', 'varchar(30) NULL ', 'string', '', '', '1', '', '22', '0', '1', '1464772695', '1464772695', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('300', 'user_nickname', '用户昵称', 'varchar(30) NULL ', 'string', '', '', '1', '', '22', '0', '1', '1464772695', '1464772695', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('301', 'amount', '支付金额', 'double(10,2) NULL ', 'string', '0.00', '', '1', '', '22', '0', '1', '1464772695', '1464772695', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('302', 'real_amount', '实际金额', 'double(10,2) NULL ', 'string', '0.00', '', '1', '', '22', '0', '1', '1464772695', '1464772695', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('303', 'status', '支付状态', 'tinyint(2) NULL ', 'string', '0', '', '1', '', '22', '0', '1', '1464772695', '1464772695', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('304', 'pay_type', '类型', 'tinyint(2) NULL ', 'string', '', '', '1', '', '22', '0', '1', '1464772695', '1464772695', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('305', 'create_time', '时间', 'int(11) NULL ', 'string', '', '', '1', '', '22', '0', '1', '1464772695', '1464772695', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('306', 'zhekou', '折扣比例', 'int(11) NOT NULL ', 'string', '0', '', '1', '', '22', '0', '1', '1464772695', '1464772695', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('307', 'promote_id', '推广员ID', 'int(11) NULL ', 'string', '', '', '1', '', '24', '0', '1', '1464945957', '1464945957', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('308', 'game_id', '游戏ID', 'varchar(32) NULL ', 'string', '', '', '1', '', '24', '0', '1', '1464945957', '1464945957', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('309', 'spend_time', '消费时间', 'int(11) NULL ', 'string', '', '', '1', '', '24', '0', '1', '1464945957', '1464945957', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('310', 'reg_num', '注册人数', 'int(10) NULL ', 'string', '0', '', '1', '', '24', '0', '1', '1464945957', '1464945957', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('311', 'spend_num', '消费人数', 'int(10) NULL ', 'string', '0', '', '1', '', '24', '0', '1', '1464945957', '1464945957', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('312', 'money', '金额', 'double(10,2) NULL ', 'string', '0.00', '', '1', '', '24', '0', '1', '1464945957', '1464945957', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('313', 'real_money', '实际金额', 'double(10,2) NULL ', 'string', '0.00', '', '1', '', '24', '0', '1', '1464945957', '1464945957', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('314', 'status', '结算状态', 'tinyint(2) NULL ', 'string', '1', '', '1', '', '24', '0', '1', '1464945957', '1464945957', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('315', 'type', '类型', 'tinyint(2) NULL ', 'string', '0', '', '1', '', '24', '0', '1', '1464945957', '1464945957', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('341', 'link_url', '友链地址', 'varchar(255) NULL ', 'string', '', '', '1', '', '31', '0', '1', '1465202698', '1465202698', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('339', 'create_time', '添加时间', 'int(11) NULL ', 'string', '', '', '1', '', '30', '0', '1', '1465194413', '1465194413', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('337', 'op_id', '操作人id', 'int(11) NULL ', 'string', '', '', '1', '', '30', '0', '1', '1465194413', '1465194413', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('338', 'op_nickname', '操作人昵称', 'varchar(30) NULL ', 'string', '', '', '1', '', '30', '0', '1', '1465194413', '1465194413', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('335', 'status', '状态(-1:删除,1:正常)', 'tinyint(2) NULL ', 'string', '1', '', '1', '', '30', '0', '1', '1465194413', '1465194413', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('340', 'title', '标题', 'varchar(50) NULL ', 'string', '', '', '1', '', '31', '0', '1', '1465202698', '1465202698', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('334', 'type_name', '礼包类型名称', 'varchar(20) NULL ', 'string', '', '', '1', '', '30', '0', '1', '1465194413', '1465194413', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('342', 'link_icon', '图标', 'int(11) NULL ', 'string', '', '', '1', '', '31', '0', '1', '1465202698', '1465202698', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('343', 'status', '状态', 'tinyint(2) NULL ', 'string', '', '', '1', '', '31', '0', '1', '1465202698', '1465202698', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('344', 'type', '类型', 'tinyint(2) NULL ', 'string', '', '', '1', '', '31', '0', '1', '1465202698', '1465202698', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('345', 'remark', '备注', 'varchar(255) NULL ', 'string', '', '', '1', '', '31', '0', '1', '1465202698', '1465202698', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('346', 'create_time', '创建时间', 'int(11) NULL ', 'string', '', '', '1', '', '31', '0', '1', '1465202698', '1465202698', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('347', 'mark', '所属后台', 'varchar(50) NOT NULL', 'string', '0', '0媒体1渠道', '1', '', '31', '0', '1', '1465727293', '1465727293', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `sys_attribute` VALUES ('348', 'game_id', '游戏id', 'int(11) NULL ', 'string', '', '', '1', '', '32', '0', '1', '1465732888', '1465732888', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('349', 'user_id', '用户id', 'int(11) NULL ', 'string', '', '', '1', '', '32', '0', '1', '1465732888', '1465732888', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('350', 'title', '标题', 'varchar(50) NULL ', 'string', '', '', '1', '', '32', '0', '1', '1465732888', '1465732888', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('351', 'content', '内容', 'varchar(300) NULL ', 'string', '', '', '1', '', '32', '0', '1', '1465732888', '1465732888', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('352', 'status', '修复状态(0:未,1:已)', 'tinyint(2) NULL ', 'string', '0', '', '1', '', '32', '0', '1', '1465732888', '1465732888', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('353', 'type', '类型(0:纠错,1:留言)', 'tinyint(2) NULL ', 'string', '0', '', '1', '', '32', '0', '1', '1465732888', '1465732888', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('354', 'op_id', '操作人id', 'int(11) NULL ', 'string', '', '', '1', '', '32', '0', '1', '1465732888', '1465732888', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('355', 'op_account', '操作人账号', 'varchar(20) NULL ', 'string', '', '', '1', '', '32', '0', '1', '1465732888', '1465732888', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('356', 'create_time', '修改时间', 'int(11) NULL ', 'string', '', '', '1', '', '32', '0', '1', '1465732888', '1465732888', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('357', 'create_time', '添加时间', 'int(11) NOT NULL ', 'string', '', '', '1', '', '33', '0', '1', '1465898749', '1465898749', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('358', 'status', '状态', 'int(11) NOT NULL ', 'string', '', '', '1', '', '33', '0', '1', '1465898749', '1465898749', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('359', 'open_name', '开放类型名称', 'varchar(30) NOT NULL ', 'string', '', '', '1', '', '33', '0', '1', '1465898749', '1465898749', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('360', 'icon', '图标', 'int(12) NOT NULL', 'string', '', '', '1', '', '5', '0', '1', '1466150513', '1466150513', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `sys_attribute` VALUES ('361', 'cover', '封面', 'int(12)  NOT NULL', 'string', '', '', '1', '', '5', '0', '1', '1466150535', '1466150535', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `sys_attribute` VALUES ('362', 'game_id', '游戏id', 'int(11) NULL ', 'string', '', '', '1', '', '35', '0', '1', '1466386454', '1466386454', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('363', 'game_name', '游戏名称', 'varchar(50) NULL ', 'string', '', '', '1', '', '35', '0', '1', '1466386454', '1466386454', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('364', 'money', '金额', 'int(11) NULL ', 'string', '0', '', '1', '', '35', '0', '1', '1466386454', '1466386454', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('365', 'ratio', '返利比例', 'double(5,2) NULL ', 'string', '0.00', '', '1', '', '35', '0', '1', '1466386454', '1466386454', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('366', 'status', '状态(0关闭金额限制 1 开启金额限制)', 'int(11) NULL ', 'string', '', '', '1', '', '35', '0', '1', '1466386454', '1466386454', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('367', 'create_time', '更新时间', 'int(11) NULL ', 'string', '', '', '1', '', '35', '0', '1', '1466386454', '1466386454', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('368', 'pay_order_number', '订单号', 'varchar(30) NULL ', 'string', '', '', '1', '', '36', '0', '1', '1466386503', '1466386503', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('369', 'game_id', '游戏id', 'int(11) NULL ', 'string', '', '', '1', '', '36', '0', '1', '1466386503', '1466386503', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('370', 'game_name', '游戏名称', 'varchar(30) NULL ', 'string', '', '', '1', '', '36', '0', '1', '1466386503', '1466386503', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('371', 'user_id', '用户id', 'int(11) NULL ', 'string', '', '', '1', '', '36', '0', '1', '1466386503', '1466386503', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('372', 'user_name', '用户名', 'varchar(30) NULL ', 'string', '', '', '1', '', '36', '0', '1', '1466386503', '1466386503', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('373', 'pay_amount', '充值金额', 'double(10,2) NULL ', 'string', '0.00', '', '1', '', '36', '0', '1', '1466386503', '1466386503', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('374', 'ratio', '返利比例', 'double(5,2) NULL ', 'string', '0.00', '', '1', '', '36', '0', '1', '1466386503', '1466386503', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('375', 'ratio_amount', '返利平台币', 'double(10,2) NULL ', 'string', '', '', '1', '', '36', '0', '1', '1466386503', '1466386503', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('376', 'promote_id', '推广id', 'int(11) NULL ', 'string', '0', '', '1', '', '36', '0', '1', '1466386503', '1466386503', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('377', 'promote_name', '推广员姓名', 'varchar(30) NULL ', 'string', '', '', '1', '', '36', '0', '1', '1466386503', '1466386503', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('378', 'create_time', '创建时间', 'int(11) NULL ', 'string', '', '', '1', '', '36', '0', '1', '1466386503', '1466386503', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('379', 'push_name', '应用名', 'varchar(30) NULL ', 'string', '', '', '1', '', '37', '0', '1', '1466757612', '1466757612', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('380', 'app_key', '', 'varchar(30) NULL ', 'string', '', '', '1', '', '37', '0', '1', '1466757612', '1466757612', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('381', 'master_secret', '', 'varchar(30) NULL ', 'string', '', '', '1', '', '37', '0', '1', '1466757612', '1466757612', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('382', 'status', '状态(0关闭 1开启)', 'tinyint(2) NULL ', 'string', '', '', '1', '', '37', '0', '1', '1466757612', '1466757612', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('383', 'create_time', '创建时间', 'int(11) NULL ', 'string', '', '', '1', '', '37', '0', '1', '1466757612', '1466757612', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('392', 'push_time', '推送时间', 'int(11) NULL ', 'string', '', '', '1', '', '39', '0', '1', '1466759193', '1466759193', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('391', 'push_time_type', '推送时间(0 立即  1定时)', 'tinyint(2) NULL ', 'string', '', '', '1', '', '39', '0', '1', '1466759193', '1466759193', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('390', 'push_object', '推送类型(0 不限 1 ios 2 安卓 3 winphone)', 'int(11) NULL ', 'string', '', '', '1', '', '39', '0', '1', '1466759193', '1466759193', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('389', 'content', '推送内容', 'text NULL ', 'string', '', '', '1', '', '39', '0', '1', '1466759193', '1466759193', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('393', 'status', '推送状态', 'int(11) NULL ', 'string', '', '', '1', '', '39', '0', '1', '1466759193', '1466759193', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('394', 'create_time', '创建时间', 'int(11) NULL ', 'string', '', '', '1', '', '39', '0', '1', '1466759193', '1466759193', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('395', 'money', '注册单价', 'int(11) UNSIGNED NOT NULL', 'num', '0', '注册单价', '1', '', '4', '0', '1', '1469069883', '1469069883', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `sys_attribute` VALUES ('396', 'settlement_number', '结算单号', 'varchar(50) NULL ', 'string', '', '', '1', '', '40', '0', '1', '1469167977', '1469167977', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('397', 'sum_money', '结算金额', 'double NULL ', 'string', '', '', '1', '', '40', '0', '1', '1469167977', '1469167977', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('398', 'promote_id', '推广员id', 'int(11) NULL ', 'string', '', '', '1', '', '40', '0', '1', '1469167977', '1469167977', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('399', 'promote_account', '推广姓名', 'varchar(30) NULL ', 'string', '', '', '1', '', '40', '0', '1', '1469167977', '1469167977', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('400', 'create_time', '申请时间', 'int(11) NULL ', 'string', '', '', '1', '', '40', '0', '1', '1469167977', '1469167977', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('401', 'end_time', '完成时间', 'int(11) NULL ', 'string', '', '', '1', '', '40', '0', '1', '1469167977', '1469167977', '', '0', '', '', '', '0', '');
INSERT INTO `sys_attribute` VALUES ('402', 'status', '提现状态(-1未申请 0 申请中 1 已通过 2 已驳回)', 'int(11) NULL ', 'string', '0', '', '1', '', '40', '0', '1', '1469167977', '1469167977', '', '0', '', '', '', '0', '');

-- -----------------------------
-- Table structure for `sys_auth_extend`
-- -----------------------------
DROP TABLE IF EXISTS `sys_auth_extend`;
CREATE TABLE `sys_auth_extend` (
  `group_id` mediumint(10) unsigned NOT NULL COMMENT '用户id',
  `extend_id` mediumint(8) unsigned NOT NULL COMMENT '扩展表中数据的id',
  `type` tinyint(1) unsigned NOT NULL COMMENT '扩展类型标识 1:栏目分类权限;2:模型权限',
  UNIQUE KEY `group_extend_type` (`group_id`,`extend_id`,`type`),
  KEY `uid` (`group_id`),
  KEY `group_id` (`extend_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='用户组与分类的对应关系表';

-- -----------------------------
-- Records of `sys_auth_extend`
-- -----------------------------
INSERT INTO `sys_auth_extend` VALUES ('1', '1', '1');
INSERT INTO `sys_auth_extend` VALUES ('1', '1', '2');
INSERT INTO `sys_auth_extend` VALUES ('1', '2', '1');
INSERT INTO `sys_auth_extend` VALUES ('1', '2', '2');
INSERT INTO `sys_auth_extend` VALUES ('1', '3', '1');
INSERT INTO `sys_auth_extend` VALUES ('1', '3', '2');
INSERT INTO `sys_auth_extend` VALUES ('1', '4', '1');
INSERT INTO `sys_auth_extend` VALUES ('1', '37', '1');

-- -----------------------------
-- Table structure for `sys_auth_group`
-- -----------------------------
DROP TABLE IF EXISTS `sys_auth_group`;
CREATE TABLE `sys_auth_group` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT COMMENT '用户组id,自增主键',
  `module` varchar(20) NOT NULL DEFAULT '' COMMENT '用户组所属模块',
  `type` tinyint(4) NOT NULL DEFAULT '0' COMMENT '组类型',
  `title` char(20) NOT NULL DEFAULT '' COMMENT '用户组中文名称',
  `description` varchar(80) NOT NULL DEFAULT '' COMMENT '描述信息',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '用户组状态：为1正常，为0禁用,-1为删除',
  `rules` varchar(900) NOT NULL DEFAULT '' COMMENT '用户组拥有的规则id，多个规则 , 隔开',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `sys_auth_group`
-- -----------------------------
INSERT INTO `sys_auth_group` VALUES ('1', 'admin', '1', '默认用户组', '', '1', '1,3,4,5,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43,44,45,46,47,48,49,50,51,52,53,54,55,56,57,58,59,60,61,62,63,64,65,66,67,68,69,70,71,72,73,74,79,80,81,82,83,84,86,87,88,89,90,91,92,93,94,95,100,102,103,107,108,109,110,195,205,206,207,208,209,210,211,212,213,214,215,216,217,218,219,220,221,222,223,224,225,226,227,228,229,230,231,232,233,234,235,236,237,238,239,240,241,242,243,244,245,246,247,249,250,251,252,253,254,255,256,257,258,259,260,261,262,263,264,265,266,267,268,269,270,271,272,273,274,275,276,277,278,279,280,281,282,283,284,285,286,287,288,289,290,291,292,293,294,295,296,297,298,299,300,301,302');
INSERT INTO `sys_auth_group` VALUES ('2', 'admin', '1', '测试用户', '测试用户', '1', '1,5,56,57,58,59,60,61,62,63,64,65,66,67,68,69,70,71,72,73,74,80,81,82,83,84,86,87,89,90,91,92,93,100,102,103,195,205,206,207,208,212,213,214,215,216,218,219,220,221,222,223,224,225,226,228,229,230,231,232,233,234,235,236,237,238,239,240,241,242,243,245,246,247,249,250,251,252,253,254,255,256,257,258,259,260,261,262,265,266,268,269,271,272,274,276,279,280,282,283,284,285,289,293,295,296,297,298,299,300,302,308,309,310,311,312,313,314,315,316,317,318,319,320,321,322,323,324,325,326,333,334,335,337,338,339,342,343,346,347,348,349,350,351,352');
INSERT INTO `sys_auth_group` VALUES ('3', 'admin', '1', 'CP用户组', 'CP用户组', '1', '1,3,108,109,263,267,270,273,275,277,278,281,331,332,344');

-- -----------------------------
-- Table structure for `sys_auth_group_access`
-- -----------------------------
DROP TABLE IF EXISTS `sys_auth_group_access`;
CREATE TABLE `sys_auth_group_access` (
  `uid` int(10) unsigned NOT NULL COMMENT '用户id',
  `group_id` mediumint(8) unsigned NOT NULL COMMENT '用户组id',
  `houtai` int(11) DEFAULT '0' COMMENT '所属后台',
  UNIQUE KEY `uid_group_id` (`uid`,`group_id`),
  KEY `uid` (`uid`),
  KEY `group_id` (`group_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `sys_auth_group_access`
-- -----------------------------
INSERT INTO `sys_auth_group_access` VALUES ('2', '1', '');
INSERT INTO `sys_auth_group_access` VALUES ('3', '2', '1');
INSERT INTO `sys_auth_group_access` VALUES ('4', '1', '0');
INSERT INTO `sys_auth_group_access` VALUES ('5', '1', '0');
INSERT INTO `sys_auth_group_access` VALUES ('7', '2', '1');
INSERT INTO `sys_auth_group_access` VALUES ('10', '2', '1');
INSERT INTO `sys_auth_group_access` VALUES ('11', '3', '0');
INSERT INTO `sys_auth_group_access` VALUES ('12', '1', '1');

-- -----------------------------
-- Table structure for `sys_auth_rule`
-- -----------------------------
DROP TABLE IF EXISTS `sys_auth_rule`;
CREATE TABLE `sys_auth_rule` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT COMMENT '规则id,自增主键',
  `module` varchar(20) NOT NULL COMMENT '规则所属module',
  `type` tinyint(2) NOT NULL DEFAULT '1' COMMENT '1-url;2-主菜单',
  `name` char(80) NOT NULL DEFAULT '' COMMENT '规则唯一英文标识',
  `title` char(20) NOT NULL DEFAULT '' COMMENT '规则中文描述',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '是否有效(0:无效,1:有效)',
  `condition` varchar(300) NOT NULL DEFAULT '' COMMENT '规则附加条件',
  PRIMARY KEY (`id`),
  KEY `module` (`module`,`status`,`type`)
) ENGINE=MyISAM AUTO_INCREMENT=357 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `sys_auth_rule`
-- -----------------------------
INSERT INTO `sys_auth_rule` VALUES ('1', 'admin', '2', 'Admin/Index/index', '首页', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('2', 'admin', '2', 'Admin/Article/index', '文章', '-1', '');
INSERT INTO `sys_auth_rule` VALUES ('3', 'admin', '2', 'Admin/User/index', '用户', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('4', 'admin', '2', 'Admin/Addons/index', '扩展', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('5', 'admin', '2', 'Admin/Config/group', '系统', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('7', 'admin', '1', 'Admin/article/add', '新增', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('8', 'admin', '1', 'Admin/article/edit', '编辑', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('9', 'admin', '1', 'Admin/article/setStatus', '改变状态', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('10', 'admin', '1', 'Admin/article/update', '保存', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('11', 'admin', '1', 'Admin/article/autoSave', '保存草稿', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('12', 'admin', '1', 'Admin/article/move', '移动', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('13', 'admin', '1', 'Admin/article/copy', '复制', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('14', 'admin', '1', 'Admin/article/paste', '粘贴', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('15', 'admin', '1', 'Admin/article/permit', '还原', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('16', 'admin', '1', 'Admin/article/clear', '清空', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('17', 'admin', '1', 'Admin/Article/examine', '审核列表', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('18', 'admin', '1', 'Admin/article/recycle', '回收站', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('19', 'admin', '1', 'Admin/User/addaction', '新增用户行为', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('20', 'admin', '1', 'Admin/User/editaction', '编辑用户行为', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('21', 'admin', '1', 'Admin/User/saveAction', '保存用户行为', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('22', 'admin', '1', 'Admin/User/setStatus', '变更行为状态', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('23', 'admin', '1', 'Admin/User/changeStatus?method=forbidUser', '禁用', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('24', 'admin', '1', 'Admin/User/changeStatus?method=resumeUser', '启用', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('25', 'admin', '1', 'Admin/User/changeStatus?method=deleteUser', '删除', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('26', 'admin', '1', 'Admin/User/index', '管理员', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('27', 'admin', '1', 'Admin/User/action', '行为文档', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('28', 'admin', '1', 'Admin/AuthManager/changeStatus?method=deleteGroup', '删除', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('29', 'admin', '1', 'Admin/AuthManager/changeStatus?method=forbidGroup', '禁用', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('30', 'admin', '1', 'Admin/AuthManager/changeStatus?method=resumeGroup', '恢复', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('31', 'admin', '1', 'Admin/AuthManager/createGroup', '新增', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('32', 'admin', '1', 'Admin/AuthManager/editGroup', '编辑', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('33', 'admin', '1', 'Admin/AuthManager/writeGroup', '保存用户组', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('34', 'admin', '1', 'Admin/AuthManager/group', '授权', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('35', 'admin', '1', 'Admin/AuthManager/access', '访问授权', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('36', 'admin', '1', 'Admin/AuthManager/user', '成员授权', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('37', 'admin', '1', 'Admin/AuthManager/removeFromGroup', '解除授权', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('38', 'admin', '1', 'Admin/AuthManager/addToGroup', '保存成员授权', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('39', 'admin', '1', 'Admin/AuthManager/category', '分类授权', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('40', 'admin', '1', 'Admin/AuthManager/addToCategory', '保存分类授权', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('41', 'admin', '1', 'Admin/AuthManager/index', '角色管理', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('42', 'admin', '1', 'Admin/Addons/create', '创建', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('43', 'admin', '1', 'Admin/Addons/checkForm', '检测创建', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('44', 'admin', '1', 'Admin/Addons/preview', '预览', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('45', 'admin', '1', 'Admin/Addons/build', '快速生成插件', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('46', 'admin', '1', 'Admin/Addons/config', '设置', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('47', 'admin', '1', 'Admin/Addons/disable', '禁用', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('48', 'admin', '1', 'Admin/Addons/enable', '启用', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('49', 'admin', '1', 'Admin/Addons/install', '安装', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('50', 'admin', '1', 'Admin/Addons/uninstall', '卸载', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('51', 'admin', '1', 'Admin/Addons/saveconfig', '更新配置', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('52', 'admin', '1', 'Admin/Addons/adminList', '插件后台列表', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('53', 'admin', '1', 'Admin/Addons/execute', 'URL方式访问插件', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('54', 'admin', '1', 'Admin/Addons/index', '插件管理', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('55', 'admin', '1', 'Admin/Addons/hooks', '钩子管理', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('56', 'admin', '1', 'Admin/model/add', '新增', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('57', 'admin', '1', 'Admin/model/edit', '编辑', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('58', 'admin', '1', 'Admin/model/setStatus', '改变状态', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('59', 'admin', '1', 'Admin/model/update', '保存数据', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('60', 'admin', '1', 'Admin/Model/index', '模型管理', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('61', 'admin', '1', 'Admin/Config/edit', '编辑', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('62', 'admin', '1', 'Admin/Config/del', '删除', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('63', 'admin', '1', 'Admin/Config/add', '新增', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('64', 'admin', '1', 'Admin/Config/save', '保存', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('65', 'admin', '1', 'Admin/Config/group', '网站设置', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('66', 'admin', '1', 'Admin/Config/index', '配置管理', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('67', 'admin', '1', 'Admin/Channel/add', '新增', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('68', 'admin', '1', 'Admin/Channel/edit', '编辑', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('69', 'admin', '1', 'Admin/Channel/del', '删除', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('70', 'admin', '1', 'Admin/Channel/index', '导航管理', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('71', 'admin', '1', 'Admin/Category/edit', '编辑', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('72', 'admin', '1', 'Admin/Category/add', '新增', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('73', 'admin', '1', 'Admin/Category/remove', '删除', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('74', 'admin', '1', 'Admin/Category/index', '分类管理', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('75', 'admin', '1', 'Admin/file/upload', '上传控件', '-1', '');
INSERT INTO `sys_auth_rule` VALUES ('76', 'admin', '1', 'Admin/file/uploadPicture', '上传图片', '-1', '');
INSERT INTO `sys_auth_rule` VALUES ('77', 'admin', '1', 'Admin/file/download', '下载', '-1', '');
INSERT INTO `sys_auth_rule` VALUES ('94', 'admin', '1', 'Admin/AuthManager/modelauth', '模型授权', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('79', 'admin', '1', 'Admin/article/batchOperate', '导入', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('80', 'admin', '1', 'Admin/Database/index?type=export', '备份数据库', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('81', 'admin', '1', 'Admin/Database/index?type=import', '还原数据库', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('82', 'admin', '1', 'Admin/Database/export', '备份', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('83', 'admin', '1', 'Admin/Database/optimize', '优化表', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('84', 'admin', '1', 'Admin/Database/repair', '修复表', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('86', 'admin', '1', 'Admin/Database/import', '恢复', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('87', 'admin', '1', 'Admin/Database/del', '删除', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('88', 'admin', '1', 'Admin/User/add', '新增用户', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('89', 'admin', '1', 'Admin/Attribute/index', '属性管理', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('90', 'admin', '1', 'Admin/Attribute/add', '新增', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('91', 'admin', '1', 'Admin/Attribute/edit', '编辑', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('92', 'admin', '1', 'Admin/Attribute/setStatus', '改变状态', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('93', 'admin', '1', 'Admin/Attribute/update', '保存数据', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('95', 'admin', '1', 'Admin/AuthManager/addToModel', '保存模型授权', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('96', 'admin', '1', 'Admin/Category/move', '移动', '-1', '');
INSERT INTO `sys_auth_rule` VALUES ('97', 'admin', '1', 'Admin/Category/merge', '合并', '-1', '');
INSERT INTO `sys_auth_rule` VALUES ('98', 'admin', '1', 'Admin/Config/menu', '后台菜单管理', '-1', '');
INSERT INTO `sys_auth_rule` VALUES ('99', 'admin', '1', 'Admin/Article/mydocument', '内容', '-1', '');
INSERT INTO `sys_auth_rule` VALUES ('100', 'admin', '1', 'Admin/Menu/index', '菜单管理', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('101', 'admin', '1', 'Admin/other', '其他', '-1', '');
INSERT INTO `sys_auth_rule` VALUES ('102', 'admin', '1', 'Admin/Menu/add', '新增', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('103', 'admin', '1', 'Admin/Menu/edit', '编辑', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('104', 'admin', '1', 'Admin/Think/lists?model=article', '文章管理', '-1', '');
INSERT INTO `sys_auth_rule` VALUES ('105', 'admin', '1', 'Admin/Think/lists?model=download', '下载管理', '-1', '');
INSERT INTO `sys_auth_rule` VALUES ('106', 'admin', '1', 'Admin/Think/lists?model=config', '配置管理', '-1', '');
INSERT INTO `sys_auth_rule` VALUES ('107', 'admin', '1', 'Admin/Action/actionlog', '行为日志', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('108', 'admin', '1', 'Admin/User/updatePassword', '修改密码', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('109', 'admin', '1', 'Admin/User/updateNickname', '修改昵称', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('110', 'admin', '1', 'Admin/action/edit', '查看行为日志', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('205', 'admin', '1', 'Admin/think/add', '新增数据', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('111', 'admin', '2', 'Admin/article/index', '文档列表', '-1', '');
INSERT INTO `sys_auth_rule` VALUES ('112', 'admin', '2', 'Admin/article/add', '新增', '-1', '');
INSERT INTO `sys_auth_rule` VALUES ('113', 'admin', '2', 'Admin/article/edit', '编辑', '-1', '');
INSERT INTO `sys_auth_rule` VALUES ('114', 'admin', '2', 'Admin/article/setStatus', '改变状态', '-1', '');
INSERT INTO `sys_auth_rule` VALUES ('115', 'admin', '2', 'Admin/article/update', '保存', '-1', '');
INSERT INTO `sys_auth_rule` VALUES ('116', 'admin', '2', 'Admin/article/autoSave', '保存草稿', '-1', '');
INSERT INTO `sys_auth_rule` VALUES ('117', 'admin', '2', 'Admin/article/move', '移动', '-1', '');
INSERT INTO `sys_auth_rule` VALUES ('118', 'admin', '2', 'Admin/article/copy', '复制', '-1', '');
INSERT INTO `sys_auth_rule` VALUES ('119', 'admin', '2', 'Admin/article/paste', '粘贴', '-1', '');
INSERT INTO `sys_auth_rule` VALUES ('120', 'admin', '2', 'Admin/article/batchOperate', '导入', '-1', '');
INSERT INTO `sys_auth_rule` VALUES ('121', 'admin', '2', 'Admin/article/recycle', '回收站', '-1', '');
INSERT INTO `sys_auth_rule` VALUES ('122', 'admin', '2', 'Admin/article/permit', '还原', '-1', '');
INSERT INTO `sys_auth_rule` VALUES ('123', 'admin', '2', 'Admin/article/clear', '清空', '-1', '');
INSERT INTO `sys_auth_rule` VALUES ('124', 'admin', '2', 'Admin/User/add', '新增用户', '-1', '');
INSERT INTO `sys_auth_rule` VALUES ('125', 'admin', '2', 'Admin/User/action', '用户行为', '-1', '');
INSERT INTO `sys_auth_rule` VALUES ('126', 'admin', '2', 'Admin/User/addAction', '新增用户行为', '-1', '');
INSERT INTO `sys_auth_rule` VALUES ('127', 'admin', '2', 'Admin/User/editAction', '编辑用户行为', '-1', '');
INSERT INTO `sys_auth_rule` VALUES ('128', 'admin', '2', 'Admin/User/saveAction', '保存用户行为', '-1', '');
INSERT INTO `sys_auth_rule` VALUES ('129', 'admin', '2', 'Admin/User/setStatus', '变更行为状态', '-1', '');
INSERT INTO `sys_auth_rule` VALUES ('130', 'admin', '2', 'Admin/User/changeStatus?method=forbidUser', '禁用会员', '-1', '');
INSERT INTO `sys_auth_rule` VALUES ('131', 'admin', '2', 'Admin/User/changeStatus?method=resumeUser', '启用会员', '-1', '');
INSERT INTO `sys_auth_rule` VALUES ('132', 'admin', '2', 'Admin/User/changeStatus?method=deleteUser', '删除会员', '-1', '');
INSERT INTO `sys_auth_rule` VALUES ('133', 'admin', '2', 'Admin/AuthManager/index', '权限管理', '-1', '');
INSERT INTO `sys_auth_rule` VALUES ('134', 'admin', '2', 'Admin/AuthManager/changeStatus?method=deleteGroup', '删除', '-1', '');
INSERT INTO `sys_auth_rule` VALUES ('135', 'admin', '2', 'Admin/AuthManager/changeStatus?method=forbidGroup', '禁用', '-1', '');
INSERT INTO `sys_auth_rule` VALUES ('136', 'admin', '2', 'Admin/AuthManager/changeStatus?method=resumeGroup', '恢复', '-1', '');
INSERT INTO `sys_auth_rule` VALUES ('137', 'admin', '2', 'Admin/AuthManager/createGroup', '新增', '-1', '');
INSERT INTO `sys_auth_rule` VALUES ('138', 'admin', '2', 'Admin/AuthManager/editGroup', '编辑', '-1', '');
INSERT INTO `sys_auth_rule` VALUES ('139', 'admin', '2', 'Admin/AuthManager/writeGroup', '保存用户组', '-1', '');
INSERT INTO `sys_auth_rule` VALUES ('140', 'admin', '2', 'Admin/AuthManager/group', '授权', '-1', '');
INSERT INTO `sys_auth_rule` VALUES ('141', 'admin', '2', 'Admin/AuthManager/access', '访问授权', '-1', '');
INSERT INTO `sys_auth_rule` VALUES ('142', 'admin', '2', 'Admin/AuthManager/user', '成员授权', '-1', '');
INSERT INTO `sys_auth_rule` VALUES ('143', 'admin', '2', 'Admin/AuthManager/removeFromGroup', '解除授权', '-1', '');
INSERT INTO `sys_auth_rule` VALUES ('144', 'admin', '2', 'Admin/AuthManager/addToGroup', '保存成员授权', '-1', '');
INSERT INTO `sys_auth_rule` VALUES ('145', 'admin', '2', 'Admin/AuthManager/category', '分类授权', '-1', '');
INSERT INTO `sys_auth_rule` VALUES ('146', 'admin', '2', 'Admin/AuthManager/addToCategory', '保存分类授权', '-1', '');
INSERT INTO `sys_auth_rule` VALUES ('147', 'admin', '2', 'Admin/AuthManager/modelauth', '模型授权', '-1', '');
INSERT INTO `sys_auth_rule` VALUES ('148', 'admin', '2', 'Admin/AuthManager/addToModel', '保存模型授权', '-1', '');
INSERT INTO `sys_auth_rule` VALUES ('149', 'admin', '2', 'Admin/Addons/create', '创建', '-1', '');
INSERT INTO `sys_auth_rule` VALUES ('150', 'admin', '2', 'Admin/Addons/checkForm', '检测创建', '-1', '');
INSERT INTO `sys_auth_rule` VALUES ('151', 'admin', '2', 'Admin/Addons/preview', '预览', '-1', '');
INSERT INTO `sys_auth_rule` VALUES ('152', 'admin', '2', 'Admin/Addons/build', '快速生成插件', '-1', '');
INSERT INTO `sys_auth_rule` VALUES ('153', 'admin', '2', 'Admin/Addons/config', '设置', '-1', '');
INSERT INTO `sys_auth_rule` VALUES ('154', 'admin', '2', 'Admin/Addons/disable', '禁用', '-1', '');
INSERT INTO `sys_auth_rule` VALUES ('155', 'admin', '2', 'Admin/Addons/enable', '启用', '-1', '');
INSERT INTO `sys_auth_rule` VALUES ('156', 'admin', '2', 'Admin/Addons/install', '安装', '-1', '');
INSERT INTO `sys_auth_rule` VALUES ('157', 'admin', '2', 'Admin/Addons/uninstall', '卸载', '-1', '');
INSERT INTO `sys_auth_rule` VALUES ('158', 'admin', '2', 'Admin/Addons/saveconfig', '更新配置', '-1', '');
INSERT INTO `sys_auth_rule` VALUES ('159', 'admin', '2', 'Admin/Addons/adminList', '插件后台列表', '-1', '');
INSERT INTO `sys_auth_rule` VALUES ('160', 'admin', '2', 'Admin/Addons/execute', 'URL方式访问插件', '-1', '');
INSERT INTO `sys_auth_rule` VALUES ('161', 'admin', '2', 'Admin/Addons/hooks', '钩子管理', '-1', '');
INSERT INTO `sys_auth_rule` VALUES ('162', 'admin', '2', 'Admin/Model/index', '模型管理', '-1', '');
INSERT INTO `sys_auth_rule` VALUES ('163', 'admin', '2', 'Admin/model/add', '新增', '-1', '');
INSERT INTO `sys_auth_rule` VALUES ('164', 'admin', '2', 'Admin/model/edit', '编辑', '-1', '');
INSERT INTO `sys_auth_rule` VALUES ('165', 'admin', '2', 'Admin/model/setStatus', '改变状态', '-1', '');
INSERT INTO `sys_auth_rule` VALUES ('166', 'admin', '2', 'Admin/model/update', '保存数据', '-1', '');
INSERT INTO `sys_auth_rule` VALUES ('167', 'admin', '2', 'Admin/Attribute/index', '属性管理', '-1', '');
INSERT INTO `sys_auth_rule` VALUES ('168', 'admin', '2', 'Admin/Attribute/add', '新增', '-1', '');
INSERT INTO `sys_auth_rule` VALUES ('169', 'admin', '2', 'Admin/Attribute/edit', '编辑', '-1', '');
INSERT INTO `sys_auth_rule` VALUES ('170', 'admin', '2', 'Admin/Attribute/setStatus', '改变状态', '-1', '');
INSERT INTO `sys_auth_rule` VALUES ('171', 'admin', '2', 'Admin/Attribute/update', '保存数据', '-1', '');
INSERT INTO `sys_auth_rule` VALUES ('172', 'admin', '2', 'Admin/Config/index', '配置管理', '-1', '');
INSERT INTO `sys_auth_rule` VALUES ('173', 'admin', '2', 'Admin/Config/edit', '编辑', '-1', '');
INSERT INTO `sys_auth_rule` VALUES ('174', 'admin', '2', 'Admin/Config/del', '删除', '-1', '');
INSERT INTO `sys_auth_rule` VALUES ('175', 'admin', '2', 'Admin/Config/add', '新增', '-1', '');
INSERT INTO `sys_auth_rule` VALUES ('176', 'admin', '2', 'Admin/Config/save', '保存', '-1', '');
INSERT INTO `sys_auth_rule` VALUES ('177', 'admin', '2', 'Admin/Menu/index', '菜单管理', '-1', '');
INSERT INTO `sys_auth_rule` VALUES ('178', 'admin', '2', 'Admin/Channel/index', '导航管理', '-1', '');
INSERT INTO `sys_auth_rule` VALUES ('179', 'admin', '2', 'Admin/Channel/add', '新增', '-1', '');
INSERT INTO `sys_auth_rule` VALUES ('180', 'admin', '2', 'Admin/Channel/edit', '编辑', '-1', '');
INSERT INTO `sys_auth_rule` VALUES ('181', 'admin', '2', 'Admin/Channel/del', '删除', '-1', '');
INSERT INTO `sys_auth_rule` VALUES ('182', 'admin', '2', 'Admin/Category/index', '分类管理', '-1', '');
INSERT INTO `sys_auth_rule` VALUES ('183', 'admin', '2', 'Admin/Category/edit', '编辑', '-1', '');
INSERT INTO `sys_auth_rule` VALUES ('184', 'admin', '2', 'Admin/Category/add', '新增', '-1', '');
INSERT INTO `sys_auth_rule` VALUES ('185', 'admin', '2', 'Admin/Category/remove', '删除', '-1', '');
INSERT INTO `sys_auth_rule` VALUES ('186', 'admin', '2', 'Admin/Category/move', '移动', '-1', '');
INSERT INTO `sys_auth_rule` VALUES ('187', 'admin', '2', 'Admin/Category/merge', '合并', '-1', '');
INSERT INTO `sys_auth_rule` VALUES ('188', 'admin', '2', 'Admin/Database/index?type=export', '备份数据库', '-1', '');
INSERT INTO `sys_auth_rule` VALUES ('189', 'admin', '2', 'Admin/Database/export', '备份', '-1', '');
INSERT INTO `sys_auth_rule` VALUES ('190', 'admin', '2', 'Admin/Database/optimize', '优化表', '-1', '');
INSERT INTO `sys_auth_rule` VALUES ('191', 'admin', '2', 'Admin/Database/repair', '修复表', '-1', '');
INSERT INTO `sys_auth_rule` VALUES ('192', 'admin', '2', 'Admin/Database/index?type=import', '还原数据库', '-1', '');
INSERT INTO `sys_auth_rule` VALUES ('193', 'admin', '2', 'Admin/Database/import', '恢复', '-1', '');
INSERT INTO `sys_auth_rule` VALUES ('194', 'admin', '2', 'Admin/Database/del', '删除', '-1', '');
INSERT INTO `sys_auth_rule` VALUES ('195', 'admin', '2', 'Admin/other', '其他', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('196', 'admin', '2', 'Admin/Menu/add', '新增', '-1', '');
INSERT INTO `sys_auth_rule` VALUES ('197', 'admin', '2', 'Admin/Menu/edit', '编辑', '-1', '');
INSERT INTO `sys_auth_rule` VALUES ('198', 'admin', '2', 'Admin/Think/lists?model=article', '应用', '-1', '');
INSERT INTO `sys_auth_rule` VALUES ('199', 'admin', '2', 'Admin/Think/lists?model=download', '下载管理', '-1', '');
INSERT INTO `sys_auth_rule` VALUES ('200', 'admin', '2', 'Admin/Think/lists?model=config', '应用', '-1', '');
INSERT INTO `sys_auth_rule` VALUES ('201', 'admin', '2', 'Admin/Action/actionlog', '行为日志', '-1', '');
INSERT INTO `sys_auth_rule` VALUES ('202', 'admin', '2', 'Admin/User/updatePassword', '修改密码', '-1', '');
INSERT INTO `sys_auth_rule` VALUES ('203', 'admin', '2', 'Admin/User/updateNickname', '修改昵称', '-1', '');
INSERT INTO `sys_auth_rule` VALUES ('204', 'admin', '2', 'Admin/action/edit', '查看行为日志', '-1', '');
INSERT INTO `sys_auth_rule` VALUES ('206', 'admin', '1', 'Admin/think/edit', '编辑数据', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('207', 'admin', '1', 'Admin/Menu/import', '导入', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('208', 'admin', '1', 'Admin/Model/generate', '生成', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('209', 'admin', '1', 'Admin/Addons/addHook', '新增钩子', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('210', 'admin', '1', 'Admin/Addons/edithook', '编辑钩子', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('211', 'admin', '1', 'Admin/Article/sort', '文档排序', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('212', 'admin', '1', 'Admin/Config/sort', '排序', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('213', 'admin', '1', 'Admin/Menu/sort', '排序', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('214', 'admin', '1', 'Admin/Channel/sort', '排序', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('215', 'admin', '1', 'Admin/Category/operate/type/move', '移动', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('216', 'admin', '1', 'Admin/Category/operate/type/merge', '合并', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('217', 'admin', '1', 'Admin/article/index', '文档列表', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('218', 'admin', '1', 'Admin/think/lists', '数据列表', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('219', 'admin', '1', 'Admin/Game/add', '新增', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('220', 'admin', '1', 'Admin/Game/edit', '编辑', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('221', 'admin', '1', 'Admin/GameType/add', '新增', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('222', 'admin', '1', 'Admin/GameType/edit', '编辑', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('223', 'admin', '1', 'Admin/Server/add', '新增', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('224', 'admin', '1', 'Admin/Server/edit', '编辑', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('225', 'admin', '1', 'Admin/Giftbag/add', '新增', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('226', 'admin', '1', 'Admin/Giftbag/edit', '编辑', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('227', 'admin', '1', 'Admin/Promote/add', '新增', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('228', 'admin', '1', 'Admin/Promote/edit', '编辑', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('229', 'admin', '1', 'Admin/Adv/edit_media_adv_pos', '编辑媒体广告位', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('230', 'admin', '1', 'Admin/Adv/edit_app_adv_pos', '编辑app广告位', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('231', 'admin', '1', 'Admin/Adv/media_adv_lists', '媒体广告列表', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('232', 'admin', '1', 'Admin/Adv/edit_media_adv', '编辑媒体广告', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('233', 'admin', '1', 'Admin/Adv/add_media_adv', '新增媒体广告', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('234', 'admin', '1', 'Admin/Adv/app_adv_lists', 'app广告列表', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('235', 'admin', '1', 'Admin/Adv/add_app_adv', '新增app广告', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('236', 'admin', '1', 'Admin/Adv/edit_app_adv', '编辑app广告', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('237', 'admin', '1', 'Admin/Adv/edit_adv', '编辑', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('238', 'admin', '1', 'Admin/GameSource/add', '新增', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('239', 'admin', '1', 'Admin/GameSource/edit', '编辑', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('240', 'admin', '1', 'Admin/Mend/edit', '渠道补链', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('241', 'admin', '1', 'Admin/Game/lists', '游戏管理', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('242', 'admin', '1', 'Admin/Promote/lists', '渠道管理', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('243', 'admin', '1', 'Admin/Site/media', '基本配置', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('244', 'admin', '1', 'Admin/Stat/daily', '日常统计', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('245', 'admin', '1', 'Admin/GameType/lists', '游戏分类', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('246', 'admin', '1', 'Admin/Mend/lists', '渠道补链', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('247', 'admin', '1', 'Admin/Adv/media_adv_pos_lists', '广告管理', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('248', 'admin', '1', 'Admin/#', '代充额度', '-1', '');
INSERT INTO `sys_auth_rule` VALUES ('249', 'admin', '1', 'Admin/Server/lists', '游戏区服', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('250', 'admin', '1', 'Admin/Mend/record', '补链记录', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('251', 'admin', '1', 'Admin/Logo/media_logo', '图标设置', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('252', 'admin', '2', 'Admin/Game/lists', '游戏', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('253', 'admin', '1', 'Admin/Promote/ch_reg_list', '渠道注册', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('254', 'admin', '1', 'Admin/Site/app', '基本配置', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('255', 'admin', '1', 'Admin/GameSource/lists', '游戏原包', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('256', 'admin', '1', 'Admin/Giftbag/lists', '礼包管理', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('257', 'admin', '2', 'Admin/Promote/lists', '渠道', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('258', 'admin', '1', 'Admin/Adv/app_adv_pos_lists', '广告管理', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('259', 'admin', '1', 'Admin/Giftbag/record', '领取记录', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('260', 'admin', '1', 'Admin/Promote/spend_list', '渠道充值', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('261', 'admin', '2', 'Admin/Site/media', '站点', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('262', 'admin', '1', 'Admin/Adv/adv_lists', '广告列表', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('263', 'admin', '1', 'Admin/Member/user_info', '平台用户', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('264', 'admin', '2', 'Admin/Stat/daily', '统计', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('265', 'admin', '1', 'Admin/Logo/app_logo', '图标设置', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('266', 'admin', '1', 'Admin/Tool/smsset', '短信设置', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('267', 'admin', '1', 'Admin/Member/login_record', '登陆记录', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('268', 'admin', '1', 'Admin/Site/channel', '基本配置', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('269', 'admin', '1', 'Admin/Tool/storage', '文件存储', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('270', 'admin', '1', 'Admin/Spend/lists', 'SDK充值记录', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('271', 'admin', '1', 'Admin/Logo/channel_logo', '图标设置', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('272', 'admin', '1', 'Admin/Tool/payset', '支付设置', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('273', 'admin', '1', 'Admin/Deposit/lists', '平台币充值记录', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('274', 'admin', '1', 'Admin/Tool/email', '邮件设置', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('275', 'admin', '1', 'Admin/Provide/lists', '后台充值记录', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('276', 'admin', '1', 'Admin/Tool/thirdparty', '第三方登陆', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('277', 'admin', '1', 'Admin/BindSpend/lists', '绑币使用记录', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('278', 'admin', '1', 'Admin/Member/edit', '用户编辑', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('279', 'admin', '1', 'Admin/Apply/edit', '编辑', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('280', 'admin', '1', 'Admin/Query/withdraw_add', '提现添加', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('281', 'admin', '1', 'Admin/Provide/bdfirstpay', '后台充值', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('282', 'admin', '1', 'Admin/GiftbagType/add', '新增', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('283', 'admin', '1', 'Admin/Links/add', '新增', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('284', 'admin', '1', 'Admin/Links/edit', '编辑', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('285', 'admin', '1', 'Admin/GiftbagType/edit', '编辑', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('286', 'admin', '1', 'Admin/stat/pay_way', '来款统计', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('287', 'admin', '1', 'Admin/stat/cpa_login', '登陆统计', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('288', 'admin', '1', 'Admin/stat/cpa_register', '注册统计', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('289', 'admin', '1', 'Admin/Apply/lists', '分包管理', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('290', 'admin', '1', 'Admin/Links/lists', '友情链接', '-1', '');
INSERT INTO `sys_auth_rule` VALUES ('291', 'admin', '1', 'Admin/stat/cpa_spend', '消费统计', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('292', 'admin', '1', 'Admin/stat/userretention', '留存统计', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('293', 'admin', '1', 'Admin/Promote/agent_list', '代充记录', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('294', 'admin', '1', 'Admin/stat/userarpu', 'ARPU统计', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('295', 'admin', '1', 'Admin/GiftbagType/lists', '礼包类型', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('296', 'admin', '1', 'Admin/Query/bill', '渠道对账', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('297', 'admin', '1', 'Admin/Query/settlement', '渠道结算', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('298', 'admin', '1', 'Admin/Query/withdraw', '渠道提现', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('299', 'admin', '1', 'Admin/Promote/pay_limit_add', '新增', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('300', 'admin', '1', 'Admin/Promote/pay_limit_edit', '编辑', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('301', 'admin', '2', 'Admin/Article/mydocument', '文章', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('302', 'admin', '1', 'Admin/Promote/pay_limit', '代充额度', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('303', 'admin', '1', 'Admin/Links/lists/mark/1', '友情链接', '-1', '');
INSERT INTO `sys_auth_rule` VALUES ('304', 'admin', '1', 'Admin/Game/addopen', '新增', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('305', 'admin', '1', 'Admin/Game/editopen/', '编辑', '-1', '');
INSERT INTO `sys_auth_rule` VALUES ('306', 'admin', '1', 'Admin/Game/openlist', '开放类型', '-1', '');
INSERT INTO `sys_auth_rule` VALUES ('307', 'admin', '1', 'Admin/Links/lists/mark/0', 'PC友情链接', '-1', '');
INSERT INTO `sys_auth_rule` VALUES ('308', 'admin', '1', 'Admin/Message/wrong', '纠错管理', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('309', 'admin', '1', 'Admin/Opentype/lists', '开放类型', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('310', 'admin', '1', 'Admin/Opentype/edit', '修改', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('311', 'admin', '1', 'Admin/Opentype/add', '新增', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('312', 'admin', '1', 'Admin/Rebate/lists', '返利设置', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('313', 'admin', '1', 'Admin/Rebatelist/lists', '游戏返利', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('314', 'admin', '1', 'Admin/Rebate/add', '新增', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('315', 'admin', '1', 'Admin/Rebate/edit', '编辑', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('316', 'admin', '1', 'Admin/Push/pushsetlsit', '推送设置', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('317', 'admin', '1', 'Admin/Push/pushlist', '发送通知', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('318', 'admin', '1', 'Admin/Push/add', '新增', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('319', 'admin', '1', 'Admin/push/add_list', '新增', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('320', 'admin', '1', 'Admin/push/edit_list', '编辑', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('321', 'admin', '1', 'Admin/Push/edit', '编辑', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('322', 'admin', '1', 'Admin/Apply/package', '打包', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('323', 'admin', '1', 'Admin/Apply/set_status', '审核', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('324', 'admin', '1', 'Admin/GameType/set_status', '启用/禁用', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('325', 'admin', '1', 'Admin/Message/set_status', '未修复', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('326', 'admin', '1', 'Admin/Rebatelist/del', '删除', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('327', 'admin', '1', 'Admin/Links/lists/remark/ch', '友情链接', '-1', '');
INSERT INTO `sys_auth_rule` VALUES ('328', 'admin', '1', 'Admin/Action/clear', '清除', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('329', 'admin', '1', 'Admin/Action/remove', '删除', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('330', 'admin', '1', 'Admin/Member/delprovide', '删除', '-1', '');
INSERT INTO `sys_auth_rule` VALUES ('331', 'admin', '1', 'Admin/Provide/batch', '充值', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('332', 'admin', '1', 'Admin/Provide/delprovide', '删除', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('333', 'admin', '1', 'Admin/Game/del', '删除', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('334', 'admin', '1', 'Admin/Game/sort', '排序', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('335', 'admin', '1', 'Admin/Game/set_status', '推荐/不推荐', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('336', 'admin', '1', 'Admin/Promote/set_status', '锁定/解锁', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('337', 'admin', '1', 'Admin/Query/settl', '结算', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('338', 'admin', '1', 'Admin/Links/del', '删除', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('339', 'admin', '1', 'Admin/Adv/del_adv', '删除', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('340', 'admin', '1', 'Admin/Game/editopen', '编辑', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('341', 'admin', '1', 'Admin/Links/lists/remark/pc', 'PC友情链接', '-1', '');
INSERT INTO `sys_auth_rule` VALUES ('342', 'admin', '1', 'Admin/Wechat/index', '公众号设置', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('343', 'admin', '1', 'Admin/File/shard_upload', '上传文件', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('344', 'admin', '1', 'Admin/Member/del', '删除', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('345', 'admin', '1', 'Admin/User/edit', '编辑', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('346', 'admin', '1', 'Admin/Rebate/del', '删除', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('347', 'admin', '1', 'Admin/Giftbag/del', '删除', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('348', 'admin', '1', 'Admin/Links/chlists', '友情链接', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('349', 'admin', '1', 'Admin/Links/pclists', 'PC友情链接', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('350', 'admin', '1', 'Admin/Server/del', '删除', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('351', 'admin', '1', 'Admin/Apply/del', '删除', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('352', 'admin', '1', 'Admin/GameSource/del', '删除', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('353', 'admin', '1', 'Admin/Adv/set_status', '启用', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('354', 'admin', '1', 'Admin/Query/cpsettlement', '渠道结算', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('355', 'admin', '1', 'Admin/Seo/media', 'SEO搜索', '1', '');
INSERT INTO `sys_auth_rule` VALUES ('356', 'admin', '1', 'Admin/Seo/channel', ' 	SEO搜索', '1', '');

-- -----------------------------
-- Table structure for `sys_category`
-- -----------------------------
DROP TABLE IF EXISTS `sys_category`;
CREATE TABLE `sys_category` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '分类ID',
  `name` varchar(30) NOT NULL COMMENT '标志',
  `title` varchar(50) NOT NULL COMMENT '标题',
  `pid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '上级分类ID',
  `sort` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '排序（同级有效）',
  `list_row` tinyint(3) unsigned NOT NULL DEFAULT '10' COMMENT '列表每页行数',
  `meta_title` varchar(50) NOT NULL DEFAULT '' COMMENT 'SEO的网页标题',
  `keywords` varchar(255) NOT NULL DEFAULT '' COMMENT '关键字',
  `description` varchar(255) NOT NULL DEFAULT '' COMMENT '描述',
  `template_index` varchar(100) NOT NULL DEFAULT '' COMMENT '频道页模板',
  `template_lists` varchar(100) NOT NULL DEFAULT '' COMMENT '列表页模板',
  `template_detail` varchar(100) NOT NULL DEFAULT '' COMMENT '详情页模板',
  `template_edit` varchar(100) NOT NULL DEFAULT '' COMMENT '编辑页模板',
  `model` varchar(100) NOT NULL DEFAULT '' COMMENT '列表绑定模型',
  `model_sub` varchar(100) NOT NULL DEFAULT '' COMMENT '子文档绑定模型',
  `type` varchar(100) NOT NULL DEFAULT '' COMMENT '允许发布的内容类型',
  `link_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '外链',
  `allow_publish` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '是否允许发布内容',
  `display` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '可见性',
  `reply` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '是否允许回复',
  `check` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '发布的文章是否需要审核',
  `reply_model` varchar(100) NOT NULL DEFAULT '',
  `extend` text COMMENT '扩展设置',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `status` tinyint(4) NOT NULL DEFAULT '0' COMMENT '数据状态',
  `icon` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '分类图标',
  `groups` varchar(255) NOT NULL DEFAULT '' COMMENT '分组定义',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_name` (`name`),
  KEY `pid` (`pid`)
) ENGINE=MyISAM AUTO_INCREMENT=49 DEFAULT CHARSET=utf8 COMMENT='分类表';

-- -----------------------------
-- Records of `sys_category`
-- -----------------------------
INSERT INTO `sys_category` VALUES ('1', 'blog', '渠道站', '0', '0', '10', '', '', '', '', '', '', '', '2,3', '2', '2,1', '0', '0', '1', '0', '0', '1', '', '1379474947', '1464794659', '1', '0', '');
INSERT INTO `sys_category` VALUES ('2', 'tui_gg', '游戏公告', '1', '1', '10', '', '', '', '', '', '', '', '2', '2', '2,1,3', '0', '1', '1', '0', '1', '1', '', '1379475028', '1464827285', '1', '0', '');
INSERT INTO `sys_category` VALUES ('39', 'tui_zx', '游戏资讯', '1', '1', '10', '', '', '', '', '', '', '', '2', '2', '2', '0', '1', '1', '0', '0', '', '', '1464794769', '1464794833', '1', '0', '');
INSERT INTO `sys_category` VALUES ('40', 'tui_about', '关于我们', '1', '3', '10', '', '', '', '', '', '', '', '2', '2', '2', '0', '1', '1', '0', '0', '', '', '1464794803', '1464794831', '1', '0', '');
INSERT INTO `sys_category` VALUES ('41', 'media', '媒体站', '0', '1', '10', '', '', '', '', '', '', '', '2', '2', '2,1', '0', '1', '1', '0', '0', '', '', '1464826817', '1464827190', '1', '0', '');
INSERT INTO `sys_category` VALUES ('42', 'media_gg', '游戏公告', '41', '6', '10', '', '', '', '', '', '', '', '2', '2', '2', '0', '1', '1', '0', '0', '', '', '1464826928', '1464827209', '1', '0', '');
INSERT INTO `sys_category` VALUES ('43', 'media_new', '游戏新闻', '41', '5', '10', '', '', '', '', '', '', '', '2', '2', '2', '0', '1', '1', '0', '0', '', '', '1464826955', '1464827207', '1', '0', '');
INSERT INTO `sys_category` VALUES ('44', 'media_activity', '游戏活动', '41', '4', '10', '', '', '', '', '', '', '', '2', '2', '2', '0', '1', '1', '0', '0', '', '', '1464827047', '1464827205', '1', '0', '');
INSERT INTO `sys_category` VALUES ('45', 'media_partner', '合作伙伴', '41', '3', '10', '', '', '', '', '', '', '', '2', '2', '2', '0', '1', '1', '0', '0', '', '', '1464827079', '1464827202', '1', '0', '');
INSERT INTO `sys_category` VALUES ('46', 'media_collaborate', '商务合作', '41', '2', '10', '', '', '', '', '', '', '', '2', '2', '2', '0', '1', '1', '0', '0', '', '', '1464827119', '1464827200', '1', '0', '');
INSERT INTO `sys_category` VALUES ('47', 'media_about', '关于我们', '41', '1', '10', '', '', '', '', '', '', '', '2', '2', '2', '0', '1', '1', '0', '0', '', '', '1464827148', '1464827198', '1', '0', '');
INSERT INTO `sys_category` VALUES ('48', 'media_supervise', '家长监督', '41', '7', '10', '', '', '', '', '', '', '', '2', '2', '2', '0', '1', '1', '0', '0', '', '', '1464827180', '1464827211', '1', '0', '');

-- -----------------------------
-- Table structure for `sys_channel`
-- -----------------------------
DROP TABLE IF EXISTS `sys_channel`;
CREATE TABLE `sys_channel` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '频道ID',
  `pid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '上级频道ID',
  `title` char(30) NOT NULL COMMENT '频道标题',
  `url` char(100) NOT NULL COMMENT '频道连接',
  `sort` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '导航排序',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `status` tinyint(4) NOT NULL DEFAULT '0' COMMENT '状态',
  `target` tinyint(2) unsigned NOT NULL DEFAULT '0' COMMENT '新窗口打开',
  PRIMARY KEY (`id`),
  KEY `pid` (`pid`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `sys_channel`
-- -----------------------------
INSERT INTO `sys_channel` VALUES ('1', '0', '首页', 'Index/index', '3', '1379475111', '1379923177', '1', '0');
INSERT INTO `sys_channel` VALUES ('2', '0', '游戏公告', 'Article/lists?category=tui_gg', '2', '1379475131', '1464830131', '1', '0');
INSERT INTO `sys_channel` VALUES ('3', '0', '游戏资讯', 'Article/lists?category=tui_zx', '1', '1379475154', '1464830178', '1', '0');
INSERT INTO `sys_channel` VALUES ('4', '0', '关于我们', 'Article/detail?id=32', '0', '1466730873', '1466733900', '1', '0');

-- -----------------------------
-- Table structure for `sys_config`
-- -----------------------------
DROP TABLE IF EXISTS `sys_config`;
CREATE TABLE `sys_config` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '配置ID',
  `name` varchar(30) NOT NULL DEFAULT '' COMMENT '配置名称',
  `type` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '配置类型',
  `title` varchar(50) NOT NULL DEFAULT '' COMMENT '配置说明',
  `category` tinyint(3) NOT NULL COMMENT '配置分类',
  `group` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '配置分组',
  `extra` varchar(255) NOT NULL DEFAULT '' COMMENT '配置值',
  `remark` varchar(100) NOT NULL DEFAULT '' COMMENT '配置说明',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `status` tinyint(4) NOT NULL DEFAULT '0' COMMENT '状态',
  `value` text COMMENT '配置值',
  `sort` smallint(3) unsigned NOT NULL DEFAULT '0' COMMENT '排序',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_name` (`name`),
  KEY `type` (`type`),
  KEY `group` (`group`)
) ENGINE=MyISAM AUTO_INCREMENT=82 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `sys_config`
-- -----------------------------
INSERT INTO `sys_config` VALUES ('1', 'WEB_SITE_TITLE', '1', '网站标题', '0', '1', '', '网站标题前台显示标题', '1378898976', '1379235274', '1', '51手游平台', '0');
INSERT INTO `sys_config` VALUES ('2', 'WEB_SITE_DESCRIPTION', '2', '网站描述', '0', '1', '', '网站搜索引擎描述', '1378898976', '1379235841', '1', '手游系统管理中心', '1');
INSERT INTO `sys_config` VALUES ('3', 'WEB_SITE_KEYWORD', '2', '网站关键字', '0', '1', '', '网站搜索引擎关键字', '1378898976', '1381390100', '1', '', '8');
INSERT INTO `sys_config` VALUES ('4', 'WEB_SITE_CLOSE', '4', '关闭站点', '0', '1', '0:关闭,1:开启', '站点关闭后其他用户不能访问，管理员可以正常访问', '1378898976', '1379235296', '1', '1', '1');
INSERT INTO `sys_config` VALUES ('9', 'CONFIG_TYPE_LIST', '3', '配置类型列表', '0', '4', '', '主要用于数据解析和页面表单的生成', '1378898976', '1464137919', '1', '0:数字\r\n1:字符\r\n2:文本\r\n3:数组\r\n4:枚举\r\n5:图片', '2');
INSERT INTO `sys_config` VALUES ('10', 'WEB_SITE_ICP', '1', '网站备案号', '0', '1', '', '工业与信息化部备案', '1378900335', '1465029319', '1', '', '9');
INSERT INTO `sys_config` VALUES ('11', 'DOCUMENT_POSITION', '3', '文档推荐位', '0', '2', '', '文档推荐位，推荐到多个位置KEY值相加即可', '1379053380', '1379235329', '1', '1:列表推荐\r\n2:频道推荐\r\n4:首页推荐', '3');
INSERT INTO `sys_config` VALUES ('12', 'DOCUMENT_DISPLAY', '3', '文档可见性', '0', '2', '', '文章可见性仅影响前台显示，后台不收影响', '1379056370', '1379235322', '1', '0:所有人可见\r\n1:仅注册会员可见\r\n2:仅管理员可见', '4');
INSERT INTO `sys_config` VALUES ('13', 'COLOR_STYLE', '4', '后台色系', '0', '1', 'default_color:默认\r\nblue_color:紫罗兰', '后台颜色风格', '1379122533', '1379235904', '1', 'default_color', '10');
INSERT INTO `sys_config` VALUES ('20', 'CONFIG_GROUP_LIST', '3', '配置分组', '0', '4', '', '配置分组', '1379228036', '1384418383', '1', '1:基本\r\n2:内容\r\n3:用户\r\n4:系统', '4');
INSERT INTO `sys_config` VALUES ('21', 'HOOKS_TYPE', '3', '钩子的类型', '0', '4', '', '类型 1-用于扩展显示内容，2-用于扩展业务处理', '1379313397', '1379313407', '1', '1:视图\r\n2:控制器', '6');
INSERT INTO `sys_config` VALUES ('22', 'AUTH_CONFIG', '3', 'Auth配置', '0', '4', '', '自定义Auth.class.php类配置', '1379409310', '1379409564', '1', 'AUTH_ON:1\r\nAUTH_TYPE:2', '8');
INSERT INTO `sys_config` VALUES ('23', 'OPEN_DRAFTBOX', '4', '是否开启草稿功能', '0', '2', '0:关闭草稿功能\r\n1:开启草稿功能\r\n', '新增文章时的草稿功能配置', '1379484332', '1379484591', '1', '1', '1');
INSERT INTO `sys_config` VALUES ('24', 'DRAFT_AOTOSAVE_INTERVAL', '0', '自动保存草稿时间', '0', '2', '', '自动保存草稿的时间间隔，单位：秒', '1379484574', '1386143323', '1', '60', '2');
INSERT INTO `sys_config` VALUES ('25', 'LIST_ROWS', '0', '后台每页记录数', '0', '2', '', '后台数据每页显示记录数', '1379503896', '1380427745', '1', '15', '10');
INSERT INTO `sys_config` VALUES ('26', 'USER_ALLOW_REGISTER', '4', '是否允许用户注册', '0', '3', '0:关闭注册\r\n1:允许注册', '是否开放用户注册', '1379504487', '1379504580', '1', '1', '3');
INSERT INTO `sys_config` VALUES ('27', 'CODEMIRROR_THEME', '4', '预览插件的CodeMirror主题', '0', '4', '3024-day:3024 day\r\n3024-night:3024 night\r\nambiance:ambiance\r\nbase16-dark:base16 dark\r\nbase16-light:base16 light\r\nblackboard:blackboard\r\ncobalt:cobalt\r\neclipse:eclipse\r\nelegant:elegant\r\nerlang-dark:erlang-dark\r\nlesser-dark:lesser-dark\r\nmidnight:midnight', '详情见CodeMirror官网', '1379814385', '1384740813', '1', 'ambiance', '3');
INSERT INTO `sys_config` VALUES ('28', 'DATA_BACKUP_PATH', '1', '数据库备份根路径', '0', '4', '', '路径必须以 / 结尾', '1381482411', '1381482411', '1', './Data/', '5');
INSERT INTO `sys_config` VALUES ('29', 'DATA_BACKUP_PART_SIZE', '0', '数据库备份卷大小', '0', '4', '', '该值用于限制压缩后的分卷最大长度。单位：B；建议设置20M', '1381482488', '1381729564', '1', '20971520', '7');
INSERT INTO `sys_config` VALUES ('30', 'DATA_BACKUP_COMPRESS', '4', '数据库备份文件是否启用压缩', '0', '4', '0:不压缩\r\n1:启用压缩', '压缩备份文件需要PHP环境支持gzopen,gzwrite函数', '1381713345', '1381729544', '1', '1', '9');
INSERT INTO `sys_config` VALUES ('31', 'DATA_BACKUP_COMPRESS_LEVEL', '4', '数据库备份文件压缩级别', '0', '4', '1:普通\r\n4:一般\r\n9:最高', '数据库备份文件的压缩级别，该配置在开启压缩时生效', '1381713408', '1381713408', '1', '9', '10');
INSERT INTO `sys_config` VALUES ('32', 'DEVELOP_MODE', '4', '开启开发者模式', '0', '4', '0:关闭\r\n1:开启', '是否开启开发者模式', '1383105995', '1383291877', '1', '1', '11');
INSERT INTO `sys_config` VALUES ('33', 'ALLOW_VISIT', '3', '不受限控制器方法', '0', '0', '', '', '1386644047', '1386644741', '1', '0:article/draftbox\r\n1:article/mydocument\r\n2:Category/tree\r\n3:Index/verify\r\n4:file/upload\r\n5:file/download\r\n6:user/updatePassword\r\n7:user/updateNickname\r\n8:user/submitPassword\r\n9:user/submitNickname\r\n10:file/uploadpicture', '0');
INSERT INTO `sys_config` VALUES ('34', 'DENY_VISIT', '3', '超管专限控制器方法', '0', '0', '', '仅超级管理员可访问的控制器方法', '1386644141', '1386644659', '1', '0:Addons/addhook\r\n1:Addons/edithook\r\n2:Addons/delhook\r\n3:Addons/updateHook\r\n4:Admin/getMenus\r\n5:Admin/recordList\r\n6:AuthManager/updateRules\r\n7:AuthManager/tree', '0');
INSERT INTO `sys_config` VALUES ('36', 'ADMIN_ALLOW_IP', '2', '后台允许访问IP', '0', '4', '', '多个用逗号分隔，如果不配置表示不限制IP访问', '1387165454', '1387165553', '1', '', '12');
INSERT INTO `sys_config` VALUES ('37', 'SHOW_PAGE_TRACE', '4', '是否显示页面Trace', '0', '4', '0:关闭\r\n1:开启', '是否显示页面Trace信息', '1387165685', '1387165685', '1', '0', '1');
INSERT INTO `sys_config` VALUES ('38', 'PC_SET_TITLE', '1', '媒体官网标题设置', '1', '1', '哈哈', '用于显示媒体官网标题', '1464056166', '1464071718', '1', '51手游平台-独家手游平台', '0');
INSERT INTO `sys_config` VALUES ('39', 'CONFIG_CATEGORY_LIST', '3', '配置分组', '0', '4', '', '设置分组', '1464057350', '1464075821', '1', '1:媒体官网\r\n2:渠道官网\r\n3:APP设置\r\n4:管理后台', '0');
INSERT INTO `sys_config` VALUES ('40', 'PC_SET_META_KEY', '1', '媒体网站关键词设置', '1', '1', '', '网站关键词', '1464073412', '1464073714', '1', '51手游平台 手游', '1');
INSERT INTO `sys_config` VALUES ('41', 'PC_SET_META_DESC', '2', '媒体网站描述设置', '1', '1', '', '网站描述', '1464073618', '1464073728', '1', '手机游戏推广联盟_推广联盟中心', '2');
INSERT INTO `sys_config` VALUES ('42', 'PC_SET_COPYRIGHT', '2', '媒体官网版权信息设置', '1', '1', '', '媒体官网版权信息设置', '1464074257', '1464074463', '1', '© 上海梦创科技公司 版权所有 2016 51syw.com', '3');
INSERT INTO `sys_config` VALUES ('43', 'PC_SET_LICENSE', '1', '网络文化经营许可证编号', '1', '1', '', '网络文化经营许可证编号', '1464074566', '1464074566', '1', '', '1');
INSERT INTO `sys_config` VALUES ('44', 'PC_SET_FOR_THE_RECORD', '1', '网站备案号', '1', '1', '', '工业与信息化部备案', '1464074923', '1465029306', '1', '', '1');
INSERT INTO `sys_config` VALUES ('45', 'PC_SET_SERVER_TEL', '1', '客服电话', '1', '2', '', '客服联系电话或手机', '1464075195', '1464075195', '1', '88888888888', '0');
INSERT INTO `sys_config` VALUES ('46', 'PC_SET_SERVER_QQ', '1', '客服QQ', '1', '2', '', '客服QQ', '1464075627', '1464075647', '1', '598899001', '0');
INSERT INTO `sys_config` VALUES ('47', 'PC_SET_SERVER_EMAIL', '1', '客服邮箱', '1', '2', '', '客服邮箱', '1464075697', '1464075750', '1', '598899001@qq.com', '0');
INSERT INTO `sys_config` VALUES ('48', 'CH_SET_META_KEY', '1', '媒体网站关键词设置', '2', '1', '', '网站关键词', '1464073412', '1464073714', '1', '手游', '1');
INSERT INTO `sys_config` VALUES ('49', 'CH_SET_META_DESC', '2', '媒体网站描述设置', '2', '1', '', '网站描述', '1464073618', '1464073728', '1', '手机游戏推广联盟_推广联盟中心', '2');
INSERT INTO `sys_config` VALUES ('50', 'CH_SET_COPYRIGHT', '2', '媒体官网版权信息设置', '2', '1', '', '媒体官网版权信息设置', '1464074257', '1464074463', '1', '© 上海梦创科技有限公司 版权所有 2016 51syw.com', '3');
INSERT INTO `sys_config` VALUES ('51', 'CH_SET_LICENSE', '1', '网络文化经营许可证编号', '2', '1', '', '网络文化经营许可证编号', '1464074566', '1464074566', '1', '', '1');
INSERT INTO `sys_config` VALUES ('52', 'CH_SET_FOR_THE_RECORD', '1', '网站备案号', '2', '1', '', '工业与信息化部备案', '1464074923', '1465029259', '1', '', '1');
INSERT INTO `sys_config` VALUES ('53', 'CH_SET_SERVER_TEL', '1', '客服电话', '2', '2', '', '客服联系电话或手机', '1464075195', '1464075195', '1', '0516-83463372', '0');
INSERT INTO `sys_config` VALUES ('54', 'CH_SET_SERVER_QQ', '1', '客服QQ', '2', '2', '', '客服QQ', '1464075627', '1464075647', '1', '97471547', '0');
INSERT INTO `sys_config` VALUES ('55', 'CH_SET_SERVER_EMAIL', '1', '客服邮箱', '2', '2', '', '客服邮箱', '1464075697', '1464075750', '1', '836333669@qq.com', '0');
INSERT INTO `sys_config` VALUES ('56', 'PC_SET_LOGO', '5', '媒体网站logo', '1', '0', '', '190px * 60px', '1464137707', '1465810704', '1', '37', '0');
INSERT INTO `sys_config` VALUES ('57', 'PC_SET_QRCODE', '5', '设置媒体官网二维码', '1', '0', '', '设置媒体官网二维码 430px * 430px', '1464148155', '1465810731', '1', '', '0');
INSERT INTO `sys_config` VALUES ('58', 'PC_SET_ICO', '5', '设置媒体官网ico图标', '1', '0', '', '设置媒体官网ico图标，16px * 16px', '1464148189', '1465810764', '1', '15', '0');
INSERT INTO `sys_config` VALUES ('59', 'CH_SET_LOGO', '5', '渠道LOGO设置', '2', '0', '', '248px * 60px', '1464157183', '1465810537', '1', '37', '0');
INSERT INTO `sys_config` VALUES ('60', 'CH_SET_QRCODE', '5', '设置渠道官网二维码', '2', '0', '', '430px * 430px', '1464157237', '1465810575', '0', '', '0');
INSERT INTO `sys_config` VALUES ('61', 'CH_SET_ICO', '5', '设置渠道官网ico图标', '2', '0', '', '请上传后缀为.ico的图标，16px * 16px', '1464157295', '1465810640', '1', '', '0');
INSERT INTO `sys_config` VALUES ('62', 'APP_SET_COVER', '5', '设置APP开机画面', '3', '0', '', '用户手机APP的初始画面', '1464157375', '1464157691', '1', '88', '0');
INSERT INTO `sys_config` VALUES ('63', 'CH_SET_TITLE', '1', '渠道官网标题', '2', '1', '', '渠道官网标题', '1464339818', '1464339818', '1', '手机游戏推广联盟', '0');
INSERT INTO `sys_config` VALUES ('64', 'PC_WORK_TIME', '1', '工作时间', '1', '2', '', '工作时间', '1465216166', '1465216263', '1', '10:00-22:00', '3');
INSERT INTO `sys_config` VALUES ('65', 'PC_T_EMAIL', '1', '投诉邮箱', '1', '2', '', '投诉邮箱', '1465216195', '1465216255', '1', '598899001@qq.com', '4');
INSERT INTO `sys_config` VALUES ('66', 'CH_SET_ADDRESS', '1', '公司地址', '2', '2', '', '公司办公地址', '1465724290', '1465724290', '1', '徐州', '0');
INSERT INTO `sys_config` VALUES ('67', 'SITE_ICO', '5', '后台网址ico图标', '0', '1', '', '后台网址ico图标，16px * 16px', '1465785677', '1465868164', '1', '11', '3');
INSERT INTO `sys_config` VALUES ('68', 'HT_LOGO', '5', '后台LOGO', '0', '1', '', '后台LOGO，184px * 49px', '1465785711', '1465868114', '1', '37', '4');
INSERT INTO `sys_config` VALUES ('69', 'APP_QQ_GROUP', '0', '官方玩家群', '3', '1', '', '官方玩家群', '1466139794', '1466495929', '1', '', '0');
INSERT INTO `sys_config` VALUES ('70', 'APP_NETWORK', '1', 'PC官网地址', '3', '1', '', 'PC官网地址', '1466140005', '1466495991', '1', '', '0');
INSERT INTO `sys_config` VALUES ('71', 'APP_QQ', '0', '客服QQ号', '3', '1', '', '客服QQ号', '1466140048', '1466140048', '1', '', '0');
INSERT INTO `sys_config` VALUES ('72', 'APP_WEIXIN', '1', '微信公众号', '3', '1', '', '微信公众号', '1466140091', '1466140091', '1', '', '0');
INSERT INTO `sys_config` VALUES ('73', 'APP_ICON', '1', 'APP图标', '3', '1', '', 'APP图标', '1466140129', '1466141841', '0', 'http://admin.vlcms.com/Uploads/Picture/2016-06-07/575638bc64e72.png', '0');
INSERT INTO `sys_config` VALUES ('74', 'APP_VERSION', '1', 'APP版本号', '3', '1', '', 'APP版本号', '1466151638', '1466153664', '1', '', '0');
INSERT INTO `sys_config` VALUES ('77', 'APP_NAME', '2', 'APP名称', '3', '1', '', 'APP名称', '1466385075', '1466385075', '1', '', '0');
INSERT INTO `sys_config` VALUES ('76', 'APP_DOWNLOAD', '1', 'APP下载地址', '3', '1', '', 'app下载地址连接', '1466153743', '1466153820', '1', '', '0');
INSERT INTO `sys_config` VALUES ('79', 'ABOUT_ICO', '5', '关于我们图标', '3', '1', '', '关于我们图标', '1466496505', '1466496505', '1', '63', '13');
INSERT INTO `sys_config` VALUES ('80', 'APP_DOWNLOAD1', '1', 'APP下载地址', '3', '1', '', 'APP下载地址', '1466995341', '1466995341', '0', 'http://dl.vlcms.com/dl/Gameapp.apk', '0');
INSERT INTO `sys_config` VALUES ('81', 'PC_SET_LOGO_URL', '1', 'logo链接', '1', '0', '', 'logo链接', '1467098119', '1467098119', '1', '', '0');

-- -----------------------------
-- Table structure for `sys_document`
-- -----------------------------
DROP TABLE IF EXISTS `sys_document`;
CREATE TABLE `sys_document` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '文档ID',
  `uid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '用户ID',
  `name` char(40) NOT NULL DEFAULT '' COMMENT '标识',
  `title` char(80) NOT NULL DEFAULT '' COMMENT '标题',
  `category_id` int(10) unsigned NOT NULL COMMENT '所属分类',
  `group_id` smallint(3) unsigned NOT NULL COMMENT '所属分组',
  `description` char(140) NOT NULL DEFAULT '' COMMENT '描述',
  `root` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '根节点',
  `pid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '所属ID',
  `model_id` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '内容模型ID',
  `type` tinyint(3) unsigned NOT NULL DEFAULT '2' COMMENT '内容类型',
  `position` smallint(5) unsigned NOT NULL DEFAULT '0' COMMENT '推荐位',
  `link_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '外链',
  `cover_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '封面',
  `display` tinyint(3) unsigned NOT NULL DEFAULT '1' COMMENT '可见性',
  `deadline` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '截至时间',
  `attach` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '附件数量',
  `view` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '浏览量',
  `comment` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '评论数',
  `extend` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '扩展统计字段',
  `level` int(10) NOT NULL DEFAULT '0' COMMENT '优先级',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `admin` int(11) NOT NULL DEFAULT '0' COMMENT '文档创建者',
  `status` tinyint(4) NOT NULL DEFAULT '0' COMMENT '数据状态',
  PRIMARY KEY (`id`),
  KEY `idx_category_status` (`category_id`,`status`),
  KEY `idx_status_type_pid` (`status`,`uid`,`pid`)
) ENGINE=MyISAM AUTO_INCREMENT=56 DEFAULT CHARSET=utf8 COMMENT='文档模型基础表';

-- -----------------------------
-- Records of `sys_document`
-- -----------------------------
INSERT INTO `sys_document` VALUES ('3', '1', 'sdf', '主题信息', '2', '0', '士大夫', '2', '2', '2', '2', '0', '0', '0', '1', '0', '0', '0', '0', '0', '0', '1463642189', '1463642189', '2', '1');

-- -----------------------------
-- Table structure for `sys_document_article`
-- -----------------------------
DROP TABLE IF EXISTS `sys_document_article`;
CREATE TABLE `sys_document_article` (
  `id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '文档ID',
  `parse` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '内容解析类型',
  `content` text NOT NULL COMMENT '文章内容',
  `template` varchar(100) NOT NULL DEFAULT '' COMMENT '详情页显示模板',
  `bookmark` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '收藏数',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='文档模型文章表';

-- -----------------------------
-- Records of `sys_document_article`
-- -----------------------------
INSERT INTO `sys_document_article` VALUES ('1', '0', '<h1>\r\n	OneThink1.1开发版发布&nbsp;\r\n</h1>\r\n<p>\r\n	<br />\r\n</p>\r\n<p>\r\n	<strong>OneThink是一个开源的内容管理框架，基于最新的ThinkPHP3.2版本开发，提供更方便、更安全的WEB应用开发体验，采用了全新的架构设计和命名空间机制，融合了模块化、驱动化和插件化的设计理念于一体，开启了国内WEB应用傻瓜式开发的新潮流。&nbsp;</strong> \r\n</p>\r\n<h2>\r\n	主要特性：\r\n</h2>\r\n<p>\r\n	1. 基于ThinkPHP最新3.2版本。\r\n</p>\r\n<p>\r\n	2. 模块化：全新的架构和模块化的开发机制，便于灵活扩展和二次开发。&nbsp;\r\n</p>\r\n<p>\r\n	3. 文档模型/分类体系：通过和文档模型绑定，以及不同的文档类型，不同分类可以实现差异化的功能，轻松实现诸如资讯、下载、讨论和图片等功能。\r\n</p>\r\n<p>\r\n	4. 开源免费：OneThink遵循Apache2开源协议,免费提供使用。&nbsp;\r\n</p>\r\n<p>\r\n	5. 用户行为：支持自定义用户行为，可以对单个用户或者群体用户的行为进行记录及分享，为您的运营决策提供有效参考数据。\r\n</p>\r\n<p>\r\n	6. 云端部署：通过驱动的方式可以轻松支持平台的部署，让您的网站无缝迁移，内置已经支持SAE和BAE3.0。\r\n</p>\r\n<p>\r\n	7. 云服务支持：即将启动支持云存储、云安全、云过滤和云统计等服务，更多贴心的服务让您的网站更安心。\r\n</p>\r\n<p>\r\n	8. 安全稳健：提供稳健的安全策略，包括备份恢复、容错、防止恶意攻击登录，网页防篡改等多项安全管理功能，保证系统安全，可靠、稳定的运行。&nbsp;\r\n</p>\r\n<p>\r\n	9. 应用仓库：官方应用仓库拥有大量来自第三方插件和应用模块、模板主题，有众多来自开源社区的贡献，让您的网站“One”美无缺。&nbsp;\r\n</p>\r\n<p>\r\n	<br />\r\n</p>\r\n<p>\r\n	<strong>&nbsp;OneThink集成了一个完善的后台管理体系和前台模板标签系统，让你轻松管理数据和进行前台网站的标签式开发。&nbsp;</strong> \r\n</p>\r\n<p>\r\n	<br />\r\n</p>\r\n<h2>\r\n	后台主要功能：\r\n</h2>\r\n<p>\r\n	1. 用户Passport系统\r\n</p>\r\n<p>\r\n	2. 配置管理系统&nbsp;\r\n</p>\r\n<p>\r\n	3. 权限控制系统\r\n</p>\r\n<p>\r\n	4. 后台建模系统&nbsp;\r\n</p>\r\n<p>\r\n	5. 多级分类系统&nbsp;\r\n</p>\r\n<p>\r\n	6. 用户行为系统&nbsp;\r\n</p>\r\n<p>\r\n	7. 钩子和插件系统\r\n</p>\r\n<p>\r\n	8. 系统日志系统&nbsp;\r\n</p>\r\n<p>\r\n	9. 数据备份和还原\r\n</p>\r\n<p>\r\n	<br />\r\n</p>\r\n<p>\r\n	&nbsp;[ 官方下载：&nbsp;<a href=\"http://www.onethink.cn/download.html\" target=\"_blank\">http://www.onethink.cn/download.html</a>&nbsp;&nbsp;开发手册：<a href=\"http://document.onethink.cn/\" target=\"_blank\">http://document.onethink.cn/</a>&nbsp;]&nbsp;\r\n</p>\r\n<p>\r\n	<br />\r\n</p>\r\n<p>\r\n	<strong>OneThink开发团队 2013~2014</strong> \r\n</p>', '', '0');
INSERT INTO `sys_document_article` VALUES ('2', '0', '暗室逢灯<br />', '', '0');
INSERT INTO `sys_document_article` VALUES ('3', '0', '士大夫<br />', '', '0');

-- -----------------------------
-- Table structure for `sys_document_download`
-- -----------------------------
DROP TABLE IF EXISTS `sys_document_download`;
CREATE TABLE `sys_document_download` (
  `id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '文档ID',
  `parse` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '内容解析类型',
  `content` text NOT NULL COMMENT '下载详细描述',
  `template` varchar(100) NOT NULL DEFAULT '' COMMENT '详情页显示模板',
  `file_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '文件ID',
  `download` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '下载次数',
  `size` bigint(20) unsigned NOT NULL DEFAULT '0' COMMENT '文件大小',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='文档模型下载表';


-- -----------------------------
-- Table structure for `sys_file`
-- -----------------------------
DROP TABLE IF EXISTS `sys_file`;
CREATE TABLE `sys_file` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '文件ID',
  `name` char(30) NOT NULL DEFAULT '' COMMENT '原始文件名',
  `savename` char(20) NOT NULL DEFAULT '' COMMENT '保存名称',
  `savepath` char(30) NOT NULL DEFAULT '' COMMENT '文件保存路径',
  `ext` char(5) NOT NULL DEFAULT '' COMMENT '文件后缀',
  `mime` char(40) NOT NULL DEFAULT '' COMMENT '文件mime类型',
  `size` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '文件大小',
  `md5` char(32) NOT NULL DEFAULT '' COMMENT '文件md5',
  `sha1` char(40) NOT NULL DEFAULT '' COMMENT '文件 sha1编码',
  `location` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '文件保存位置',
  `url` varchar(255) NOT NULL DEFAULT '' COMMENT '远程地址',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '上传时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_md5` (`md5`)
) ENGINE=MyISAM AUTO_INCREMENT=109 DEFAULT CHARSET=utf8 COMMENT='文件表';

-- -----------------------------
-- Records of `sys_file`
-- -----------------------------
INSERT INTO `sys_file` VALUES ('108', 'sdk_test_demo.apk', '575122f939b19.apk', '2016-06-03/', 'apk', 'application/jar', '1197722', '1e29fa8deef7606a1f0e913a977743b4', 'bce92279b9b52cecd45a1bbfa66513f8c346710e', '0', '', '1464935161');

-- -----------------------------
-- Table structure for `sys_game`
-- -----------------------------
DROP TABLE IF EXISTS `sys_game`;
CREATE TABLE `sys_game` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `money` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '注册单价',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;


-- -----------------------------
-- Table structure for `sys_gametype`
-- -----------------------------
DROP TABLE IF EXISTS `sys_gametype`;
CREATE TABLE `sys_gametype` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `icon` int(12) NOT NULL COMMENT '图标',
  `cover` int(12) NOT NULL COMMENT '封面',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;


-- -----------------------------
-- Table structure for `sys_hooks`
-- -----------------------------
DROP TABLE IF EXISTS `sys_hooks`;
CREATE TABLE `sys_hooks` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `name` varchar(40) NOT NULL DEFAULT '' COMMENT '钩子名称',
  `description` text COMMENT '描述',
  `type` tinyint(1) unsigned NOT NULL DEFAULT '1' COMMENT '类型',
  `update_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `addons` varchar(255) NOT NULL DEFAULT '' COMMENT '钩子挂载的插件 ''，''分割',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=MyISAM AUTO_INCREMENT=18 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `sys_hooks`
-- -----------------------------
INSERT INTO `sys_hooks` VALUES ('1', 'pageHeader', '页面header钩子，一般用于加载插件CSS文件和代码', '1', '0', '', '1');
INSERT INTO `sys_hooks` VALUES ('2', 'pageFooter', '页面footer钩子，一般用于加载插件JS文件和JS代码', '1', '0', 'ReturnTop', '1');
INSERT INTO `sys_hooks` VALUES ('3', 'documentEditForm', '添加编辑表单的 扩展内容钩子', '1', '0', 'Attachment', '1');
INSERT INTO `sys_hooks` VALUES ('4', 'documentDetailAfter', '文档末尾显示', '1', '0', 'Attachment,SocialComment', '1');
INSERT INTO `sys_hooks` VALUES ('5', 'documentDetailBefore', '页面内容前显示用钩子', '1', '0', '', '1');
INSERT INTO `sys_hooks` VALUES ('6', 'documentSaveComplete', '保存文档数据后的扩展钩子', '2', '0', 'Attachment', '1');
INSERT INTO `sys_hooks` VALUES ('7', 'documentEditFormContent', '添加编辑表单的内容显示钩子', '1', '0', 'Editor', '1');
INSERT INTO `sys_hooks` VALUES ('8', 'adminArticleEdit', '后台内容编辑页编辑器', '1', '1378982734', 'EditorForAdmin', '1');
INSERT INTO `sys_hooks` VALUES ('13', 'AdminIndex', '首页小格子个性化显示', '1', '1382596073', 'SiteStat,SystemInfo,DevTeam', '1');
INSERT INTO `sys_hooks` VALUES ('14', 'topicComment', '评论提交方式扩展钩子。', '1', '1380163518', 'Editor', '1');
INSERT INTO `sys_hooks` VALUES ('16', 'app_begin', '应用开始', '2', '1384481614', '', '1');
INSERT INTO `sys_hooks` VALUES ('17', 'UploadImages', '多图片上传', '1', '1465785232', 'UploadImages', '1');

-- -----------------------------
-- Table structure for `sys_links`
-- -----------------------------
DROP TABLE IF EXISTS `sys_links`;
CREATE TABLE `sys_links` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `mark` varchar(50) NOT NULL DEFAULT '0' COMMENT '所属后台',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;


-- -----------------------------
-- Table structure for `sys_member`
-- -----------------------------
DROP TABLE IF EXISTS `sys_member`;
CREATE TABLE `sys_member` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '用户ID',
  `nickname` char(16) NOT NULL DEFAULT '' COMMENT '昵称',
  `sex` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '性别',
  `birthday` date NOT NULL DEFAULT '0000-00-00' COMMENT '生日',
  `qq` char(10) NOT NULL DEFAULT '' COMMENT 'qq号',
  `score` mediumint(8) NOT NULL DEFAULT '0' COMMENT '用户积分',
  `login` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '登录次数',
  `reg_ip` bigint(20) NOT NULL DEFAULT '0' COMMENT '注册IP',
  `reg_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '注册时间',
  `last_login_ip` bigint(20) NOT NULL DEFAULT '0' COMMENT '最后登录IP',
  `last_login_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '最后登录时间',
  `status` tinyint(4) NOT NULL DEFAULT '0' COMMENT '会员状态',
  PRIMARY KEY (`uid`),
  KEY `status` (`status`)
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=utf8 COMMENT='会员表';

-- -----------------------------
-- Records of `sys_member`
-- -----------------------------
INSERT INTO `sys_member` VALUES ('1', 'admin', '0', '0000-00-00', '', '180', '395', '0', '1463641749', '1022946991', '1470992089', '1');
INSERT INTO `sys_member` VALUES ('2', '111111', '0', '0000-00-00', '', '0', '0', '0', '0', '0', '0', '-1');
INSERT INTO `sys_member` VALUES ('3', 'asdasd', '0', '0000-00-00', '', '110', '61', '0', '0', '2130706433', '1470640699', '-1');
INSERT INTO `sys_member` VALUES ('4', 'qwe123', '0', '0000-00-00', '', '10', '2', '0', '0', '0', '1465286875', '-1');
INSERT INTO `sys_member` VALUES ('5', 'qwe135', '0', '0000-00-00', '', '20', '5', '0', '0', '2130706433', '1465962238', '-1');
INSERT INTO `sys_member` VALUES ('7', 'ceshi11', '0', '0000-00-00', '', '0', '0', '0', '0', '0', '0', '-1');
INSERT INTO `sys_member` VALUES ('10', 'ceshi223', '0', '0000-00-00', '', '10', '1', '0', '0', '2130706433', '1468572522', '-1');
INSERT INTO `sys_member` VALUES ('11', 'mhxy', '0', '0000-00-00', '', '10', '7', '0', '0', '3396183722', '1470993780', '1');
INSERT INTO `sys_member` VALUES ('12', 'qwe1234', '0', '0000-00-00', '', '0', '0', '0', '0', '0', '0', '-1');

-- -----------------------------
-- Table structure for `sys_menu`
-- -----------------------------
DROP TABLE IF EXISTS `sys_menu`;
CREATE TABLE `sys_menu` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '文档ID',
  `title` varchar(50) NOT NULL DEFAULT '' COMMENT '标题',
  `pp` int(11) DEFAULT '0' COMMENT '商务后台权限',
  `pid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '上级分类ID',
  `sort` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '排序（同级有效）',
  `url` char(255) NOT NULL DEFAULT '' COMMENT '链接地址',
  `hide` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '是否隐藏',
  `tip` varchar(255) NOT NULL DEFAULT '' COMMENT '提示',
  `group` varchar(50) DEFAULT '' COMMENT '分组',
  `is_dev` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '是否仅开发者模式可见',
  `status` tinyint(1) NOT NULL DEFAULT '0' COMMENT '状态',
  PRIMARY KEY (`id`),
  KEY `pid` (`pid`),
  KEY `status` (`status`)
) ENGINE=MyISAM AUTO_INCREMENT=264 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `sys_menu`
-- -----------------------------
INSERT INTO `sys_menu` VALUES ('1', '首页', '1', '0', '1', 'Index/index', '0', '', '', '0', '1');
INSERT INTO `sys_menu` VALUES ('2', '文章', '0', '0', '2', 'Article/mydocument', '0', '', '', '0', '1');
INSERT INTO `sys_menu` VALUES ('3', '文档列表', '0', '2', '0', 'article/index', '1', '', '内容', '0', '1');
INSERT INTO `sys_menu` VALUES ('4', '新增', '0', '3', '0', 'article/add', '0', '', '', '0', '1');
INSERT INTO `sys_menu` VALUES ('5', '编辑', '0', '3', '0', 'article/edit', '0', '', '', '0', '1');
INSERT INTO `sys_menu` VALUES ('6', '改变状态', '0', '3', '0', 'article/setStatus', '0', '', '', '0', '1');
INSERT INTO `sys_menu` VALUES ('7', '保存', '0', '3', '0', 'article/update', '0', '', '', '0', '1');
INSERT INTO `sys_menu` VALUES ('8', '保存草稿', '0', '3', '0', 'article/autoSave', '0', '', '', '0', '1');
INSERT INTO `sys_menu` VALUES ('9', '移动', '0', '3', '0', 'article/move', '0', '', '', '0', '1');
INSERT INTO `sys_menu` VALUES ('10', '复制', '0', '3', '0', 'article/copy', '0', '', '', '0', '1');
INSERT INTO `sys_menu` VALUES ('11', '粘贴', '0', '3', '0', 'article/paste', '0', '', '', '0', '1');
INSERT INTO `sys_menu` VALUES ('12', '导入', '0', '3', '0', 'article/batchOperate', '0', '', '', '0', '1');
INSERT INTO `sys_menu` VALUES ('13', '回收站', '0', '2', '0', 'article/recycle', '1', '', '内容', '0', '1');
INSERT INTO `sys_menu` VALUES ('14', '还原', '0', '13', '0', 'article/permit', '0', '', '', '0', '1');
INSERT INTO `sys_menu` VALUES ('15', '清空', '0', '13', '0', 'article/clear', '0', '', '', '0', '1');
INSERT INTO `sys_menu` VALUES ('16', '用户', '0', '0', '3', 'User/index', '0', '', '', '0', '1');
INSERT INTO `sys_menu` VALUES ('17', '管理员', '0', '16', '1', 'User/index', '0', '', '管理组', '0', '1');
INSERT INTO `sys_menu` VALUES ('18', '新增用户', '0', '17', '0', 'User/add', '0', '添加新用户', '', '0', '1');
INSERT INTO `sys_menu` VALUES ('19', '行为文档', '0', '16', '4', 'User/action', '0', '', '管理组', '0', '1');
INSERT INTO `sys_menu` VALUES ('20', '新增用户行为', '0', '19', '0', 'User/addaction', '0', '', '', '0', '1');
INSERT INTO `sys_menu` VALUES ('21', '编辑用户行为', '0', '19', '0', 'User/editaction', '0', '', '', '0', '1');
INSERT INTO `sys_menu` VALUES ('22', '保存用户行为', '0', '19', '0', 'User/saveAction', '0', '\"用户->用户行为\"保存编辑和新增的用户行为', '', '0', '1');
INSERT INTO `sys_menu` VALUES ('23', '变更行为状态', '0', '19', '0', 'User/setStatus', '0', '\"用户->用户行为\"中的启用,禁用和删除权限', '', '0', '1');
INSERT INTO `sys_menu` VALUES ('24', '禁用会员', '0', '19', '0', 'User/changeStatus?method=forbidUser', '0', '\"用户->用户信息\"中的禁用', '', '0', '1');
INSERT INTO `sys_menu` VALUES ('25', '启用会员', '0', '19', '0', 'User/changeStatus?method=resumeUser', '0', '\"用户->用户信息\"中的启用', '', '0', '1');
INSERT INTO `sys_menu` VALUES ('26', '删除会员', '0', '19', '0', 'User/changeStatus?method=deleteUser', '0', '\"用户->用户信息\"中的删除', '', '0', '1');
INSERT INTO `sys_menu` VALUES ('27', '角色管理', '0', '16', '2', 'AuthManager/index', '0', '', '管理组', '0', '1');
INSERT INTO `sys_menu` VALUES ('28', '删除', '0', '27', '0', 'AuthManager/changeStatus?method=deleteGroup', '0', '删除用户组', '', '0', '1');
INSERT INTO `sys_menu` VALUES ('29', '禁用', '0', '27', '0', 'AuthManager/changeStatus?method=forbidGroup', '0', '禁用用户组', '', '0', '1');
INSERT INTO `sys_menu` VALUES ('30', '恢复', '0', '27', '0', 'AuthManager/changeStatus?method=resumeGroup', '0', '恢复已禁用的用户组', '', '0', '1');
INSERT INTO `sys_menu` VALUES ('31', '新增', '0', '27', '0', 'AuthManager/createGroup', '0', '创建新的用户组', '', '0', '1');
INSERT INTO `sys_menu` VALUES ('32', '编辑', '0', '27', '0', 'AuthManager/editGroup', '0', '编辑用户组名称和描述', '', '0', '1');
INSERT INTO `sys_menu` VALUES ('33', '保存用户组', '0', '27', '0', 'AuthManager/writeGroup', '0', '新增和编辑用户组的\"保存\"按钮', '', '0', '1');
INSERT INTO `sys_menu` VALUES ('34', '授权', '0', '27', '0', 'AuthManager/group', '0', '\"后台 \\ 用户 \\ 用户信息\"列表页的\"授权\"操作按钮,用于设置用户所属用户组', '', '0', '1');
INSERT INTO `sys_menu` VALUES ('35', '访问授权', '0', '27', '0', 'AuthManager/access', '0', '\"后台 \\ 用户 \\ 权限管理\"列表页的\"访问授权\"操作按钮', '', '0', '1');
INSERT INTO `sys_menu` VALUES ('36', '成员授权', '0', '27', '0', 'AuthManager/user', '0', '\"后台 \\ 用户 \\ 权限管理\"列表页的\"成员授权\"操作按钮', '', '0', '1');
INSERT INTO `sys_menu` VALUES ('37', '解除授权', '0', '27', '0', 'AuthManager/removeFromGroup', '0', '\"成员授权\"列表页内的解除授权操作按钮', '', '0', '1');
INSERT INTO `sys_menu` VALUES ('38', '保存成员授权', '0', '27', '0', 'AuthManager/addToGroup', '0', '\"用户信息\"列表页\"授权\"时的\"保存\"按钮和\"成员授权\"里右上角的\"添加\"按钮)', '', '0', '1');
INSERT INTO `sys_menu` VALUES ('39', '分类授权', '0', '27', '0', 'AuthManager/category', '0', '\"后台 \\ 用户 \\ 权限管理\"列表页的\"分类授权\"操作按钮', '', '0', '1');
INSERT INTO `sys_menu` VALUES ('40', '保存分类授权', '0', '27', '0', 'AuthManager/addToCategory', '0', '\"分类授权\"页面的\"保存\"按钮', '', '0', '1');
INSERT INTO `sys_menu` VALUES ('41', '模型授权', '0', '27', '0', 'AuthManager/modelauth', '0', '\"后台 \\ 用户 \\ 权限管理\"列表页的\"模型授权\"操作按钮', '', '0', '1');
INSERT INTO `sys_menu` VALUES ('42', '保存模型授权', '0', '27', '0', 'AuthManager/addToModel', '0', '\"分类授权\"页面的\"保存\"按钮', '', '0', '1');
INSERT INTO `sys_menu` VALUES ('43', '扩展', '0', '0', '9', 'Addons/index', '0', '', '', '0', '1');
INSERT INTO `sys_menu` VALUES ('44', '插件管理', '0', '43', '1', 'Addons/index', '0', '', '扩展', '0', '1');
INSERT INTO `sys_menu` VALUES ('45', '创建', '0', '44', '0', 'Addons/create', '0', '服务器上创建插件结构向导', '', '0', '1');
INSERT INTO `sys_menu` VALUES ('46', '检测创建', '0', '44', '0', 'Addons/checkForm', '0', '检测插件是否可以创建', '', '0', '1');
INSERT INTO `sys_menu` VALUES ('47', '预览', '0', '44', '0', 'Addons/preview', '0', '预览插件定义类文件', '', '0', '1');
INSERT INTO `sys_menu` VALUES ('48', '快速生成插件', '0', '44', '0', 'Addons/build', '0', '开始生成插件结构', '', '0', '1');
INSERT INTO `sys_menu` VALUES ('49', '设置', '0', '44', '0', 'Addons/config', '0', '设置插件配置', '', '0', '1');
INSERT INTO `sys_menu` VALUES ('50', '禁用', '0', '44', '0', 'Addons/disable', '0', '禁用插件', '', '0', '1');
INSERT INTO `sys_menu` VALUES ('51', '启用', '0', '44', '0', 'Addons/enable', '0', '启用插件', '', '0', '1');
INSERT INTO `sys_menu` VALUES ('52', '安装', '0', '44', '0', 'Addons/install', '0', '安装插件', '', '0', '1');
INSERT INTO `sys_menu` VALUES ('53', '卸载', '0', '44', '0', 'Addons/uninstall', '0', '卸载插件', '', '0', '1');
INSERT INTO `sys_menu` VALUES ('54', '更新配置', '0', '44', '0', 'Addons/saveconfig', '0', '更新插件配置处理', '', '0', '1');
INSERT INTO `sys_menu` VALUES ('55', '插件后台列表', '0', '44', '0', 'Addons/adminList', '0', '', '', '0', '1');
INSERT INTO `sys_menu` VALUES ('56', 'URL方式访问插件', '0', '44', '0', 'Addons/execute', '0', '控制是否有权限通过url访问插件控制器方法', '', '0', '1');
INSERT INTO `sys_menu` VALUES ('57', '钩子管理', '0', '43', '2', 'Addons/hooks', '0', '', '扩展', '0', '1');
INSERT INTO `sys_menu` VALUES ('58', '模型管理', '0', '68', '8', 'Model/index', '0', '', '系统设置', '0', '1');
INSERT INTO `sys_menu` VALUES ('59', '新增', '0', '58', '0', 'model/add', '0', '', '', '0', '1');
INSERT INTO `sys_menu` VALUES ('60', '编辑', '0', '58', '0', 'model/edit', '0', '', '', '0', '1');
INSERT INTO `sys_menu` VALUES ('61', '改变状态', '0', '58', '0', 'model/setStatus', '0', '', '', '0', '1');
INSERT INTO `sys_menu` VALUES ('62', '保存数据', '0', '58', '0', 'model/update', '0', '', '', '0', '1');
INSERT INTO `sys_menu` VALUES ('63', '属性管理', '0', '68', '1', 'Attribute/index', '1', '网站属性配置。', '', '0', '1');
INSERT INTO `sys_menu` VALUES ('64', '新增', '0', '63', '0', 'Attribute/add', '0', '', '', '0', '1');
INSERT INTO `sys_menu` VALUES ('65', '编辑', '0', '63', '0', 'Attribute/edit', '0', '', '', '0', '1');
INSERT INTO `sys_menu` VALUES ('66', '改变状态', '0', '63', '0', 'Attribute/setStatus', '0', '', '', '0', '1');
INSERT INTO `sys_menu` VALUES ('67', '保存数据', '0', '63', '0', 'Attribute/update', '0', '', '', '0', '1');
INSERT INTO `sys_menu` VALUES ('68', '系统', '0', '0', '8', 'Config/group', '0', '', '', '0', '1');
INSERT INTO `sys_menu` VALUES ('69', '网站设置', '0', '68', '6', 'Config/group', '0', '', '系统设置', '0', '1');
INSERT INTO `sys_menu` VALUES ('70', '配置管理', '0', '68', '9', 'Config/index', '0', '', '系统设置', '0', '1');
INSERT INTO `sys_menu` VALUES ('71', '编辑', '0', '70', '0', 'Config/edit', '0', '新增编辑和保存配置', '', '0', '1');
INSERT INTO `sys_menu` VALUES ('72', '删除', '0', '70', '0', 'Config/del', '0', '删除配置', '', '0', '1');
INSERT INTO `sys_menu` VALUES ('73', '新增', '0', '70', '0', 'Config/add', '0', '新增配置', '', '0', '1');
INSERT INTO `sys_menu` VALUES ('74', '保存', '0', '70', '0', 'Config/save', '0', '保存配置', '', '0', '1');
INSERT INTO `sys_menu` VALUES ('75', '菜单管理', '0', '68', '10', 'Menu/index', '0', '', '系统设置', '0', '1');
INSERT INTO `sys_menu` VALUES ('76', '导航管理', '0', '68', '11', 'Channel/index', '0', '', '系统设置', '0', '1');
INSERT INTO `sys_menu` VALUES ('77', '新增', '0', '76', '0', 'Channel/add', '0', '', '', '0', '1');
INSERT INTO `sys_menu` VALUES ('78', '编辑', '0', '76', '0', 'Channel/edit', '0', '', '', '0', '1');
INSERT INTO `sys_menu` VALUES ('79', '删除', '0', '76', '0', 'Channel/del', '0', '', '', '0', '1');
INSERT INTO `sys_menu` VALUES ('80', '分类管理', '0', '68', '7', 'Category/index', '0', '', '系统设置', '0', '1');
INSERT INTO `sys_menu` VALUES ('81', '编辑', '0', '80', '0', 'Category/edit', '0', '编辑和保存栏目分类', '', '0', '1');
INSERT INTO `sys_menu` VALUES ('82', '新增', '0', '80', '0', 'Category/add', '0', '新增栏目分类', '', '0', '1');
INSERT INTO `sys_menu` VALUES ('83', '删除', '0', '80', '0', 'Category/remove', '0', '删除栏目分类', '', '0', '1');
INSERT INTO `sys_menu` VALUES ('84', '移动', '0', '80', '0', 'Category/operate/type/move', '0', '移动栏目分类', '', '0', '1');
INSERT INTO `sys_menu` VALUES ('85', '合并', '0', '80', '0', 'Category/operate/type/merge', '0', '合并栏目分类', '', '0', '1');
INSERT INTO `sys_menu` VALUES ('86', '备份数据库', '0', '68', '2', 'Database/index?type=export', '0', '', '数据备份', '0', '1');
INSERT INTO `sys_menu` VALUES ('87', '备份', '0', '86', '0', 'Database/export', '0', '备份数据库', '', '0', '1');
INSERT INTO `sys_menu` VALUES ('88', '优化表', '0', '86', '0', 'Database/optimize', '0', '优化数据表', '', '0', '1');
INSERT INTO `sys_menu` VALUES ('89', '修复表', '0', '86', '0', 'Database/repair', '0', '修复数据表', '', '0', '1');
INSERT INTO `sys_menu` VALUES ('90', '还原数据库', '0', '68', '3', 'Database/index?type=import', '0', '', '数据备份', '0', '1');
INSERT INTO `sys_menu` VALUES ('91', '恢复', '0', '90', '0', 'Database/import', '0', '数据库恢复', '', '0', '1');
INSERT INTO `sys_menu` VALUES ('92', '删除', '0', '90', '0', 'Database/del', '0', '删除备份文件', '', '0', '1');
INSERT INTO `sys_menu` VALUES ('93', '其他', '0', '0', '10', 'other', '1', '', '', '0', '1');
INSERT INTO `sys_menu` VALUES ('96', '新增', '0', '75', '0', 'Menu/add', '0', '', '系统设置', '0', '1');
INSERT INTO `sys_menu` VALUES ('98', '编辑', '0', '75', '0', 'Menu/edit', '0', '', '', '0', '1');
INSERT INTO `sys_menu` VALUES ('106', '行为日志', '0', '16', '3', 'Action/actionlog', '0', '', '管理组', '0', '1');
INSERT INTO `sys_menu` VALUES ('108', '修改密码', '0', '16', '5', 'User/updatePassword', '1', '', '', '0', '1');
INSERT INTO `sys_menu` VALUES ('109', '修改昵称', '0', '16', '6', 'User/updateNickname', '1', '', '', '0', '1');
INSERT INTO `sys_menu` VALUES ('110', '查看行为日志', '0', '106', '0', 'action/edit', '1', '', '', '0', '1');
INSERT INTO `sys_menu` VALUES ('112', '新增数据', '0', '58', '0', 'think/add', '1', '', '', '0', '1');
INSERT INTO `sys_menu` VALUES ('113', '编辑数据', '0', '58', '0', 'think/edit', '1', '', '', '0', '1');
INSERT INTO `sys_menu` VALUES ('114', '导入', '0', '75', '0', 'Menu/import', '0', '', '', '0', '1');
INSERT INTO `sys_menu` VALUES ('115', '生成', '0', '58', '0', 'Model/generate', '0', '', '', '0', '1');
INSERT INTO `sys_menu` VALUES ('116', '新增钩子', '0', '57', '0', 'Addons/addHook', '0', '', '', '0', '1');
INSERT INTO `sys_menu` VALUES ('117', '编辑钩子', '0', '57', '0', 'Addons/edithook', '0', '', '', '0', '1');
INSERT INTO `sys_menu` VALUES ('118', '文档排序', '0', '3', '0', 'Article/sort', '1', '', '', '0', '1');
INSERT INTO `sys_menu` VALUES ('119', '排序', '0', '70', '0', 'Config/sort', '1', '', '', '0', '1');
INSERT INTO `sys_menu` VALUES ('120', '排序', '0', '75', '0', 'Menu/sort', '1', '', '', '0', '1');
INSERT INTO `sys_menu` VALUES ('121', '排序', '0', '76', '0', 'Channel/sort', '1', '', '', '0', '1');
INSERT INTO `sys_menu` VALUES ('122', '数据列表', '0', '58', '0', 'think/lists', '1', '', '', '0', '1');
INSERT INTO `sys_menu` VALUES ('123', '审核列表', '0', '3', '0', 'Article/examine', '1', '', '', '0', '1');
INSERT INTO `sys_menu` VALUES ('124', '游戏', '1', '0', '4', 'Game/lists', '0', '游戏管理', '游戏管理', '0', '1');
INSERT INTO `sys_menu` VALUES ('125', '游戏管理', '1', '124', '1', 'Game/lists', '0', '游戏管理', '游戏管理', '0', '1');
INSERT INTO `sys_menu` VALUES ('126', '新增', '0', '125', '0', 'Game/add', '0', '新增游戏', '', '0', '1');
INSERT INTO `sys_menu` VALUES ('127', '编辑', '0', '125', '0', 'Game/edit', '0', '编辑游戏', '', '0', '1');
INSERT INTO `sys_menu` VALUES ('128', '游戏分类', '0', '124', '2', 'GameType/lists', '0', '游戏类型管理', '游戏管理', '0', '1');
INSERT INTO `sys_menu` VALUES ('129', '新增', '0', '128', '0', 'GameType/add', '0', '新增游戏类型', '', '0', '1');
INSERT INTO `sys_menu` VALUES ('130', '编辑', '0', '128', '0', 'GameType/edit', '0', '编辑游戏类型', '', '0', '1');
INSERT INTO `sys_menu` VALUES ('131', '游戏区服', '0', '124', '3', 'Server/lists', '0', '游戏区服', '游戏管理', '0', '1');
INSERT INTO `sys_menu` VALUES ('132', '新增', '0', '131', '0', 'Server/add', '0', '新增区服', '', '0', '1');
INSERT INTO `sys_menu` VALUES ('133', '编辑', '0', '131', '0', 'Server/edit', '0', '编辑游戏区服', '', '0', '1');
INSERT INTO `sys_menu` VALUES ('134', '礼包管理', '0', '124', '5', 'Giftbag/lists', '0', '礼包管理', '礼包管理', '0', '1');
INSERT INTO `sys_menu` VALUES ('135', '领取记录', '0', '124', '6', 'Giftbag/record', '0', '礼包管理', '礼包管理', '0', '1');
INSERT INTO `sys_menu` VALUES ('136', '新增', '0', '134', '0', 'Giftbag/add', '0', '新增礼包', '', '0', '1');
INSERT INTO `sys_menu` VALUES ('137', '编辑', '0', '134', '0', 'Giftbag/edit', '0', '礼包管理', '', '0', '1');
INSERT INTO `sys_menu` VALUES ('138', '渠道', '1', '0', '5', 'Promote/lists', '0', '渠道管理', '渠道管理', '0', '1');
INSERT INTO `sys_menu` VALUES ('139', '渠道管理', '1', '138', '1', 'Promote/lists', '0', '渠道管理', '渠道管理', '0', '1');
INSERT INTO `sys_menu` VALUES ('140', '新增', '0', '139', '0', 'Promote/add', '0', '新增渠道', '', '0', '1');
INSERT INTO `sys_menu` VALUES ('141', '编辑', '0', '139', '0', 'Promote/edit', '0', '编辑渠道', '', '0', '1');
INSERT INTO `sys_menu` VALUES ('142', '渠道补链', '0', '138', '2', 'Mend/lists', '0', '渠道补链', '渠道管理', '0', '1');
INSERT INTO `sys_menu` VALUES ('143', '补链记录', '0', '138', '3', 'Mend/record', '0', '补链记录', '渠道管理', '0', '1');
INSERT INTO `sys_menu` VALUES ('144', '渠道注册', '1', '138', '4', 'Promote/ch_reg_list', '0', '渠道注册用户', '渠道数据', '0', '1');
INSERT INTO `sys_menu` VALUES ('145', '渠道充值', '1', '138', '6', 'Promote/spend_list', '0', '', '渠道数据', '0', '1');
INSERT INTO `sys_menu` VALUES ('146', '代充记录', '1', '138', '7', 'Promote/agent_list', '0', '', '渠道数据', '0', '1');
INSERT INTO `sys_menu` VALUES ('147', '代充额度', '0', '138', '8', 'Promote/pay_limit', '0', '', '渠道数据', '0', '1');
INSERT INTO `sys_menu` VALUES ('148', '渠道对账', '1', '138', '9', 'Query/bill', '0', '', '渠道对账', '0', '1');
INSERT INTO `sys_menu` VALUES ('149', '渠道结算', '0', '138', '10', 'Query/settlement', '0', '', '渠道对账', '0', '1');
INSERT INTO `sys_menu` VALUES ('150', '渠道提现', '0', '138', '11', 'Query/withdraw', '0', '', '渠道对账', '0', '1');
INSERT INTO `sys_menu` VALUES ('151', '平台用户', '0', '16', '7', 'Member/user_info', '0', '', '用户组', '0', '1');
INSERT INTO `sys_menu` VALUES ('152', '登陆记录', '0', '16', '8', 'Member/login_record', '0', '', '用户组', '0', '1');
INSERT INTO `sys_menu` VALUES ('153', 'SDK充值记录', '0', '16', '9', 'Spend/lists', '0', '', '充值组', '0', '1');
INSERT INTO `sys_menu` VALUES ('154', '平台币充值记录', '0', '16', '10', 'Deposit/lists', '0', '', '充值组', '0', '1');
INSERT INTO `sys_menu` VALUES ('155', '后台充值记录', '0', '16', '12', 'Provide/lists', '0', '', '充值组', '0', '1');
INSERT INTO `sys_menu` VALUES ('156', '绑币使用记录', '0', '16', '13', 'BindSpend/lists', '0', '', '充值组', '0', '1');
INSERT INTO `sys_menu` VALUES ('157', '站点', '0', '0', '6', 'Site/media', '0', '', '', '0', '1');
INSERT INTO `sys_menu` VALUES ('158', '基本配置', '0', '157', '1', 'Site/media', '0', '媒体官网的基本配置', '媒体官网', '0', '1');
INSERT INTO `sys_menu` VALUES ('159', '广告管理', '0', '157', '2', 'Adv/media_adv_pos_lists', '0', '', '媒体官网', '0', '1');
INSERT INTO `sys_menu` VALUES ('160', '统计', '0', '0', '7', 'Stat/daily', '0', '统计模块', '', '0', '1');
INSERT INTO `sys_menu` VALUES ('161', '基本配置', '0', '157', '4', 'Site/app', '0', '', 'APP管理', '0', '1');
INSERT INTO `sys_menu` VALUES ('162', '基本配置', '0', '157', '8', 'Site/channel', '0', '', '渠道站管理', '0', '1');
INSERT INTO `sys_menu` VALUES ('163', '广告管理', '0', '157', '5', 'Adv/app_adv_pos_lists', '0', '', 'APP管理', '0', '1');
INSERT INTO `sys_menu` VALUES ('164', '编辑媒体广告位', '0', '159', '0', 'Adv/edit_media_adv_pos', '0', '编辑媒体广告位', '', '0', '1');
INSERT INTO `sys_menu` VALUES ('165', '编辑app广告位', '0', '163', '0', 'Adv/edit_app_adv_pos', '0', '编辑app广告位', '', '0', '1');
INSERT INTO `sys_menu` VALUES ('166', '媒体广告列表', '0', '159', '0', 'Adv/media_adv_lists', '0', '媒体广告列表', '', '0', '1');
INSERT INTO `sys_menu` VALUES ('167', '编辑媒体广告', '0', '159', '0', 'Adv/edit_media_adv', '0', '编辑媒体广告', '', '0', '1');
INSERT INTO `sys_menu` VALUES ('168', '新增媒体广告', '0', '159', '0', 'Adv/add_media_adv', '0', '新增媒体广告', '', '0', '1');
INSERT INTO `sys_menu` VALUES ('169', 'app广告列表', '0', '163', '0', 'Adv/app_adv_lists', '0', 'app广告列表', '', '0', '1');
INSERT INTO `sys_menu` VALUES ('170', '新增app广告', '0', '163', '0', 'Adv/add_app_adv', '0', '新增app广告', '', '0', '1');
INSERT INTO `sys_menu` VALUES ('171', '编辑app广告', '0', '163', '0', 'Adv/edit_app_adv', '0', '编辑app广告', '', '0', '1');
INSERT INTO `sys_menu` VALUES ('172', '广告列表', '0', '157', '6', 'Adv/adv_lists', '0', '', '广告列表', '0', '1');
INSERT INTO `sys_menu` VALUES ('173', '编辑', '0', '172', '0', 'Adv/edit_adv', '0', '编辑广告', '', '0', '1');
INSERT INTO `sys_menu` VALUES ('174', '图标设置', '0', '157', '3', 'Logo/media_logo', '0', '', '媒体官网', '0', '1');
INSERT INTO `sys_menu` VALUES ('175', '图标设置', '0', '157', '7', 'Logo/app_logo', '0', '', 'APP管理', '0', '1');
INSERT INTO `sys_menu` VALUES ('176', '图标设置', '0', '157', '9', 'Logo/channel_logo', '0', '', '渠道站管理', '0', '1');
INSERT INTO `sys_menu` VALUES ('177', '短信设置', '0', '68', '12', 'Tool/smsset', '0', '', '扩展工具', '0', '1');
INSERT INTO `sys_menu` VALUES ('178', '文件存储', '0', '68', '13', 'Tool/storage', '0', '', '扩展工具', '0', '1');
INSERT INTO `sys_menu` VALUES ('179', '支付设置', '0', '68', '14', 'Tool/payset', '0', '', '扩展工具', '0', '1');
INSERT INTO `sys_menu` VALUES ('180', '第三方登陆', '0', '68', '16', 'Tool/thirdparty', '0', '', '扩展工具', '0', '1');
INSERT INTO `sys_menu` VALUES ('181', '邮件设置', '0', '68', '15', 'Tool/email', '0', '', '扩展工具', '0', '1');
INSERT INTO `sys_menu` VALUES ('182', '日常统计', '0', '160', '1', 'Stat/daily', '0', '', '日常统计', '0', '1');
INSERT INTO `sys_menu` VALUES ('183', '来款统计', '0', '160', '2', 'stat/pay_way', '0', '', '日常统计', '0', '1');
INSERT INTO `sys_menu` VALUES ('184', '登陆统计', '0', '160', '3', 'stat/cpa_login', '0', '', 'CPS统计', '0', '1');
INSERT INTO `sys_menu` VALUES ('185', '注册统计', '0', '160', '4', 'stat/cpa_register', '0', '', 'CPS统计', '0', '1');
INSERT INTO `sys_menu` VALUES ('186', '消费统计', '0', '160', '5', 'stat/cpa_spend', '0', '', 'CPS统计', '0', '1');
INSERT INTO `sys_menu` VALUES ('187', '留存统计', '0', '160', '6', 'stat/userretention', '0', '', '运营分析', '0', '1');
INSERT INTO `sys_menu` VALUES ('188', 'ARPU统计', '1', '160', '7', 'stat/userarpu', '0', '', '运营分析', '0', '1');
INSERT INTO `sys_menu` VALUES ('189', '游戏原包', '1', '124', '4', 'GameSource/lists', '0', '', '游戏管理', '0', '1');
INSERT INTO `sys_menu` VALUES ('190', '新增', '0', '189', '0', 'GameSource/add', '0', '上传游戏原包', '', '0', '1');
INSERT INTO `sys_menu` VALUES ('191', '编辑', '0', '189', '0', 'GameSource/edit', '0', '编辑游戏原包', '', '0', '1');
INSERT INTO `sys_menu` VALUES ('192', '渠道补链', '0', '142', '0', 'Mend/edit', '0', '', '', '0', '1');
INSERT INTO `sys_menu` VALUES ('194', '用户编辑', '0', '151', '0', 'Member/edit', '0', '', '平台用户', '0', '1');
INSERT INTO `sys_menu` VALUES ('195', '分包管理', '1', '138', '4', 'Apply/lists', '0', '', '渠道管理', '0', '1');
INSERT INTO `sys_menu` VALUES ('196', '编辑', '1', '195', '0', 'Apply/edit', '0', '', '分包管理', '0', '1');
INSERT INTO `sys_menu` VALUES ('197', '提现添加', '0', '150', '0', 'Query/withdraw_add', '0', '', '渠道提现', '0', '1');
INSERT INTO `sys_menu` VALUES ('199', '礼包类型', '0', '124', '7', 'GiftbagType/lists', '1', '', '礼包管理', '0', '1');
INSERT INTO `sys_menu` VALUES ('200', '后台充值', '0', '16', '11', 'Provide/bdfirstpay', '0', '', '充值组', '0', '1');
INSERT INTO `sys_menu` VALUES ('201', '编辑', '0', '199', '1', 'GiftbagType/edit', '0', '', '礼包类型', '0', '1');
INSERT INTO `sys_menu` VALUES ('202', '新增', '0', '199', '0', 'GiftbagType/add', '0', '', '礼包类型', '0', '1');
INSERT INTO `sys_menu` VALUES ('204', 'PC友情链接', '0', '157', '4', 'Links/pclists', '0', '', '媒体官网', '0', '1');
INSERT INTO `sys_menu` VALUES ('205', '新增', '0', '204', '0', 'Links/add', '0', '', '友情链接', '0', '1');
INSERT INTO `sys_menu` VALUES ('206', '编辑', '0', '204', '0', 'Links/edit', '0', '', '友情链接', '0', '1');
INSERT INTO `sys_menu` VALUES ('208', '新增', '0', '147', '0', 'Promote/pay_limit_add', '0', '', '代充额度', '0', '1');
INSERT INTO `sys_menu` VALUES ('209', '编辑', '0', '147', '0', 'Promote/pay_limit_edit', '0', '', '代充额度', '0', '1');
INSERT INTO `sys_menu` VALUES ('257', '友情链接', '0', '157', '0', 'Links/chlists', '0', '', '渠道站管理', '0', '1');
INSERT INTO `sys_menu` VALUES ('211', '纠错管理', '0', '124', '5', 'Message/wrong', '0', '', '游戏管理', '0', '1');
INSERT INTO `sys_menu` VALUES ('218', '返利设置', '0', '124', '0', 'Rebate/lists', '0', '', '返利管理', '0', '1');
INSERT INTO `sys_menu` VALUES ('213', '新增', '0', '212', '0', 'Game/addopen', '0', '', '开放类型', '0', '1');
INSERT INTO `sys_menu` VALUES ('214', '编辑', '0', '212', '1', 'Game/editopen', '0', '', '开发类型', '0', '1');
INSERT INTO `sys_menu` VALUES ('215', '开放类型', '0', '124', '0', 'Opentype/lists', '0', '', '游戏管理', '0', '1');
INSERT INTO `sys_menu` VALUES ('216', '新增', '0', '215', '0', 'Opentype/add', '0', '', '', '0', '1');
INSERT INTO `sys_menu` VALUES ('217', '修改', '0', '215', '0', 'Opentype/edit', '0', '', '', '0', '1');
INSERT INTO `sys_menu` VALUES ('219', '游戏返利', '0', '124', '1', 'Rebatelist/lists', '0', '', '返利管理', '0', '1');
INSERT INTO `sys_menu` VALUES ('220', '新增', '0', '218', '0', 'Rebate/add', '0', '', '', '0', '1');
INSERT INTO `sys_menu` VALUES ('221', '编辑', '0', '218', '0', 'Rebate/edit', '0', '', '', '0', '1');
INSERT INTO `sys_menu` VALUES ('222', '打包', '0', '195', '0', 'Apply/package', '0', '', '分包管理', '0', '1');
INSERT INTO `sys_menu` VALUES ('223', '推送设置', '0', '68', '4', 'Push/pushsetlsit', '0', '', '极光推送', '0', '1');
INSERT INTO `sys_menu` VALUES ('224', '新增', '0', '223', '0', 'Push/add', '0', '', '', '0', '1');
INSERT INTO `sys_menu` VALUES ('225', '编辑', '0', '223', '0', 'Push/edit', '0', '', '', '0', '1');
INSERT INTO `sys_menu` VALUES ('226', '发送通知', '0', '68', '5', 'Push/pushlist', '0', '', '极光推送', '0', '1');
INSERT INTO `sys_menu` VALUES ('227', '新增', '0', '226', '0', 'push/add_list', '0', '', '', '0', '1');
INSERT INTO `sys_menu` VALUES ('228', '编辑', '0', '226', '0', 'push/edit_list', '0', '', '', '0', '1');
INSERT INTO `sys_menu` VALUES ('229', '审核', '0', '195', '0', 'Apply/set_status', '0', '', '', '0', '1');
INSERT INTO `sys_menu` VALUES ('230', '启用', '0', '17', '0', 'User/changeStatus?method=resumeUser', '0', '', '', '0', '1');
INSERT INTO `sys_menu` VALUES ('231', '禁用', '0', '17', '0', 'User/changeStatus?method=forbidUser', '0', '', '', '0', '1');
INSERT INTO `sys_menu` VALUES ('232', '删除', '0', '17', '0', 'User/changeStatus?method=deleteUser', '0', '', '', '0', '1');
INSERT INTO `sys_menu` VALUES ('233', '清除', '0', '106', '0', 'Action/clear', '0', '', '', '0', '1');
INSERT INTO `sys_menu` VALUES ('234', '删除', '0', '106', '0', 'Action/remove', '0', '', '', '0', '1');
INSERT INTO `sys_menu` VALUES ('235', '删除', '0', '152', '0', 'Member/del', '0', '', '', '0', '1');
INSERT INTO `sys_menu` VALUES ('236', '充值', '0', '155', '0', 'Provide/batch', '0', '', '', '0', '1');
INSERT INTO `sys_menu` VALUES ('237', '删除', '0', '155', '0', 'Provide/delprovide', '0', '', '', '0', '1');
INSERT INTO `sys_menu` VALUES ('238', '删除', '0', '125', '0', 'Game/del', '0', '', '', '0', '1');
INSERT INTO `sys_menu` VALUES ('239', '排序', '0', '125', '0', 'Game/sort', '0', '', '', '0', '1');
INSERT INTO `sys_menu` VALUES ('240', '推荐/不推荐', '0', '125', '0', 'Game/set_status', '0', '', '', '0', '1');
INSERT INTO `sys_menu` VALUES ('241', '删除', '0', '219', '0', 'Rebatelist/del', '0', '', '', '0', '1');
INSERT INTO `sys_menu` VALUES ('242', '启用/禁用', '0', '128', '0', 'GameType/set_status', '0', '', '', '0', '1');
INSERT INTO `sys_menu` VALUES ('243', '修复', '0', '211', '0', 'Message/set_status', '0', '', '', '0', '1');
INSERT INTO `sys_menu` VALUES ('244', '审核/拉黑', '0', '139', '0', 'Promote/set_status', '0', '', '', '0', '1');
INSERT INTO `sys_menu` VALUES ('245', '锁定/解锁', '0', '144', '0', 'Promote/set_status', '0', '', '', '0', '1');
INSERT INTO `sys_menu` VALUES ('246', '结算', '0', '149', '0', 'Query/settl', '0', '', '', '0', '1');
INSERT INTO `sys_menu` VALUES ('247', '启用/禁用', '0', '159', '0', 'Adv/set_status', '0', '', '', '0', '1');
INSERT INTO `sys_menu` VALUES ('248', '删除', '0', '204', '0', 'Links/del', '0', '', '', '0', '1');
INSERT INTO `sys_menu` VALUES ('249', '启用', '0', '163', '0', 'Adv/set_status', '0', '', '', '0', '1');
INSERT INTO `sys_menu` VALUES ('250', '删除', '0', '172', '0', 'Adv/del_adv', '0', '', '', '0', '1');
INSERT INTO `sys_menu` VALUES ('251', '公众号设置', '0', '68', '17', 'Wechat/index', '0', '', '扩展工具', '0', '1');
INSERT INTO `sys_menu` VALUES ('252', '上传文件', '0', '189', '0', 'File/shard_upload', '0', '', '', '0', '1');
INSERT INTO `sys_menu` VALUES ('253', '编辑', '0', '17', '0', 'User/edit', '0', '', '管理员', '0', '1');
INSERT INTO `sys_menu` VALUES ('254', '未修复', '0', '211', '0', 'Message/set_status', '0', '', '', '0', '1');
INSERT INTO `sys_menu` VALUES ('255', '删除', '0', '218', '0', 'Rebate/del', '0', '', '', '0', '1');
INSERT INTO `sys_menu` VALUES ('256', '删除', '0', '134', '0', 'Giftbag/del', '0', '', '', '0', '1');
INSERT INTO `sys_menu` VALUES ('258', '删除', '0', '131', '0', 'Server/del', '0', '', '', '0', '1');
INSERT INTO `sys_menu` VALUES ('259', '删除', '0', '195', '0', 'Apply/del', '0', '', '', '0', '1');
INSERT INTO `sys_menu` VALUES ('260', '删除', '0', '189', '0', 'GameSource/del', '0', '', '', '0', '1');
INSERT INTO `sys_menu` VALUES ('261', '渠道结算', '0', '138', '0', 'Query/cpsettlement', '0', '', 'CP结算', '0', '1');
INSERT INTO `sys_menu` VALUES ('262', 'SEO搜索', '0', '157', '0', 'Seo/media', '0', '', '媒体官网', '0', '1');
INSERT INTO `sys_menu` VALUES ('263', ' 	SEO搜索', '0', '157', '0', 'Seo/channel', '0', '', '渠道站管理', '0', '1');

-- -----------------------------
-- Table structure for `sys_model`
-- -----------------------------
DROP TABLE IF EXISTS `sys_model`;
CREATE TABLE `sys_model` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '模型ID',
  `name` char(30) NOT NULL DEFAULT '' COMMENT '模型标识',
  `title` char(30) NOT NULL DEFAULT '' COMMENT '模型名称',
  `extend` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '继承的模型',
  `relation` varchar(30) NOT NULL DEFAULT '' COMMENT '继承与被继承模型的关联字段',
  `need_pk` tinyint(1) unsigned NOT NULL DEFAULT '1' COMMENT '新建表时是否需要主键字段',
  `field_sort` text COMMENT '表单字段排序',
  `field_group` varchar(255) NOT NULL DEFAULT '1:基础' COMMENT '字段分组',
  `attribute_list` text COMMENT '属性列表（表的字段）',
  `attribute_alias` varchar(255) NOT NULL DEFAULT '' COMMENT '属性别名定义',
  `template_list` varchar(100) NOT NULL DEFAULT '' COMMENT '列表模板',
  `template_add` varchar(100) NOT NULL DEFAULT '' COMMENT '新增模板',
  `template_edit` varchar(100) NOT NULL DEFAULT '' COMMENT '编辑模板',
  `list_grid` text COMMENT '列表定义',
  `list_row` smallint(2) unsigned NOT NULL DEFAULT '10' COMMENT '列表数据长度',
  `search_key` varchar(50) NOT NULL DEFAULT '' COMMENT '默认搜索字段',
  `search_list` varchar(255) NOT NULL DEFAULT '' COMMENT '高级搜索的字段',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `status` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '状态',
  `engine_type` varchar(25) NOT NULL DEFAULT 'MyISAM' COMMENT '数据库引擎',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=41 DEFAULT CHARSET=utf8 COMMENT='文档模型表';

-- -----------------------------
-- Records of `sys_model`
-- -----------------------------
INSERT INTO `sys_model` VALUES ('1', 'document', '基础文档', '0', '', '1', '{\"1\":[\"2\",\"3\",\"5\",\"9\",\"10\",\"11\",\"12\",\"13\",\"14\",\"16\",\"17\",\"19\",\"20\"]}', '1:基础', '', '', '', '', '', 'id:编号\r\ntitle:标题:[EDIT]\r\ntype:类型\r\nupdate_time:最后更新\r\nstatus:状态\r\nadmin|get_admin_name:创建者\r\nview:浏览\r\nid:操作:[EDIT]|编辑,[DELETE]|删除', '0', '', '', '1383891233', '1465377046', '1', 'MyISAM');
INSERT INTO `sys_model` VALUES ('2', 'article', '文章', '1', '', '1', '{\"1\":[\"3\",\"24\",\"2\",\"5\"],\"2\":[\"9\",\"13\",\"19\",\"10\",\"12\",\"16\",\"17\",\"26\",\"20\",\"14\",\"11\",\"25\"]}', '1:基础,2:扩展', '', '', '', '', '', '', '0', '', '', '1383891243', '1387260622', '1', 'MyISAM');
INSERT INTO `sys_model` VALUES ('3', 'download', '下载', '1', '', '1', '{\"1\":[\"3\",\"28\",\"30\",\"32\",\"2\",\"5\",\"31\"],\"2\":[\"13\",\"10\",\"27\",\"9\",\"12\",\"16\",\"17\",\"19\",\"11\",\"20\",\"14\",\"29\"]}', '1:基础,2:扩展', '', '', '', '', '', '', '0', '', '', '1383891252', '1387260449', '1', 'MyISAM');
INSERT INTO `sys_model` VALUES ('4', 'game', '游戏', '0', '', '1', '{\"1\":[\"53\",\"54\",\"52\",\"51\",\"49\",\"50\",\"55\",\"56\",\"60\",\"61\",\"59\",\"58\",\"57\",\"48\",\"47\",\"38\",\"39\",\"37\",\"36\",\"34\",\"35\",\"40\",\"41\",\"45\",\"46\",\"44\",\"43\",\"42\",\"33\",\"395\"]}', '1:基础', '', '', '', '', '', 'id:编号\r\nsort:排序\r\ngame_name:游戏名称\r\ngame_type_name:游戏类型\r\ngame_appid:游戏appid\r\ngame_status|get_info_status:显示状态\r\nrecommend_status|get_info_status*1:推荐状态\r\nid:操作:[EDIT]&id=[id]|编辑,Game/del?ids=[id]|删除', '10', 'game_name', 'game_name', '1463664513', '1469441863', '1', 'MyISAM');
INSERT INTO `sys_model` VALUES ('5', 'GameType', '游戏类型', '0', '', '1', '{\"1\":[\"66\",\"67\",\"65\",\"64\",\"63\",\"62\"]}', '1:基础', '', '', '', '', '', 'id:编号\r\ntype_name:游戏类型\r\nstatus_show|get_info_status*8:显示状态\r\nop_nickname:操作人\r\ncreate_time|set_show_time:添加时间\r\nid:操作:[EDIT]&id=[id]|编辑,GameType/del?ids=[id]|删除', '10', 'type_name', '', '1463968087', '1463982517', '1', 'MyISAM');
INSERT INTO `sys_model` VALUES ('6', 'Server', '游戏区服', '0', '', '1', '{\"1\":[\"77\",\"76\",\"78\",\"79\",\"81\",\"80\",\"75\",\"74\",\"70\",\"69\",\"71\",\"72\",\"73\",\"68\"]}', '1:基础', '', '', '', '', '', 'id:编号\r\ngame_name:游戏名称\r\nserver_name:区服名称\r\nshow_status|get_info_status:区服状态\r\nstart_time|set_show_time:开服时间\r\nid:操作:[EDIT]&id=[id]|编辑,Server/del?ids=[id]|删除', '10', 'server_name', '', '1463982982', '1465353647', '1', 'MyISAM');
INSERT INTO `sys_model` VALUES ('7', 'giftbag', '礼包管理', '0', '', '1', '{\"1\":[\"94\",\"93\",\"92\",\"95\",\"96\",\"98\",\"97\",\"91\",\"90\",\"85\",\"84\",\"83\",\"86\",\"87\",\"89\",\"88\",\"82\"]}', '1:基础', '', '', '', '', '', 'id:编号\r\ngame_name:游戏名称\r\ngiftbag_name:礼包名称\r\nnovice|arr_count:剩余数量\r\nstatus|get_info_status:状态\r\nid:操作:[EDIT]&id=[id]|编辑,Giftbag/del?ids=[id]|删除', '10', 'giftbag_name', '', '1463985936', '1465356043', '1', 'MyISAM');
INSERT INTO `sys_model` VALUES ('8', 'GiftRecord', '礼包记录', '0', '', '1', '{\"1\":[\"107\",\"106\",\"108\",\"109\",\"110\",\"105\",\"104\",\"100\",\"101\",\"102\",\"103\",\"99\"]}', '1:基础', '', '', '', '', '', 'id:编号\r\ngame_name:游戏名称\r\ngift_name:礼包名称\r\nuser_id|get_user_account:用户账号\r\nnovice:礼包卡号\r\ncreate_time|set_show_time*time:领取时间', '10', 'game_name', '', '1463987676', '1465874967', '1', 'MyISAM');
INSERT INTO `sys_model` VALUES ('9', 'promote', '渠道管理', '0', '', '1', '{\"1\":[\"123\",\"122\",\"121\",\"124\",\"125\",\"128\",\"127\",\"126\",\"120\",\"119\",\"114\",\"113\",\"112\",\"115\",\"116\",\"118\",\"117\",\"111\"]}', '1:基础', '', '', '', '', '', 'id:渠道ID\r\naccount:渠道账号\r\nadmin_id|get_admin_nickname:所属专员\r\nreal_name:姓名\r\nmobile_phone:手机\r\nparent_id|get_top_promote|id:上线渠道\r\nstatus|get_info_status*3:状态\r\nparent_id|get_qu_promote:渠道等级\r\ncreate_time|set_show_time:注册时间\r\nlast_login_time|set_show_time:最后登陆时间\r\nid:操作:[EDIT]&id=[id]|查看', '10', '', '', '1463989240', '1469168754', '1', 'MyISAM');
INSERT INTO `sys_model` VALUES ('10', 'mend', '补链管理', '0', '', '1', '{\"1\":[\"136\",\"137\",\"138\",\"139\",\"135\",\"134\",\"130\",\"131\",\"132\",\"133\",\"129\"]}', '1:基础', '', '', '', '', '', 'id:编号\r\nuser_account:账号\r\nuser_nickname:昵称\r\npromote_id:推广员编号\r\npromote_account:推广员账号\r\npromote_id_to:修改后编号\r\npromote_account_to:修改后账号\r\ncreate_time:时间\r\nop_account:操作人账号', '10', '', '', '1463997570', '1464332332', '1', 'MyISAM');
INSERT INTO `sys_model` VALUES ('11', 'user', '用户信息', '0', '', '1', '{\"1\":[\"153\",\"152\",\"151\",\"154\",\"155\",\"158\",\"157\",\"156\",\"150\",\"149\",\"143\",\"142\",\"141\",\"144\",\"145\",\"148\",\"147\",\"146\",\"140\"]}', '1:基础', '', '', '', '', '', 'id:编号\r\naccount:账号\r\nnickname:昵称\r\npromote_id:推广员编号\r\npromote_account:所属渠道\r\nbalance:余额\r\nlock_status|get_status_text*1:锁定状态\r\nlogin_time:登陆时间\r\nregister_way:注册方式\r\nregister_time:注册时间\r\nlogin_ip:登陆IP\r\nregister_ip:注册IP', '10', '', '', '1463997820', '1465292937', '1', 'MyISAM');
INSERT INTO `sys_model` VALUES ('12', 'UserPlay', '玩家信息', '0', '', '1', '{\"1\":[\"168\",\"167\",\"169\",\"170\",\"172\",\"171\",\"166\",\"165\",\"161\",\"160\",\"162\",\"163\",\"164\",\"159\"]}', '1:基础', '', '', '', '', '', 'id:编号', '10', '', '', '1463997856', '1463997966', '1', 'MyISAM');
INSERT INTO `sys_model` VALUES ('13', 'UserLoginRecord', '用户登陆记录', '0', '', '1', '{\"1\":[\"179\",\"180\",\"181\",\"182\",\"178\",\"177\",\"174\",\"175\",\"176\",\"173\"]}', '1:基础', '', '', '', '', '', 'id:编号\r\nuser_account:用户名\r\nuser_nickname:昵称\r\ngame_id:游戏ID\r\ngame_name:游戏名称\r\nlogin_time:登陆时间', '10', '', '', '1463997904', '1465892986', '1', 'MyISAM');
INSERT INTO `sys_model` VALUES ('14', 'spend', '消费记录', '0', '', '1', '{\"1\":[\"196\",\"195\",\"194\",\"197\",\"198\",\"201\",\"200\",\"199\",\"193\",\"192\",\"186\",\"185\",\"184\",\"187\",\"188\",\"190\",\"191\",\"189\",\"183\"]}', '1:基础', '', '', '', '', '', 'id:编号\r\npay_order_number:订单号\r\nuser_account:用户账号\r\ngame_name:游戏名称\r\npay_amount:充值金额\r\npay_time|set_show_time:充值时间\r\npay_way|get_pay_way:充值方式\r\npay_status|get_info_status*12:充值状态\r\nspend_ip:充值ip', '10', '', '', '1464012355', '1465711729', '1', 'MyISAM');
INSERT INTO `sys_model` VALUES ('15', 'adv', '广告管理', '0', '', '1', '{\"1\":[\"209\",\"210\",\"211\",\"212\",\"208\",\"207\",\"203\",\"204\",\"205\",\"206\",\"202\"]}', '1:基础', '', '', '', '', '', 'id:编号\r\ntitle:标题\r\npos_id:广告位\r\ndata:图片\r\nurl:链接地址\r\nsort:排序\r\nstatus:状态\r\nstart_time:开始时间\r\nend_time:结束时间\r\ntarget:打开方式', '10', '', '', '1464083427', '1464099752', '1', 'MyISAM');
INSERT INTO `sys_model` VALUES ('16', 'AdvPos', '广告位', '0', '', '1', '{\"1\":[\"220\",\"221\",\"222\",\"223\",\"219\",\"218\",\"214\",\"215\",\"216\",\"217\",\"213\"]}', '1:基础', '', '', '', '', '', 'id:编号', '10', '', '', '1464084894', '1464087047', '1', 'MyISAM');
INSERT INTO `sys_model` VALUES ('17', 'deposit', '平台币充值', '0', '', '1', '{\"1\":[\"233\",\"232\",\"234\",\"235\",\"236\",\"231\",\"230\",\"226\",\"225\",\"227\",\"228\",\"229\",\"224\"]}', '1:基础', '', '', '', '', '', 'id:编号\r\npay_order_number:订单号\r\nuser_account:用户账号\r\npromote_id|get_promote_name:所属渠道\r\npay_amount:支付金额\r\ncreate_time|set_show_time:支付时间\r\npay_status|get_info_status*12:支付状态\r\npay_way|get_pay_way:支付方式\r\npay_ip:支付IP', '10', '', '', '1464233084', '1465804691', '1', 'MyISAM');
INSERT INTO `sys_model` VALUES ('18', 'provide', '平台币发放', '0', '', '1', '{\"1\":[\"247\",\"246\",\"248\",\"249\",\"251\",\"250\",\"245\",\"244\",\"239\",\"238\",\"240\",\"241\",\"243\",\"242\",\"237\"]}', '1:基础', '', '', '', '', '', 'id:编号\r\npay_order_number:订单号\r\ngame_name:游戏名称\r\nuser_account:用户账号\r\nuser_nickname:用户昵称\r\namount:发放金额\r\nstatus|get_info_status*9:状态\r\nop_account:操作人\r\ncreate_time|set_show_time:发放时间', '10', '', '', '1464233863', '1465799181', '1', 'MyISAM');
INSERT INTO `sys_model` VALUES ('19', 'BindSpend', '绑定平台币消费', '0', '', '1', '{\"1\":[\"263\",\"262\",\"261\",\"264\",\"265\",\"267\",\"266\",\"260\",\"259\",\"254\",\"253\",\"255\",\"256\",\"258\",\"257\",\"252\"]}', '1:基础', '', '', '', '', '', 'id:编号\r\npay_order_number:订单号\r\nuser_nickname:用户账号\r\ngame_name:游戏名称\r\npromote_account:所属渠道\r\npay_amount:充值金额\r\npay_time|set_show_time:充值时间\r\npay_status|get_info_status*12:状态\r\nspend_ip:充值IP', '10', '', '', '1464234376', '1465712509', '1', 'MyISAM');
INSERT INTO `sys_model` VALUES ('20', 'GameSource', '游戏原包', '0', '', '1', '{\"1\":[\"275\",\"276\",\"277\",\"278\",\"274\",\"273\",\"269\",\"270\",\"271\",\"272\",\"268\"]}', '1:基础', '', '', '', '', '', 'id:编号\r\ngame_id|get_game_name*id:游戏名称\r\nfile_name:文件名称\r\nfile_url:文件路径\r\nfile_size:文件大小\r\nop_account:操作人\r\ncreate_time|set_show_time:时间', '10', '', '', '1464235301', '1464940574', '1', 'MyISAM');
INSERT INTO `sys_model` VALUES ('21', 'Apply', '游戏申请管理', '0', '', '1', '{\"1\":[\"287\",\"286\",\"288\",\"289\",\"290\",\"285\",\"284\",\"280\",\"281\",\"282\",\"283\",\"279\"]}', '1:基础', '', '', '', '', '', 'id:编号\r\npromote_id|get_promote_name:渠道账号\r\ngame_id|get_game_name:游戏名称\r\npattern|get_pattern:合作模式\r\nratio|ratio_stytl*pattern:分成比例\r\nmoney:注册单价\r\nstatus|get_info_status*5:状态\r\napply_time|set_show_time:申请时间\r\ndispose_id|get_admin_nickname:审核人\r\ndispose_time|set_show_time:审核时间\r\ndow_url:下载链接\r\nid:操作:Apply/[EDIT]|编辑,Apply/package?ids=[id]|打包', '10', '', '', '1464356213', '1469098777', '1', 'MyISAM');
INSERT INTO `sys_model` VALUES ('22', 'agent', '代充记录', '0', '', '1', '{\"1\":[\"302\",\"301\",\"300\",\"303\",\"304\",\"306\",\"305\",\"299\",\"298\",\"293\",\"292\",\"294\",\"295\",\"297\",\"296\",\"291\"]}', '1:基础', '', '', '', '', '', 'id:编号\r\nuser_account:代充账号\r\ngame_name:代充游戏\r\namount:代充金额\r\nreal_amount:实扣金额\r\nzhekou:折扣比例\r\npay_status|get_info_status*7:充值状态\r\npromote_account:所属渠道\r\npromote_id|get_belong_admin:所属管理员\r\ncreate_time|set_show_time:创建时间', '10', '', '', '1464772695', '1465789172', '1', 'MyISAM');
INSERT INTO `sys_model` VALUES ('24', 'settlement', '结算表', '0', '', '1', '', '1:基础', '', '', '', '', '', '', '10', '', '', '1464945956', '1464945956', '1', 'MyISAM');
INSERT INTO `sys_model` VALUES ('30', 'GiftbagType', '礼包类型', '0', '', '1', '{\"1\":[\"336\",\"334\",\"335\",\"338\",\"337\",\"339\"]}', '1:基础', '', '', '', '', '', 'id:编号\r\ntype_name:礼包类型\r\nstatus|get_info_status*8:显示状态\r\nop_nickname:操作人\r\ncreate_time|set_show_time:添加时间\r\nid:操作:[EDIT]&id=[id]|编辑,GiftbagType/del?ids=[id]|删除', '10', '', '', '1465194413', '1465199742', '1', 'MyISAM');
INSERT INTO `sys_model` VALUES ('31', 'Links', '友情链接', '0', '', '1', '{\"1\":[\"345\",\"347\",\"346\",\"344\",\"343\",\"340\",\"342\",\"341\"]}', '1:基础', '', '', '', '', '', 'id:编号\r\ntitle:标题\r\nlink_url:链接\r\nstatus|get_info_status:状态\r\ncreate_time|set_show_time:添加时间\r\nid:操作:[EDIT]&id=[id]|编辑,Links/del?ids=[id]|删除', '10', '', '', '1465202697', '1465727927', '1', 'MyISAM');
INSERT INTO `sys_model` VALUES ('32', 'message', '留言纠错', '0', '', '1', '{\"1\":[\"354\",\"355\",\"356\",\"353\",\"352\",\"349\",\"350\",\"351\",\"348\"]}', '1:基础', '', '', '', '', '', 'id:编号\r\ngame_id|get_game_name:游戏名称\r\ntitle:错误内容\r\ncreate_time|set_show_time:提交时间\r\nstatus|get_info_status*6:修复状态\r\nop_account:操作人', '10', '', '', '1465732888', '1465733083', '1', 'MyISAM');
INSERT INTO `sys_model` VALUES ('33', 'opentype', '开放类型', '0', '', '1', '{\"1\":[\"359\",\"358\",\"357\"]}', '1:基础', '', '', '', '', '', 'id:编号\r\nopen_name:类型名称\r\nstatus|get_info_status:状态\r\ncreate_time|set_show_time:添加时间\r\nid:操作:[EDIT]&id=[id]|编辑,Opentype/del?ids=[id]|删除', '10', '', '', '1465898749', '1466149206', '1', 'MyISAM');
INSERT INTO `sys_model` VALUES ('35', 'rebate', '返利设置', '0', '', '1', '{\"1\":[\"366\",\"367\",\"365\",\"364\",\"363\",\"362\"]}', '1:基础', '', '', '', '', '', 'id:编号\r\ngame_name:游戏名称\r\nstatus|get_info_status:是否开启金额限制\r\nratio|ratio_stytl:返利比例\r\ncreate_time|set_show_time:添加时间\r\nid:操作:[EDIT]&id=[id]|编辑,rebate/del?ids=[id]|删除', '10', '', '', '1466386454', '1466389821', '1', 'MyISAM');
INSERT INTO `sys_model` VALUES ('36', 'RebateList', '游戏返利', '0', '', '1', '{\"1\":[\"375\",\"376\",\"377\",\"378\",\"374\",\"373\",\"369\",\"370\",\"371\",\"372\",\"368\"]}', '1:基础', '', '', '', '', '', 'id:编号\r\npay_order_number:订单号\r\nuser_id|get_user_account:用户名\r\ngame_name:游戏名称\r\npay_amount:充值金额\r\nratio|ratio_stytl:返利比例\r\nratio_amount:返利金额\r\npromote_id|get_promote_name:所属推广员\r\ncreate_time|set_show_time:添加时间\r\nid:操作:rebatelist/del?ids=[id]|删除', '10', '', '', '1466386503', '1466386622', '1', 'MyISAM');
INSERT INTO `sys_model` VALUES ('37', 'push', '推送设置', '0', '', '1', '{\"1\":[\"383\",\"382\",\"381\",\"380\",\"379\"]}', '1:基础', '', '', '', '', '', 'id:编号\r\npush_name:应用名称\r\napp_key:app_key\r\nmaster_secret:master_secret\r\nstatus|get_info_status:状态\r\ncreate_time|set_show_time:添加时间\r\nid:操作:[EDIT]&id=[id]|编辑,push/del?ids=[id]|删除', '10', '', '', '1466757612', '1466990427', '1', 'MyISAM');
INSERT INTO `sys_model` VALUES ('39', 'PushNotice', '发送通知', '0', '', '1', '{\"1\":[\"393\",\"394\",\"389\",\"390\",\"391\",\"392\"]}', '1:基础', '', '', '', '', '', 'id:编号\r\npush_name:应用名称\r\ncontent:推送内容\r\npush_object|get_phone_type:推送类型\r\npush_time_type|get_push_time:时间设置\r\npush_time|set_show_time:推送时间\r\ncreate_time|set_show_time:添加时间\r\nid:操作:push/del_list?ids=[id]|删除', '10', '', '', '1466759193', '1466990401', '1', 'MyISAM');
INSERT INTO `sys_model` VALUES ('40', 'withdraw', '渠道提现', '0', '', '1', '{\"1\":[\"401\",\"402\",\"400\",\"399\",\"397\",\"398\",\"396\"]}', '1:基础', '', '', '', '', '', 'id:编号\r\nsettlement_number:结算单号\r\nsum_money:结算金额\r\npromote_id:所属渠道\r\ncreate_time:申请时间\r\nend_time:完成时间\r\nstatus:提现状态', '10', '', '', '1469167976', '1469168245', '1', 'MyISAM');

-- -----------------------------
-- Table structure for `sys_picture`
-- -----------------------------
DROP TABLE IF EXISTS `sys_picture`;
CREATE TABLE `sys_picture` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键id自增',
  `path` varchar(255) NOT NULL DEFAULT '' COMMENT '路径',
  `url` varchar(255) NOT NULL DEFAULT '' COMMENT '图片链接',
  `md5` char(32) NOT NULL DEFAULT '' COMMENT '文件md5',
  `sha1` char(40) NOT NULL DEFAULT '' COMMENT '文件 sha1编码',
  `status` tinyint(2) NOT NULL DEFAULT '0' COMMENT '状态',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=38 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `sys_picture`
-- -----------------------------
INSERT INTO `sys_picture` VALUES ('1', '/Uploads/Picture/2016-08-09/57a988e8a47c6.jpg', '', '565a3e317a4001ae6012b70a35d10239', '53135865e4ebb448fb32d8bba813162171d2e123', '1', '1470728424');
INSERT INTO `sys_picture` VALUES ('2', '/Uploads/Picture/2016-08-09/57a9896f6fcf3.jpg', '', 'ec4a6109910e8856a640ea9840658005', 'fd0e711909d4d92aab5e6bb2901bb738976f57e2', '1', '1470728559');
INSERT INTO `sys_picture` VALUES ('3', '/Uploads/Picture/2016-08-09/57a98995927e6.jpg', '', '2eec352568b31473a0a12baa8654ba27', '2f99d9f736a070e7a8f8c4d930cc2a66d2adb978', '1', '1470728597');
INSERT INTO `sys_picture` VALUES ('4', '/Uploads/Picture/2016-08-09/57a98a19169fd.jpg', '', '02b752222f6f658331cb0ac249b38ba6', '2e016a5455de8ec0e23b5a17c6fbcfa22d585f29', '1', '1470728729');
INSERT INTO `sys_picture` VALUES ('5', '/Uploads/Picture/2016-08-09/57a98a19ba64e.jpg', '', '1928659ca69fb60fe7d8baedcda63292', '167d44228c86dbec831efd7e86f5e7670aeb35a9', '1', '1470728729');
INSERT INTO `sys_picture` VALUES ('6', '/Uploads/Picture/2016-08-09/57a98a1a1dd9f.jpg', '', 'ba187ce4a71496c89eabc97b21a213f2', 'd0df14a9a87f7de2b9c5bc78a34e75fc0c9752d5', '1', '1470728730');
INSERT INTO `sys_picture` VALUES ('7', '/Uploads/Picture/2016-08-09/57a98a1ac56e0.jpg', '', '8c54861028687e5f531c135830943cbb', 'b3900f93a647a900597c0056c6cb84edd78aa588', '1', '1470728730');
INSERT INTO `sys_picture` VALUES ('8', '/Uploads/Picture/2016-08-09/57a98a1b02cd0.jpg', '', '1796597871031c22146f3b3eb799c60e', '8b4b99e08c1e06a9c17f726cf98073348d18df08', '1', '1470728730');
INSERT INTO `sys_picture` VALUES ('9', '/Uploads/Picture/2016-08-09/57a98ad1a04d1.jpg', '', '7bf38a5664d90d805af1206b982b6f98', '4899f813e7efc74563922bd1685f23922dd7b499', '1', '1470728913');
INSERT INTO `sys_picture` VALUES ('10', '/Uploads/Picture/2016-08-09/57a98b03852c9.jpg', '', 'eec789f3b67f4c1abbcd4466a0802bb8', '9b594c6f49a98bab42e63d060c5da4a0c1282942', '1', '1470728963');
INSERT INTO `sys_picture` VALUES ('11', '/Uploads/Picture/2016-08-09/57a98b8e5e2bd.ico', '', 'c992701c23c3568f65931acd2a494e3e', 'ac74d871858ccdb25695bf587bcfea7f43d0f5dc', '1', '1470729102');
INSERT INTO `sys_picture` VALUES ('12', '/Uploads/Picture/2016-08-09/57a98c0f2437f.png', '', '62fd111629c5aa1f5aaad7e6a0e4c5d1', '5a30738a943368474cac26c231d545656c7a5a46', '1', '1470729231');
INSERT INTO `sys_picture` VALUES ('13', '/Uploads/Picture/2016-08-09/57a98c362bda3.png', '', '18d9c8bc809443bd173b6f441fab8eab', '7259fb70207eb0a54af9c83fa193fcab46cfd196', '1', '1470729270');
INSERT INTO `sys_picture` VALUES ('14', '/Uploads/Picture/2016-08-09/57a98e7655b37.png', '', '44a831a77227cee90204cdaf5bc95970', 'b73922e77c135a375c18cb3fbe98474d39fd2a0e', '1', '1470729846');
INSERT INTO `sys_picture` VALUES ('15', '/Uploads/Picture/2016-08-09/57a98e9704451.png', '', '124facfefb5a95be19974ef33b627699', '020473bf18f8dd4958095c70658e18606d44f199', '1', '1470729878');
INSERT INTO `sys_picture` VALUES ('16', '/Uploads/Picture/2016-08-09/57a98f5e3fbaf.jpg', '', '8d31c51e75313e7919a891d7220e0a17', 'e542c9373c524c1c6fbe6407cdd9e2bf5f2e6f6d', '1', '1470730078');
INSERT INTO `sys_picture` VALUES ('17', '/Uploads/Picture/2016-08-09/57a99605b3fcf.jpg', '', '11b3d669bcc23b3fcb4152199d67fda2', 'b876ac269ea81f19a21dc60eca3e1fb905962486', '1', '1470731781');
INSERT INTO `sys_picture` VALUES ('18', '/Uploads/Picture/2016-08-09/57a99f37546a2.jpg', '', '16e50e8f8d3728e911f187d551b2d488', '271bd8a88868a86c6ee0d0c886298a47bf0f7799', '1', '1470734135');
INSERT INTO `sys_picture` VALUES ('19', '/Uploads/Picture/2016-08-10/57aac4b0abf62.jpg', '', '40355d17a78a5d5050b56f02b31671dc', 'cbcf803ae1e09b549ee20da87908d18d679f7977', '1', '1470809264');
INSERT INTO `sys_picture` VALUES ('20', '/Uploads/Picture/2016-08-10/57aac534619a9.png', '', '2e63e2614eb5d7e5cef588e641bea4f2', '8aa7e75c7304757ae19e255deef5e205b6694dd5', '1', '1470809396');
INSERT INTO `sys_picture` VALUES ('21', '/Uploads/Picture/2016-08-10/57aac5896685f.jpg', '', 'dd387d66b07abb82761e3fb329d747c2', 'ccfd526afbdd162a48ed3c871568fd4474f9e7d3', '1', '1470809481');
INSERT INTO `sys_picture` VALUES ('22', '/Uploads/Picture/2016-08-10/57aac59203cbe.jpg', '', '2a3bc2f54779c73095c8ac3f4292746c', '7f2e89a524fe8ea28fd0cb506b52ce076be9a414', '1', '1470809489');
INSERT INTO `sys_picture` VALUES ('23', '/Uploads/Picture/2016-08-10/57aac59338ba0.jpg', '', '0ed13fc1b796ceb6093d15588ad8e551', 'e7a6a68427f598f9a5ce40cb8fbef1783f556a44', '1', '1470809491');
INSERT INTO `sys_picture` VALUES ('24', '/Uploads/Picture/2016-08-10/57aac59447922.jpg', '', '857c18039a74d522ee36f24af73cec89', 'df91ac2a58c03b95d1af16744e9c826d1219c13d', '1', '1470809492');
INSERT INTO `sys_picture` VALUES ('25', '/Uploads/Picture/2016-08-10/57aac5950e0d3.jpg', '', 'd4d25577c62ef2ec6d657c1ae7af6ea6', '9a3f1b4c0da810af1d3488b12318dab7f5a1fcd8', '1', '1470809492');
INSERT INTO `sys_picture` VALUES ('26', '/Uploads/Picture/2016-08-10/57aac68971150.jpg', '', 'c0041f6c25501adac8aec51f8d7670de', '9e10fd665948730ccdc659accc023e978ff996b0', '1', '1470809737');
INSERT INTO `sys_picture` VALUES ('27', '/Uploads/Picture/2016-08-10/57aac6f50262d.jpg', '', 'e74b756266e158a3b6303180b0cd2fb0', '7744ec6ecfea8314e9e98860ba94a1bcbdb212f2', '1', '1470809844');
INSERT INTO `sys_picture` VALUES ('28', '/Uploads/Picture/2016-08-10/57aac9df917ac.png', '', '0190e3692226a576268a9dc993a26dd7', '908165b875f308d0155919d2e4ad8b3d404d22cc', '1', '1470810591');
INSERT INTO `sys_picture` VALUES ('29', '/Uploads/Picture/2016-08-10/57aacafd2b331.png', '', '9c1724557ec5bfd5c0d40571a2dca6b0', '4294463969f47588f652cd4819b8d5596bb00586', '1', '1470810877');
INSERT INTO `sys_picture` VALUES ('30', '/Uploads/Picture/2016-08-10/57aacb487ffde.jpg', '', 'da7ba2980f51dd34432df979698839be', 'db48ad92188fcb614e2fd23af27a8e838c28d92a', '1', '1470810952');
INSERT INTO `sys_picture` VALUES ('31', '/Uploads/Picture/2016-08-10/57aacb7ebc905.png', '', '01d8351b234865100cba80c4514cc9b6', '91981a3607a1479ffb3c8fa7f9b682bee8187f23', '1', '1470811006');
INSERT INTO `sys_picture` VALUES ('32', '/Uploads/Picture/2016-08-10/57aacf8155f4a.png', '', '2c01af814a5f09dd2ae6039c8994e6d3', '2f79b3d71f82fc6277d11c7709324678d15d6fb1', '1', '1470812033');
INSERT INTO `sys_picture` VALUES ('33', '/Uploads/Picture/2016-08-10/57aacf8a676a9.jpg', '', 'b7ef8ab9ee10d6cda5aadd50ccf30e65', 'fbfb32a58707ef8813518478623c73d3b6adfc1a', '1', '1470812042');
INSERT INTO `sys_picture` VALUES ('34', '/Uploads/Picture/2016-08-10/57aad2ed61365.jpg', '', 'fa234b7035c81f85b2dd3d57fd558af7', '1cf821a05010c442cf5d46a1b40fd89756359946', '1', '1470812909');
INSERT INTO `sys_picture` VALUES ('35', '/Uploads/Picture/2016-08-10/57aad3410c716.png', '', 'd1b7748b51d12a31123e159c24645ca1', '838d80da0e2edbde3b1f8caf7699679d2e77237d', '1', '1470812992');
INSERT INTO `sys_picture` VALUES ('36', '/Uploads/Picture/2016-08-11/57ab9521cf6f8.png', '', 'f3913478d7faaf6098a5363d81be96f1', '8d0c86dd06972e61eedd7251ec3a2748862fd819', '1', '1470862625');
INSERT INTO `sys_picture` VALUES ('37', '/Uploads/Picture/2016-08-11/57ac3b0f16004.png', '', '93f18fb3c39cb8a6fb3956a5f4a5cef7', '85c434696dcd61c827069ee145a2fc6c7d5c195b', '1', '1470905102');

-- -----------------------------
-- Table structure for `sys_short_message`
-- -----------------------------
DROP TABLE IF EXISTS `sys_short_message`;
CREATE TABLE `sys_short_message` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `phone` varchar(20) NOT NULL COMMENT '电话号码',
  `send_status` varchar(10) NOT NULL COMMENT '短信发送状态',
  `send_time` varchar(15) NOT NULL COMMENT '发送时间',
  `smsId` varchar(40) NOT NULL COMMENT '发送短信唯一标识',
  `create_time` int(10) unsigned NOT NULL COMMENT '记录时间',
  `pid` varchar(40) NOT NULL COMMENT '渠道id',
  `status` tinyint(2) NOT NULL COMMENT '状态',
  `ratio` int(10) unsigned NOT NULL COMMENT '比率',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=203 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

-- -----------------------------
-- Records of `sys_short_message`
-- -----------------------------
INSERT INTO `sys_short_message` VALUES ('1', '18036377593', '000000', '1466129419', '925ab82b45574dc8d16bbcbe5238dbb1', '1466129422', '13270282266', '0', '0');
INSERT INTO `sys_short_message` VALUES ('2', '18036377593', '000000', '1466129725', '0029e9480be7779ebf715d3acb34ae07', '1466129728', '13270282266', '0', '0');
INSERT INTO `sys_short_message` VALUES ('3', '15720793112', '100019', '', '', '1466412333', '13270282266', '0', '0');
INSERT INTO `sys_short_message` VALUES ('4', '15720793112', '100019', '', '', '1466412334', '13270282266', '0', '0');
INSERT INTO `sys_short_message` VALUES ('5', '15720793112', '100019', '', '', '1466412334', '13270282266', '0', '0');
INSERT INTO `sys_short_message` VALUES ('6', '15050838825', '100019', '', '', '1466495399', '0', '0', '0');
INSERT INTO `sys_short_message` VALUES ('7', '15050838825', '100019', '', '', '1466495457', '0', '0', '0');
INSERT INTO `sys_short_message` VALUES ('8', '13270282266', '000000', '1466990789', '290039595b580062ce6070f564ef8c9c', '1466990789', '13270282266', '0', '0');
INSERT INTO `sys_short_message` VALUES ('9', '15720793112', '000000', '1467083079', 'f5ca950546d2b04cb7bda0af726c8c83', '1467083080', '13270282266', '0', '0');
INSERT INTO `sys_short_message` VALUES ('10', '18012007909', '000000', '1467083426', 'fb484ac32b281cc11b56101ee0e57768', '1467083427', '13270282266', '0', '0');
INSERT INTO `sys_short_message` VALUES ('11', '18012007909', '000000', '1467083426', '8dda8e8aaf5676835e2b3153ff3a6145', '1467083427', '13270282266', '0', '0');
INSERT INTO `sys_short_message` VALUES ('12', '18012007909', '000000', '1467083426', '4f85940f7d922970963606d4e1d3c79e', '1467083427', '13270282266', '0', '0');
INSERT INTO `sys_short_message` VALUES ('13', '18012007909', '000000', '1467083427', 'f16fb50c060dfcafadbca1f7850293b2', '1467083428', '13270282266', '0', '0');
INSERT INTO `sys_short_message` VALUES ('14', '18012007909', '000000', '1467083427', 'a71f74e2bfe54d413f689e0eab861b24', '1467083428', '13270282266', '0', '0');
INSERT INTO `sys_short_message` VALUES ('15', '18012007909', '000000', '1467083427', 'b2558de9588e8b7e9109a8e29c6625dc', '1467083428', '13270282266', '0', '0');
INSERT INTO `sys_short_message` VALUES ('16', '18012007909', '000000', '1467083427', 'b296a75742120cd0c76a28aa17a581c7', '1467083428', '13270282266', '0', '0');
INSERT INTO `sys_short_message` VALUES ('17', '18012007909', '000000', '1467083427', '0709638ba56d93b47c8c049aea2aac05', '1467083428', '13270282266', '0', '0');
INSERT INTO `sys_short_message` VALUES ('18', '18012007909', '000000', '1467083427', '5ea281055f993777666e1a833712722e', '1467083428', '13270282266', '0', '0');
INSERT INTO `sys_short_message` VALUES ('19', '18012007909', '000000', '1467083427', 'b159665832e8aa8b0a9eb34da759b0fa', '1467083428', '13270282266', '0', '0');
INSERT INTO `sys_short_message` VALUES ('20', '18012007909', '000000', '1467083427', '77983c8c0b1aa994e29448f7724762b8', '1467083428', '13270282266', '0', '0');
INSERT INTO `sys_short_message` VALUES ('21', '15720793112', '000000', '1467093803', 'eaa7d91c978e0738b31d8e8035c6d2e6', '1467093804', '13270282266', '0', '0');
INSERT INTO `sys_short_message` VALUES ('22', '18361253866', '000000', '1467268862', '5bc56214797848df43f3b3f7f7efe73b', '1467268862', '0', '0', '0');
INSERT INTO `sys_short_message` VALUES ('23', '18361253866', '000000', '1467268960', 'ab90901da709998657342b04c29f6c57', '1467268960', '0', '0', '0');
INSERT INTO `sys_short_message` VALUES ('24', '18361253866', '000000', '1467269028', '3fb70a98404492f287de38b60dfb6b25', '1467269028', '0', '0', '0');
INSERT INTO `sys_short_message` VALUES ('25', '18361253866', '000000', '1467269421', 'fa1a4a64d153ea907b4dcfe9fe5f1ba6', '1467269420', '0', '0', '0');
INSERT INTO `sys_short_message` VALUES ('26', '18361253866', '000000', '1467274899', '21f3f310855a6c3eb1f67a4d42bca7e2', '1467274899', '0', '0', '0');
INSERT INTO `sys_short_message` VALUES ('27', '18361253866', '000000', '1467275064', 'e4eaafc22e4840ee2cf1d34eddfc1a6f', '1467275064', '0', '0', '0');
INSERT INTO `sys_short_message` VALUES ('28', '15050838825', '000000', '1468413707', 'af040c7ecab8359081cf17baf1b1b505', '1468413639', '0', '0', '0');
INSERT INTO `sys_short_message` VALUES ('29', '18361253866', '000000', '1469588789', '13174e9cbab618b4efb5cb75f7cafb18', '1469588823', '13270282266', '0', '0');
INSERT INTO `sys_short_message` VALUES ('30', '18361253866', '000000', '1469589004', '4d4db9b6457e28f8ed7ab2169f3aa634', '1469589038', '13270282266', '0', '0');
INSERT INTO `sys_short_message` VALUES ('31', '18905157894', '000000', '1469612385', '0e05c1a32ce530828658f6141778ef0c', '1469612385', '0', '0', '0');
INSERT INTO `sys_short_message` VALUES ('32', '18905157894', '000000', '1469612393', '0e05c1a32ce530828658f6141778ef0c', '1469612393', '0', '0', '0');
INSERT INTO `sys_short_message` VALUES ('33', '18905219112', '000000', '1469612393', '0e05c1a32ce530828658f6141778ef0c', '1469612393', '0', '0', '0');
INSERT INTO `sys_short_message` VALUES ('34', '18905157894', '000000', '1469612471', '0e05c1a32ce530828658f6141778ef0c', '1469612471', '0', '0', '0');
INSERT INTO `sys_short_message` VALUES ('35', '18905219112', '000000', '1469612471', '0e05c1a32ce530828658f6141778ef0c', '1469612471', '0', '0', '0');
INSERT INTO `sys_short_message` VALUES ('36', '18905219114', '000000', '1469612531', '0e05c1a32ce530828658f6141778ef0c', '1469612531', '0', '0', '0');
INSERT INTO `sys_short_message` VALUES ('37', '18905219112', '000000', '1469612531', '0e05c1a32ce530828658f6141778ef0c', '1469612531', '0', '0', '0');
INSERT INTO `sys_short_message` VALUES ('38', '18905157894', '000000', '1469612531', '0e05c1a32ce530828658f6141778ef0c', '1469612531', '0', '0', '0');
INSERT INTO `sys_short_message` VALUES ('39', '18905219112', '000000', '1469612532', '0e05c1a32ce530828658f6141778ef0c', '1469612532', '0', '0', '0');
INSERT INTO `sys_short_message` VALUES ('40', '18905219112', '000000', '1469612532', '0e05c1a32ce530828658f6141778ef0c', '1469612532', '0', '0', '0');
INSERT INTO `sys_short_message` VALUES ('41', '18905219112', '000000', '1470042009', '0e05c1a32ce530828658f6141778ef0c', '1470042009', '0', '0', '0');
INSERT INTO `sys_short_message` VALUES ('42', '18905219112', '000000', '1470045016', '0e05c1a32ce530828658f6141778ef0c', '1470045016', '0', '0', '0');
INSERT INTO `sys_short_message` VALUES ('43', '18905219112', '000000', '1470045016', '0e05c1a32ce530828658f6141778ef0c', '1470045016', '0', '0', '0');
INSERT INTO `sys_short_message` VALUES ('44', '18905219112', '000000', '1470045017', '0e05c1a32ce530828658f6141778ef0c', '1470045017', '0', '0', '0');
INSERT INTO `sys_short_message` VALUES ('45', '18905219112', '000000', '1470045247', '0e05c1a32ce530828658f6141778ef0c', '1470045247', '0', '0', '0');
INSERT INTO `sys_short_message` VALUES ('46', '18905219112', '000000', '1470045247', '0e05c1a32ce530828658f6141778ef0c', '1470045247', '0', '0', '0');
INSERT INTO `sys_short_message` VALUES ('47', '18905219112', '000000', '1470045247', '0e05c1a32ce530828658f6141778ef0c', '1470045247', '0', '0', '0');
INSERT INTO `sys_short_message` VALUES ('48', '18905219112', '000000', '1470045248', '0e05c1a32ce530828658f6141778ef0c', '1470045248', '0', '0', '0');
INSERT INTO `sys_short_message` VALUES ('49', '18905219112', '000000', '1470045248', '0e05c1a32ce530828658f6141778ef0c', '1470045248', '0', '0', '0');
INSERT INTO `sys_short_message` VALUES ('50', '14714843794', '000000', '1470827156', '982395b4831735816ba8f8542a13e0fc', '1470827157', '13270282266', '0', '0');
INSERT INTO `sys_short_message` VALUES ('51', '15505437898', '000000', '1470827257', 'f2403d0667117807ada4e6dd6b43feab', '1470827259', '13270282266', '0', '0');
INSERT INTO `sys_short_message` VALUES ('52', '13406351617', '000000', '1470930308', '60c3ff47ace7bc6bfa01c76c8a9aaa1f', '1470930300', '13270282266', '0', '0');
INSERT INTO `sys_short_message` VALUES ('53', '13406351617', '000000', '1470930309', '85eb49bed450c3bc4451961c41eff800', '1470930301', '13270282266', '0', '0');
INSERT INTO `sys_short_message` VALUES ('54', '13665464694', '000000', '1470930313', '5064c62f6f8ea92047f6f0388df114ea', '1470930305', '13270282266', '0', '0');
INSERT INTO `sys_short_message` VALUES ('55', '15117861717', '000000', '1470930336', '80eb91cbbfa2fdb63959badc717534fd', '1470930328', '13270282266', '0', '0');
INSERT INTO `sys_short_message` VALUES ('56', '15117861717', '000000', '1470930336', 'd68997551f2114ba5f3a04706bf507a0', '1470930329', '13270282266', '0', '0');
INSERT INTO `sys_short_message` VALUES ('57', '13665464694', '000000', '1470930381', '10703c69e1f2b8a8b99b536fcf2e26a0', '1470930373', '13270282266', '0', '0');
INSERT INTO `sys_short_message` VALUES ('58', '13665464694', '000000', '1470930383', '9a7e16e5dd3c91ee74ad333a68da9713', '1470930376', '13270282266', '0', '0');
INSERT INTO `sys_short_message` VALUES ('59', '13665464694', '000000', '1470930438', '7c1b6187acd469a7ff74a23c0ecee76b', '1470930430', '13270282266', '0', '0');
INSERT INTO `sys_short_message` VALUES ('60', '13665464694', '000000', '1470930441', '2de523a15b07126d889ecd9c4042dcc2', '1470930433', '13270282266', '0', '0');
INSERT INTO `sys_short_message` VALUES ('61', '13665464694', '000000', '1470930503', '9e1179ee3f95e3b41a402a84a1b03eb6', '1470930496', '13270282266', '0', '0');
INSERT INTO `sys_short_message` VALUES ('62', '15260363578', '000000', '1470930544', 'f89bc697f693b447905b5089a614f0f5', '1470930537', '13270282266', '0', '0');
INSERT INTO `sys_short_message` VALUES ('63', '15260363578', '000000', '1470930545', '2d1eddcdd4acb5fc6acdb281e17eeb5c', '1470930537', '13270282266', '0', '0');
INSERT INTO `sys_short_message` VALUES ('64', '13750584020', '000000', '1470932762', 'ec9c6046000ffb5b3f2311faed7b7fac', '1470932755', '13270282266', '0', '0');
INSERT INTO `sys_short_message` VALUES ('65', '18771660262', '000000', '1470934963', '73115f4691ace0ecb2096a794c3a3b74', '1470934956', '13270282266', '0', '0');
INSERT INTO `sys_short_message` VALUES ('66', '13265818137', '000000', '1470954877', 'efe50470e777d278f6b1f500ad5577aa', '1470954870', '13270282266', '0', '0');
INSERT INTO `sys_short_message` VALUES ('67', '13265818137', '000000', '1470954878', '59708b8589044fd3202f0d0ae276be0c', '1470954870', '13270282266', '0', '0');
INSERT INTO `sys_short_message` VALUES ('68', '13265818137', '000000', '1470954878', '416e24ec699aa4c33b0d009aa7870a64', '1470954871', '13270282266', '0', '0');
INSERT INTO `sys_short_message` VALUES ('69', '13265818137', '000000', '1470954878', '92231920c38bd74ab3b61e9818b866eb', '1470954871', '13270282266', '0', '0');
INSERT INTO `sys_short_message` VALUES ('70', '13265818137', '000000', '1470954878', '9891c56753f8f84113837f6398d1169a', '1470954871', '13270282266', '0', '0');
INSERT INTO `sys_short_message` VALUES ('71', '13265818137', '000000', '1470954878', '66e170192cfdd46dcc38285386ab82fd', '1470954871', '13270282266', '0', '0');
INSERT INTO `sys_short_message` VALUES ('72', '13265818137', '000000', '1470954879', '081c9bacb1bae2ce01740cc5bb127dfd', '1470954871', '13270282266', '0', '0');
INSERT INTO `sys_short_message` VALUES ('73', '18368889337', '000000', '1470956466', '379357fd21cd958330602b1f1dec29eb', '1470956459', '13270282266', '0', '0');
INSERT INTO `sys_short_message` VALUES ('74', '18368889337', '000000', '1470956467', 'ffe789092f5780946f299f5f12f0f07c', '1470956460', '13270282266', '0', '0');
INSERT INTO `sys_short_message` VALUES ('75', '18368889337', '000000', '1470956467', '995eb3e47688cd82c151dca9e7bdd26c', '1470956460', '13270282266', '0', '0');
INSERT INTO `sys_short_message` VALUES ('76', '18368889337', '000000', '1470956530', '5df487f0ffb01f3143f75844e88023ad', '1470956523', '13270282266', '0', '0');
INSERT INTO `sys_short_message` VALUES ('77', '13663520030', '000000', '1470957288', '4ffcc2bfc7ac24a6bcf02d0d06ed10d9', '1470957281', '13270282266', '0', '0');
INSERT INTO `sys_short_message` VALUES ('78', '18503840163', '000000', '1470958030', '8bfa975086fc052d2cb7723bd8555fe1', '1470958023', '13270282266', '0', '0');
INSERT INTO `sys_short_message` VALUES ('79', '15099889223', '000000', '1470968435', 'aea1cc167ff881f8430f25395a9d68e1', '1470968428', '13270282266', '0', '0');
INSERT INTO `sys_short_message` VALUES ('80', '13455324515', '000000', '1470969223', '1ed9fb645b38489d973b511264197258', '1470969216', '13270282266', '0', '0');
INSERT INTO `sys_short_message` VALUES ('81', '13455324515', '000000', '1470969224', 'c1f5f203fd446e9fa3866eb09ebd246d', '1470969217', '13270282266', '0', '0');
INSERT INTO `sys_short_message` VALUES ('82', '13390244146', '000000', '1470969741', '603d3238b5745a4d288ae521f41ce986', '1470969734', '13270282266', '0', '0');
INSERT INTO `sys_short_message` VALUES ('83', '13390244146', '000000', '1470969742', '8e619de8827e1354c6c44f02f9b3eafa', '1470969735', '13270282266', '0', '0');
INSERT INTO `sys_short_message` VALUES ('84', '13390244146', '000000', '1470969742', '0f8cc9d1a8c7b6e8bd569b1e6c73c942', '1470969735', '13270282266', '0', '0');
INSERT INTO `sys_short_message` VALUES ('85', '13390244146', '000000', '1470969855', '8013b5c1efb78f12aa7d0a0b86b87c98', '1470969848', '13270282266', '0', '0');
INSERT INTO `sys_short_message` VALUES ('86', '13390244146', '000000', '1470969856', '96a611d1348feb8771b611b1eadc25d6', '1470969849', '13270282266', '0', '0');
INSERT INTO `sys_short_message` VALUES ('87', '18705505084', '000000', '1470970034', '6389e1491e4031cbdcfde007bde110e8', '1470970027', '13270282266', '0', '0');
INSERT INTO `sys_short_message` VALUES ('88', '18206220940', '000000', '1470970435', '249f89aca89f6132a804f7392c5a4b9e', '1470970427', '13270282266', '0', '0');
INSERT INTO `sys_short_message` VALUES ('89', '18206220940', '000000', '1470970435', 'eb01b4371fc35632b7539536ad618390', '1470970428', '13270282266', '0', '0');
INSERT INTO `sys_short_message` VALUES ('90', '18206220940', '000000', '1470970435', 'a760e849e5b750c9ebe3452d75e504ae', '1470970428', '13270282266', '0', '0');
INSERT INTO `sys_short_message` VALUES ('91', '18206220940', '000000', '1470970435', 'e6ca508e95ab223b94f7994e8dfbee61', '1470970428', '13270282266', '0', '0');
INSERT INTO `sys_short_message` VALUES ('92', '18206220940', '000000', '1470970436', '5d467d243de593037b73c0e3f181fa41', '1470970429', '13270282266', '0', '0');
INSERT INTO `sys_short_message` VALUES ('93', '18206220940', '000000', '1470970435', '74c69f14a4468d774b755d2ac17b3879', '1470970429', '13270282266', '0', '0');
INSERT INTO `sys_short_message` VALUES ('94', '18206220940', '000000', '1470970436', 'e34c7502adccde12cffc524a0ee83d72', '1470970429', '13270282266', '0', '0');
INSERT INTO `sys_short_message` VALUES ('95', '18206220940', '000000', '1470970436', '6358c3f6bae2c52d120f3309a8740a7c', '1470970429', '13270282266', '0', '0');
INSERT INTO `sys_short_message` VALUES ('96', '18634801194', '000000', '1470970482', '44ee60adf93fd6e153206f5ece48991f', '1470970475', '13270282266', '0', '0');
INSERT INTO `sys_short_message` VALUES ('97', '18206220940', '000000', '1470970501', 'bc515393bf39246d78b1a4778531f97e', '1470970494', '13270282266', '0', '0');
INSERT INTO `sys_short_message` VALUES ('98', '18237396228', '000000', '1470970535', 'db67e59ba3bc07757963ab15024475c4', '1470970528', '13270282266', '0', '0');
INSERT INTO `sys_short_message` VALUES ('99', '13971048993', '000000', '1470971054', '3bb5b3b0f94a6d2c31c2645b1c1bc45d', '1470971047', '13270282266', '0', '0');
INSERT INTO `sys_short_message` VALUES ('100', '15016205992', '000000', '1470972105', '2c45c5156622c6db4ee2dbed0b0cef7d', '1470972098', '13270282266', '0', '0');
INSERT INTO `sys_short_message` VALUES ('101', '15201669177', '000000', '1470972921', 'fcc1074e041aaf3663b125b7b836b5c2', '1470972914', '13270282266', '0', '0');
INSERT INTO `sys_short_message` VALUES ('102', '15864110597', '000000', '1470974904', '66c8f64dd940205feae8f33f3cb5f212', '1470974897', '13270282266', '0', '0');
INSERT INTO `sys_short_message` VALUES ('103', '18325505542', '000000', '1470974994', 'ed4b06ebd5170f61f1b49853c7a397d6', '1470974987', '13270282266', '0', '0');
INSERT INTO `sys_short_message` VALUES ('104', '15156589827', '000000', '1470975615', 'cf07dc51181cbb39982b56353336af88', '1470975608', '13270282266', '0', '0');
INSERT INTO `sys_short_message` VALUES ('105', '13533664553', '000000', '1470975997', '7cc7e53136a1ad7b9af0125ffc4f82fc', '1470975990', '13270282266', '0', '0');
INSERT INTO `sys_short_message` VALUES ('106', '18817109620', '000000', '1470976132', '09461c1cf15549b7946bdabfece63dc7', '1470976125', '13270282266', '0', '0');
INSERT INTO `sys_short_message` VALUES ('107', '18863944666', '000000', '1470976658', '5bf92fd21b2f9cf2cfb3aefdd9dccd70', '1470976651', '13270282266', '0', '0');
INSERT INTO `sys_short_message` VALUES ('108', '13912806950', '000000', '1470976781', '96626c6f18c08b19f41075b197777f6a', '1470976774', '13270282266', '0', '0');
INSERT INTO `sys_short_message` VALUES ('109', '13912806950', '000000', '1470976782', 'bafaf832f9c8e0d96d98fdc4ff9c064a', '1470976775', '13270282266', '0', '0');
INSERT INTO `sys_short_message` VALUES ('110', '13912806950', '000000', '1470976782', '634a6b2962e4676bf4452fb3bea47766', '1470976775', '13270282266', '0', '0');
INSERT INTO `sys_short_message` VALUES ('111', '18873835270', '000000', '1470977233', 'ec22850b5fe9150f8b5e0476fd27af62', '1470977226', '13270282266', '0', '0');
INSERT INTO `sys_short_message` VALUES ('112', '18873835270', '000000', '1470977234', '587145baeb08ce87c868e62a411ee57b', '1470977227', '13270282266', '0', '0');
INSERT INTO `sys_short_message` VALUES ('113', '18873835270', '000000', '1470977300', 'da8946058f74556d47836f310424d149', '1470977293', '13270282266', '0', '0');
INSERT INTO `sys_short_message` VALUES ('114', '13730199076', '000000', '1470977471', 'a14fe6a7a904fe8def30e8886300b2ed', '1470977464', '13270282266', '0', '0');
INSERT INTO `sys_short_message` VALUES ('115', '15566666666', '000000', '1470977869', 'd3b55f45911d3ad1923e4e5b648fea9b', '1470977862', '13270282266', '0', '0');
INSERT INTO `sys_short_message` VALUES ('116', '15566666666', '000000', '1470977869', 'a782b0f05135084d201070d8c3c3cc3b', '1470977862', '13270282266', '0', '0');
INSERT INTO `sys_short_message` VALUES ('117', '18504842291', '000000', '1470977919', '06f60d13855b46ebf013168b1c5412b6', '1470977912', '13270282266', '0', '0');
INSERT INTO `sys_short_message` VALUES ('118', '18863944666', '000000', '1470982395', '3784be4cf754136b68180e6eee1af777', '1470982388', '13270282266', '0', '0');
INSERT INTO `sys_short_message` VALUES ('119', '18920423096', '000000', '1470982749', '3a44985537334d899063d3ca354ccbe7', '1470982742', '13270282266', '0', '0');
INSERT INTO `sys_short_message` VALUES ('120', '13002096204', '000000', '1470983659', '8a57444e17de93e826481880ea7dfcc1', '1470983652', '13270282266', '0', '0');
INSERT INTO `sys_short_message` VALUES ('121', '13002096204', '000000', '1470983659', '8ac200fed41b4317354cdd96f3e0b0d9', '1470983653', '13270282266', '0', '0');
INSERT INTO `sys_short_message` VALUES ('122', '18121728357', '000000', '1470984127', '76b6b2dfb1dae5b397284b01012f3ef8', '1470984120', '13270282266', '0', '0');
INSERT INTO `sys_short_message` VALUES ('123', '18121728357', '000000', '1470984128', '4bbcee3e8c4521778b55077ad6c1db89', '1470984121', '13270282266', '0', '0');
INSERT INTO `sys_short_message` VALUES ('124', '18121728357', '000000', '1470984194', 'fb87c32c34355314700d1b1ec0af2b82', '1470984187', '13270282266', '0', '0');
INSERT INTO `sys_short_message` VALUES ('125', '13569105784', '000000', '1470986671', 'ae8e7988e740b623ffda5f96c7d89991', '1470986665', '13270282266', '0', '0');
INSERT INTO `sys_short_message` VALUES ('126', '13569105784', '000000', '1470986673', '8626567cdef9ade113ff5ce55f585788', '1470986666', '13270282266', '0', '0');
INSERT INTO `sys_short_message` VALUES ('127', '13569105784', '000000', '1470986676', '35a3a3535b8212dade9b203bd2e73c5a', '1470986669', '13270282266', '0', '0');
INSERT INTO `sys_short_message` VALUES ('128', '15517166851', '000000', '1470986721', '6df73ed9bbe4954bdfcf5c64b60c4328', '1470986714', '13270282266', '0', '0');
INSERT INTO `sys_short_message` VALUES ('129', '15517166851', '000000', '1470986722', '06d142bf6c4f3f3433be00efb9513519', '1470986716', '13270282266', '0', '0');
INSERT INTO `sys_short_message` VALUES ('130', '18634541613', '000000', '1470987847', '0da98349593ee24e36a1885d8e9bd3a8', '1470987840', '13270282266', '0', '0');
INSERT INTO `sys_short_message` VALUES ('131', '13241737367', '000000', '1470988110', '8b834e604197e18de7a5c9653698130a', '1470988103', '13270282266', '0', '0');
INSERT INTO `sys_short_message` VALUES ('132', '13241737367', '000000', '1470988116', 'da1841432b7ef11a8d7a4caadd40e275', '1470988109', '13270282266', '0', '0');
INSERT INTO `sys_short_message` VALUES ('133', '15267836139', '000000', '1470988459', 'ff629e439a3ff385ad7dd2669dd0eea7', '1470988452', '13270282266', '0', '0');
INSERT INTO `sys_short_message` VALUES ('134', '15267836139', '000000', '1470988460', '0a69ea4f15b8bad118140d74ef5a60b4', '1470988453', '13270282266', '0', '0');
INSERT INTO `sys_short_message` VALUES ('135', '15766224557', '000000', '1470989064', '76271c0d363ea1b270f2d0de50da77a3', '1470989057', '13270282266', '0', '0');
INSERT INTO `sys_short_message` VALUES ('136', '15766224557', '000000', '1470989064', '7284d993a615bace1e316a261baa9492', '1470989057', '13270282266', '0', '0');
INSERT INTO `sys_short_message` VALUES ('137', '15766224557', '000000', '1470989065', 'cd6f768fb5cc02205f6700cfe261818d', '1470989058', '13270282266', '0', '0');
INSERT INTO `sys_short_message` VALUES ('138', '15766224557', '000000', '1470989065', '4f628ec148fe5c9015eec897d511bfdb', '1470989058', '13270282266', '0', '0');
INSERT INTO `sys_short_message` VALUES ('139', '15766224557', '000000', '1470989066', 'a9f371f203feb11da947f854757b1d1e', '1470989059', '13270282266', '0', '0');
INSERT INTO `sys_short_message` VALUES ('140', '15766224557', '000000', '1470989132', 'ca1af7ce3d8aeb539a91b4394ca51b13', '1470989126', '13270282266', '0', '0');
INSERT INTO `sys_short_message` VALUES ('141', '15766224557', '000000', '1470989219', 'd409041ecd6a4d71a819a7bdc431a5cd', '1470989212', '13270282266', '0', '0');
INSERT INTO `sys_short_message` VALUES ('142', '13072015431', '000000', '1470990930', '73677d9f65aee4b8bc03930e78f1e84b', '1470990923', '13270282266', '0', '0');
INSERT INTO `sys_short_message` VALUES ('143', '15531434368', '000000', '1470990946', 'c6ee45f807d1425c2a890daed05ac687', '1470990939', '13270282266', '0', '0');
INSERT INTO `sys_short_message` VALUES ('144', '15821126952', '000000', '1470991918', '06091efa063dd455a2011af5c3273392', '1470991911', '13270282266', '0', '0');
INSERT INTO `sys_short_message` VALUES ('145', '18370790913', '000000', '1470992003', '272598ee5208911d1e82ae9ed8dc34d4', '1470991996', '13270282266', '0', '0');
INSERT INTO `sys_short_message` VALUES ('146', '13752942057', '000000', '1470992538', '6059db3751a8e5d95758c3d628f762dd', '1470992531', '13270282266', '0', '0');
INSERT INTO `sys_short_message` VALUES ('147', '13752942057', '000000', '1470992550', '04c4ed57662f85b4b1a9af9fe226d269', '1470992543', '13270282266', '0', '0');
INSERT INTO `sys_short_message` VALUES ('148', '13752942057', '000000', '1470992553', 'd69b42f7e6c8c551698897997b503235', '1470992547', '13270282266', '0', '0');
INSERT INTO `sys_short_message` VALUES ('149', '13938988559', '000000', '1470993079', '2448f9df8e57ace1d9c65a1ae08297e5', '1470993072', '13270282266', '0', '0');
INSERT INTO `sys_short_message` VALUES ('150', '13938988559', '000000', '1470993129', 'f1202ed3e0bbfd440362e177ac96e55c', '1470993122', '13270282266', '0', '0');
INSERT INTO `sys_short_message` VALUES ('151', '13938988559', '000000', '1470993173', 'ef99c7408d49a875749d29c91ccf2691', '1470993167', '13270282266', '0', '0');
INSERT INTO `sys_short_message` VALUES ('152', '13938988559', '000000', '1470993174', '7ce9226bbc35cd0b1ad136d232b26867', '1470993167', '13270282266', '0', '0');
INSERT INTO `sys_short_message` VALUES ('153', '13938988559', '000000', '1470993175', 'e9449a459a2e79206123b01bdad15735', '1470993169', '13270282266', '0', '0');
INSERT INTO `sys_short_message` VALUES ('154', '15136668149', '000000', '1470993266', '494cd6f7c99fc1f5bbcf6687c50063da', '1470993259', '13270282266', '0', '0');
INSERT INTO `sys_short_message` VALUES ('155', '15920193954', '000000', '1470993358', '0099d92b10f91cb445278bde342043e9', '1470993351', '13270282266', '0', '0');
INSERT INTO `sys_short_message` VALUES ('156', '15920193954', '000000', '1470993358', '751652d4ae43c26a25e2df0a23d04a6f', '1470993351', '13270282266', '0', '0');
INSERT INTO `sys_short_message` VALUES ('157', '15920193954', '000000', '1470993358', '4ef94bcdb9b9bf18db3212570e958054', '1470993351', '13270282266', '0', '0');
INSERT INTO `sys_short_message` VALUES ('158', '15920193954', '000000', '1470993359', 'ca3b09669c5f0c7b646718c5b249d958', '1470993352', '13270282266', '0', '0');
INSERT INTO `sys_short_message` VALUES ('159', '15920193954', '000000', '1470993359', '8bb8f199479a212baabf903618d0f7f4', '1470993352', '13270282266', '0', '0');
INSERT INTO `sys_short_message` VALUES ('160', '15920193954', '000000', '1470993359', '4899e631c9c156a389c14feb40882841', '1470993352', '13270282266', '0', '0');
INSERT INTO `sys_short_message` VALUES ('161', '15920193954', '000000', '1470993359', 'b522114184f812723b72ecc94a775463', '1470993352', '13270282266', '0', '0');
INSERT INTO `sys_short_message` VALUES ('162', '15920193954', '000000', '1470993359', 'ced4826204632165f5dfb954a0773fe9', '1470993352', '13270282266', '0', '0');
INSERT INTO `sys_short_message` VALUES ('163', '15920193954', '000000', '1470993359', '715ad4d3e73bf5f0533ec840f37f425a', '1470993353', '13270282266', '0', '0');
INSERT INTO `sys_short_message` VALUES ('164', '15920193954', '000000', '1470993360', '34586591b15d9cd9ced04355f32bea3e', '1470993353', '13270282266', '0', '0');
INSERT INTO `sys_short_message` VALUES ('165', '15920193954', '000000', '1470993360', '8ee22d775a5d013ef849c736bb9dc554', '1470993353', '13270282266', '0', '0');
INSERT INTO `sys_short_message` VALUES ('166', '15920193954', '000000', '1470993360', '58926df918cf8d5ac71d8d0254ce44d5', '1470993353', '13270282266', '0', '0');
INSERT INTO `sys_short_message` VALUES ('167', '15920193954', '000000', '1470993360', '6f5e01d5d8fcfade46be6a98d34b9ac8', '1470993353', '13270282266', '0', '0');
INSERT INTO `sys_short_message` VALUES ('168', '15920193954', '000000', '1470993361', '466d868ad7822af5adcf0e78ef175666', '1470993354', '13270282266', '0', '0');
INSERT INTO `sys_short_message` VALUES ('169', '18778781196', '000000', '1470994676', 'ff855cf1adcf46cb1c12f24615c95769', '1470994669', '13270282266', '0', '0');
INSERT INTO `sys_short_message` VALUES ('170', '18778781196', '000000', '1470994677', 'a5e9332e2f4e74d974d6063963257f9a', '1470994670', '13270282266', '0', '0');
INSERT INTO `sys_short_message` VALUES ('171', '15915514152', '000000', '1470995264', '65668f40ecfebc10bb457d120745743f', '1470995257', '13270282266', '0', '0');
INSERT INTO `sys_short_message` VALUES ('172', '15915514152', '000000', '1470995266', 'b350903c39d0dea3022a33785c495dc1', '1470995259', '13270282266', '0', '0');
INSERT INTO `sys_short_message` VALUES ('173', '18700605571', '000000', '1470995292', '76228a33240addaf4124128be223d06d', '1470995285', '13270282266', '0', '0');
INSERT INTO `sys_short_message` VALUES ('174', '13275383606', '000000', '1470995628', 'fa463d771f28b6f6d83951471a3bb30d', '1470995621', '13270282266', '0', '0');
INSERT INTO `sys_short_message` VALUES ('175', '13275383606', '000000', '1470995629', 'b15ce7eae643845a945186b0f4d2f89c', '1470995622', '13270282266', '0', '0');
INSERT INTO `sys_short_message` VALUES ('176', '13504994340', '000000', '1470996177', '2ed2354759a9b797c2ebe50a24e53271', '1470996170', '13270282266', '0', '0');
INSERT INTO `sys_short_message` VALUES ('177', '13504994340', '000000', '1470996177', '1fa0f6a40d554064070a054baf83061b', '1470996170', '13270282266', '0', '0');
INSERT INTO `sys_short_message` VALUES ('178', '13504994340', '000000', '1470996178', '4eb8f167ccaf8e94c7f47d604ec15f16', '1470996171', '13270282266', '0', '0');
INSERT INTO `sys_short_message` VALUES ('179', '13504994340', '000000', '1470996246', 'c61b514dc810669e038b498ef44a5557', '1470996239', '13270282266', '0', '0');
INSERT INTO `sys_short_message` VALUES ('180', '15181739702', '000000', '1470996436', '6f436df1dee2fbeab51f92f272bad937', '1470996429', '13270282266', '0', '0');
INSERT INTO `sys_short_message` VALUES ('181', '15181739702', '000000', '1470996436', '2feb70a5e9725b0c4d943c223880a8a0', '1470996429', '13270282266', '0', '0');
INSERT INTO `sys_short_message` VALUES ('182', '15181739702', '000000', '1470996436', '1d5153bd204dbdd0fc9f6b27fae4d303', '1470996429', '13270282266', '0', '0');
INSERT INTO `sys_short_message` VALUES ('183', '15181739702', '000000', '1470996437', 'dc18b5b463fafb7080dd5e3e6f6bb651', '1470996430', '13270282266', '0', '0');
INSERT INTO `sys_short_message` VALUES ('184', '15181739702', '000000', '1470996437', '1fff3ed4cfec6960cccf15c69c049633', '1470996430', '13270282266', '0', '0');
INSERT INTO `sys_short_message` VALUES ('185', '15181739702', '000000', '1470996437', 'f37f5a7fa21bcee5c283049ce95bec54', '1470996430', '13270282266', '0', '0');
INSERT INTO `sys_short_message` VALUES ('186', '15181739702', '000000', '1470996437', '4abaf2c003cb43deeaaa19711a0d7e0b', '1470996430', '13270282266', '0', '0');
INSERT INTO `sys_short_message` VALUES ('187', '15181739702', '000000', '1470996438', '90d34342b45f7f233ad578c459715113', '1470996431', '13270282266', '0', '0');
INSERT INTO `sys_short_message` VALUES ('188', '15181739702', '000000', '1470996438', '88b82dc9b50dedddb3a50a0ef0bfb924', '1470996431', '13270282266', '0', '0');
INSERT INTO `sys_short_message` VALUES ('189', '15181739702', '000000', '1470996439', '2ee8c67108676b5151e2fe6b2ef75dbf', '1470996432', '13270282266', '0', '0');
INSERT INTO `sys_short_message` VALUES ('190', '15181739702', '000000', '1470996442', '87a8b3a6219914c688335f26ed1d39f2', '1470996435', '13270282266', '0', '0');
INSERT INTO `sys_short_message` VALUES ('191', '15181739702', '000000', '1470996447', '38f0719259b7e96ae3a6ca2146aa4ff8', '1470996440', '13270282266', '0', '0');
INSERT INTO `sys_short_message` VALUES ('192', '15181739702', '000000', '1470996509', 'a22f0b68968a998d30c51d5bd74afae2', '1470996502', '13270282266', '0', '0');
INSERT INTO `sys_short_message` VALUES ('193', '15181739702', '000000', '1470996510', '6dfb274e478797ee547dfd3070142e86', '1470996503', '13270282266', '0', '0');
INSERT INTO `sys_short_message` VALUES ('194', '13995607651', '000000', '1470997445', '5a7e33761654a6870080f38bec32b160', '1470997438', '13270282266', '0', '0');
INSERT INTO `sys_short_message` VALUES ('195', '13995607651', '000000', '1470997446', '21ac013b0e033e296a2476591560f534', '1470997439', '13270282266', '0', '0');
INSERT INTO `sys_short_message` VALUES ('196', '13995607651', '000000', '1470997446', '9cce4d26cb126ffde387c0a59f8ab949', '1470997439', '13270282266', '0', '0');
INSERT INTO `sys_short_message` VALUES ('197', '15220943549', '000000', '1470997609', '0ac3c30487ea57e423fdccbebfeff944', '1470997602', '13270282266', '0', '0');
INSERT INTO `sys_short_message` VALUES ('198', '13455535475', '000000', '1470998284', '242aeaf8e6946d27d515fc3d600bf8cf', '1470998277', '13270282266', '0', '0');
INSERT INTO `sys_short_message` VALUES ('199', '13455535475', '000000', '1470998284', '33cd741f439aca7c20ed122b3e698a57', '1470998278', '13270282266', '0', '0');
INSERT INTO `sys_short_message` VALUES ('200', '13455535475', '000000', '1470998285', 'c2d5a39a381bc28cf05740616230c59f', '1470998278', '13270282266', '0', '0');
INSERT INTO `sys_short_message` VALUES ('201', '13455535475', '000000', '1470998337', '870c7abad3b32afed1c6b3527f8eea79', '1470998330', '13270282266', '0', '0');
INSERT INTO `sys_short_message` VALUES ('202', '15984306325', '000000', '1470998358', '0855d305ee47b2ab190ae7bc5ed11162', '1470998351', '13270282266', '0', '0');

-- -----------------------------
-- Table structure for `sys_ucenter_admin`
-- -----------------------------
DROP TABLE IF EXISTS `sys_ucenter_admin`;
CREATE TABLE `sys_ucenter_admin` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '管理员ID',
  `member_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '管理员用户ID',
  `status` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '管理员状态',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='管理员表';


-- -----------------------------
-- Table structure for `sys_ucenter_app`
-- -----------------------------
DROP TABLE IF EXISTS `sys_ucenter_app`;
CREATE TABLE `sys_ucenter_app` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '应用ID',
  `title` varchar(30) NOT NULL COMMENT '应用名称',
  `url` varchar(100) NOT NULL COMMENT '应用URL',
  `ip` char(15) NOT NULL DEFAULT '' COMMENT '应用IP',
  `auth_key` varchar(100) NOT NULL DEFAULT '' COMMENT '加密KEY',
  `sys_login` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '同步登陆',
  `allow_ip` varchar(255) NOT NULL DEFAULT '' COMMENT '允许访问的IP',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `status` tinyint(4) NOT NULL DEFAULT '0' COMMENT '应用状态',
  PRIMARY KEY (`id`),
  KEY `status` (`status`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='应用表';


-- -----------------------------
-- Table structure for `sys_ucenter_member`
-- -----------------------------
DROP TABLE IF EXISTS `sys_ucenter_member`;
CREATE TABLE `sys_ucenter_member` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '用户ID',
  `username` char(16) NOT NULL COMMENT '用户名',
  `password` char(32) NOT NULL COMMENT '密码',
  `email` char(32) NOT NULL COMMENT '用户邮箱',
  `mobile` char(15) NOT NULL DEFAULT '' COMMENT '用户手机',
  `reg_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '注册时间',
  `reg_ip` bigint(20) NOT NULL DEFAULT '0' COMMENT '注册IP',
  `last_login_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '最后登录时间',
  `last_login_ip` bigint(20) NOT NULL DEFAULT '0' COMMENT '最后登录IP',
  `update_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `status` tinyint(4) DEFAULT '0' COMMENT '用户状态',
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  UNIQUE KEY `email` (`email`),
  KEY `status` (`status`)
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=utf8 COMMENT='用户表';

-- -----------------------------
-- Records of `sys_ucenter_member`
-- -----------------------------
INSERT INTO `sys_ucenter_member` VALUES ('1', 'admin', '393bcf9336da6dcda694a9573f076b28', 'admin@163.com', '', '1470811518', '1022946991', '1470992089', '1022946991', '1470811518', '1');
INSERT INTO `sys_ucenter_member` VALUES ('2', '111111', '43b54e1bfa09eb9819eb58fdeb34af69', '1@qq.com', '', '1464665603', '2130706433', '1470992146', '3396183728', '1464665603', '1');
INSERT INTO `sys_ucenter_member` VALUES ('3', 'asdasd', 'a57f0e607a25375869fd68467399f2c7', 'asdss@qq.com', '', '1465269970', '2130706433', '1470991501', '3396183722', '1465269970', '1');
INSERT INTO `sys_ucenter_member` VALUES ('4', 'qwe123', '43b54e1bfa09eb9819eb58fdeb34af69', '45741212125@qq.com', '', '1465286609', '0', '1470992156', '3396183712', '1465286609', '1');
INSERT INTO `sys_ucenter_member` VALUES ('5', 'qwe135', '43b54e1bfa09eb9819eb58fdeb34af69', '45612@qq.com', '', '1465694356', '0', '1465962238', '2130706433', '1465694356', '1');
INSERT INTO `sys_ucenter_member` VALUES ('10', 'ceshi223', '43b54e1bfa09eb9819eb58fdeb34af69', '12121112@qq.com', '', '1468572469', '2130706433', '1468572522', '2130706433', '1468572469', '1');
INSERT INTO `sys_ucenter_member` VALUES ('7', 'ceshi11', 'f714e22d958eb5fe42829a9c737ca0af', '111@qq.com', '', '1468563510', '2130706433', '1470991539', '3396183712', '1468563510', '1');
INSERT INTO `sys_ucenter_member` VALUES ('8', 'ceshi2', '43b54e1bfa09eb9819eb58fdeb34af69', '1111@qq.com', '', '1468563859', '2130706433', '1468573144', '2130706433', '1468563859', '1');
INSERT INTO `sys_ucenter_member` VALUES ('9', 'ceshi23', '43b54e1bfa09eb9819eb58fdeb34af69', '121212@qq.com', '', '1468564254', '2130706433', '0', '0', '1468564254', '1');
INSERT INTO `sys_ucenter_member` VALUES ('11', 'mhxy', '708a8e139e8414b538fa3b0f9748fc28', 'mhxy@qq.com', '', '1470895644', '1022946991', '1470993780', '3396183722', '1470895644', '1');
INSERT INTO `sys_ucenter_member` VALUES ('12', 'qwe1234', '43b54e1bfa09eb9819eb58fdeb34af69', '564254@qq.com', '', '1470896565', '2634080840', '1470991579', '3396183722', '1470896565', '1');

-- -----------------------------
-- Table structure for `sys_ucenter_setting`
-- -----------------------------
DROP TABLE IF EXISTS `sys_ucenter_setting`;
CREATE TABLE `sys_ucenter_setting` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '设置ID',
  `type` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '配置类型（1-用户配置）',
  `value` text NOT NULL COMMENT '配置数据',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='设置表';


-- -----------------------------
-- Table structure for `sys_url`
-- -----------------------------
DROP TABLE IF EXISTS `sys_url`;
CREATE TABLE `sys_url` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT '链接唯一标识',
  `url` char(255) NOT NULL DEFAULT '' COMMENT '链接地址',
  `short` char(100) NOT NULL DEFAULT '' COMMENT '短网址',
  `status` tinyint(2) NOT NULL DEFAULT '2' COMMENT '状态',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_url` (`url`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='链接表';


-- -----------------------------
-- Table structure for `sys_userdata`
-- -----------------------------
DROP TABLE IF EXISTS `sys_userdata`;
CREATE TABLE `sys_userdata` (
  `uid` int(10) unsigned NOT NULL COMMENT '用户id',
  `type` tinyint(3) unsigned NOT NULL COMMENT '类型标识',
  `target_id` int(10) unsigned NOT NULL COMMENT '目标id',
  UNIQUE KEY `uid` (`uid`,`type`,`target_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


-- -----------------------------
-- Table structure for `tab_adv`
-- -----------------------------
DROP TABLE IF EXISTS `tab_adv`;
CREATE TABLE `tab_adv` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `title` char(80) NOT NULL DEFAULT '' COMMENT '广告名称',
  `pos_id` int(11) NOT NULL COMMENT '广告位置',
  `data` text NOT NULL COMMENT '图片地址',
  `click_count` int(11) NOT NULL COMMENT '点击量',
  `url` varchar(500) NOT NULL COMMENT '链接地址',
  `sort` int(3) unsigned NOT NULL DEFAULT '0' COMMENT '排序',
  `status` tinyint(2) NOT NULL DEFAULT '1' COMMENT '状态（0：禁用，1：正常）',
  `create_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '开始时间',
  `start_time` int(11) DEFAULT NULL,
  `end_time` int(11) unsigned DEFAULT '0' COMMENT '结束时间',
  `target` varchar(20) DEFAULT '_blank',
  `mini_pic` int(10) NOT NULL COMMENT '缩略图',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='广告表';

-- -----------------------------
-- Records of `tab_adv`
-- -----------------------------
INSERT INTO `tab_adv` VALUES ('1', '游戏中心测试0', '7', '35', '0', 'http://www.baidu.com', '0', '1', '0', '', '0', '_blank', '33');
INSERT INTO `tab_adv` VALUES ('2', '游戏中心测试1', '7', '29', '0', 'http://www.baidu.com', '1', '1', '0', '', '0', '_blank', '34');
INSERT INTO `tab_adv` VALUES ('3', '神武2手游', '1', '19', '0', '', '0', '1', '0', '', '0', '_blank', '0');

-- -----------------------------
-- Table structure for `tab_adv_pos`
-- -----------------------------
DROP TABLE IF EXISTS `tab_adv_pos`;
CREATE TABLE `tab_adv_pos` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `name` varchar(50) NOT NULL,
  `title` char(80) NOT NULL DEFAULT '' COMMENT '广告位置名称',
  `module` varchar(100) NOT NULL COMMENT '所在模块 模块/控制器/方法',
  `type` int(11) unsigned NOT NULL DEFAULT '1' COMMENT '广告位类型 \r\n1.单图\r\n2.多图\r\n3.文字链接\r\n4.代码',
  `status` tinyint(2) NOT NULL DEFAULT '1' COMMENT '状态（0：禁用，1：正常）',
  `data` varchar(500) NOT NULL COMMENT '额外的数据',
  `width` char(20) NOT NULL DEFAULT '' COMMENT '广告位置宽度',
  `height` char(20) NOT NULL DEFAULT '' COMMENT '广告位置高度',
  `margin` varchar(50) NOT NULL COMMENT '边缘',
  `padding` varchar(50) NOT NULL COMMENT '留白',
  `theme` varchar(50) NOT NULL DEFAULT 'all' COMMENT '适用主题，默认为all，通用',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=17 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='广告位置表';

-- -----------------------------
-- Records of `tab_adv_pos`
-- -----------------------------
INSERT INTO `tab_adv_pos` VALUES ('1', 'slider_media', '媒体首页轮播图', 'media', '1', '1', '', '1200px', '300px', '0', '0', 'all');
INSERT INTO `tab_adv_pos` VALUES ('2', 'index_top_media', '媒体首页顶部广告', 'media', '1', '0', '', '120px', '50px', '0', '0', 'all');
INSERT INTO `tab_adv_pos` VALUES ('3', 'slider_app', 'app首页轮播图', 'app', '3', '1', '', '120px', '30px', '0', '0', 'all');
INSERT INTO `tab_adv_pos` VALUES ('7', 'slider_game_media', '游戏中心轮播图', 'media', '2', '1', '', '810', '320', '', '', 'all');
INSERT INTO `tab_adv_pos` VALUES ('16', 'index_bottom_media', '媒体首页底部广告', 'media', '1', '1', '', '390', '160', '', '', 'all');
INSERT INTO `tab_adv_pos` VALUES ('9', 'gift_top_media', '礼包中心宣传位#1', 'media', '1', '1', '', '320', '320', '', '', 'all');
INSERT INTO `tab_adv_pos` VALUES ('10', 'gift_top_media', '礼包中心宣传位#2', 'media', '1', '1', '', '253', '159', '', '', 'all');
INSERT INTO `tab_adv_pos` VALUES ('11', 'gift_top_media', '礼包中心宣传位#3', 'media', '1', '1', '', '253', '159', '', '', 'all');
INSERT INTO `tab_adv_pos` VALUES ('12', 'gift_top_media', '礼包中心宣传位#4', 'media', '1', '1', '', '265', '320', '', '', 'all');
INSERT INTO `tab_adv_pos` VALUES ('13', 'gift_top_media', '礼包中心宣传位#5', 'media', '1', '1', '', '416', '159', '', '', 'all');
INSERT INTO `tab_adv_pos` VALUES ('14', 'gift_top_media', '礼包中心宣传位#6', 'media', '1', '1', '', '207', '158', '', '', 'all');
INSERT INTO `tab_adv_pos` VALUES ('15', 'gift_top_media', '礼包中心宣传位#7', 'media', '1', '1', '', '207', '158', '', '', 'all');

-- -----------------------------
-- Table structure for `tab_agent`
-- -----------------------------
DROP TABLE IF EXISTS `tab_agent`;
CREATE TABLE `tab_agent` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '自增主键',
  `order_number` varchar(30) DEFAULT NULL COMMENT '订单号',
  `pay_order_number` varchar(30) NOT NULL COMMENT '支付订单号 ',
  `game_id` int(11) DEFAULT NULL COMMENT '游戏ID',
  `game_appid` varchar(32) DEFAULT NULL COMMENT '游戏APPID',
  `game_name` varchar(30) DEFAULT NULL COMMENT '游戏名称',
  `promote_id` int(11) DEFAULT '0' COMMENT '推广员ID',
  `promote_account` varchar(30) DEFAULT NULL COMMENT '推广员账号',
  `user_id` int(11) DEFAULT NULL COMMENT '用户ID',
  `user_account` varchar(30) DEFAULT NULL COMMENT '玩家账号',
  `user_nickname` varchar(30) DEFAULT NULL COMMENT '用户昵称',
  `amount` double(10,2) DEFAULT '0.00' COMMENT '支付金额',
  `real_amount` double(10,2) DEFAULT '0.00' COMMENT '实际金额',
  `pay_way` tinyint(2) DEFAULT NULL COMMENT '支付方式 1支付宝 2微信',
  `pay_status` tinyint(2) DEFAULT '0' COMMENT '支付状态',
  `pay_type` tinyint(2) DEFAULT NULL COMMENT '类型',
  `create_time` int(11) DEFAULT NULL COMMENT '时间',
  `zhekou` int(11) NOT NULL DEFAULT '0' COMMENT '折扣比例',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COMMENT='代理充值记录';

-- -----------------------------
-- Records of `tab_agent`
-- -----------------------------
INSERT INTO `tab_agent` VALUES ('1', '', 'AG_2016081204112226Vo', '1', 'CC44E9A9FDC231C00', '神武2', '4', 'daniel0857', '38', '183383', '183383', '98.00', '0.00', '1', '0', '0', '1470946282', '0');
INSERT INTO `tab_agent` VALUES ('2', '', 'AG_20160812041146aIwP', '1', 'CC44E9A9FDC231C00', '神武2', '4', 'daniel0857', '38', '183383', '183383', '100.00', '0.00', '2', '0', '0', '1470946306', '0');

-- -----------------------------
-- Table structure for `tab_apply`
-- -----------------------------
DROP TABLE IF EXISTS `tab_apply`;
CREATE TABLE `tab_apply` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '自增主键',
  `game_id` int(11) DEFAULT NULL COMMENT '游戏ID',
  `game_name` varchar(30) DEFAULT NULL COMMENT '游戏名称',
  `promote_id` int(11) DEFAULT NULL COMMENT '推广员ID',
  `promote_account` varchar(30) DEFAULT NULL COMMENT '推广账号',
  `pattern` tinyint(2) DEFAULT '0' COMMENT '合作模式(0 CPS 1 CPA)',
  `ratio` double(5,2) DEFAULT '0.00' COMMENT '分成比例',
  `money` int(11) DEFAULT '0' COMMENT '注册单价',
  `apply_time` int(11) DEFAULT NULL COMMENT '申请时间',
  `status` tinyint(2) DEFAULT NULL COMMENT '审核状态',
  `enable_status` tinyint(2) DEFAULT NULL COMMENT '操作状态',
  `pack_url` varchar(255) DEFAULT NULL COMMENT '游戏包地址',
  `dow_url` varchar(255) DEFAULT NULL COMMENT '下载地址',
  `dispose_id` int(11) DEFAULT NULL COMMENT '操作人',
  `dispose_time` int(11) DEFAULT NULL COMMENT '操作时间',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=utf8 COMMENT='游戏申请表';

-- -----------------------------
-- Records of `tab_apply`
-- -----------------------------
INSERT INTO `tab_apply` VALUES ('1', '1', '神武2', '5', 'b0936155', '0', '50.00', '0', '1470855981', '0', '1', '', '', '', '');
INSERT INTO `tab_apply` VALUES ('2', '1', '神武2', '4', 'daniel0857', '0', '50.00', '0', '1470856308', '1', '1', './Uploads/GamePack/game_package1-4.apk', '/index.php?s=/Home/Down/down_file/game_id/1/promote_id/4', '1', '1470925769');
INSERT INTO `tab_apply` VALUES ('8', '1', '神武2', '7', 'zlt12345', '0', '20.00', '0', '1470933624', '1', '1', './Uploads/GamePack/game_package1-7.apk', '/index.php?s=/Home/Down/down_file/game_id/1/promote_id/7', '1', '1470933666');

-- -----------------------------
-- Table structure for `tab_areas`
-- -----------------------------
DROP TABLE IF EXISTS `tab_areas`;
CREATE TABLE `tab_areas` (
  `area_id` smallint(6) unsigned NOT NULL AUTO_INCREMENT COMMENT '地区id',
  `parent_id` smallint(6) unsigned NOT NULL DEFAULT '0' COMMENT '地区父id',
  `area_name` varchar(120) NOT NULL DEFAULT '' COMMENT '地区名称',
  `area_type` tinyint(1) NOT NULL DEFAULT '2' COMMENT '地区类型 0:country,1:province,2:city,3:district',
  PRIMARY KEY (`area_id`),
  KEY `parent_id` (`parent_id`),
  KEY `area_type` (`area_type`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


-- -----------------------------
-- Table structure for `tab_bill`
-- -----------------------------
DROP TABLE IF EXISTS `tab_bill`;
CREATE TABLE `tab_bill` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `bill_number` varchar(80) NOT NULL COMMENT '对账单号',
  `bill_time` varchar(30) NOT NULL COMMENT '对账时间',
  `promote_id` int(11) DEFAULT NULL COMMENT '推广员ID',
  `promote_account` varchar(30) DEFAULT NULL COMMENT '推广员账号',
  `game_id` int(11) DEFAULT NULL COMMENT '游戏ID',
  `game_name` varchar(30) NOT NULL COMMENT '游戏名称',
  `total_money` double(10,2) DEFAULT '0.00' COMMENT '充值总额',
  `total_number` int(19) unsigned NOT NULL COMMENT '注册人数',
  `status` tinyint(2) NOT NULL DEFAULT '1' COMMENT '状态',
  `bill_start_time` int(19) unsigned NOT NULL COMMENT '对账开始时间',
  `bill_end_time` int(19) unsigned NOT NULL COMMENT '对账结束时间',
  `create_time` int(11) DEFAULT NULL COMMENT '创建时间',
  `settlement_status` tinyint(2) NOT NULL DEFAULT '0' COMMENT '结算状态',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;


-- -----------------------------
-- Table structure for `tab_bind_spend`
-- -----------------------------
DROP TABLE IF EXISTS `tab_bind_spend`;
CREATE TABLE `tab_bind_spend` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '自增主键',
  `user_id` int(11) NOT NULL COMMENT '用户id',
  `user_account` varchar(30) NOT NULL COMMENT '用户账号',
  `user_nickname` varchar(30) NOT NULL COMMENT '用户昵称',
  `game_id` int(11) NOT NULL COMMENT '游戏id',
  `game_appid` varchar(30) NOT NULL COMMENT '游戏appid',
  `game_name` varchar(30) NOT NULL COMMENT '游戏名称',
  `order_number` varchar(30) NOT NULL COMMENT '订单号',
  `pay_order_number` varchar(30) NOT NULL COMMENT '商户订单号',
  `props_name` varchar(30) NOT NULL COMMENT '道具名称',
  `pay_amount` double(10,2) NOT NULL DEFAULT '0.00' COMMENT '金额',
  `pay_time` int(11) NOT NULL COMMENT '支付时间',
  `pay_status` tinyint(2) NOT NULL DEFAULT '0' COMMENT '支付状态',
  `pay_game_status` tinyint(2) NOT NULL DEFAULT '0' COMMENT '游戏支付状态',
  `extend` varchar(32) DEFAULT NULL COMMENT '通知游戏方扩展(一般是游戏方透传)',
  `pay_way` tinyint(2) NOT NULL DEFAULT '0' COMMENT '支付方式',
  `pay_source` tinyint(2) NOT NULL DEFAULT '0' COMMENT '支付来源',
  `spend_ip` varchar(16) NOT NULL COMMENT '支付ip',
  `promote_account` varchar(30) NOT NULL COMMENT '推广员账号',
  `promote_id` int(11) NOT NULL DEFAULT '0' COMMENT '推广员id 0自然注册',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COMMENT='绑定消费表';

-- -----------------------------
-- Records of `tab_bind_spend`
-- -----------------------------
INSERT INTO `tab_bind_spend` VALUES ('1', '38', '183383', '183383', '1', 'CC44E9A9FDC231C00', '神武2', 'PF_20160812100134WfbV', 'PF_20160812100134WfbV', '19600元宝首充礼包', '98.00', '1470967294', '1', '1', 'gf=xiyou#kid=md_s_1#rid=10026#gi', '1', '0', '60.248.238.175', 'daniel0857', '4');

-- -----------------------------
-- Table structure for `tab_deposit`
-- -----------------------------
DROP TABLE IF EXISTS `tab_deposit`;
CREATE TABLE `tab_deposit` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '自增主键',
  `order_number` varchar(30) DEFAULT NULL COMMENT '订单号',
  `pay_order_number` varchar(30) DEFAULT NULL COMMENT '支付订单号',
  `user_id` int(11) DEFAULT NULL COMMENT '用户id',
  `user_account` varchar(30) DEFAULT NULL COMMENT '用户账号',
  `user_nickname` varchar(30) DEFAULT NULL COMMENT '用户昵称',
  `promote_id` int(11) DEFAULT NULL COMMENT '推广员ID',
  `promote_account` varchar(30) DEFAULT NULL COMMENT '推广账号',
  `pay_amount` double(10,2) DEFAULT '0.00' COMMENT '充值金额',
  `pay_status` tinyint(2) DEFAULT '0' COMMENT '充值状态',
  `pay_way` tinyint(2) DEFAULT '0' COMMENT '支付方式',
  `pay_source` tinyint(2) DEFAULT '0' COMMENT '支付来源',
  `pay_ip` varchar(20) DEFAULT NULL COMMENT '充值IP',
  `create_time` int(11) DEFAULT NULL COMMENT '支付时间',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=79 DEFAULT CHARSET=utf8 COMMENT='平台币充值记录';

-- -----------------------------
-- Records of `tab_deposit`
-- -----------------------------
INSERT INTO `tab_deposit` VALUES ('1', '', 'PF_20160808203939fAiz', '2', '674640', '674640', '0', '自然注册', '1.00', '0', '3', '2', '153.36.68.207', '1470659979');
INSERT INTO `tab_deposit` VALUES ('2', '', 'PF_201608082045038uLS', '1', '316046', '316046', '0', '自然注册', '1.00', '0', '3', '2', '153.36.68.207', '1470660303');
INSERT INTO `tab_deposit` VALUES ('3', '', 'PF_20160808204750roS7', '2', '674640', '674640', '0', '自然注册', '111.00', '0', '3', '2', '153.36.68.207', '1470660470');
INSERT INTO `tab_deposit` VALUES ('4', '', 'PF_20160808205053QGN9', '2', '674640', '674640', '0', '自然注册', '111.00', '0', '3', '2', '153.36.68.207', '1470660653');
INSERT INTO `tab_deposit` VALUES ('5', '', 'PF_20160808210121N92E', '3', '564942', '564942', '0', '自然注册', '1.00', '0', '3', '2', '153.36.68.207', '1470661281');
INSERT INTO `tab_deposit` VALUES ('6', '', 'PF_201608082101292Uth', '3', '564942', '564942', '0', '自然注册', '1.00', '0', '3', '2', '153.36.68.207', '1470661289');
INSERT INTO `tab_deposit` VALUES ('7', '', 'PF_20160808210302Y4SX', '4', '563000', '563000', '0', '自然注册', '1.00', '0', '3', '2', '153.36.68.207', '1470661382');
INSERT INTO `tab_deposit` VALUES ('8', '', 'PF_20160808210335lJTE', '4', '563000', '563000', '0', '自然注册', '11.00', '0', '3', '2', '153.36.68.207', '1470661415');
INSERT INTO `tab_deposit` VALUES ('9', '', 'PF_20160809093658ur3d', '5', 'a111111', '', '0', '', '1.00', '0', '1', '1', '153.36.161.180', '1470706618');
INSERT INTO `tab_deposit` VALUES ('10', '', 'PF_20160809093740URP2', '5', 'a111111', '', '0', '', '1.00', '0', '1', '1', '153.36.161.180', '1470706660');
INSERT INTO `tab_deposit` VALUES ('11', '', 'PF_201608090941467EIq', '5', 'a111111', '', '0', '', '1.00', '0', '1', '1', '153.36.161.180', '1470706906');
INSERT INTO `tab_deposit` VALUES ('12', '', 'PF_20160809094920LMPk', '5', 'a111111', '', '0', '', '1.00', '0', '1', '1', '153.36.161.180', '1470707360');
INSERT INTO `tab_deposit` VALUES ('13', '', 'PF_20160809095317pjaO', '6', 'aaaaaa', '', '0', '', '1.00', '0', '1', '1', '153.36.161.180', '1470707597');
INSERT INTO `tab_deposit` VALUES ('14', '', 'PF_2016080910043202ca', '6', 'aaaaaa', '', '0', '', '1.00', '0', '1', '1', '153.36.161.180', '1470708272');
INSERT INTO `tab_deposit` VALUES ('15', '', 'PF_201608091005223Zlc', '6', 'aaaaaa', '', '0', '', '1.00', '0', '1', '1', '153.36.161.180', '1470708322');
INSERT INTO `tab_deposit` VALUES ('16', '', 'PF_201608091005543kvb', '6', 'aaaaaa', '', '0', '', '1.00', '0', '1', '1', '153.36.161.180', '1470708354');
INSERT INTO `tab_deposit` VALUES ('17', '', 'PF_20160809100804qUal', '6', 'aaaaaa', '', '0', '', '1.00', '0', '1', '1', '153.36.161.180', '1470708484');
INSERT INTO `tab_deposit` VALUES ('18', '', 'PF_20160809101050DGAj', '6', 'aaaaaa', '', '0', '', '1.00', '0', '1', '1', '153.36.161.180', '1470708650');
INSERT INTO `tab_deposit` VALUES ('19', '', 'PF_20160809101247GnWm', '6', 'aaaaaa', '', '0', '', '1.00', '0', '1', '1', '153.36.161.180', '1470708767');
INSERT INTO `tab_deposit` VALUES ('20', '', 'PF_20160809101352KEyy', '6', 'aaaaaa', '', '0', '', '1.00', '0', '1', '1', '153.36.161.180', '1470708832');
INSERT INTO `tab_deposit` VALUES ('21', '', 'PF_20160809101722EXSM', '6', 'aaaaaa', '', '0', '', '1.00', '0', '1', '1', '153.36.161.180', '1470709042');
INSERT INTO `tab_deposit` VALUES ('22', '', 'PF_20160809102140rcya', '6', 'aaaaaa', '', '0', '', '1.00', '0', '1', '1', '153.36.161.180', '1470709300');
INSERT INTO `tab_deposit` VALUES ('23', '', 'PF_20160809102221rojR', '6', 'aaaaaa', '', '0', '', '1.00', '0', '1', '1', '153.36.161.180', '1470709341');
INSERT INTO `tab_deposit` VALUES ('24', '', 'PF_201608091246313x3C', '7', 'daniel0857', '', '0', '', '1.00', '0', '1', '1', '60.248.238.175', '1470717991');
INSERT INTO `tab_deposit` VALUES ('25', '', 'PF_201608091253217Ixo', '6', 'aaaaaa', '', '0', '', '1.00', '0', '1', '1', '153.36.161.180', '1470718401');
INSERT INTO `tab_deposit` VALUES ('26', '', 'PF_20160809130350m4Bm', '7', 'daniel0857', '', '0', '', '1.00', '0', '1', '1', '60.248.238.175', '1470719030');
INSERT INTO `tab_deposit` VALUES ('27', '', 'PF_20160809131054V2aF', '6', 'aaaaaa', '', '0', '', '1.00', '0', '1', '1', '153.36.161.180', '1470719454');
INSERT INTO `tab_deposit` VALUES ('28', '', 'PF_201608091312259wnx', '7', 'daniel0857', '', '0', '', '1.00', '0', '1', '1', '60.248.238.175', '1470719545');
INSERT INTO `tab_deposit` VALUES ('29', '', 'PF_201608091324207kNP', '6', 'aaaaaa', '', '0', '', '1.00', '0', '1', '1', '153.36.161.180', '1470720260');
INSERT INTO `tab_deposit` VALUES ('30', '', 'PF_20160809132538S4vj', '6', 'aaaaaa', '', '0', '', '1.00', '0', '1', '1', '153.36.161.180', '1470720338');
INSERT INTO `tab_deposit` VALUES ('31', '', 'PF_20160809132655NeFZ', '6', 'aaaaaa', '', '0', '', '1.00', '0', '1', '1', '153.36.161.180', '1470720415');
INSERT INTO `tab_deposit` VALUES ('32', '', 'PF_20160809132735rkd5', '6', 'aaaaaa', '', '0', '', '1.00', '0', '1', '1', '153.36.161.180', '1470720455');
INSERT INTO `tab_deposit` VALUES ('33', '', 'PF_20160809132813ziQG', '6', 'aaaaaa', '', '0', '', '1.00', '0', '1', '1', '153.36.161.180', '1470720493');
INSERT INTO `tab_deposit` VALUES ('34', '', 'PF_201608091329383dQv', '6', 'aaaaaa', '', '0', '', '1.00', '0', '1', '1', '153.36.161.180', '1470720578');
INSERT INTO `tab_deposit` VALUES ('35', '', 'PF_20160809133005tMaC', '6', 'aaaaaa', '', '0', '', '1.00', '0', '1', '1', '153.36.161.180', '1470720605');
INSERT INTO `tab_deposit` VALUES ('36', '', 'PF_201608091330247cvm', '6', 'aaaaaa', '', '0', '', '1.00', '0', '1', '1', '153.36.161.180', '1470720624');
INSERT INTO `tab_deposit` VALUES ('37', '', 'PF_20160809133047JVoe', '6', 'aaaaaa', '', '0', '', '1.00', '0', '1', '1', '153.36.161.180', '1470720647');
INSERT INTO `tab_deposit` VALUES ('38', '', 'PF_201608091331465KCe', '6', 'aaaaaa', '', '0', '', '1.00', '0', '1', '1', '153.36.161.180', '1470720706');
INSERT INTO `tab_deposit` VALUES ('39', '', 'PF_20160809133356fn8h', '6', 'aaaaaa', '', '0', '', '1.00', '0', '1', '1', '153.36.161.180', '1470720836');
INSERT INTO `tab_deposit` VALUES ('40', '', 'PF_201608091337137zbe', '6', 'aaaaaa', '', '0', '', '1.00', '0', '1', '1', '153.36.161.180', '1470721033');
INSERT INTO `tab_deposit` VALUES ('41', '', 'PF_20160809134045zNfo', '6', 'aaaaaa', '', '0', '', '1.00', '0', '1', '1', '153.36.161.180', '1470721245');
INSERT INTO `tab_deposit` VALUES ('42', '', 'PF_20160809134117uZg6', '6', 'aaaaaa', '', '0', '', '1.00', '0', '1', '1', '153.36.161.180', '1470721277');
INSERT INTO `tab_deposit` VALUES ('43', '', 'PF_20160809134542j1xY', '6', 'aaaaaa', '', '0', '', '1.00', '0', '1', '1', '153.36.161.180', '1470721541');
INSERT INTO `tab_deposit` VALUES ('44', '', 'PF_20160809134605vsaZ', '6', 'aaaaaa', '', '0', '', '1.00', '0', '1', '1', '153.36.161.180', '1470721564');
INSERT INTO `tab_deposit` VALUES ('45', '', 'PF_20160809135350CB9g', '7', 'daniel0857', '', '0', '', '1.00', '0', '1', '1', '60.248.238.175', '1470722030');
INSERT INTO `tab_deposit` VALUES ('46', '', 'PF_20160809135409fFmB', '7', 'daniel0857', '', '0', '', '1.00', '0', '1', '1', '60.248.238.175', '1470722049');
INSERT INTO `tab_deposit` VALUES ('47', '', 'PF_2016080914025131sb', '7', 'daniel0857', '', '0', '', '1.00', '0', '1', '1', '60.248.238.175', '1470722571');
INSERT INTO `tab_deposit` VALUES ('48', '', 'PF_20160809141018EPqq', '7', 'daniel0857', '', '0', '', '1.00', '0', '1', '1', '60.248.238.175', '1470723018');
INSERT INTO `tab_deposit` VALUES ('49', '', 'PF_20160809143603zUd8', '6', 'aaaaaa', '', '0', '', '1.00', '0', '1', '1', '153.36.161.180', '1470724563');
INSERT INTO `tab_deposit` VALUES ('50', '', 'PF_20160809151011ehO6', '6', 'aaaaaa', '', '0', '', '1.00', '0', '1', '1', '153.36.161.180', '1470726611');
INSERT INTO `tab_deposit` VALUES ('51', '', 'PF_20160809151028HaYz', '6', 'aaaaaa', '', '0', '', '1.00', '0', '1', '1', '153.36.161.180', '1470726628');
INSERT INTO `tab_deposit` VALUES ('52', '', 'PF_20160809151059v3Np', '6', 'aaaaaa', '', '0', '', '1.00', '0', '1', '1', '153.36.161.180', '1470726659');
INSERT INTO `tab_deposit` VALUES ('53', '', 'PF_201608091511586EKl', '6', 'aaaaaa', '', '0', '', '1.00', '0', '1', '1', '153.36.161.180', '1470726718');
INSERT INTO `tab_deposit` VALUES ('54', '', 'PF_20160809152033WGxF', '6', 'aaaaaa', '', '0', '', '1.00', '0', '1', '1', '153.36.161.180', '1470727233');
INSERT INTO `tab_deposit` VALUES ('55', '', 'PF_20160809152111xXKW', '6', 'aaaaaa', '', '0', '', '1.00', '0', '1', '1', '153.36.161.180', '1470727271');
INSERT INTO `tab_deposit` VALUES ('56', '', 'PF_20160809152347cGxL', '6', 'aaaaaa', '', '0', '', '1.00', '0', '1', '1', '153.36.161.180', '1470727427');
INSERT INTO `tab_deposit` VALUES ('57', '', 'PF_20160809152501uUDV', '6', 'aaaaaa', '', '0', '', '1.00', '0', '1', '1', '153.36.161.180', '1470727501');
INSERT INTO `tab_deposit` VALUES ('58', '', 'PF_20160809152704Dfys', '6', 'aaaaaa', '', '0', '', '1.00', '0', '1', '1', '153.36.161.180', '1470727624');
INSERT INTO `tab_deposit` VALUES ('59', '', 'PF_20160809155540rtGp', '6', 'aaaaaa', '', '0', '', '1.00', '0', '1', '1', '153.36.161.180', '1470729340');
INSERT INTO `tab_deposit` VALUES ('60', '', 'PF_20160809155959gnmR', '6', 'aaaaaa', '', '0', '', '1.00', '0', '1', '1', '153.36.161.180', '1470729599');
INSERT INTO `tab_deposit` VALUES ('61', '', 'PF_201608091600320Dwp', '6', 'aaaaaa', '', '0', '', '1.00', '0', '1', '1', '153.36.161.180', '1470729632');
INSERT INTO `tab_deposit` VALUES ('62', '', 'PF_20160809160112vxBe', '6', 'aaaaaa', '', '0', '', '1.00', '0', '1', '1', '153.36.161.180', '1470729672');
INSERT INTO `tab_deposit` VALUES ('63', '', 'PF_20160809161950WexV', '6', 'aaaaaa', '', '0', '', '1.00', '0', '1', '1', '153.36.161.180', '1470730790');
INSERT INTO `tab_deposit` VALUES ('64', '', 'PF_20160809162309OfiT', '6', 'aaaaaa', '', '0', '', '1.00', '0', '1', '1', '153.36.161.180', '1470730989');
INSERT INTO `tab_deposit` VALUES ('65', '', 'PF_20160809162553ttRy', '7', 'daniel0857', '', '0', '', '1.00', '0', '1', '1', '60.248.238.175', '1470731153');
INSERT INTO `tab_deposit` VALUES ('66', '', 'PF_20160809170421pgNZ', '6', 'aaaaaa', '', '0', '', '1.00', '0', '3', '1', '153.36.161.180', '1470733461');
INSERT INTO `tab_deposit` VALUES ('67', '', 'PF_20160810091105j8xn', '6', 'aaaaaa', '', '0', '', '0.01', '0', '3', '1', '153.36.164.6', '1470791465');
INSERT INTO `tab_deposit` VALUES ('68', '', 'PF_20160811032251UzUx', '19', '15505437898', '15505437898', '3', 'test1234', '100.00', '0', '3', '2', '60.248.238.175', '1470856971');
INSERT INTO `tab_deposit` VALUES ('69', '', 'PF_20160811135930boMO', '24', '781352', '781352', '0', '自然注册', '111.00', '0', '3', '2', '157.0.226.72', '1470895170');
INSERT INTO `tab_deposit` VALUES ('70', '', 'PF_20160812022933lRup', '38', '183383', '183383', '4', 'daniel0857', '1000.00', '0', '3', '2', '60.248.238.175', '1470940173');
INSERT INTO `tab_deposit` VALUES ('71', '', 'PF_20160812032541QPaB', '73', '650265', '650265', '4', 'daniel0857', '6.00', '1', '3', '2', '60.248.238.175', '1470943541');
INSERT INTO `tab_deposit` VALUES ('72', '', 'PF_20160812152545yno1', '180', '777888', '777888', '0', '自然注册', '11.00', '0', '3', '2', '153.36.68.155', '1470986745');
INSERT INTO `tab_deposit` VALUES ('73', '', 'PF_20160812152611rdAS', '180', '777888', '777888', '0', '自然注册', '11111.00', '0', '3', '2', '153.36.68.155', '1470986771');
INSERT INTO `tab_deposit` VALUES ('74', '', 'PF_20160812152625lm9b', '180', '777888', '777888', '0', '自然注册', '11.00', '0', '3', '2', '153.36.68.155', '1470986785');
INSERT INTO `tab_deposit` VALUES ('75', '', 'PF_20160812152701cS9n', '180', '777888', '777888', '0', '自然注册', '11.00', '0', '3', '2', '153.36.68.155', '1470986821');
INSERT INTO `tab_deposit` VALUES ('76', '', 'PF_20160812153315Ffod', '180', '777888', '777888', '0', '自然注册', '11.00', '0', '3', '2', '153.36.68.155', '1470987195');
INSERT INTO `tab_deposit` VALUES ('77', '', 'PF_201608121750461H0s', '244', '265288', '265288', '7', 'zlt12345', '1.00', '0', '3', '2', '115.49.180.154', '1470995446');
INSERT INTO `tab_deposit` VALUES ('78', '', 'PF_20160812175056Zt1Z', '244', '265288', '265288', '7', 'zlt12345', '2.00', '0', '3', '2', '115.49.180.154', '1470995456');

-- -----------------------------
-- Table structure for `tab_down_stat`
-- -----------------------------
DROP TABLE IF EXISTS `tab_down_stat`;
CREATE TABLE `tab_down_stat` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键自增',
  `promote_id` int(11) DEFAULT NULL COMMENT '推广员id',
  `game_id` int(11) DEFAULT NULL COMMENT '游戏id',
  `number` int(2) DEFAULT '1' COMMENT '下载次数',
  `create_time` int(11) DEFAULT NULL COMMENT '时间',
  `type` int(2) DEFAULT NULL COMMENT '类型',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=26 DEFAULT CHARSET=utf8 COMMENT='下载统计表';

-- -----------------------------
-- Records of `tab_down_stat`
-- -----------------------------
INSERT INTO `tab_down_stat` VALUES ('1', '0', '1', '1', '1470918523', '0');
INSERT INTO `tab_down_stat` VALUES ('2', '0', '1', '1', '1470921424', '0');
INSERT INTO `tab_down_stat` VALUES ('3', '0', '1', '1', '1470933566', '0');
INSERT INTO `tab_down_stat` VALUES ('4', '0', '1', '1', '1470934419', '0');
INSERT INTO `tab_down_stat` VALUES ('5', '0', '1', '1', '1470934552', '0');
INSERT INTO `tab_down_stat` VALUES ('6', '0', '1', '1', '1470935391', '0');
INSERT INTO `tab_down_stat` VALUES ('7', '0', '1', '1', '1470935445', '0');
INSERT INTO `tab_down_stat` VALUES ('8', '0', '1', '1', '1470935459', '0');
INSERT INTO `tab_down_stat` VALUES ('9', '0', '1', '1', '1470935577', '0');
INSERT INTO `tab_down_stat` VALUES ('10', '0', '1', '1', '1470936381', '0');
INSERT INTO `tab_down_stat` VALUES ('11', '0', '1', '1', '1470947626', '0');
INSERT INTO `tab_down_stat` VALUES ('12', '0', '1', '1', '1470948759', '0');
INSERT INTO `tab_down_stat` VALUES ('13', '0', '1', '1', '1470967351', '0');
INSERT INTO `tab_down_stat` VALUES ('14', '0', '1', '1', '1470967358', '0');
INSERT INTO `tab_down_stat` VALUES ('15', '0', '1', '1', '1470967358', '0');
INSERT INTO `tab_down_stat` VALUES ('16', '0', '1', '1', '1470967360', '0');
INSERT INTO `tab_down_stat` VALUES ('17', '0', '1', '1', '1470967363', '0');
INSERT INTO `tab_down_stat` VALUES ('18', '0', '1', '1', '1470967365', '0');
INSERT INTO `tab_down_stat` VALUES ('19', '0', '1', '1', '1470967368', '0');
INSERT INTO `tab_down_stat` VALUES ('20', '0', '1', '1', '1470967382', '0');
INSERT INTO `tab_down_stat` VALUES ('21', '0', '1', '1', '1470967397', '0');
INSERT INTO `tab_down_stat` VALUES ('22', '0', '1', '1', '1470967547', '0');
INSERT INTO `tab_down_stat` VALUES ('23', '0', '1', '1', '1470968877', '0');
INSERT INTO `tab_down_stat` VALUES ('24', '0', '1', '1', '1470969205', '0');
INSERT INTO `tab_down_stat` VALUES ('25', '0', '1', '1', '1470977768', '0');

-- -----------------------------
-- Table structure for `tab_game`
-- -----------------------------
DROP TABLE IF EXISTS `tab_game`;
CREATE TABLE `tab_game` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键自增',
  `game_name` varchar(30) DEFAULT NULL COMMENT '游戏名称',
  `sort` int(10) unsigned DEFAULT '1' COMMENT '排序',
  `short` varchar(20) DEFAULT NULL COMMENT '游戏简写',
  `game_type_id` int(10) DEFAULT NULL COMMENT '游戏类型id',
  `game_type_name` varchar(20) DEFAULT NULL COMMENT '游戏类型名称',
  `game_score` double(3,0) DEFAULT NULL COMMENT '游戏评分',
  `features` varchar(50) DEFAULT NULL COMMENT '游戏特征',
  `recommend_level` double(3,0) DEFAULT NULL,
  `version` varchar(10) DEFAULT NULL COMMENT '版本号',
  `game_size` varchar(10) DEFAULT '0' COMMENT '游戏大小',
  `icon` int(11) DEFAULT NULL COMMENT '游戏图标',
  `cover` int(11) DEFAULT NULL COMMENT '游戏封面',
  `screenshot` varchar(255) DEFAULT NULL COMMENT '游戏截图',
  `introduction` varchar(300) DEFAULT NULL COMMENT '游戏简介',
  `and_dow_address` varchar(255) NOT NULL COMMENT '安卓游戏下载地址',
  `ios_dow_address` varchar(255) DEFAULT NULL COMMENT 'ios游戏下载地址',
  `game_address` varchar(255) DEFAULT NULL COMMENT '外部链接游戏地址',
  `dow_num` int(10) DEFAULT '0' COMMENT '游戏下载数量',
  `game_status` tinyint(2) DEFAULT NULL COMMENT '游戏状态(0:关闭,1:开启)',
  `recommend_status` tinyint(2) DEFAULT '1' COMMENT '推荐状态(0:否,1是)',
  `pay_status` tinyint(2) DEFAULT '1' COMMENT '充值状态(0:关闭,1:开启)',
  `dow_status` tinyint(2) DEFAULT '1' COMMENT '下载状态(0:关闭,1:开启)',
  `developers` varchar(30) DEFAULT NULL COMMENT '开发商',
  `create_time` int(11) DEFAULT NULL COMMENT '创建时间',
  `discount` double(4,2) DEFAULT NULL COMMENT '折扣',
  `language` varchar(10) DEFAULT NULL COMMENT '语言',
  `game_appid` varchar(32) DEFAULT NULL COMMENT '游戏appid',
  `game_coin_name` varchar(10) DEFAULT NULL COMMENT '游戏币名称',
  `game_coin_ration` varchar(10) DEFAULT NULL COMMENT '游戏币比例',
  `category` tinyint(2) DEFAULT '0' COMMENT '游戏开放类型',
  `ratio` double(5,2) unsigned NOT NULL DEFAULT '0.00' COMMENT '分成比例',
  `money` int(11) NOT NULL DEFAULT '0' COMMENT '注册单价',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COMMENT='游戏表';

-- -----------------------------
-- Records of `tab_game`
-- -----------------------------
INSERT INTO `tab_game` VALUES ('1', '神武2', '1', '', '', '', '10', '经典回合制手游', '9', '0.0.2', '226.22MB', '20', '27', '22,23,24,25', '', './Uploads/SourcePack/20160811222820_867.apk', '', './Uploads/SourcePack/20160811222820_867.apk', '35', '1', '1', '1', '1', '', '1470727453', '0.00', '', 'CC44E9A9FDC231C00', '', '', '0', '50.00', '0');

-- -----------------------------
-- Table structure for `tab_game_set`
-- -----------------------------
DROP TABLE IF EXISTS `tab_game_set`;
CREATE TABLE `tab_game_set` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT '自增主键',
  `game_id` int(11) NOT NULL COMMENT '游戏ID',
  `login_notify_url` varchar(255) DEFAULT NULL COMMENT '游戏登陆通知地址',
  `pay_notify_url` varchar(255) DEFAULT NULL COMMENT '游戏支付通知地址',
  `game_role_url` varchar(255) DEFAULT NULL COMMENT '游戏角色获取地址',
  `game_gift_url` varchar(255) DEFAULT NULL COMMENT '游戏礼包领取地址',
  `game_key` varchar(32) DEFAULT NULL COMMENT '游戏key',
  `access_key` varchar(32) DEFAULT NULL COMMENT '访问秘钥',
  `agent_id` varchar(32) DEFAULT NULL COMMENT '代理id(合作方标示)',
  `game_pay_appid` varchar(32) DEFAULT NULL COMMENT '游戏支付APPID',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COMMENT='游戏设置表（游戏对接时调用）';

-- -----------------------------
-- Records of `tab_game_set`
-- -----------------------------
INSERT INTO `tab_game_set` VALUES ('1', '1', '', 'http://mhxy.51syw.com:8001/dzg/payed', '', '', 'mengchuang', '', '', 'CC44E9A9FDC231C00');

-- -----------------------------
-- Table structure for `tab_game_source`
-- -----------------------------
DROP TABLE IF EXISTS `tab_game_source`;
CREATE TABLE `tab_game_source` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '自增主键',
  `game_id` int(11) DEFAULT NULL COMMENT '游戏id',
  `game_name` varchar(30) DEFAULT NULL COMMENT '游戏名称',
  `file_id` int(11) DEFAULT NULL COMMENT '文件id',
  `file_name` varchar(30) DEFAULT NULL COMMENT '文件名称',
  `file_url` varchar(255) DEFAULT NULL COMMENT '文件路径',
  `file_size` varchar(30) NOT NULL COMMENT '文件大小',
  `file_type` tinyint(2) DEFAULT NULL COMMENT '原包类型',
  `op_id` int(11) DEFAULT NULL COMMENT '操作人id',
  `op_account` varchar(30) DEFAULT NULL COMMENT '操作人名称',
  `remark` varchar(100) DEFAULT NULL COMMENT '备注',
  `create_time` int(11) DEFAULT NULL COMMENT '时间',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COMMENT='游戏原包';

-- -----------------------------
-- Records of `tab_game_source`
-- -----------------------------
INSERT INTO `tab_game_source` VALUES ('6', '1', '神武2', '0', '20160811222820_867.apk', './Uploads/SourcePack/20160811222820_867.apk', '226.22MB', '1', '1', 'admin', '', '1470925704');

-- -----------------------------
-- Table structure for `tab_game_type`
-- -----------------------------
DROP TABLE IF EXISTS `tab_game_type`;
CREATE TABLE `tab_game_type` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '自增主键',
  `type_name` varchar(20) DEFAULT NULL COMMENT '游戏类型名称',
  `icon` int(12) NOT NULL COMMENT '图标',
  `cover` int(12) NOT NULL COMMENT '封面',
  `status` tinyint(2) DEFAULT '1' COMMENT '状态(-1:删除,1:正常)',
  `status_show` tinyint(2) DEFAULT '1' COMMENT '显示状态(0:不显示,1:显示)',
  `op_id` int(11) DEFAULT NULL COMMENT '操作人id',
  `op_nickname` varchar(30) DEFAULT NULL COMMENT '操作人昵称',
  `create_time` int(11) DEFAULT NULL COMMENT '添加时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='游戏类型表';


-- -----------------------------
-- Table structure for `tab_gift_record`
-- -----------------------------
DROP TABLE IF EXISTS `tab_gift_record`;
CREATE TABLE `tab_gift_record` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT '自增主键',
  `game_id` int(11) DEFAULT NULL COMMENT '游戏id',
  `game_name` varchar(30) DEFAULT NULL COMMENT '游戏名称',
  `server_id` int(11) DEFAULT NULL COMMENT '区服id',
  `server_name` varchar(30) DEFAULT NULL COMMENT '区服名称',
  `gift_id` int(11) DEFAULT NULL COMMENT '礼包id',
  `gift_name` varchar(30) DEFAULT NULL COMMENT '礼包名称',
  `status` tinyint(2) DEFAULT '1' COMMENT '状态(0:未使用,1:已使用)',
  `novice` varchar(30) DEFAULT NULL COMMENT '激活码',
  `user_id` int(11) DEFAULT NULL COMMENT '用户id',
  `user_account` varchar(30) DEFAULT NULL COMMENT '用户昵称',
  `user_nickname` varchar(30) DEFAULT NULL COMMENT '用户昵称',
  `create_time` int(11) DEFAULT NULL COMMENT '创建时间',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='礼包领取记录';


-- -----------------------------
-- Table structure for `tab_giftbag`
-- -----------------------------
DROP TABLE IF EXISTS `tab_giftbag`;
CREATE TABLE `tab_giftbag` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '自增主键',
  `game_id` int(11) DEFAULT NULL COMMENT '游戏id',
  `game_name` varchar(30) DEFAULT NULL COMMENT '游戏名称',
  `server_id` int(11) DEFAULT NULL COMMENT '区服id',
  `server_name` varchar(30) DEFAULT NULL COMMENT '区服名称',
  `giftbag_name` varchar(30) DEFAULT NULL COMMENT '礼包名称',
  `giftbag_type` tinyint(2) DEFAULT NULL COMMENT '礼包类型',
  `level` int(3) DEFAULT NULL COMMENT '领取等级',
  `sort` int(10) DEFAULT '0' COMMENT '排序',
  `status` tinyint(2) DEFAULT '1' COMMENT '状态',
  `call_api` tinyint(2) DEFAULT '0' COMMENT '调用接口',
  `tong_server` tinyint(2) DEFAULT '0' COMMENT '是否通服',
  `recommend_status` tinyint(2) DEFAULT NULL COMMENT '礼包推荐状态',
  `novice` varchar(3000) DEFAULT NULL COMMENT '激活码',
  `digest` varchar(300) DEFAULT NULL COMMENT '摘要',
  `desribe` varchar(300) DEFAULT NULL COMMENT '描述',
  `start_time` int(11) DEFAULT NULL COMMENT '开始时间',
  `end_time` int(11) DEFAULT NULL COMMENT '结束时间',
  `create_time` int(11) DEFAULT NULL COMMENT '创建时间',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='礼包管理';


-- -----------------------------
-- Table structure for `tab_giftbag_type`
-- -----------------------------
DROP TABLE IF EXISTS `tab_giftbag_type`;
CREATE TABLE `tab_giftbag_type` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '自增主键',
  `type_name` varchar(20) DEFAULT NULL COMMENT '礼包类型名称',
  `status` tinyint(2) DEFAULT '1' COMMENT '状态(0:禁用,1:启用)',
  `op_id` int(11) DEFAULT NULL COMMENT '操作人id',
  `op_nickname` varchar(30) DEFAULT NULL COMMENT '操作人昵称',
  `create_time` int(11) DEFAULT NULL COMMENT '添加时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


-- -----------------------------
-- Table structure for `tab_links`
-- -----------------------------
DROP TABLE IF EXISTS `tab_links`;
CREATE TABLE `tab_links` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '自增主键',
  `title` varchar(50) DEFAULT NULL COMMENT '标题',
  `link_url` varchar(255) DEFAULT NULL COMMENT '友链地址',
  `status` tinyint(2) DEFAULT NULL COMMENT '状态',
  `type` tinyint(2) DEFAULT NULL COMMENT '类型',
  `remark` varchar(255) DEFAULT NULL COMMENT '备注',
  `create_time` int(11) DEFAULT NULL COMMENT '创建时间',
  `mark` varchar(50) DEFAULT '0' COMMENT '0媒体 1渠道',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


-- -----------------------------
-- Table structure for `tab_mend`
-- -----------------------------
DROP TABLE IF EXISTS `tab_mend`;
CREATE TABLE `tab_mend` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '自增主键',
  `user_id` int(11) NOT NULL COMMENT '用户id',
  `user_account` varchar(30) DEFAULT NULL COMMENT '用户账号',
  `user_nickname` varchar(30) DEFAULT NULL COMMENT '用户昵称',
  `promote_id` int(11) DEFAULT NULL COMMENT '推广员id',
  `promote_account` varchar(30) DEFAULT NULL COMMENT '推广员账号',
  `promote_id_to` int(11) DEFAULT NULL COMMENT '修改后推广员id',
  `promote_account_to` varchar(30) DEFAULT NULL COMMENT '修改后推广员账号',
  `remark` varchar(100) DEFAULT NULL COMMENT '备注',
  `create_time` int(11) DEFAULT NULL COMMENT '创建时间',
  `op_id` int(11) DEFAULT NULL COMMENT '操作人id',
  `op_account` varchar(30) DEFAULT NULL COMMENT '操作人账号',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


-- -----------------------------
-- Table structure for `tab_message`
-- -----------------------------
DROP TABLE IF EXISTS `tab_message`;
CREATE TABLE `tab_message` (
  `qq` varchar(20) DEFAULT NULL COMMENT 'QQ号',
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键自增',
  `game_id` int(11) DEFAULT NULL COMMENT '游戏id',
  `user_id` int(11) DEFAULT NULL COMMENT '用户id',
  `title` varchar(50) DEFAULT NULL COMMENT '标题',
  `content` varchar(300) DEFAULT NULL COMMENT '内容',
  `status` tinyint(2) DEFAULT '0' COMMENT '修复状态(0:未,1:已)',
  `type` tinyint(2) DEFAULT '0' COMMENT '类型(0:纠错,1:留言)',
  `op_id` int(11) DEFAULT NULL COMMENT '操作人id',
  `op_account` varchar(20) DEFAULT NULL COMMENT '操作人账号',
  `create_time` int(11) DEFAULT NULL COMMENT '修改时间',
  `123` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='留言';


-- -----------------------------
-- Table structure for `tab_opentype`
-- -----------------------------
DROP TABLE IF EXISTS `tab_opentype`;
CREATE TABLE `tab_opentype` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `create_time` int(11) NOT NULL COMMENT '添加时间',
  `status` int(11) NOT NULL COMMENT '状态',
  `open_name` varchar(30) NOT NULL COMMENT '开放类型名称',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;


-- -----------------------------
-- Table structure for `tab_promote`
-- -----------------------------
DROP TABLE IF EXISTS `tab_promote`;
CREATE TABLE `tab_promote` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '自增主键',
  `account` varchar(30) DEFAULT NULL COMMENT '账号',
  `password` varchar(32) DEFAULT NULL COMMENT '密码',
  `second_pwd` varchar(32) DEFAULT NULL COMMENT '二级密码',
  `nickname` varchar(30) DEFAULT NULL COMMENT '昵称',
  `mobile_phone` varchar(11) DEFAULT NULL COMMENT '手机号',
  `email` varchar(50) DEFAULT NULL COMMENT '邮箱',
  `real_name` varchar(10) DEFAULT NULL COMMENT '真实姓名',
  `bank_name` varchar(50) DEFAULT NULL COMMENT '银行',
  `bank_card` varchar(20) DEFAULT NULL COMMENT '银行卡',
  `money` double(10,2) DEFAULT '0.00' COMMENT '金额',
  `total_money` double(10,2) DEFAULT '0.00' COMMENT '总金额',
  `balance_coin` double(10,2) DEFAULT '0.00' COMMENT '平台币',
  `promote_type` int(2) DEFAULT '1' COMMENT '推广员类型',
  `status` int(11) DEFAULT '1' COMMENT '状态',
  `parent_id` int(11) DEFAULT '0' COMMENT '父类ID',
  `pay_limit` int(11) DEFAULT '0' COMMENT '代充额度',
  `referee_id` int(11) DEFAULT '0' COMMENT '推荐人ID',
  `set_pay_time` int(11) DEFAULT NULL COMMENT '代充额度设置时间',
  `last_login_time` int(11) DEFAULT NULL COMMENT '最后登陆时间',
  `create_time` int(11) DEFAULT NULL COMMENT '添加时间',
  `admin_id` int(11) NOT NULL COMMENT '管理员id',
  `mark1` varchar(255) DEFAULT NULL COMMENT '基本信息备注',
  `bank_area` varchar(255) DEFAULT NULL COMMENT '开户地点',
  `account_openin` varchar(255) DEFAULT NULL COMMENT '开户网点',
  `bank_account` varchar(255) DEFAULT NULL COMMENT '银行户名',
  `mark2` varchar(255) DEFAULT NULL COMMENT '结算信息备注',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=utf8 COMMENT='推广员';

-- -----------------------------
-- Records of `tab_promote`
-- -----------------------------
INSERT INTO `tab_promote` VALUES ('1', '111111', 'f714e22d958eb5fe42829a9c737ca0af', '', '111111', '18361353866', '', '111', '', '', '0.00', '0.00', '0.00', '1', '2', '0', '0', '0', '', '1470917854', '1470650742', '1', '', '', '', '', '');
INSERT INTO `tab_promote` VALUES ('2', 'asd123', '43b54e1bfa09eb9819eb58fdeb34af69', '', 'asd123', '15864895462', '', 'dasdas', '', '', '0.00', '0.00', '0.00', '1', '2', '0', '0', '0', '', '', '1470651991', '0', '', '', '', '', '');
INSERT INTO `tab_promote` VALUES ('3', 'test1234', 'cd703417df82ae9561d1ef2956dd8752', '', 'test1234', '15505437878', '', '测试渠道', '', '', '0.00', '0.00', '0.00', '1', '1', '0', '0', '0', '', '1470719193', '1470659378', '1', '', '', '', '', '');
INSERT INTO `tab_promote` VALUES ('4', 'daniel0857', 'cd703417df82ae9561d1ef2956dd8752', 'f714e22d958eb5fe42829a9c737ca0af', 'daniel0857', '', '', '', '', '', '0.00', '0.00', '0.00', '1', '1', '0', '1000', '0', '1470946225', '1470995091', '1470855854', '1', '', '', '', '', '');
INSERT INTO `tab_promote` VALUES ('5', 'b0936155', '43f676afcd4372070f35dd67d5b5d822', '', 'b0936155', '', '', 'KEVIN', '', '', '0.00', '0.00', '0.00', '1', '1', '0', '0', '0', '', '1470987800', '1470855906', '1', '', '', '', '', '');
INSERT INTO `tab_promote` VALUES ('6', 'asdasd', 'a57f0e607a25375869fd68467399f2c7', '', 'asdasd', '15052505896', '', '232sad', '', '', '0.00', '0.00', '0.00', '1', '2', '0', '0', '0', '', '1470921572', '1470921528', '0', '', '', '', '', '');
INSERT INTO `tab_promote` VALUES ('7', 'zlt12345', '629e931e4576845269d15e9214c6c0c4', '', 'zlt12345', '15184382373', '', 'Tian', '', '', '0.00', '0.00', '0.00', '1', '1', '0', '0', '0', '', '1470997079', '1470933493', '1', '601589801', '', '', '', '');

-- -----------------------------
-- Table structure for `tab_provide`
-- -----------------------------
DROP TABLE IF EXISTS `tab_provide`;
CREATE TABLE `tab_provide` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '自增主键',
  `order_number` varchar(30) DEFAULT NULL COMMENT '订单号',
  `pay_order_number` varchar(30) DEFAULT NULL COMMENT '商户订单号',
  `cost` int(11) DEFAULT '0' COMMENT '是否计算成本',
  `user_id` int(11) DEFAULT NULL COMMENT '用户ID',
  `user_account` varchar(30) DEFAULT NULL COMMENT '用户账号',
  `user_nickname` varchar(30) DEFAULT NULL COMMENT '用户昵称',
  `game_id` int(11) DEFAULT NULL COMMENT '游戏id',
  `game_name` varchar(30) DEFAULT NULL COMMENT '游戏名称',
  `promote_id` int(11) DEFAULT '0' COMMENT '推广id',
  `promote_account` varchar(30) DEFAULT NULL COMMENT '推广员姓名',
  `server_id` int(11) DEFAULT NULL COMMENT '区服id',
  `server_name` varchar(30) DEFAULT NULL COMMENT '区服名称',
  `amount` double(10,2) DEFAULT NULL COMMENT '充值金额',
  `remark` varchar(100) DEFAULT NULL COMMENT '备注',
  `status` tinyint(2) DEFAULT '0' COMMENT '状态',
  `op_id` int(11) DEFAULT NULL COMMENT '操作人id',
  `op_account` varchar(30) DEFAULT NULL COMMENT '操作人账号',
  `create_time` int(11) DEFAULT NULL COMMENT '时间',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COMMENT='平台币发发放记录';

-- -----------------------------
-- Records of `tab_provide`
-- -----------------------------
INSERT INTO `tab_provide` VALUES ('1', 'ZF_2016081254535110', '2016081254535110', '0', '38', '183383', '316046', '1', '神武2', '0', '', '', '', '100.00', '', '1', '1', 'admin', '1470945878');
INSERT INTO `tab_provide` VALUES ('2', 'ZF_2016081253501015', '2016081253501015', '0', '38', '183383', '316046', '1', '神武2', '0', '', '', '', '100.00', '', '1', '1', 'admin', '1470946420');

-- -----------------------------
-- Table structure for `tab_push`
-- -----------------------------
DROP TABLE IF EXISTS `tab_push`;
CREATE TABLE `tab_push` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `push_name` varchar(30) DEFAULT NULL COMMENT '应用名',
  `app_key` varchar(30) DEFAULT NULL,
  `master_secret` varchar(30) DEFAULT NULL,
  `status` tinyint(2) DEFAULT NULL COMMENT '状态(0关闭 1开启)',
  `create_time` int(11) DEFAULT NULL COMMENT '创建时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


-- -----------------------------
-- Table structure for `tab_push_notice`
-- -----------------------------
DROP TABLE IF EXISTS `tab_push_notice`;
CREATE TABLE `tab_push_notice` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `push_id` int(11) DEFAULT NULL,
  `push_name` varchar(32) DEFAULT NULL,
  `content` text COMMENT '推送内容',
  `push_object` int(11) DEFAULT NULL COMMENT '推送类型(0 不限 1 ios 2 安卓 3 winphone)',
  `push_time_type` tinyint(2) DEFAULT NULL COMMENT '推送时间(0 立即  1定时)',
  `push_time` int(11) DEFAULT NULL COMMENT '推送时间',
  `create_time` int(11) DEFAULT NULL COMMENT '创建时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


-- -----------------------------
-- Table structure for `tab_rebate`
-- -----------------------------
DROP TABLE IF EXISTS `tab_rebate`;
CREATE TABLE `tab_rebate` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `game_id` int(11) DEFAULT NULL COMMENT '游戏id',
  `game_name` varchar(50) DEFAULT NULL COMMENT '游戏名称',
  `money` int(11) DEFAULT '0' COMMENT '金额',
  `ratio` double(5,2) DEFAULT '0.00' COMMENT '返利比例',
  `status` int(11) DEFAULT NULL COMMENT '状态(0关闭金额限制 1 开启金额限制)',
  `create_time` int(11) DEFAULT NULL COMMENT '更新时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


-- -----------------------------
-- Table structure for `tab_rebate_list`
-- -----------------------------
DROP TABLE IF EXISTS `tab_rebate_list`;
CREATE TABLE `tab_rebate_list` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `pay_order_number` varchar(30) DEFAULT NULL COMMENT '订单号',
  `game_id` int(11) DEFAULT NULL COMMENT '游戏id',
  `game_name` varchar(30) DEFAULT NULL COMMENT '游戏名称',
  `user_id` int(11) DEFAULT NULL COMMENT '用户id',
  `user_name` varchar(30) DEFAULT NULL COMMENT '用户名',
  `pay_amount` double(10,2) DEFAULT '0.00' COMMENT '充值金额',
  `ratio` double(5,2) DEFAULT '0.00' COMMENT '返利比例',
  `ratio_amount` double(10,2) DEFAULT NULL COMMENT '返利平台币',
  `promote_id` int(11) DEFAULT '0' COMMENT '推广id',
  `promote_name` varchar(30) DEFAULT NULL COMMENT '推广员姓名',
  `create_time` int(11) DEFAULT NULL COMMENT '创建时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


-- -----------------------------
-- Table structure for `tab_seo`
-- -----------------------------
DROP TABLE IF EXISTS `tab_seo`;
CREATE TABLE `tab_seo` (
  `id` int(10) unsigned NOT NULL COMMENT '主键',
  `name` varchar(35) NOT NULL COMMENT '标识',
  `title` varchar(25) NOT NULL COMMENT '标题',
  `seo_title` varchar(65) NOT NULL COMMENT '搜索优化标题',
  `seo_keyword` varchar(165) NOT NULL COMMENT '搜索优化关键字',
  `seo_description` varchar(255) NOT NULL COMMENT '搜索优化描述'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

-- -----------------------------
-- Records of `tab_seo`
-- -----------------------------
INSERT INTO `tab_seo` VALUES ('1', 'media_index', '首页', ' ', ' ', ' ');
INSERT INTO `tab_seo` VALUES ('2', 'media_game_list', '游戏列表页', ' ', ' ', ' ');
INSERT INTO `tab_seo` VALUES ('3', 'media_game_detail', '游戏详情页', ' ', ' ', ' ');
INSERT INTO `tab_seo` VALUES ('4', 'media_gift_index', '礼包首页', ' ', ' ', ' ');
INSERT INTO `tab_seo` VALUES ('5', 'media_gift_list', '礼包列表页', ' ', ' ', ' ');
INSERT INTO `tab_seo` VALUES ('6', 'media_gift_detail', '礼包详情页', ' ', ' ', ' ');
INSERT INTO `tab_seo` VALUES ('7', 'media_news_list', '资讯列表页', ' ', ' ', ' ');
INSERT INTO `tab_seo` VALUES ('8', 'media_news_detail', '资讯详情页', ' ', ' ', ' ');
INSERT INTO `tab_seo` VALUES ('9', 'media_recharge', '充值页', ' ', ' ', ' ');
INSERT INTO `tab_seo` VALUES ('10', 'media_service', '客服页', ' ', ' ', ' ');
INSERT INTO `tab_seo` VALUES ('11', 'channel_index', '首页', ' ', ' ', ' ');
INSERT INTO `tab_seo` VALUES ('12', 'channel_game_list', '全部应用页', ' ', ' ', ' ');
INSERT INTO `tab_seo` VALUES ('13', 'channel_news_list', '资讯列表页', ' ', ' ', ' ');
INSERT INTO `tab_seo` VALUES ('14', 'channel_news_detail', '资讯详情页', ' ', ' ', ' ');

-- -----------------------------
-- Table structure for `tab_server`
-- -----------------------------
DROP TABLE IF EXISTS `tab_server`;
CREATE TABLE `tab_server` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键自增',
  `game_id` int(11) NOT NULL COMMENT '游戏id',
  `game_name` varchar(30) DEFAULT NULL COMMENT '游戏名称',
  `server_name` varchar(30) DEFAULT NULL COMMENT '区服名称',
  `server_num` int(11) DEFAULT NULL COMMENT '对接区服id',
  `recommend_status` tinyint(2) DEFAULT '1' COMMENT '推荐状态(0:否,1:是)',
  `show_status` tinyint(2) DEFAULT '1' COMMENT '显示状态(0:否,1:是)',
  `stop_status` tinyint(2) DEFAULT '0' COMMENT '是否停服(0:否,1:是)',
  `server_status` tinyint(2) DEFAULT '0' COMMENT '区服状态(0:正常,1拥挤,2爆满)',
  `icon` int(11) DEFAULT NULL COMMENT '区服图标',
  `start_time` int(11) DEFAULT NULL COMMENT '开始时间',
  `desride` varchar(300) DEFAULT NULL COMMENT '描述',
  `prompt` varchar(300) DEFAULT NULL COMMENT '停服提示',
  `parent_id` int(11) DEFAULT NULL COMMENT '父类id',
  `create_time` int(11) DEFAULT NULL COMMENT '创建时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='游戏区服表';


-- -----------------------------
-- Table structure for `tab_settlement`
-- -----------------------------
DROP TABLE IF EXISTS `tab_settlement`;
CREATE TABLE `tab_settlement` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '自增主键',
  `promote_id` int(11) DEFAULT NULL COMMENT '推广员ID',
  `game_id` varchar(32) DEFAULT NULL COMMENT '游戏ID',
  `status` tinyint(2) DEFAULT '1' COMMENT '结算状态',
  `ti_status` int(11) DEFAULT '-1' COMMENT '提现状态(-1未申请 0 申请中 1 已通过 2 已驳回)',
  `game_name` varchar(40) NOT NULL COMMENT '游戏名称',
  `promote_account` varchar(55) NOT NULL COMMENT '推广员账号',
  `total_money` double(10,2) DEFAULT NULL COMMENT '充值总额',
  `total_number` int(19) unsigned NOT NULL DEFAULT '0' COMMENT '注册人数',
  `settlement_number` varchar(60) NOT NULL COMMENT '结算单号',
  `pattern` int(11) NOT NULL DEFAULT '0' COMMENT '合作模式',
  `ratio` double(5,2) unsigned DEFAULT '0.00' COMMENT 'CPS分成比例(%)',
  `money` double(10,2) unsigned DEFAULT '0.00' COMMENT 'CPA注册单价(元)',
  `sum_money` double(10,2) DEFAULT '0.00' COMMENT '结算金额',
  `create_time` int(11) DEFAULT NULL COMMENT '结算时间',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


-- -----------------------------
-- Table structure for `tab_son_settlement`
-- -----------------------------
DROP TABLE IF EXISTS `tab_son_settlement`;
CREATE TABLE `tab_son_settlement` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `settlement_number` varchar(30) DEFAULT NULL,
  `settlement_start_time` int(11) DEFAULT NULL COMMENT '结算开始时间',
  `settlement_end_time` int(11) DEFAULT NULL COMMENT '结算结束时间',
  `game_id` int(11) DEFAULT NULL COMMENT '游戏id',
  `game_name` varchar(30) DEFAULT NULL COMMENT '游戏名称',
  `promote_id` int(11) DEFAULT NULL COMMENT '推广id(子账号id)',
  `promote_account` varchar(30) DEFAULT NULL COMMENT '子账号',
  `pattern` int(11) DEFAULT NULL COMMENT '合作模式',
  `sum_money` double DEFAULT NULL COMMENT '充值总额',
  `reg_number` int(11) DEFAULT NULL COMMENT '注册人数',
  `ratio` double(11,0) DEFAULT NULL COMMENT '分成比例',
  `money` double(11,0) DEFAULT NULL COMMENT '注册单价',
  `jie_money` double DEFAULT NULL COMMENT '结算金额',
  `create_time` int(11) DEFAULT NULL COMMENT '添加时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


-- -----------------------------
-- Table structure for `tab_spend`
-- -----------------------------
DROP TABLE IF EXISTS `tab_spend`;
CREATE TABLE `tab_spend` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '自增主键',
  `user_id` int(11) NOT NULL COMMENT ' 用户ID',
  `user_account` varchar(30) DEFAULT NULL COMMENT '用户账号',
  `user_nickname` varchar(30) DEFAULT NULL COMMENT '用户昵称',
  `game_id` int(11) DEFAULT NULL COMMENT '游戏id',
  `game_appid` varchar(32) DEFAULT NULL COMMENT '游戏appid',
  `game_name` varchar(30) DEFAULT NULL COMMENT '游戏名称',
  `server_id` int(11) DEFAULT NULL COMMENT '区服id',
  `server_name` varchar(30) DEFAULT NULL COMMENT '区服名称',
  `promote_id` int(11) DEFAULT NULL COMMENT '推广员id',
  `promote_account` varchar(30) DEFAULT NULL COMMENT '推广员账号',
  `order_number` varchar(30) DEFAULT NULL COMMENT '订单号',
  `pay_order_number` varchar(30) DEFAULT NULL COMMENT '支付订单号',
  `props_name` varchar(30) DEFAULT NULL COMMENT '道具名称',
  `pay_amount` double(10,2) DEFAULT NULL COMMENT '支付金额',
  `pay_time` int(11) DEFAULT NULL COMMENT '支付时间',
  `pay_status` tinyint(2) DEFAULT NULL COMMENT '支付状态',
  `pay_game_status` tinyint(2) DEFAULT NULL COMMENT '游戏支付状态',
  `extend` varchar(32) DEFAULT NULL COMMENT '通知游戏方扩展(一般是游戏方透传)',
  `pay_way` tinyint(2) DEFAULT NULL COMMENT '支付方式',
  `spend_ip` varchar(20) DEFAULT NULL COMMENT '支付IP',
  `is_check` int(11) DEFAULT '1' COMMENT '是否对账  1参与 2不参与 3参与(已对账) 4不参与(已对账)',
  `selle_status` int(11) NOT NULL DEFAULT '0' COMMENT 'CP结算 0未结算1 结算',
  `selle_ratio` double(5,2) DEFAULT '0.00' COMMENT 'cp分成比例',
  `sub_status` int(11) NOT NULL DEFAULT '0' COMMENT '子渠道结算状态',
  `selle_time` varchar(30) DEFAULT NULL COMMENT 'cp结算时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=189 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `tab_spend`
-- -----------------------------
INSERT INTO `tab_spend` VALUES ('1', '38', '183383', '183383', '1', 'CC44E9A9FDC231C00', '神武2', '0', '', '4', 'daniel0857', '', 'SP_20160811230957RSn1', '1200元宝首充礼包', '6.00', '1470928197', '0', '0', '', '3', '60.248.238.175', '1', '0', '0.00', '0', '');
INSERT INTO `tab_spend` VALUES ('2', '48', '182073a', '182073a', '1', 'CC44E9A9FDC231C00', '神武2', '0', '', '4', 'daniel0857', '', 'SP_20160811234731SVMd', '3000元宝月卡礼包', '80.00', '1470930451', '0', '0', '', '3', '123.139.44.221', '1', '0', '0.00', '0', '');
INSERT INTO `tab_spend` VALUES ('3', '64', 'zyxztt', 'zyxztt', '1', 'CC44E9A9FDC231C00', '神武2', '0', '', '4', 'daniel0857', '', 'SP_20160812004353Ofod', '1000000元宝首充礼包', '5000.00', '1470933833', '0', '0', '', '3', '113.128.74.59', '1', '0', '0.00', '0', '');
INSERT INTO `tab_spend` VALUES ('4', '69', 'abc123', 'abc123', '1', 'CC44E9A9FDC231C00', '神武2', '0', '', '7', 'zlt12345', '', 'SP_20160812021126Jhmo', '1200元宝首充礼包', '6.00', '1470939085', '1', '0', '', '3', '125.71.115.129', '1', '0', '0.00', '0', '');
INSERT INTO `tab_spend` VALUES ('5', '69', 'abc123', 'abc123', '1', 'CC44E9A9FDC231C00', '神武2', '0', '', '7', 'zlt12345', '', 'SP_20160812021429c7gw', '1200元宝首充礼包', '6.00', '1470939269', '0', '0', '', '3', '125.71.115.129', '1', '0', '0.00', '0', '');
INSERT INTO `tab_spend` VALUES ('6', '69', 'abc123', 'abc123', '1', 'CC44E9A9FDC231C00', '神武2', '0', '', '7', 'zlt12345', '', 'SP_20160812021520eMRt', '1200元宝首充礼包', '6.00', '1470939320', '0', '0', '', '3', '125.71.115.129', '1', '0', '0.00', '0', '');
INSERT INTO `tab_spend` VALUES ('7', '69', 'abc123', 'abc123', '1', 'CC44E9A9FDC231C00', '神武2', '0', '', '7', 'zlt12345', '', 'SP_20160812021823bj9c', '1200元宝首充礼包', '6.00', '1470939503', '0', '0', '', '3', '125.71.115.129', '1', '0', '0.00', '0', '');
INSERT INTO `tab_spend` VALUES ('8', '69', 'abc123', 'abc123', '1', 'CC44E9A9FDC231C00', '神武2', '0', '', '7', 'zlt12345', '', 'SP_20160812021835UFvx', '1200元宝首充礼包', '6.00', '1470939515', '0', '0', '', '3', '125.71.115.129', '1', '0', '0.00', '0', '');
INSERT INTO `tab_spend` VALUES ('9', '69', 'abc123', 'abc123', '1', 'CC44E9A9FDC231C00', '神武2', '0', '', '7', 'zlt12345', '', 'SP_20160812021850ITs4', '6000元宝首充礼包', '30.00', '1470939530', '0', '0', '', '3', '125.71.115.129', '1', '0', '0.00', '0', '');
INSERT INTO `tab_spend` VALUES ('10', '38', '183383', '183383', '1', 'CC44E9A9FDC231C00', '神武2', '0', '', '4', 'daniel0857', '', 'SP_20160812022109fyuC', '1200元宝首充礼包', '6.00', '1470939669', '0', '0', '', '3', '60.248.238.175', '1', '0', '0.00', '0', '');
INSERT INTO `tab_spend` VALUES ('11', '69', 'abc123', 'abc123', '1', 'CC44E9A9FDC231C00', '神武2', '0', '', '7', 'zlt12345', '', 'SP_20160812022301Kch3', '6000元宝首充礼包', '30.00', '1470939781', '0', '0', '', '3', '125.71.115.129', '1', '0', '0.00', '0', '');
INSERT INTO `tab_spend` VALUES ('12', '38', '183383', '183383', '1', 'CC44E9A9FDC231C00', '神武2BT', '0', '', '4', 'daniel0857', '', 'SP_20160812022419Fc6b', '1200元宝首充礼包', '6.00', '1470939859', '0', '0', '', '3', '60.248.238.175', '1', '0', '0.00', '0', '');
INSERT INTO `tab_spend` VALUES ('13', '69', 'abc123', 'abc123', '1', 'CC44E9A9FDC231C00', '神武2', '0', '', '7', 'zlt12345', '', 'SP_20160812022640NjZ6', '6000元宝首充礼包', '30.00', '1470940000', '0', '0', '', '3', '125.71.115.129', '1', '0', '0.00', '0', '');
INSERT INTO `tab_spend` VALUES ('14', '69', 'abc123', 'abc123', '1', 'CC44E9A9FDC231C00', '神武2', '0', '', '7', 'zlt12345', '', 'SP_20160812022821v1lK', '1200元宝首充礼包', '6.00', '1470940101', '0', '0', '', '3', '125.71.115.129', '1', '0', '0.00', '0', '');
INSERT INTO `tab_spend` VALUES ('15', '69', 'abc123', 'abc123', '1', 'CC44E9A9FDC231C00', '神武2', '0', '', '7', 'zlt12345', '', 'SP_20160812023058Q0q0', '1200元宝首充礼包', '6.00', '1470940258', '0', '0', '', '3', '125.71.115.129', '1', '0', '0.00', '0', '');
INSERT INTO `tab_spend` VALUES ('16', '69', 'abc123', 'abc123', '1', 'CC44E9A9FDC231C00', '神武2', '0', '', '7', 'zlt12345', '', 'SP_201608120243114bRW', '1200元宝首充礼包', '6.00', '1470940991', '0', '0', '', '3', '125.71.115.129', '1', '0', '0.00', '0', '');
INSERT INTO `tab_spend` VALUES ('17', '69', 'abc123', 'abc123', '1', 'CC44E9A9FDC231C00', '神武2', '0', '', '7', 'zlt12345', '', 'SP_20160812024642QE0b', '1200元宝首充礼包', '6.00', '1470941202', '0', '0', '', '3', '125.71.115.129', '1', '0', '0.00', '0', '');
INSERT INTO `tab_spend` VALUES ('18', '69', 'abc123', 'abc123', '1', 'CC44E9A9FDC231C00', '神武2', '0', '', '7', 'zlt12345', '', 'SP_20160812024739YDO2', '1200元宝首充礼包', '6.00', '1470941259', '0', '0', '', '3', '125.71.115.129', '1', '0', '0.00', '0', '');
INSERT INTO `tab_spend` VALUES ('19', '69', 'abc123', 'abc123', '1', 'CC44E9A9FDC231C00', '神武2', '0', '', '7', 'zlt12345', '', 'SP_201608120249003q5H', '1200元宝首充礼包', '6.00', '1470941340', '0', '0', '', '3', '125.71.115.129', '1', '0', '0.00', '0', '');
INSERT INTO `tab_spend` VALUES ('20', '69', 'abc123', 'abc123', '1', 'CC44E9A9FDC231C00', '神武2', '0', '', '7', 'zlt12345', '', 'SP_20160812024918NT3o', '1200元宝首充礼包', '6.00', '1470941358', '0', '0', '', '3', '125.71.115.129', '1', '0', '0.00', '0', '');
INSERT INTO `tab_spend` VALUES ('21', '69', 'abc123', 'abc123', '1', 'CC44E9A9FDC231C00', '神武2', '0', '', '7', 'zlt12345', '', 'SP_20160812024940b3Yi', '1200元宝首充礼包', '6.00', '1470941380', '0', '0', '', '3', '125.71.115.129', '1', '0', '0.00', '0', '');
INSERT INTO `tab_spend` VALUES ('22', '69', 'abc123', 'abc123', '1', 'CC44E9A9FDC231C00', '神武2', '0', '', '7', 'zlt12345', '', 'SP_20160812024951dqIE', '1200元宝首充礼包', '6.00', '1470941391', '0', '0', '', '3', '125.71.115.129', '1', '0', '0.00', '0', '');
INSERT INTO `tab_spend` VALUES ('23', '69', 'abc123', 'abc123', '1', 'CC44E9A9FDC231C00', '神武2', '0', '', '7', 'zlt12345', '', 'SP_20160812025125Owcs', '1200元宝首充礼包', '6.00', '1470941485', '0', '0', '', '3', '125.71.115.129', '1', '0', '0.00', '0', '');
INSERT INTO `tab_spend` VALUES ('24', '38', '183383', '183383', '1', 'CC44E9A9FDC231C00', '神武2BT', '0', '', '4', 'daniel0857', '', 'SP_20160812025248grci', '1200元宝首充礼包', '6.00', '1470941568', '0', '0', '', '3', '60.248.238.175', '1', '0', '0.00', '0', '');
INSERT INTO `tab_spend` VALUES ('25', '69', 'abc123', 'abc123', '1', 'CC44E9A9FDC231C00', '神武2', '0', '', '7', 'zlt12345', '', 'SP_20160812025343DG5r', '1200元宝首充礼包', '6.00', '1470941623', '0', '0', '', '3', '125.71.115.129', '1', '0', '0.00', '0', '');
INSERT INTO `tab_spend` VALUES ('26', '69', 'abc123', 'abc123', '1', 'CC44E9A9FDC231C00', '神武2', '0', '', '7', 'zlt12345', '', 'SP_20160812025427aPMe', '1200元宝首充礼包', '6.00', '1470941667', '0', '0', '', '3', '125.71.115.129', '1', '0', '0.00', '0', '');
INSERT INTO `tab_spend` VALUES ('27', '69', 'abc123', 'abc123', '1', 'CC44E9A9FDC231C00', '神武2', '0', '', '7', 'zlt12345', '', 'SP_20160812025529qxSI', '1200元宝首充礼包', '6.00', '1470941729', '0', '0', '', '3', '125.71.115.129', '1', '0', '0.00', '0', '');
INSERT INTO `tab_spend` VALUES ('28', '38', '183383', '183383', '1', 'CC44E9A9FDC231C00', '神武2BT', '0', '', '4', 'daniel0857', '', 'SP_20160812025705LO52', '19600元宝首充礼包', '98.00', '1470941825', '0', '0', '', '3', '60.248.238.175', '1', '0', '0.00', '0', '');
INSERT INTO `tab_spend` VALUES ('29', '69', 'abc123', 'abc123', '1', 'CC44E9A9FDC231C00', '神武2', '0', '', '7', 'zlt12345', '', 'SP_201608120257301wrK', '1200元宝首充礼包', '6.00', '1470941850', '0', '0', '', '3', '125.71.115.129', '1', '0', '0.00', '0', '');
INSERT INTO `tab_spend` VALUES ('30', '38', '183383', '183383', '1', 'CC44E9A9FDC231C00', '神武2BT', '0', '', '4', 'daniel0857', '', 'SP_20160812025749leW9', '19600元宝首充礼包', '98.00', '1470941869', '0', '0', '', '3', '60.248.238.175', '1', '0', '0.00', '0', '');
INSERT INTO `tab_spend` VALUES ('31', '69', 'abc123', 'abc123', '1', 'CC44E9A9FDC231C00', '神武2', '0', '', '7', 'zlt12345', '', 'SP_20160812025820qOfH', '1200元宝首充礼包', '6.00', '1470941900', '0', '0', '', '3', '125.71.115.129', '1', '0', '0.00', '0', '');
INSERT INTO `tab_spend` VALUES ('32', '69', 'abc123', 'abc123', '1', 'CC44E9A9FDC231C00', '神武2', '0', '', '7', 'zlt12345', '', 'SP_201608120258346UaQ', '6000元宝首充礼包', '30.00', '1470941914', '0', '0', '', '3', '125.71.115.129', '1', '0', '0.00', '0', '');
INSERT INTO `tab_spend` VALUES ('33', '38', '183383', '183383', '1', 'CC44E9A9FDC231C00', '神武2BT', '0', '', '4', 'daniel0857', '', 'SP_20160812025935cQMz', '1200元宝首充礼包', '6.00', '1470941975', '0', '0', '', '3', '60.248.238.175', '1', '0', '0.00', '0', '');
INSERT INTO `tab_spend` VALUES ('34', '69', 'abc123', 'abc123', '1', 'CC44E9A9FDC231C00', '神武2', '0', '', '7', 'zlt12345', '', 'SP_20160812030711rePu', '1200元宝首充礼包', '6.00', '1470942431', '1', '1', 'gf=xiyou#kid=md_s_1#rid=10058#gi', '3', '125.71.115.129', '1', '0', '0.00', '0', '');
INSERT INTO `tab_spend` VALUES ('35', '69', 'abc123', 'abc123', '1', 'CC44E9A9FDC231C00', '神武2', '0', '', '7', 'zlt12345', '', 'SP_20160812030857cMhx', '1200元宝', '6.00', '1470942537', '0', '0', '', '3', '125.71.115.129', '1', '0', '0.00', '0', '');
INSERT INTO `tab_spend` VALUES ('36', '69', 'abc123', 'abc123', '1', 'CC44E9A9FDC231C00', '神武2', '0', '', '7', 'zlt12345', '', 'SP_20160812031106fuyE', '1200元宝', '6.00', '1470942666', '1', '1', 'gf=xiyou#kid=md_s_1#rid=10058#gi', '3', '125.71.115.129', '1', '0', '0.00', '0', '');
INSERT INTO `tab_spend` VALUES ('37', '38', '183383', '183383', '1', 'CC44E9A9FDC231C00', '神武2', '0', '', '4', 'daniel0857', '', 'SP_20160812031153y4Kb', '1200元宝首充礼包', '6.00', '1470942713', '0', '0', '', '3', '60.248.238.175', '1', '0', '0.00', '0', '');
INSERT INTO `tab_spend` VALUES ('38', '69', 'abc123', 'abc123', '1', 'CC44E9A9FDC231C00', '神武2', '0', '', '7', 'zlt12345', '', 'SP_20160812031323S2Sb', '1200元宝', '6.00', '1470942802', '0', '0', '', '3', '125.71.115.129', '1', '0', '0.00', '0', '');
INSERT INTO `tab_spend` VALUES ('39', '38', '183383', '183383', '1', 'CC44E9A9FDC231C00', '神武2', '0', '', '4', 'daniel0857', '', 'SP_20160812031325auce', '1200元宝首充礼包', '6.00', '1470942805', '0', '0', '', '3', '60.248.238.175', '1', '0', '0.00', '0', '');
INSERT INTO `tab_spend` VALUES ('40', '38', '183383', '183383', '1', 'CC44E9A9FDC231C00', '神武2', '0', '', '4', 'daniel0857', '', 'SP_20160812031423KQXU', '1200元宝首充礼包', '6.00', '1470942863', '1', '0', '', '3', '60.248.238.175', '1', '0', '0.00', '0', '');
INSERT INTO `tab_spend` VALUES ('41', '38', '183383', '183383', '1', 'CC44E9A9FDC231C00', '神武2', '0', '', '4', 'daniel0857', '', 'SP_2016081203154967FR', '1200元宝首充礼包', '6.00', '1470942949', '1', '1', 'gf=xiyou#kid=md_s_1#rid=10026#gi', '3', '60.248.238.175', '1', '0', '0.00', '0', '');
INSERT INTO `tab_spend` VALUES ('42', '70', '608493', '608493', '1', 'CC44E9A9FDC231C00', '神武2', '0', '', '7', 'zlt12345', '', 'SP_20160812031636qvkU', '1200元宝首充礼包', '6.00', '1470942996', '1', '0', '', '3', '125.71.115.129', '1', '0', '0.00', '0', '');
INSERT INTO `tab_spend` VALUES ('43', '38', '183383', '183383', '1', 'CC44E9A9FDC231C00', '神武2', '0', '', '4', 'daniel0857', '', 'SP_20160812031930Xn7J', '1200元宝', '6.00', '1470943170', '1', '1', 'gf=xiyou#kid=md_s_1#rid=10026#gi', '3', '60.248.238.175', '1', '0', '0.00', '0', '');
INSERT INTO `tab_spend` VALUES ('44', '71', '332171', '332171', '1', 'CC44E9A9FDC231C00', '神武2', '0', '', '4', 'daniel0857', '', 'SP_20160812032149eNNQ', '1200元宝首充礼包', '6.00', '1470943309', '0', '0', '', '3', '60.248.238.175', '1', '0', '0.00', '0', '');
INSERT INTO `tab_spend` VALUES ('45', '72', '928412', '928412', '1', 'CC44E9A9FDC231C00', '神武2', '0', '', '4', 'daniel0857', '', 'SP_20160812032250tcUe', '1200元宝首充礼包', '6.00', '1470943370', '1', '1', 'gf=xiyou#kid=md_s_1#rid=10061#gi', '3', '60.248.238.175', '1', '0', '0.00', '0', '');
INSERT INTO `tab_spend` VALUES ('46', '73', '650265', '650265', '1', 'CC44E9A9FDC231C00', '神武2', '0', '', '4', 'daniel0857', 'PF_201608120326191Dva', 'PF_201608120326191Dva', '1200元宝首充礼包', '6.00', '1470943578', '1', '1', 'gf=xiyou#kid=md_s_1#rid=10062#gi', '0', '60.248.238.175', '1', '0', '0.00', '0', '');
INSERT INTO `tab_spend` VALUES ('47', '74', '926990', '926990', '1', 'CC44E9A9FDC231C00', '神武2', '0', '', '4', 'daniel0857', '', 'SP_20160812033101OjaJ', '1200元宝首充礼包', '6.00', '1470943861', '1', '1', 'gf=xiyou#kid=md_s_1#rid=10063#gi', '3', '60.248.238.175', '1', '0', '0.00', '0', '');
INSERT INTO `tab_spend` VALUES ('48', '75', '236496', '236496', '1', 'CC44E9A9FDC231C00', '神武2', '0', '', '4', 'daniel0857', '', 'SP_20160812033411WnWJ', '1200元宝首充礼包', '6.00', '1470944051', '1', '1', 'gf=xiyou#kid=md_s_1#rid=10064#gi', '3', '60.248.238.175', '1', '0', '0.00', '0', '');
INSERT INTO `tab_spend` VALUES ('49', '75', '236496', '236496', '1', 'CC44E9A9FDC231C00', '神武2', '0', '', '4', 'daniel0857', '', 'SP_20160812033540pvDp', '1200元宝', '6.00', '1470944140', '0', '0', '', '3', '60.248.238.175', '1', '0', '0.00', '0', '');
INSERT INTO `tab_spend` VALUES ('50', '38', '183383', '183383', '1', 'CC44E9A9FDC231C00', '神武2', '0', '', '4', 'daniel0857', '', 'SP_20160812100736b2eQ', '1200元宝', '6.00', '1470967656', '0', '0', '', '3', '60.248.238.175', '1', '0', '0.00', '0', '');
INSERT INTO `tab_spend` VALUES ('51', '94', '237815', '237815', '12', '520D9380CF1B71E89', '决战中洲', '0', '', '0', '自然注册', '', 'SP_201608121027514XTF', '钻石', '0.01', '1470968870', '0', '0', '', '3', '153.36.68.155', '1', '0', '0.00', '0', '');
INSERT INTO `tab_spend` VALUES ('52', '94', '237815', '237815', '12', '520D9380CF1B71E89', '决战中洲', '0', '', '0', '自然注册', '', 'SP_20160812102948Y4qN', '钻石', '0.01', '1470968988', '0', '0', '', '3', '153.36.68.155', '1', '0', '0.00', '0', '');
INSERT INTO `tab_spend` VALUES ('53', '94', '237815', '237815', '12', '520D9380CF1B71E89', '决战中洲', '0', '', '0', '自然注册', '', 'SP_20160812103157vwoS', '钻石', '0.01', '1470969117', '0', '0', '', '3', '153.36.68.155', '1', '0', '0.00', '0', '');
INSERT INTO `tab_spend` VALUES ('54', '94', '237815', '237815', '12', '520D9380CF1B71E89', '决战中洲', '0', '', '0', '自然注册', '', 'SP_201608121034156tmj', '钻石', '0.01', '1470969255', '0', '0', '', '3', '153.36.68.155', '1', '0', '0.00', '0', '');
INSERT INTO `tab_spend` VALUES ('55', '94', '237815', '237815', '12', '520D9380CF1B71E89', '决战中洲', '0', '', '0', '自然注册', '', 'SP_20160812103519eiOb', '钻石', '0.01', '1470969319', '0', '0', '', '3', '153.36.68.155', '1', '0', '0.00', '0', '');
INSERT INTO `tab_spend` VALUES ('56', '38', '183383', '183383', '1', 'CC44E9A9FDC231C00', '神武2', '0', '', '4', 'daniel0857', '', 'SP_20160812104503duiK', '1200元宝', '6.00', '1470969903', '0', '0', '', '3', '60.248.238.175', '1', '0', '0.00', '0', '');
INSERT INTO `tab_spend` VALUES ('57', '38', '183383', '183383', '1', 'CC44E9A9FDC231C00', '神武2', '0', '', '4', 'daniel0857', '', 'SP_20160812104716VXr8', '1200元宝', '6.00', '1470970036', '0', '0', '', '3', '60.248.238.175', '1', '0', '0.00', '0', '');
INSERT INTO `tab_spend` VALUES ('58', '104', '791455', '791455', '12', '520D9380CF1B71E89', '决战中洲', '0', '', '0', '自然注册', '', 'SP_20160812105211fAfl', '钻石', '0.01', '1470970331', '0', '0', '', '3', '153.36.68.155', '1', '0', '0.00', '0', '');
INSERT INTO `tab_spend` VALUES ('59', '106', '618693', '618693', '12', '520D9380CF1B71E89', '决战中洲', '0', '', '0', '自然注册', '', 'SP_20160812105427lg0a', '钻石', '0.01', '1470970467', '0', '0', '', '3', '153.36.68.155', '1', '0', '0.00', '0', '');
INSERT INTO `tab_spend` VALUES ('60', '106', '618693', '618693', '12', '520D9380CF1B71E89', '决战中洲', '0', '', '0', '自然注册', '', 'SP_20160812105452kSBE', '钻石', '0.01', '1470970492', '0', '0', '', '3', '153.36.68.155', '1', '0', '0.00', '0', '');
INSERT INTO `tab_spend` VALUES ('61', '106', '618693', '618693', '12', '520D9380CF1B71E89', '决战中洲', '0', '', '0', '自然注册', '', 'SP_20160812105559MOVl', '钻石', '0.20', '1470970559', '0', '0', '', '3', '153.36.68.155', '1', '0', '0.00', '0', '');
INSERT INTO `tab_spend` VALUES ('62', '45', '20998526', '20998526', '1', 'CC44E9A9FDC231C00', '神武2', '0', '', '4', 'daniel0857', '', 'SP_20160812105626XcC3', '1200元宝首充礼包', '6.00', '1470970586', '0', '0', '', '3', '117.28.181.145', '1', '0', '0.00', '0', '');
INSERT INTO `tab_spend` VALUES ('63', '106', '618693', '618693', '12', '520D9380CF1B71E89', '决战中洲', '0', '', '0', '自然注册', '', 'SP_20160812105834NFvd', '钻石', '0.20', '1470970713', '0', '0', '', '3', '153.36.68.155', '1', '0', '0.00', '0', '');
INSERT INTO `tab_spend` VALUES ('64', '45', '20998526', '20998526', '1', 'CC44E9A9FDC231C00', '神武2', '0', '', '4', 'daniel0857', '', 'SP_20160812110015OSso', '1200元宝首充礼包', '6.00', '1470970815', '1', '1', 'gf=xiyou#kid=md_s_1#rid=10034#gi', '3', '117.28.181.145', '1', '0', '0.00', '0', '');
INSERT INTO `tab_spend` VALUES ('65', '111', '621943', '621943', '12', '520D9380CF1B71E89', '决战中洲', '0', '', '0', '自然注册', '', 'SP_20160812110022qrKL', '钻石', '1.20', '1470970822', '0', '0', '', '3', '153.36.68.155', '1', '0', '0.00', '0', '');
INSERT INTO `tab_spend` VALUES ('66', '112', '700647', '700647', '12', '520D9380CF1B71E89', '决战中洲', '0', '', '0', '自然注册', '', 'SP_20160812110136Qj8n', '钻石', '11.20', '1470970896', '0', '0', '', '3', '153.36.68.155', '1', '0', '0.00', '0', '');
INSERT INTO `tab_spend` VALUES ('67', '112', '700647', '700647', '12', '520D9380CF1B71E89', '决战中洲', '0', '', '0', '自然注册', '', 'SP_20160812110154WUkW', '钻石', '11.20', '1470970914', '0', '0', '', '3', '153.36.68.155', '1', '0', '0.00', '0', '');
INSERT INTO `tab_spend` VALUES ('68', '112', '700647', '700647', '12', '520D9380CF1B71E89', '决战中洲', '0', '', '0', '自然注册', '', 'SP_20160812110217a9IF', '钻石', '11.20', '1470970937', '0', '0', '', '3', '153.36.68.155', '1', '0', '0.00', '0', '');
INSERT INTO `tab_spend` VALUES ('69', '112', '700647', '700647', '12', '520D9380CF1B71E89', '决战中洲', '0', '', '0', '自然注册', '', 'SP_20160812110242frEJ', '钻石', '11.20', '1470970962', '0', '0', '', '3', '153.36.68.155', '1', '0', '0.00', '0', '');
INSERT INTO `tab_spend` VALUES ('70', '114', '224912', '224912', '12', '520D9380CF1B71E89', '决战中洲', '0', '', '0', '自然注册', '', 'SP_20160812110928E8C0', '钻石', '11.20', '1470971368', '0', '0', '', '3', '153.36.68.155', '1', '0', '0.00', '0', '');
INSERT INTO `tab_spend` VALUES ('71', '114', '224912', '224912', '12', '520D9380CF1B71E89', '决战中洲', '0', '', '0', '自然注册', '', 'SP_201608121110307TmP', '钻石', '11.20', '1470971430', '0', '0', '', '3', '153.36.68.155', '1', '0', '0.00', '0', '');
INSERT INTO `tab_spend` VALUES ('72', '114', '224912', '224912', '12', '520D9380CF1B71E89', '决战中洲', '0', '', '0', '自然注册', '', 'SP_20160812111440CyJX', '钻石', '11.20', '1470971680', '0', '0', '', '3', '153.36.68.155', '1', '0', '0.00', '0', '');
INSERT INTO `tab_spend` VALUES ('73', '114', '224912', '224912', '12', '520D9380CF1B71E89', '决战中洲', '0', '', '0', '自然注册', '', 'SP_20160812112651XLZe', '钻石', '11.20', '1470972411', '0', '0', '', '3', '153.36.68.155', '1', '0', '0.00', '0', '');
INSERT INTO `tab_spend` VALUES ('74', '119', '860830', '860830', '1', 'CC44E9A9FDC231C00', '神武2', '0', '', '7', 'zlt12345', '', 'SP_20160812113058yGsD', '1000000元宝首充礼包', '5000.00', '1470972658', '0', '0', '', '3', '223.146.89.219', '1', '0', '0.00', '0', '');
INSERT INTO `tab_spend` VALUES ('75', '131', '976217', '976217', '12', '520D9380CF1B71E89', '决战中洲', '0', '', '0', '自然注册', '', 'SP_20160812115457K2xT', '钻石', '6.00', '1470974097', '0', '0', '', '3', '153.36.68.155', '1', '0', '0.00', '0', '');
INSERT INTO `tab_spend` VALUES ('76', '131', '976217', '976217', '12', '520D9380CF1B71E89', '决战中洲', '0', '', '0', '自然注册', '', 'SP_201608121156397OtJ', '钻石', '6.00', '1470974199', '0', '0', '', '3', '153.36.68.155', '1', '0', '0.00', '0', '');
INSERT INTO `tab_spend` VALUES ('77', '139', 'wolfkill', 'wolfkill', '1', 'CC44E9A9FDC231C00', '神武2', '0', '', '7', 'zlt12345', '', 'SP_20160812120739EtpM', '1000000元宝首充礼包', '5000.00', '1470974859', '0', '0', '', '3', '113.76.154.148', '1', '0', '0.00', '0', '');
INSERT INTO `tab_spend` VALUES ('78', '150', '847421822', '847421822', '1', 'CC44E9A9FDC231C00', '神武2', '0', '', '7', 'zlt12345', '', 'SP_20160812122838rllr', '人参果王*16(6折)', '98.00', '1470976118', '0', '0', '', '3', '219.137.118.217', '1', '0', '0.00', '0', '');
INSERT INTO `tab_spend` VALUES ('79', '38', '183383', '183383', '1', 'CC44E9A9FDC231C00', '神武2', '0', '', '4', 'daniel0857', '', 'SP_20160812122938wnH1', '1200元宝', '6.00', '1470976178', '0', '0', '', '3', '60.248.238.175', '1', '0', '0.00', '0', '');
INSERT INTO `tab_spend` VALUES ('80', '137', 'a857248868', 'a857248868', '1', 'CC44E9A9FDC231C00', '神武2', '0', '', '7', 'zlt12345', '', 'SP_20160812123328k0f3', '1200元宝首充礼包', '6.00', '1470976408', '1', '1', 'gf=xiyou#kid=md_s_1#rid=10123#gi', '3', '117.136.4.177', '1', '0', '0.00', '0', '');
INSERT INTO `tab_spend` VALUES ('81', '158', 'cxxcxx', 'cxxcxx', '1', 'CC44E9A9FDC231C00', '神武2', '0', '', '7', 'zlt12345', '', 'SP_20160812125037JAgj', '超级亲密丹*20(6.5折)', '328.00', '1470977437', '0', '0', '', '3', '61.153.44.110', '1', '0', '0.00', '0', '');
INSERT INTO `tab_spend` VALUES ('82', '180', '777888', '777888', '12', '520D9380CF1B71E89', '决战中洲', '0', '', '0', '自然注册', '', 'SP_20160812133920psQW', '钻石', '6.00', '1470980360', '0', '0', '', '3', '153.36.68.155', '1', '0', '0.00', '0', '');
INSERT INTO `tab_spend` VALUES ('83', '180', '777888', '777888', '1', 'CC44E9A9FDC231C00', '神武2', '0', '', '0', '自然注册', '', 'SP_20160812134550P8nJ', '1200元宝首充礼包', '6.00', '1470980750', '0', '0', '', '3', '153.36.68.155', '1', '0', '0.00', '0', '');
INSERT INTO `tab_spend` VALUES ('84', '180', '777888', '777888', '1', 'CC44E9A9FDC231C00', '神武2', '0', '', '0', '自然注册', '', 'SP_201608121349082DnP', '1200元宝首充礼包', '6.00', '1470980948', '0', '0', '', '3', '153.36.68.155', '1', '0', '0.00', '0', '');
INSERT INTO `tab_spend` VALUES ('85', '180', '777888', '777888', '1', 'CC44E9A9FDC231C00', '神武2', '0', '', '0', '自然注册', '', 'SP_20160812134914kI0p', '1200元宝首充礼包', '6.00', '1470980954', '0', '0', '', '3', '153.36.68.155', '1', '0', '0.00', '0', '');
INSERT INTO `tab_spend` VALUES ('86', '180', '777888', '777888', '1', 'CC44E9A9FDC231C00', '神武2', '0', '', '0', '自然注册', '', 'SP_201608121350271R5c', '1200元宝首充礼包', '6.00', '1470981027', '0', '0', '', '3', '153.36.68.155', '1', '0', '0.00', '0', '');
INSERT INTO `tab_spend` VALUES ('87', '180', '777888', '777888', '1', 'CC44E9A9FDC231C00', '神武2', '0', '', '0', '自然注册', '', 'SP_20160812135105sifv', '19600元宝首充礼包', '98.00', '1470981065', '0', '0', '', '3', '153.36.68.155', '1', '0', '0.00', '0', '');
INSERT INTO `tab_spend` VALUES ('88', '180', '777888', '777888', '1', 'CC44E9A9FDC231C00', '神武2', '0', '', '0', '自然注册', '', 'SP_201608121352126bTk', '19600元宝首充礼包', '98.00', '1470981132', '0', '0', '', '3', '153.36.68.155', '1', '0', '0.00', '0', '');
INSERT INTO `tab_spend` VALUES ('89', '180', '777888', '777888', '1', 'CC44E9A9FDC231C00', '神武2', '0', '', '0', '自然注册', '', 'SP_20160812135303DxeK', '1200元宝首充礼包', '6.00', '1470981183', '0', '0', '', '3', '153.36.68.155', '1', '0', '0.00', '0', '');
INSERT INTO `tab_spend` VALUES ('90', '180', '777888', '777888', '12', '520D9380CF1B71E89', '决战中洲', '0', '', '0', '自然注册', '', 'SP_20160812135532wWjZ', '钻石', '6.00', '1470981332', '0', '0', '', '3', '153.36.68.155', '1', '0', '0.00', '0', '');
INSERT INTO `tab_spend` VALUES ('91', '180', '777888', '777888', '12', '520D9380CF1B71E89', '决战中洲', '0', '', '0', '自然注册', '', 'SP_201608121355441lpH', '钻石', '6.00', '1470981344', '0', '0', '', '3', '153.36.68.155', '1', '0', '0.00', '0', '');
INSERT INTO `tab_spend` VALUES ('92', '183', '761207', '761207', '12', '520D9380CF1B71E89', '决战中洲', '0', '', '0', '自然注册', '', 'SP_201608121359149oSy', '钻石', '6.00', '1470981554', '0', '0', '', '3', '153.36.68.155', '1', '0', '0.00', '0', '');
INSERT INTO `tab_spend` VALUES ('93', '183', '761207', '761207', '12', '520D9380CF1B71E89', '决战中洲', '0', '', '0', '自然注册', '', 'SP_20160812140030CIBv', '钻石', '6.00', '1470981630', '0', '0', '', '3', '153.36.68.155', '1', '0', '0.00', '0', '');
INSERT INTO `tab_spend` VALUES ('94', '183', '761207', '761207', '12', '520D9380CF1B71E89', '决战中洲', '0', '', '0', '自然注册', '', 'SP_20160812140409ksF5', '钻石', '6.00', '1470981849', '0', '0', '', '3', '153.36.68.155', '1', '0', '0.00', '0', '');
INSERT INTO `tab_spend` VALUES ('95', '183', '761207', '761207', '12', '520D9380CF1B71E89', '决战中洲', '0', '', '0', '自然注册', '', 'SP_201608121406533ICm', '钻石', '6.00', '1470982013', '0', '0', '', '3', '153.36.68.155', '1', '0', '0.00', '0', '');
INSERT INTO `tab_spend` VALUES ('96', '192', '388866', '388866', '12', '520D9380CF1B71E89', '决战中洲', '0', '', '0', '自然注册', '', 'SP_20160812142211QM2b', '钻石', '6.00', '1470982931', '0', '0', '', '3', '153.36.68.155', '1', '0', '0.00', '0', '');
INSERT INTO `tab_spend` VALUES ('97', '192', '388866', '388866', '12', '520D9380CF1B71E89', '决战中洲', '0', '', '0', '自然注册', '', 'SP_20160812142253jcIB', '钻石', '6.00', '1470982973', '0', '0', '', '3', '153.36.68.155', '1', '0', '0.00', '0', '');
INSERT INTO `tab_spend` VALUES ('98', '192', '388866', '388866', '12', '520D9380CF1B71E89', '决战中洲', '0', '', '0', '自然注册', '', 'SP_201608121422589QU2', '钻石', '6.00', '1470982978', '0', '0', '', '3', '153.36.68.155', '1', '0', '0.00', '0', '');
INSERT INTO `tab_spend` VALUES ('99', '192', '388866', '388866', '12', '520D9380CF1B71E89', '决战中洲', '0', '', '0', '自然注册', '', 'SP_20160812142308jCjo', '钻石', '6.00', '1470982988', '0', '0', '', '3', '153.36.68.155', '1', '0', '0.00', '0', '');
INSERT INTO `tab_spend` VALUES ('100', '192', '388866', '388866', '12', '520D9380CF1B71E89', '决战中洲', '0', '', '0', '自然注册', '', 'SP_20160812142650a3E5', '钻石', '6.00', '1470983210', '0', '0', '', '3', '153.36.68.155', '1', '0', '0.00', '0', '');
INSERT INTO `tab_spend` VALUES ('101', '192', '388866', '388866', '12', '520D9380CF1B71E89', '决战中洲', '0', '', '0', '自然注册', '', 'SP_20160812143308xpXs', '钻石', '6.00', '1470983588', '0', '0', '', '3', '153.36.68.155', '1', '0', '0.00', '0', '');
INSERT INTO `tab_spend` VALUES ('102', '197', '838725', '838725', '12', '520D9380CF1B71E89', '决战中洲', '0', '', '0', '自然注册', '', 'SP_20160812143456EKpF', '钻石', '6.00', '1470983696', '0', '0', '', '3', '153.36.68.155', '1', '0', '0.00', '0', '');
INSERT INTO `tab_spend` VALUES ('103', '199', '789390', '789390', '12', '520D9380CF1B71E89', '决战中洲', '0', '', '0', '自然注册', '', 'SP_20160812143749lALe', '钻石', '6.00', '1470983869', '0', '0', '', '3', '153.36.68.155', '1', '0', '0.00', '0', '');
INSERT INTO `tab_spend` VALUES ('104', '199', '789390', '789390', '12', '520D9380CF1B71E89', '决战中洲', '0', '', '0', '自然注册', '', 'SP_20160812143846WrWm', '钻石', '6.00', '1470983925', '0', '0', '', '3', '153.36.68.155', '1', '0', '0.00', '0', '');
INSERT INTO `tab_spend` VALUES ('105', '199', '789390', '789390', '12', '520D9380CF1B71E89', '决战中洲', '0', '', '0', '自然注册', '', 'SP_20160812143912Cpnh', '钻石', '6.00', '1470983952', '0', '0', '', '3', '153.36.68.155', '1', '0', '0.00', '0', '');
INSERT INTO `tab_spend` VALUES ('106', '199', '789390', '789390', '12', '520D9380CF1B71E89', '决战中洲', '0', '', '0', '自然注册', '', 'SP_20160812144200MiJu', '钻石', '6.00', '1470984120', '0', '0', '', '3', '153.36.68.155', '1', '0', '0.00', '0', '');
INSERT INTO `tab_spend` VALUES ('107', '180', '777888', '777888', '12', '520D9380CF1B71E89', '决战中洲', '0', '', '0', '自然注册', '', 'SP_20160812144441Jwd7', '钻石', '6.00', '1470984281', '0', '0', '', '3', '153.36.68.155', '1', '0', '0.00', '0', '');
INSERT INTO `tab_spend` VALUES ('108', '180', '777888', '777888', '12', '520D9380CF1B71E89', '决战中洲', '0', '', '0', '自然注册', '', 'SP_20160812144500maYt', '钻石', '6.00', '1470984300', '0', '0', '', '3', '153.36.68.155', '1', '0', '0.00', '0', '');
INSERT INTO `tab_spend` VALUES ('109', '180', '777888', '777888', '12', '520D9380CF1B71E89', '决战中洲', '0', '', '0', '自然注册', '', 'SP_2016081214453629Nx', '钻石', '6.00', '1470984336', '0', '0', '', '3', '153.36.68.155', '1', '0', '0.00', '0', '');
INSERT INTO `tab_spend` VALUES ('110', '180', '777888', '777888', '12', '520D9380CF1B71E89', '决战中洲', '0', '', '0', '自然注册', '', 'SP_20160812144642hlQ4', '钻石', '6.00', '1470984402', '0', '0', '', '3', '153.36.68.155', '1', '0', '0.00', '0', '');
INSERT INTO `tab_spend` VALUES ('111', '180', '777888', '777888', '12', '520D9380CF1B71E89', '决战中洲', '0', '', '0', '自然注册', '', 'SP_20160812144708I1ru', '钻石', '6.00', '1470984428', '0', '0', '', '3', '153.36.68.155', '1', '0', '0.00', '0', '');
INSERT INTO `tab_spend` VALUES ('112', '180', '777888', '777888', '12', '520D9380CF1B71E89', '决战中洲', '0', '', '0', '自然注册', '', 'SP_20160812144940757A', '钻石', '0.50', '1470984580', '0', '0', '', '3', '153.36.68.155', '1', '0', '0.00', '0', '');
INSERT INTO `tab_spend` VALUES ('113', '180', '777888', '777888', '12', '520D9380CF1B71E89', '决战中洲', '0', '', '0', '自然注册', '', 'SP_20160812145025PnNU', '钻石', '6.00', '1470984624', '0', '0', '', '3', '153.36.68.155', '1', '0', '0.00', '0', '');
INSERT INTO `tab_spend` VALUES ('114', '180', '777888', '777888', '12', '520D9380CF1B71E89', '决战中洲', '0', '', '0', '自然注册', '', 'SP_20160812145037rlN3', '钻石', '6.00', '1470984637', '0', '0', '', '3', '153.36.68.155', '1', '0', '0.00', '0', '');
INSERT INTO `tab_spend` VALUES ('115', '180', '777888', '777888', '12', '520D9380CF1B71E89', '决战中洲', '0', '', '0', '自然注册', '', 'SP_20160812145110oCgW', '钻石', '6.00', '1470984670', '0', '0', '', '3', '153.36.68.155', '1', '0', '0.00', '0', '');
INSERT INTO `tab_spend` VALUES ('116', '180', '777888', '777888', '12', '520D9380CF1B71E89', '决战中洲', '0', '', '0', '自然注册', '', 'SP_20160812145118zXWf', '钻石', '6.00', '1470984678', '0', '0', '', '3', '153.36.68.155', '1', '0', '0.00', '0', '');
INSERT INTO `tab_spend` VALUES ('117', '180', '777888', '777888', '12', '520D9380CF1B71E89', '决战中洲', '0', '', '0', '自然注册', '', 'SP_20160812145149qj70', '钻石', '6.00', '1470984709', '0', '0', '', '3', '153.36.68.155', '1', '0', '0.00', '0', '');
INSERT INTO `tab_spend` VALUES ('118', '180', '777888', '777888', '12', '520D9380CF1B71E89', '决战中洲', '0', '', '0', '自然注册', '', 'SP_20160812145202IH05', '钻石', '6.00', '1470984722', '0', '0', '', '3', '153.36.68.155', '1', '0', '0.00', '0', '');
INSERT INTO `tab_spend` VALUES ('119', '180', '777888', '777888', '12', '520D9380CF1B71E89', '决战中洲', '0', '', '0', '自然注册', '', 'SP_20160812145325Z6B6', '钻石', '6.00', '1470984805', '0', '0', '', '3', '153.36.68.155', '1', '0', '0.00', '0', '');
INSERT INTO `tab_spend` VALUES ('120', '180', '777888', '777888', '12', '520D9380CF1B71E89', '决战中洲', '0', '', '0', '自然注册', '', 'SP_20160812145347JJwm', '钻石', '6.00', '1470984827', '0', '0', '', '3', '153.36.68.155', '1', '0', '0.00', '0', '');
INSERT INTO `tab_spend` VALUES ('121', '180', '777888', '777888', '12', '520D9380CF1B71E89', '决战中洲', '0', '', '0', '自然注册', '', 'SP_20160812145608nAg8', '钻石', '6.00', '1470984968', '0', '0', '', '3', '153.36.68.155', '1', '0', '0.00', '0', '');
INSERT INTO `tab_spend` VALUES ('122', '180', '777888', '777888', '12', '520D9380CF1B71E89', '决战中洲', '0', '', '0', '自然注册', '', 'SP_20160812145643AI85', '钻石', '6.00', '1470985003', '0', '0', '', '3', '153.36.68.155', '1', '0', '0.00', '0', '');
INSERT INTO `tab_spend` VALUES ('123', '180', '777888', '777888', '12', '520D9380CF1B71E89', '决战中洲', '0', '', '0', '自然注册', '', 'SP_20160812150752s0OQ', '钻石', '6.00', '1470985672', '0', '0', '', '3', '153.36.68.155', '1', '0', '0.00', '0', '');
INSERT INTO `tab_spend` VALUES ('124', '180', '777888', '777888', '12', '520D9380CF1B71E89', '决战中洲', '0', '', '0', '自然注册', '', 'SP_20160812150846RMjw', '钻石', '6.00', '1470985726', '0', '0', '', '3', '153.36.68.155', '1', '0', '0.00', '0', '');
INSERT INTO `tab_spend` VALUES ('125', '180', '777888', '777888', '12', '520D9380CF1B71E89', '决战中洲', '0', '', '0', '自然注册', '', 'SP_20160812151341VuLV', '钻石', '6.00', '1470986021', '0', '0', '', '3', '153.36.68.155', '1', '0', '0.00', '0', '');
INSERT INTO `tab_spend` VALUES ('126', '180', '777888', '777888', '12', '520D9380CF1B71E89', '决战中洲', '0', '', '0', '自然注册', '', 'SP_20160812152234MuIm', '钻石', '6.00', '1470986554', '0', '0', '', '3', '153.36.68.155', '1', '0', '0.00', '0', '');
INSERT INTO `tab_spend` VALUES ('127', '180', '777888', '777888', '12', '520D9380CF1B71E89', '决战中洲', '0', '', '0', '自然注册', '', 'SP_20160812152255rsx4', '钻石', '6.00', '1470986575', '0', '0', '', '3', '153.36.68.155', '1', '0', '0.00', '0', '');
INSERT INTO `tab_spend` VALUES ('128', '180', '777888', '777888', '12', '520D9380CF1B71E89', '决战中洲', '0', '', '0', '自然注册', '', 'SP_20160812152328OkCB', '钻石', '6.00', '1470986607', '0', '0', '', '3', '153.36.68.155', '1', '0', '0.00', '0', '');
INSERT INTO `tab_spend` VALUES ('129', '180', '777888', '777888', '12', '520D9380CF1B71E89', '决战中洲', '0', '', '0', '自然注册', '', 'SP_20160812152341WhR7', '钻石', '6.00', '1470986621', '0', '0', '', '3', '153.36.68.155', '1', '0', '0.00', '0', '');
INSERT INTO `tab_spend` VALUES ('130', '180', '777888', '777888', '12', '520D9380CF1B71E89', '决战中洲', '0', '', '0', '自然注册', '', 'SP_20160812152437TrxQ', '钻石', '6.00', '1470986677', '0', '0', '', '3', '153.36.68.155', '1', '0', '0.00', '0', '');
INSERT INTO `tab_spend` VALUES ('131', '180', '777888', '777888', '12', '520D9380CF1B71E89', '决战中洲', '0', '', '0', '自然注册', '', 'SP_20160812152447SS52', '钻石', '6.00', '1470986687', '0', '0', '', '3', '153.36.68.155', '1', '0', '0.00', '0', '');
INSERT INTO `tab_spend` VALUES ('132', '180', '777888', '777888', '12', '520D9380CF1B71E89', '决战中洲', '0', '', '0', '自然注册', '', 'SP_20160812152516Bl2t', '钻石', '6.00', '1470986716', '0', '0', '', '3', '153.36.68.155', '1', '0', '0.00', '0', '');
INSERT INTO `tab_spend` VALUES ('133', '180', '777888', '777888', '12', '520D9380CF1B71E89', '决战中洲', '0', '', '0', '自然注册', '', 'SP_20160812152751G5M9', '钻石', '6.00', '1470986871', '0', '0', '', '3', '153.36.68.155', '1', '0', '0.00', '0', '');
INSERT INTO `tab_spend` VALUES ('134', '180', '777888', '777888', '12', '520D9380CF1B71E89', '决战中洲', '0', '', '0', '自然注册', '', 'SP_20160812153414DREd', '钻石', '6.00', '1470987254', '0', '0', '', '3', '153.36.68.155', '1', '0', '0.00', '0', '');
INSERT INTO `tab_spend` VALUES ('135', '180', '777888', '777888', '12', '520D9380CF1B71E89', '决战中洲', '0', '', '0', '自然注册', '', 'SP_20160812153432I5If', '钻石', '6.00', '1470987272', '0', '0', '', '3', '153.36.68.155', '1', '0', '0.00', '0', '');
INSERT INTO `tab_spend` VALUES ('136', '180', '777888', '777888', '12', '520D9380CF1B71E89', '决战中洲', '0', '', '0', '自然注册', '', 'SP_20160812153512rmnX', '钻石', '6.00', '1470987312', '0', '0', '', '3', '153.36.68.155', '1', '0', '0.00', '0', '');
INSERT INTO `tab_spend` VALUES ('137', '180', '777888', '777888', '12', '520D9380CF1B71E89', '决战中洲', '0', '', '0', '自然注册', '', 'SP_201608121535222b40', '钻石', '6.00', '1470987322', '0', '0', '', '3', '153.36.68.155', '1', '0', '0.00', '0', '');
INSERT INTO `tab_spend` VALUES ('138', '219', 'liwz5200', 'liwz5200', '1', 'CC44E9A9FDC231C00', '神武2', '0', '', '7', 'zlt12345', '', 'SP_20160812153700E9Yf', '超级亲密丹*20(6.5折)', '328.00', '1470987419', '0', '0', '', '3', '183.27.48.106', '1', '0', '0.00', '0', '');
INSERT INTO `tab_spend` VALUES ('139', '222', '984526', '984526', '12', '520D9380CF1B71E89', '决战中洲', '0', '', '0', '自然注册', '', 'SP_20160812153721twgQ', '钻石', '6.00', '1470987441', '0', '0', '', '3', '153.36.68.155', '1', '0', '0.00', '0', '');
INSERT INTO `tab_spend` VALUES ('140', '78', 'lixian1992', 'lixian1992', '1', 'CC44E9A9FDC231C00', '神武2', '0', '', '4', 'daniel0857', '', 'SP_20160812153920dTBR', '超级亲密丹*20(6.5折)', '328.00', '1470987560', '0', '0', '', '3', '1.191.46.93', '1', '0', '0.00', '0', '');
INSERT INTO `tab_spend` VALUES ('141', '180', '777888', '777888', '12', '520D9380CF1B71E89', '决战中洲', '0', '', '0', '自然注册', '', 'SP_201608121539506riq', '钻石', '6.00', '1470987590', '0', '0', '', '3', '153.36.68.155', '1', '0', '0.00', '0', '');
INSERT INTO `tab_spend` VALUES ('142', '180', '777888', '777888', '12', '520D9380CF1B71E89', '决战中洲', '0', '', '0', '自然注册', '', 'SP_20160812154106fQfk', '钻石', '6.00', '1470987666', '0', '0', '', '3', '153.36.68.155', '1', '0', '0.00', '0', '');
INSERT INTO `tab_spend` VALUES ('143', '222', '984526', '984526', '12', '520D9380CF1B71E89', '决战中洲', '0', '', '0', '自然注册', '', 'SP_20160812154132lVb2', '钻石', '6.00', '1470987692', '0', '0', '', '3', '153.36.68.155', '1', '0', '0.00', '0', '');
INSERT INTO `tab_spend` VALUES ('144', '180', '777888', '777888', '12', '520D9380CF1B71E89', '决战中洲', '0', '', '0', '自然注册', '', 'SP_20160812154146V1J9', '钻石', '6.00', '1470987706', '0', '0', '', '3', '153.36.68.155', '1', '0', '0.00', '0', '');
INSERT INTO `tab_spend` VALUES ('145', '180', '777888', '777888', '12', '520D9380CF1B71E89', '决战中洲', '0', '', '0', '自然注册', '', 'SP_20160812154158FkcJ', '钻石', '6.00', '1470987718', '0', '0', '', '3', '153.36.68.155', '1', '0', '0.00', '0', '');
INSERT INTO `tab_spend` VALUES ('146', '180', '777888', '777888', '12', '520D9380CF1B71E89', '决战中洲', '0', '', '0', '自然注册', '', 'SP_20160812154215WvNS', '钻石', '6.00', '1470987735', '0', '0', '', '3', '153.36.68.155', '1', '0', '0.00', '0', '');
INSERT INTO `tab_spend` VALUES ('147', '180', '777888', '777888', '12', '520D9380CF1B71E89', '决战中洲', '0', '', '0', '自然注册', '', 'SP_20160812154221Ablk', '钻石', '6.00', '1470987740', '0', '0', '', '3', '153.36.68.155', '1', '0', '0.00', '0', '');
INSERT INTO `tab_spend` VALUES ('148', '180', '777888', '777888', '12', '520D9380CF1B71E89', '决战中洲', '0', '', '0', '自然注册', '', 'SP_20160812154228N6op', '钻石', '6.00', '1470987748', '0', '0', '', '3', '153.36.68.155', '1', '0', '0.00', '0', '');
INSERT INTO `tab_spend` VALUES ('149', '180', '777888', '777888', '12', '520D9380CF1B71E89', '决战中洲', '0', '', '0', '自然注册', '', 'SP_20160812154734mJUg', '钻石', '6.00', '1470988054', '0', '0', '', '3', '153.36.68.155', '1', '0', '0.00', '0', '');
INSERT INTO `tab_spend` VALUES ('150', '222', '984526', '984526', '12', '520D9380CF1B71E89', '决战中洲', '0', '', '0', '自然注册', '', 'SP_20160812154807mMaR', '钻石', '6.00', '1470988087', '0', '0', '', '3', '153.36.68.155', '1', '0', '0.00', '0', '');
INSERT INTO `tab_spend` VALUES ('151', '180', '777888', '777888', '12', '520D9380CF1B71E89', '决战中洲', '0', '', '0', '自然注册', '', 'SP_20160812154837VHLP', '钻石', '6.00', '1470988117', '0', '0', '', '3', '153.36.68.155', '1', '0', '0.00', '0', '');
INSERT INTO `tab_spend` VALUES ('152', '180', '777888', '777888', '12', '520D9380CF1B71E89', '决战中洲', '0', '', '0', '自然注册', '', 'SP_20160812160422EoLI', '钻石', '6.00', '1470989062', '0', '0', '', '3', '153.36.68.155', '1', '0', '0.00', '0', '');
INSERT INTO `tab_spend` VALUES ('153', '180', '777888', '777888', '12', '520D9380CF1B71E89', '决战中洲', '0', '', '0', '自然注册', '', 'SP_20160812160454IMTy', '钻石', '6.00', '1470989094', '0', '0', '', '3', '153.36.68.155', '1', '0', '0.00', '0', '');
INSERT INTO `tab_spend` VALUES ('154', '180', '777888', '777888', '12', '520D9380CF1B71E89', '决战中洲', '0', '', '0', '自然注册', '', 'SP_201608121605092IQE', '钻石', '6.00', '1470989109', '0', '0', '', '3', '153.36.68.155', '1', '0', '0.00', '0', '');
INSERT INTO `tab_spend` VALUES ('155', '222', '984526', '984526', '12', '520D9380CF1B71E89', '决战中洲', '0', '', '0', '自然注册', '', 'SP_20160812160729T3jp', '钻石', '6.00', '1470989249', '0', '0', '', '3', '153.36.68.155', '1', '0', '0.00', '0', '');
INSERT INTO `tab_spend` VALUES ('156', '180', '777888', '777888', '12', '520D9380CF1B71E89', '决战中洲', '0', '', '0', '自然注册', '', 'SP_20160812160749eKpR', '钻石', '6.00', '1470989269', '0', '0', '', '3', '153.36.68.155', '1', '0', '0.00', '0', '');
INSERT INTO `tab_spend` VALUES ('157', '180', '777888', '777888', '12', '520D9380CF1B71E89', '决战中洲', '0', '', '0', '自然注册', '', 'SP_20160812161038ed4I', '钻石', '6.00', '1470989438', '0', '0', '', '3', '153.36.68.155', '1', '0', '0.00', '0', '');
INSERT INTO `tab_spend` VALUES ('158', '180', '777888', '777888', '12', '520D9380CF1B71E89', '决战中洲', '0', '', '0', '自然注册', '', 'SP_20160812161112unAj', '钻石', '6.00', '1470989472', '0', '0', '', '3', '153.36.68.155', '1', '0', '0.00', '0', '');
INSERT INTO `tab_spend` VALUES ('159', '180', '777888', '777888', '12', '520D9380CF1B71E89', '决战中洲', '0', '', '0', '自然注册', '', 'SP_20160812161124oou6', '钻石', '6.00', '1470989484', '0', '0', '', '3', '153.36.68.155', '1', '0', '0.00', '0', '');
INSERT INTO `tab_spend` VALUES ('160', '180', '777888', '777888', '12', '520D9380CF1B71E89', '决战中洲', '0', '', '0', '自然注册', '', 'SP_20160812161132rjr6', '钻石', '6.00', '1470989492', '0', '0', '', '3', '153.36.68.155', '1', '0', '0.00', '0', '');
INSERT INTO `tab_spend` VALUES ('161', '180', '777888', '777888', '12', '520D9380CF1B71E89', '决战中洲', '0', '', '0', '自然注册', '', 'SP_201608121611593hZ7', '钻石', '6.00', '1470989519', '0', '0', '', '3', '153.36.68.155', '1', '0', '0.00', '0', '');
INSERT INTO `tab_spend` VALUES ('162', '229', '15267836139', '15267836139', '1', 'CC44E9A9FDC231C00', '神武2', '0', '', '4', 'daniel0857', '', 'SP_201608121612144ZNu', '1200元宝首充礼包', '6.00', '1470989534', '1', '1', 'gf=xiyou#kid=md_s_1#rid=10214#gi', '3', '123.152.136.161', '1', '0', '0.00', '0', '');
INSERT INTO `tab_spend` VALUES ('163', '180', '777888', '777888', '12', '520D9380CF1B71E89', '决战中洲', '0', '', '0', '自然注册', '', 'SP_20160812161231hc9m', '钻石', '6.00', '1470989551', '0', '0', '', '3', '153.36.68.155', '1', '0', '0.00', '0', '');
INSERT INTO `tab_spend` VALUES ('164', '229', '15267836139', '15267836139', '1', 'CC44E9A9FDC231C00', '神武2', '0', '', '4', 'daniel0857', '', 'SP_20160812161242047b', '1200元宝首充礼包', '6.00', '1470989562', '0', '0', '', '3', '123.152.136.161', '1', '0', '0.00', '0', '');
INSERT INTO `tab_spend` VALUES ('165', '180', '777888', '777888', '12', '520D9380CF1B71E89', '决战中洲', '0', '', '0', '自然注册', '', 'SP_201608121613062ynO', '钻石', '6.00', '1470989586', '0', '0', '', '3', '153.36.68.155', '1', '0', '0.00', '0', '');
INSERT INTO `tab_spend` VALUES ('166', '180', '777888', '777888', '12', '520D9380CF1B71E89', '决战中洲', '0', '', '0', '自然注册', '', 'SP_20160812161404vA6J', '钻石', '6.00', '1470989644', '0', '0', '', '3', '153.36.68.155', '1', '0', '0.00', '0', '');
INSERT INTO `tab_spend` VALUES ('167', '180', '777888', '777888', '12', '520D9380CF1B71E89', '决战中洲', '0', '', '0', '自然注册', '', 'SP_201608121615434iG8', '钻石', '6.00', '1470989743', '0', '0', '', '3', '153.36.68.155', '1', '0', '0.00', '0', '');
INSERT INTO `tab_spend` VALUES ('168', '180', '777888', '777888', '12', '520D9380CF1B71E89', '决战中洲', '0', '', '0', '自然注册', '', 'SP_20160812161650EUEb', '钻石', '6.00', '1470989810', '0', '0', '', '3', '153.36.68.155', '1', '0', '0.00', '0', '');
INSERT INTO `tab_spend` VALUES ('169', '180', '777888', '777888', '12', '520D9380CF1B71E89', '决战中洲', '0', '', '0', '自然注册', '', 'SP_20160812162052MmVB', '钻石', '6.00', '1470990052', '0', '0', '', '3', '153.36.68.155', '1', '0', '0.00', '0', '');
INSERT INTO `tab_spend` VALUES ('170', '180', '777888', '777888', '12', '520D9380CF1B71E89', '决战中洲', '0', '', '0', '自然注册', '', 'SP_20160812162110Oe29', '钻石', '6.00', '1470990070', '0', '0', '', '3', '153.36.68.155', '1', '0', '0.00', '0', '');
INSERT INTO `tab_spend` VALUES ('171', '180', '777888', '777888', '12', '520D9380CF1B71E89', '决战中洲', '0', '', '0', '自然注册', '', 'SP_20160812164008MLLE', '钻石', '6.00', '1470991208', '0', '0', '', '3', '153.36.68.155', '1', '0', '0.00', '0', '');
INSERT INTO `tab_spend` VALUES ('172', '180', '777888', '777888', '12', '520D9380CF1B71E89', '决战中洲', '0', '', '0', '自然注册', '', 'SP_20160812164033zSyf', '钻石', '6.00', '1470991233', '0', '0', '', '3', '153.36.68.155', '1', '0', '0.00', '0', '');
INSERT INTO `tab_spend` VALUES ('173', '216', '929596', '929596', '1', 'CC44E9A9FDC231C00', '神武2', '0', '', '7', 'zlt12345', '', 'SP_20160812164854aLgO', '1000000元宝首充礼包', '5000.00', '1470991734', '0', '0', '', '3', '117.136.36.92', '1', '0', '0.00', '0', '');
INSERT INTO `tab_spend` VALUES ('174', '216', '929596', '929596', '1', 'CC44E9A9FDC231C00', '神武2', '0', '', '7', 'zlt12345', '', 'SP_20160812164916OPDq', '超级亲密丹*20(6.5折)', '328.00', '1470991756', '0', '0', '', '3', '117.136.36.92', '1', '0', '0.00', '0', '');
INSERT INTO `tab_spend` VALUES ('175', '244', '265288', '265288', '1', 'CC44E9A9FDC231C00', '神武2', '0', '', '7', 'zlt12345', '', 'SP_20160812170841zYMK', '1000000元宝首充礼包', '5000.00', '1470992921', '0', '0', '', '3', '115.49.180.154', '1', '0', '0.00', '0', '');
INSERT INTO `tab_spend` VALUES ('176', '244', '265288', '265288', '1', 'CC44E9A9FDC231C00', '神武2', '0', '', '7', 'zlt12345', '', 'SP_20160812170853Eb4E', '1000000元宝首充礼包', '5000.00', '1470992933', '0', '0', '', '3', '115.49.180.154', '1', '0', '0.00', '0', '');
INSERT INTO `tab_spend` VALUES ('177', '270', '2733164728', '2733164728', '1', 'CC44E9A9FDC231C00', '神武2', '0', '', '7', 'zlt12345', '', 'SP_20160812171031ipmy', '超级亲密丹*20(6.5折)', '328.00', '1470993031', '0', '0', '', '3', '112.234.208.244', '1', '0', '0.00', '0', '');
INSERT INTO `tab_spend` VALUES ('178', '272', '720222', '720222', '1', 'CC44E9A9FDC231C00', '神武2', '0', '', '7', 'zlt12345', '', 'SP_20160812171429PHZi', '1000000元宝首充礼包', '5000.00', '1470993268', '0', '0', '', '3', '121.12.126.41', '1', '0', '0.00', '0', '');
INSERT INTO `tab_spend` VALUES ('179', '300', '15181739702', '15181739702', '1', 'CC44E9A9FDC231C00', '神武2', '0', '', '4', 'daniel0857', '', 'SP_20160812181031SPKY', '灵珠*260(7.5折)', '30.00', '1470996631', '0', '0', '', '3', '125.66.93.221', '1', '0', '0.00', '0', '');
INSERT INTO `tab_spend` VALUES ('180', '301', '998433', '998433', '1', 'CC44E9A9FDC231C00', '神武2', '0', '', '4', 'daniel0857', '', 'SP_20160812181439hw2q', '超级亲密丹*20(6.5折)', '328.00', '1470996879', '0', '0', '', '3', '36.57.32.173', '1', '0', '0.00', '0', '');
INSERT INTO `tab_spend` VALUES ('181', '302', 'qq1363508033', 'qq1363508033', '1', 'CC44E9A9FDC231C00', '神武2', '0', '', '7', 'zlt12345', '', 'SP_20160812181936Gwpu', '1200元宝首充礼包', '6.00', '1470997176', '0', '0', '', '3', '116.53.168.83', '1', '0', '0.00', '0', '');
INSERT INTO `tab_spend` VALUES ('182', '180', '777888', '777888', '12', '520D9380CF1B71E89', '决战中洲', '0', '', '0', '自然注册', '', 'SP_201608121838595eDm', '钻石', '0.01', '1470998339', '0', '0', '', '3', '153.36.68.155', '1', '0', '0.00', '0', '');
INSERT INTO `tab_spend` VALUES ('183', '180', '777888', '777888', '12', '520D9380CF1B71E89', '决战中洲', '0', '', '0', '自然注册', '', 'SP_20160812183902TEDf', '钻石', '0.01', '1470998342', '0', '0', '', '3', '153.36.68.155', '1', '0', '0.00', '0', '');
INSERT INTO `tab_spend` VALUES ('184', '180', '777888', '777888', '12', '520D9380CF1B71E89', '决战中洲', '0', '', '0', '自然注册', '', 'SP_2016081218390452Yd', '钻石', '0.01', '1470998344', '0', '0', '', '3', '153.36.68.155', '1', '0', '0.00', '0', '');
INSERT INTO `tab_spend` VALUES ('185', '180', '777888', '777888', '12', '520D9380CF1B71E89', '决战中洲', '0', '', '0', '自然注册', '', 'SP_20160812183909MmBv', '钻石', '0.01', '1470998349', '0', '0', '', '3', '153.36.68.155', '1', '0', '0.00', '0', '');
INSERT INTO `tab_spend` VALUES ('186', '180', '777888', '777888', '12', '520D9380CF1B71E89', '决战中洲', '0', '', '0', '自然注册', '', 'SP_20160812183921cpu3', '钻石', '0.01', '1470998361', '0', '0', '', '3', '153.36.68.155', '1', '0', '0.00', '0', '');
INSERT INTO `tab_spend` VALUES ('187', '180', '777888', '777888', '12', '520D9380CF1B71E89', '决战中洲', '0', '', '0', '自然注册', '', 'SP_20160812183932w2o8', '钻石', '0.01', '1470998372', '0', '0', '', '3', '153.36.68.155', '1', '0', '0.00', '0', '');
INSERT INTO `tab_spend` VALUES ('188', '180', '777888', '777888', '12', '520D9380CF1B71E89', '决战中洲', '0', '', '0', '自然注册', '', 'SP_20160812183949VFFo', '钻石', '0.01', '1470998389', '0', '0', '', '3', '153.36.68.155', '1', '0', '0.00', '0', '');

-- -----------------------------
-- Table structure for `tab_tool`
-- -----------------------------
DROP TABLE IF EXISTS `tab_tool`;
CREATE TABLE `tab_tool` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '自增主键',
  `name` varchar(30) DEFAULT NULL COMMENT '标识',
  `title` varchar(30) DEFAULT NULL COMMENT '标题',
  `config` text COMMENT '配置文件内容',
  `template` text COMMENT '模板内容',
  `type` tinyint(3) DEFAULT NULL COMMENT '类型',
  `status` tinyint(3) DEFAULT NULL COMMENT '状态',
  `create_time` int(11) DEFAULT NULL COMMENT '添加时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8 COMMENT='扩展工具表';

-- -----------------------------
-- Records of `tab_tool`
-- -----------------------------
INSERT INTO `tab_tool` VALUES ('1', 'sms_set', '短信设置', '{\"smtp\":\"tfnj3gru6ztmw5pk78ha4v9esixbqydl\",\"smtp_account\":\"1960daf08fa64ecbbe85fb4f88204384\",\"smtp_password\":\"1\",\"smtp_port\":\"24952\"}', '', '1', '0', '1464164373');
INSERT INTO `tab_tool` VALUES ('2', 'oss_storage', 'OSS存储', '', '', '1', '0', '1464164373');
INSERT INTO `tab_tool` VALUES ('3', 'qiniu_storage', '七牛存储', '{\"bucket\":\"\",\"accesskeyid\":\"\",\"accesskeysecr\":\"\",\"domain\":\"\"}', '', '1', '0', '1464164373');
INSERT INTO `tab_tool` VALUES ('4', 'alipay', '支付宝设置', '{\"partner\":\"2088221482070129\",\"key\":\"6uh8jntp6nb72mqkvl2rou6llv5yu5r9\",\"email\":\"339517@qq.com\"}', '', '1', '1', '1464164373');
INSERT INTO `tab_tool` VALUES ('5', 'weixin', '微信设置', '{\"partner\":\"7551000001\",\"email\":\"1230\",\"key\":\"9d101c97133837e13dde2d32a5054abb\"}', '', '1', '1', '1464164373');
INSERT INTO `tab_tool` VALUES ('6', 'email_set', '邮件设置', '', '', '1', '1', '1464164373');
INSERT INTO `tab_tool` VALUES ('7', 'qq_login', 'QQ登陆设置', '{\"appid\":\"1\",\"key\":\"1\",\"account\":\"1\"}', '', '1', '1', '1464164373');
INSERT INTO `tab_tool` VALUES ('8', 'wx_login', '微信登陆设置', '{\"appid\":\"1\",\"mchid\":\"1\",\"key\":\"1\",\"appsecret\":\"1\"}', '', '1', '0', '1464164373');
INSERT INTO `tab_tool` VALUES ('9', 'heepay', '汇付宝设置', '{\"partner\":\"1664502\",\"email\":\"\",\"key\":\"2933282B4F95485D999D1788\"}', '', '1', '1', '1464164373');
INSERT INTO `tab_tool` VALUES ('10', 'jubaobar', '聚宝云', '{\"partner\":\"16070723351477716966\",\"key\":\"269bee27cc8546faab3e3cb71fb42772\"}', '', '1', '1', '1464164373');

-- -----------------------------
-- Table structure for `tab_user`
-- -----------------------------
DROP TABLE IF EXISTS `tab_user`;
CREATE TABLE `tab_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键自增',
  `account` varchar(30) DEFAULT NULL COMMENT '登陆账号',
  `password` varchar(32) DEFAULT NULL COMMENT '登陆密码',
  `promote_id` int(11) NOT NULL DEFAULT '0' COMMENT '推广id',
  `promote_account` varchar(30) DEFAULT NULL COMMENT '推广员账号',
  `parent_id` int(11) DEFAULT '0' COMMENT '父类id',
  `parent_name` varchar(30) DEFAULT NULL COMMENT '父类名称',
  `fgame_id` int(11) DEFAULT '0',
  `fgame_name` varchar(30) DEFAULT NULL,
  `nickname` varchar(30) DEFAULT NULL COMMENT '昵称',
  `sex` int(11) DEFAULT '0' COMMENT '性别(0 男 1 女)',
  `email` varchar(50) DEFAULT NULL COMMENT '邮箱',
  `phone` varchar(15) DEFAULT NULL COMMENT '手机号码',
  `real_name` varchar(20) DEFAULT NULL COMMENT '真实姓名',
  `idcard` varchar(20) DEFAULT NULL COMMENT '身份证',
  `vip_level` tinyint(2) DEFAULT '0' COMMENT 'vip等级',
  `cumulative` double(10,2) DEFAULT '0.00' COMMENT '累计充值',
  `balance` double(10,2) DEFAULT '0.00' COMMENT '余额',
  `anti_addiction` tinyint(2) DEFAULT '0' COMMENT '防沉迷',
  `lock_status` tinyint(2) DEFAULT '1' COMMENT '锁定状态',
  `register_way` tinyint(2) DEFAULT '0' COMMENT '注册方式',
  `register_time` int(11) DEFAULT NULL COMMENT '注册时间',
  `login_time` int(11) DEFAULT NULL COMMENT '登陆时间',
  `register_ip` varchar(16) NOT NULL COMMENT '注册ip',
  `login_ip` varchar(16) NOT NULL COMMENT '登陆ip',
  `is_check` int(11) NOT NULL DEFAULT '1' COMMENT '是否对账  1参与 2不参与 3参与(已对账) 4不参与(已对账)',
  `sub_status` int(11) DEFAULT '0' COMMENT '子渠道结算状态(0未结算 1已结算)',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=316 DEFAULT CHARSET=utf8 COMMENT='用户表';

-- -----------------------------
-- Records of `tab_user`
-- -----------------------------
INSERT INTO `tab_user` VALUES ('1', '316046', 'f714e22d958eb5fe42829a9c737ca0af', '0', '自然注册', '0', '', '12', '决战中洲', '316046', '0', '', '', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470641939', '1470658268', '153.36.68.207', '153.36.68.207', '1', '0');
INSERT INTO `tab_user` VALUES ('2', '674640', 'f714e22d958eb5fe42829a9c737ca0af', '0', '自然注册', '0', '', '12', '决战中洲', '674640', '0', '', '', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470652774', '1470713650', '153.36.68.207', '153.36.161.180', '1', '0');
INSERT INTO `tab_user` VALUES ('3', '564942', 'f714e22d958eb5fe42829a9c737ca0af', '0', '自然注册', '0', '', '12', '决战中洲', '564942', '0', '', '', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470661272', '1470661272', '153.36.68.207', '153.36.68.207', '1', '0');
INSERT INTO `tab_user` VALUES ('4', '563000', 'f714e22d958eb5fe42829a9c737ca0af', '0', '自然注册', '0', '', '12', '决战中洲', '563000', '0', '', '', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470661373', '1470661652', '153.36.68.207', '153.36.68.207', '1', '0');
INSERT INTO `tab_user` VALUES ('5', 'a111111', '2050677218f8836236e8c34f7242713f', '0', '', '0', '', '0', '', '', '0', '', '', '', '', '0', '0.00', '0.00', '0', '1', '0', '1470704659', '1470704659', '153.36.161.180', '153.36.161.180', '1', '0');
INSERT INTO `tab_user` VALUES ('6', 'aaaaaa', '2050677218f8836236e8c34f7242713f', '0', '', '0', '', '0', '', '', '0', '', '', '', '', '0', '0.00', '0.00', '0', '1', '0', '1470707497', '1470707497', '153.36.161.180', '153.36.161.180', '1', '0');
INSERT INTO `tab_user` VALUES ('7', 'daniel0857', 'cd703417df82ae9561d1ef2956dd8752', '0', '', '0', '', '0', '', '', '0', '', '', '', '', '0', '0.00', '0.00', '0', '1', '0', '1470717966', '1470719151', '60.248.238.175', '60.248.238.175', '1', '0');
INSERT INTO `tab_user` VALUES ('8', '231149', '43b54e1bfa09eb9819eb58fdeb34af69', '3', 'test1234', '0', 'test1234', '1', '梦幻西游BT', '231149', '0', '', '', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470732503', '1470735092', '218.19.136.119', '218.19.136.119', '1', '0');
INSERT INTO `tab_user` VALUES ('9', '871103', '4bc024390fa5bc81bf4ad5bdc60fc395', '3', 'test1234', '0', 'test1234', '1', '梦幻西游BT', '871103', '0', '', '', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470734558', '1470734559', '218.19.136.119', '218.19.136.119', '1', '0');
INSERT INTO `tab_user` VALUES ('10', '471341', '43b54e1bfa09eb9819eb58fdeb34af69', '3', 'test1234', '0', 'test1234', '1', '梦幻西游BT', '471341', '0', '', '', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470736304', '1470794766', '218.19.136.119', '218.19.136.119', '1', '0');
INSERT INTO `tab_user` VALUES ('11', '471341', '43b54e1bfa09eb9819eb58fdeb34af69', '3', 'test1234', '0', 'test1234', '1', '梦幻西游BT', '471341', '0', '', '', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470736304', '', '218.19.136.119', '', '1', '0');
INSERT INTO `tab_user` VALUES ('12', '356596', 'f714e22d958eb5fe42829a9c737ca0af', '3', 'test1234', '0', 'test1234', '1', '梦幻西游BT', '356596', '0', '', '', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470737114', '1470737114', '218.19.136.119', '218.19.136.119', '1', '0');
INSERT INTO `tab_user` VALUES ('13', '682928', '43b54e1bfa09eb9819eb58fdeb34af69', '3', 'test1234', '0', 'test1234', '1', '梦幻西游BT', '682928', '0', '', '', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470794990', '1470794990', '218.19.136.119', '218.19.136.119', '1', '0');
INSERT INTO `tab_user` VALUES ('14', '962674', '43b54e1bfa09eb9819eb58fdeb34af69', '3', 'test1234', '0', 'test1234', '1', '梦幻西游BT', '962674', '0', '', '', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470796119', '1470796133', '112.96.115.97', '112.96.115.97', '1', '0');
INSERT INTO `tab_user` VALUES ('15', '710020', '43b54e1bfa09eb9819eb58fdeb34af69', '3', 'test1234', '0', 'test1234', '1', '梦幻西游BT', '710020', '0', '', '', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470796147', '1470796302', '112.96.115.97', '218.19.136.119', '1', '0');
INSERT INTO `tab_user` VALUES ('16', '472800', 'f714e22d958eb5fe42829a9c737ca0af', '3', 'test1234', '0', 'test1234', '1', '梦幻西游BT', '472800', '0', '', '', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470796677', '1470796678', '218.19.136.119', '218.19.136.119', '1', '0');
INSERT INTO `tab_user` VALUES ('17', '346367', '43b54e1bfa09eb9819eb58fdeb34af69', '3', 'test1234', '0', 'test1234', '1', '梦幻西游BT', '346367', '0', '', '', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470796870', '1470796870', '218.19.136.119', '218.19.136.119', '1', '0');
INSERT INTO `tab_user` VALUES ('18', '415399', 'f714e22d958eb5fe42829a9c737ca0af', '3', 'test1234', '0', 'test1234', '1', '梦幻西游BT', '415399', '0', '', '', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470820664', '1470821021', '218.19.136.119', '218.19.136.119', '1', '0');
INSERT INTO `tab_user` VALUES ('19', '15505437898', 'cd703417df82ae9561d1ef2956dd8752', '3', 'test1234', '0', 'test1234', '1', '梦幻西游BT', '15505437898', '0', '', '15505437898', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470827325', '1470900596', '60.248.238.175', '60.248.238.175', '1', '0');
INSERT INTO `tab_user` VALUES ('20', '868327', 'f714e22d958eb5fe42829a9c737ca0af', '3', 'test1234', '0', 'test1234', '1', '神武2BT', '868327', '0', '', '', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470888937', '1470888937', '218.19.136.119', '218.19.136.119', '1', '0');
INSERT INTO `tab_user` VALUES ('21', '161510', 'f714e22d958eb5fe42829a9c737ca0af', '3', 'test1234', '0', 'test1234', '1', '神武2BT', '161510', '0', '', '', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470893280', '1470893281', '218.19.136.119', '218.19.136.119', '1', '0');
INSERT INTO `tab_user` VALUES ('22', '371180', 'f714e22d958eb5fe42829a9c737ca0af', '3', 'test1234', '0', 'test1234', '1', '神武2BT', '371180', '0', '', '', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470894212', '1470894338', '218.19.136.119', '218.19.136.119', '1', '0');
INSERT INTO `tab_user` VALUES ('23', '513248', 'f714e22d958eb5fe42829a9c737ca0af', '3', 'test1234', '0', 'test1234', '1', '神武2BT', '513248', '0', '', '', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470894955', '1470898814', '218.19.136.119', '218.19.136.119', '1', '0');
INSERT INTO `tab_user` VALUES ('24', '781352', 'f714e22d958eb5fe42829a9c737ca0af', '0', '自然注册', '0', '', '12', '决战中洲', '781352', '0', '', '', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470895110', '1470895110', '157.0.226.72', '157.0.226.72', '1', '0');
INSERT INTO `tab_user` VALUES ('25', '424842', 'f714e22d958eb5fe42829a9c737ca0af', '0', '自然注册', '0', '', '12', '决战中洲', '424842', '0', '', '', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470895559', '1470895559', '157.0.226.72', '157.0.226.72', '1', '0');
INSERT INTO `tab_user` VALUES ('26', '772794', '43b54e1bfa09eb9819eb58fdeb34af69', '3', 'test1234', '0', 'test1234', '1', '神武2BT', '772794', '0', '', '', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470896417', '1470898172', '218.19.136.119', '112.96.128.124', '1', '0');
INSERT INTO `tab_user` VALUES ('27', '322187', 'f714e22d958eb5fe42829a9c737ca0af', '0', '自然注册', '0', '', '12', '决战中洲', '322187', '0', '', '', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470897315', '1470897327', '157.0.226.72', '157.0.226.72', '1', '0');
INSERT INTO `tab_user` VALUES ('28', '210926', '43b54e1bfa09eb9819eb58fdeb34af69', '3', 'test1234', '0', 'test1234', '1', '神武2BT', '210926', '0', '', '', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470898497', '1470900829', '218.19.136.119', '218.19.136.119', '1', '0');
INSERT INTO `tab_user` VALUES ('29', '374925', 'f714e22d958eb5fe42829a9c737ca0af', '0', '自然注册', '0', '', '12', '决战中洲', '374925', '0', '', '', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470899078', '1470899079', '157.0.226.72', '157.0.226.72', '1', '0');
INSERT INTO `tab_user` VALUES ('30', '252341', 'f714e22d958eb5fe42829a9c737ca0af', '0', '自然注册', '0', '', '12', '决战中洲', '252341', '0', '', '', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470899495', '1470899495', '157.0.226.72', '157.0.226.72', '1', '0');
INSERT INTO `tab_user` VALUES ('31', '147043', 'f714e22d958eb5fe42829a9c737ca0af', '0', '自然注册', '0', '', '12', '决战中洲', '147043', '0', '', '', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470900062', '1470905465', '157.0.226.72', '157.0.226.72', '1', '0');
INSERT INTO `tab_user` VALUES ('32', '550135', 'f714e22d958eb5fe42829a9c737ca0af', '3', 'test1234', '0', 'test1234', '1', '神武2BT', '550135', '0', '', '', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470907461', '1470907461', '218.19.138.137', '218.19.138.137', '1', '0');
INSERT INTO `tab_user` VALUES ('33', '896852', '43b54e1bfa09eb9819eb58fdeb34af69', '3', 'test1234', '0', 'test1234', '1', '神武2BT', '896852', '0', '', '', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470907798', '1470907798', '218.19.138.137', '218.19.138.137', '1', '0');
INSERT INTO `tab_user` VALUES ('34', '861130', '43b54e1bfa09eb9819eb58fdeb34af69', '3', 'test1234', '0', 'test1234', '1', '神武2BT', '861130', '0', '', '', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470908118', '1470908225', '218.19.138.137', '218.19.138.137', '1', '0');
INSERT INTO `tab_user` VALUES ('35', '592371', 'f8394e6f10d9c6ac8df62128a24a61f4', '3', 'test1234', '0', 'test1234', '1', '神武2BT', '592371', '0', '', '', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470908584', '1470911483', '218.19.138.137', '218.19.138.137', '1', '0');
INSERT INTO `tab_user` VALUES ('36', '955710', '43b54e1bfa09eb9819eb58fdeb34af69', '3', 'test1234', '0', 'test1234', '1', '神武2BT', '955710', '0', '', '', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470908939', '1470908939', '218.19.138.137', '218.19.138.137', '1', '0');
INSERT INTO `tab_user` VALUES ('37', '379986', '43b54e1bfa09eb9819eb58fdeb34af69', '4', 'daniel0857', '0', 'daniel0857', '1', '神武2', '379986', '0', '', '', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470927827', '', '60.248.238.175', '', '1', '0');
INSERT INTO `tab_user` VALUES ('38', '183383', '43b54e1bfa09eb9819eb58fdeb34af69', '4', 'daniel0857', '0', 'daniel0857', '1', '神武2', '183383', '0', '', '', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470927838', '1470976165', '60.248.238.175', '60.248.238.175', '1', '0');
INSERT INTO `tab_user` VALUES ('39', '6225540', '5f8b0e0d17aff7b1fc4a6677579fba23', '4', 'daniel0857', '0', 'daniel0857', '1', '神武2', '6225540', '0', '', '', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470928539', '1470990270', '139.201.153.110', '139.201.153.110', '1', '0');
INSERT INTO `tab_user` VALUES ('40', 'd123456', '43b54e1bfa09eb9819eb58fdeb34af69', '4', 'daniel0857', '0', 'daniel0857', '1', '神武2', 'd123456', '0', '', '', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470928783', '1470967307', '60.222.97.42', '60.222.65.78', '1', '0');
INSERT INTO `tab_user` VALUES ('41', 'aa5587831', '08af7ec38d72e611240d1c1315dd1c0f', '4', 'daniel0857', '0', 'daniel0857', '1', '神武2', 'aa5587831', '0', '', '', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470928810', '1470987178', '171.107.17.200', '171.107.17.200', '1', '0');
INSERT INTO `tab_user` VALUES ('42', 'caomengyao1636', 'ee9006c68574372e86978b2e8208d8a1', '4', 'daniel0857', '0', 'daniel0857', '1', '神武2', 'caomengyao1636', '0', '', '', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470928817', '1470955721', '123.138.186.99', '123.138.186.123', '1', '0');
INSERT INTO `tab_user` VALUES ('43', 'zlt123456', 'c05b696320e7300e6458d5bbf5a6370e', '4', 'daniel0857', '0', 'daniel0857', '1', '神武2', 'zlt123456', '0', '', '', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470928870', '1470929828', '125.71.115.129', '125.71.115.129', '1', '0');
INSERT INTO `tab_user` VALUES ('44', 'ycxinpeng0911', 'fd63d1341dbafb03642b01e2a25f6e50', '4', 'daniel0857', '0', 'daniel0857', '1', '神武2', 'ycxinpeng0911', '0', '', '', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470928933', '1470990362', '27.207.77.40', '27.207.77.40', '1', '0');
INSERT INTO `tab_user` VALUES ('45', '20998526', '43b54e1bfa09eb9819eb58fdeb34af69', '4', 'daniel0857', '0', 'daniel0857', '1', '神武2', '20998526', '0', '', '', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470929366', '1470989020', '117.28.181.145', '117.28.181.145', '1', '0');
INSERT INTO `tab_user` VALUES ('46', 'wei320781', '43b54e1bfa09eb9819eb58fdeb34af69', '4', 'daniel0857', '0', 'daniel0857', '1', '神武2', 'wei320781', '0', '', '', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470929699', '1470929699', '183.67.175.34', '183.67.175.34', '1', '0');
INSERT INTO `tab_user` VALUES ('47', 'yuan123', '43b54e1bfa09eb9819eb58fdeb34af69', '4', 'daniel0857', '0', 'daniel0857', '1', '神武2', 'yuan123', '0', '', '', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470930212', '1470930212', '59.59.231.95', '59.59.231.95', '1', '0');
INSERT INTO `tab_user` VALUES ('48', '182073a', 'fa8c5a6da9687f41fc90d32a3dc805a7', '4', 'daniel0857', '0', 'daniel0857', '1', '神武2', '182073a', '0', '', '', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470930223', '1470930224', '123.139.44.221', '123.139.44.221', '1', '0');
INSERT INTO `tab_user` VALUES ('49', 'loklok', '1bb75166ee50b35438615c1a3b085a89', '4', 'daniel0857', '0', 'daniel0857', '1', '神武2', 'loklok', '0', '', '', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470930253', '1470966735', '60.52.22.96', '60.52.22.96', '1', '0');
INSERT INTO `tab_user` VALUES ('50', '13406351617', '43b54e1bfa09eb9819eb58fdeb34af69', '4', 'daniel0857', '0', 'daniel0857', '1', '神武2', '13406351617', '0', '', '13406351617', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470930314', '1470930314', '218.56.31.82', '218.56.31.82', '1', '0');
INSERT INTO `tab_user` VALUES ('51', '15117861717', '179b2a5e908483b757758dd35cd00a44', '4', 'daniel0857', '0', 'daniel0857', '1', '神武2', '15117861717', '0', '', '15117861717', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470930351', '1470987361', '114.139.104.39', '114.139.104.39', '1', '0');
INSERT INTO `tab_user` VALUES ('52', 'xm332418', '147117b0536ecae02cdfc600149ad52e', '4', 'daniel0857', '0', 'daniel0857', '1', '神武2', 'xm332418', '0', '', '', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470930355', '1470930355', '111.77.37.130', '111.77.37.130', '1', '0');
INSERT INTO `tab_user` VALUES ('53', '102549', '8ba9f4849c87c077e7ac3d589814e0dc', '4', 'daniel0857', '0', 'daniel0857', '1', '神武2', '102549', '0', '', '', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470930365', '1470930603', '171.115.93.135', '171.115.93.135', '1', '0');
INSERT INTO `tab_user` VALUES ('54', '15260363578', '2fa6358711dfc51df64df5ecfd12400e', '4', 'daniel0857', '0', 'daniel0857', '1', '神武2', '15260363578', '0', '', '15260363578', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470930565', '1470968730', '171.12.124.117', '171.12.124.117', '1', '0');
INSERT INTO `tab_user` VALUES ('55', '1196135202', '8189e9a2ef1bd11856b6b837f1fb1a7b', '4', 'daniel0857', '0', 'daniel0857', '1', '神武2', '1196135202', '0', '', '', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470930712', '1470939101', '117.136.94.246', '223.104.2.174', '1', '0');
INSERT INTO `tab_user` VALUES ('56', 'smw888', '96b735413a48730c47770d971c11cd26', '4', 'daniel0857', '0', 'daniel0857', '1', '神武2', 'smw888', '0', '', '', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470930725', '1470930725', '111.74.215.9', '111.74.215.4', '1', '0');
INSERT INTO `tab_user` VALUES ('57', 'qq8684253', 'f18fd5a50b60574a56ea855aa2faafa9', '4', 'daniel0857', '0', 'daniel0857', '1', '神武2', 'qq8684253', '0', '', '', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470930766', '1470930767', '183.186.136.239', '183.186.136.239', '1', '0');
INSERT INTO `tab_user` VALUES ('58', 'xxs8822', 'a6e8f472e36d1d5979509d57a03564f3', '4', 'daniel0857', '0', 'daniel0857', '1', '神武2', 'xxs8822', '0', '', '', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470930777', '1470930777', '120.85.69.181', '120.85.69.181', '1', '0');
INSERT INTO `tab_user` VALUES ('59', '141115', 'f714e22d958eb5fe42829a9c737ca0af', '4', 'daniel0857', '0', 'daniel0857', '1', '神武2', '141115', '0', '', '', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470930859', '1470930859', '218.68.71.145', '218.68.71.145', '1', '0');
INSERT INTO `tab_user` VALUES ('60', 'q11250', 'ea24b433595dd76036fe46a24daf6756', '4', 'daniel0857', '0', 'daniel0857', '1', '神武2', 'q11250', '0', '', '', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470931035', '1470931036', '218.93.206.199', '218.93.206.199', '1', '0');
INSERT INTO `tab_user` VALUES ('61', 'x2192831197', '92ea81a063b57920babb1f6c6b42e303', '4', 'daniel0857', '0', 'daniel0857', '1', '神武2', 'x2192831197', '0', '', '', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470932197', '1470932259', '36.101.77.134', '36.101.77.134', '1', '0');
INSERT INTO `tab_user` VALUES ('62', '13750584020', '432f35b209805907fed84de9a381bdb2', '4', 'daniel0857', '0', 'daniel0857', '1', '神武2', '13750584020', '0', '', '13750584020', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470932789', '1470932789', '183.52.0.194', '183.52.0.194', '1', '0');
INSERT INTO `tab_user` VALUES ('63', '8989290', '55fe61864fffe22a6ee54d35263a7796', '4', 'daniel0857', '0', 'daniel0857', '1', '神武2', '8989290', '0', '', '', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470933553', '1470933553', '220.194.71.56', '220.194.71.56', '1', '0');
INSERT INTO `tab_user` VALUES ('64', 'zyxztt', '64e177f408dcefaee8b9e3684049684f', '4', 'daniel0857', '0', 'daniel0857', '1', '神武2', 'zyxztt', '0', '', '', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470933705', '1470933730', '103.44.207.35', '113.128.89.62', '1', '0');
INSERT INTO `tab_user` VALUES ('65', '921937277', '76653d593cfc5a3f332717fb1260eb4a', '4', 'daniel0857', '0', 'daniel0857', '1', '神武2', '921937277', '0', '', '', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470934481', '1470934482', '110.167.164.10', '110.167.164.10', '1', '0');
INSERT INTO `tab_user` VALUES ('66', '18771660262', '869eeb571d786bcb65ca745bba413688', '4', 'daniel0857', '0', 'daniel0857', '1', '神武2', '18771660262', '0', '', '18771660262', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470934972', '1470934989', '113.81.145.253', '223.104.63.57', '1', '0');
INSERT INTO `tab_user` VALUES ('67', 'ys779235950', '31d7261c8ad7851920d4c04bdbf29fe9', '4', 'daniel0857', '0', 'daniel0857', '1', '神武2', 'ys779235950', '0', '', '', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470937485', '1470955779', '222.85.11.220', '222.85.11.220', '1', '0');
INSERT INTO `tab_user` VALUES ('68', '277740768', 'b74cc006f8269ebf14abf4198fac372f', '4', 'daniel0857', '0', 'daniel0857', '1', '神武2', '277740768', '0', '', '', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470938403', '1470981899', '182.124.103.95', '182.124.103.95', '1', '0');
INSERT INTO `tab_user` VALUES ('69', 'abc123', '43b54e1bfa09eb9819eb58fdeb34af69', '7', 'zlt12345', '0', 'zlt12345', '1', '神武2', 'abc123', '0', '', '', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470938972', '1470976751', '125.71.115.129', '125.71.115.129', '1', '0');
INSERT INTO `tab_user` VALUES ('70', '608493', '43b54e1bfa09eb9819eb58fdeb34af69', '7', 'zlt12345', '0', 'zlt12345', '1', '神武2', '608493', '0', '', '', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470942978', '1470944556', '125.71.115.129', '125.71.115.129', '1', '0');
INSERT INTO `tab_user` VALUES ('71', '332171', '43b54e1bfa09eb9819eb58fdeb34af69', '4', 'daniel0857', '0', 'daniel0857', '1', '神武2', '332171', '0', '', '', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470943286', '1470943286', '60.248.238.175', '60.248.238.175', '1', '0');
INSERT INTO `tab_user` VALUES ('72', '928412', '43b54e1bfa09eb9819eb58fdeb34af69', '4', 'daniel0857', '0', 'daniel0857', '1', '神武2', '928412', '0', '', '', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470943348', '1470943348', '60.248.238.175', '60.248.238.175', '1', '0');
INSERT INTO `tab_user` VALUES ('73', '650265', '43b54e1bfa09eb9819eb58fdeb34af69', '4', 'daniel0857', '0', 'daniel0857', '1', '神武2', '650265', '0', '', '', '', '', '0', '6.00', '0.00', '0', '1', '1', '1470943502', '1470943502', '60.248.238.175', '60.248.238.175', '1', '0');
INSERT INTO `tab_user` VALUES ('74', '926990', 'f714e22d958eb5fe42829a9c737ca0af', '4', 'daniel0857', '0', 'daniel0857', '1', '神武2', '926990', '0', '', '', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470943844', '1470943844', '60.248.238.175', '60.248.238.175', '1', '0');
INSERT INTO `tab_user` VALUES ('75', '236496', 'f714e22d958eb5fe42829a9c737ca0af', '4', 'daniel0857', '0', 'daniel0857', '1', '神武2', '236496', '0', '', '', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470944037', '1470944126', '60.248.238.175', '60.248.238.175', '1', '0');
INSERT INTO `tab_user` VALUES ('76', '937795', 'acaa0ebfa6448333df1d1cecffa4a418', '4', 'daniel0857', '0', 'daniel0857', '1', '神武2', '937795', '0', '', '', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470952553', '1470959065', '117.136.0.187', '223.104.38.226', '1', '0');
INSERT INTO `tab_user` VALUES ('77', '974778761', '54d0c4782d91e490b9afb1ed92c48416', '4', 'daniel0857', '0', 'daniel0857', '1', '神武2', '974778761', '0', '', '', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470954890', '1470954891', '113.105.139.213', '113.105.139.212', '1', '0');
INSERT INTO `tab_user` VALUES ('78', 'lixian1992', '610bb8f0316b1b54c6fc01ced71ab080', '4', 'daniel0857', '0', 'daniel0857', '1', '神武2', 'lixian1992', '0', '', '', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470955285', '1470986468', '1.191.46.93', '1.191.46.93', '1', '0');
INSERT INTO `tab_user` VALUES ('79', '18368889337', 'd17da0dc37f5e7aee8d4829e1ba734a2', '4', 'daniel0857', '0', 'daniel0857', '1', '神武2', '18368889337', '0', '', '18368889337', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470956536', '1470956536', '122.235.168.55', '122.235.168.55', '1', '0');
INSERT INTO `tab_user` VALUES ('80', '424022', 'fb7bea95f7823052090eae5e5a8d763e', '4', 'daniel0857', '0', 'daniel0857', '1', '神武2', '424022', '0', '', '', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470957291', '1470990931', '123.206.94.240', '123.206.94.240', '1', '0');
INSERT INTO `tab_user` VALUES ('81', 'q7745092', 'baa40f63828c0d424f07bcc5229206f0', '4', 'daniel0857', '0', 'daniel0857', '1', '神武2', 'q7745092', '0', '', '', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470958008', '1470958017', '113.228.56.194', '113.228.56.194', '1', '0');
INSERT INTO `tab_user` VALUES ('82', '18503840163', 'cd306f144fc095323df910208693af61', '4', 'daniel0857', '0', 'daniel0857', '1', '神武2', '18503840163', '0', '', '18503840163', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470958051', '1470958052', '125.41.160.15', '125.41.160.15', '1', '0');
INSERT INTO `tab_user` VALUES ('83', '369258', '47b78d9af6b97eb7ed0f55535bf4a27d', '4', 'daniel0857', '0', 'daniel0857', '1', '神武2', '369258', '0', '', '', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470958278', '1470958278', '175.2.62.1', '175.2.62.1', '1', '0');
INSERT INTO `tab_user` VALUES ('84', '123456', '43b54e1bfa09eb9819eb58fdeb34af69', '4', 'daniel0857', '0', 'daniel0857', '1', '神武2', '123456', '0', '', '', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470959191', '1470959191', '183.253.130.14', '183.253.130.14', '1', '0');
INSERT INTO `tab_user` VALUES ('85', 'qzqzqz1', 'd39a4083becb37cf5e234310cc56b739', '4', 'daniel0857', '0', 'daniel0857', '1', '神武2', 'qzqzqz1', '0', '', '', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470966766', '1470988266', '223.104.19.13', '183.245.147.126', '1', '0');
INSERT INTO `tab_user` VALUES ('146', 'alv369', 'e701749245b19f13f29753f3ae7753a3', '7', 'zlt12345', '0', 'zlt12345', '1', '神武2', 'alv369', '0', '', '', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470975389', '1470975390', '113.138.166.116', '113.138.166.116', '1', '0');
INSERT INTO `tab_user` VALUES ('86', 'liziang16', '97a7ef6d284498e8656965a2acf2e345', '4', 'daniel0857', '0', 'daniel0857', '1', '神武2', 'liziang16', '0', '', '', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470967227', '1470967227', '123.121.135.56', '123.121.135.56', '1', '0');
INSERT INTO `tab_user` VALUES ('87', 'feijihao1', '43b54e1bfa09eb9819eb58fdeb34af69', '4', 'daniel0857', '0', 'daniel0857', '1', '神武2', 'feijihao1', '0', '', '', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470967830', '1470983527', '59.41.129.50', '59.41.129.50', '1', '0');
INSERT INTO `tab_user` VALUES ('88', '991214', '005a6ddcd3ef2a9f0ab0e48db07a8989', '4', 'daniel0857', '0', 'daniel0857', '1', '神武2', '991214', '0', '', '', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470968173', '1470990602', '101.69.195.142', '101.69.195.143', '1', '0');
INSERT INTO `tab_user` VALUES ('89', '15099889223', '58e16fc8e3aa43851416aecdadc84629', '4', 'daniel0857', '0', 'daniel0857', '1', '神武2', '15099889223', '0', '', '15099889223', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470968441', '1470971658', '119.127.54.11', '119.127.54.11', '1', '0');
INSERT INTO `tab_user` VALUES ('90', 'q962056', 'a1ccfa3d6da9a5704f24a579e393aded', '4', 'daniel0857', '0', 'daniel0857', '1', '神武2', 'q962056', '0', '', '', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470968700', '1470985582', '222.90.70.82', '124.114.123.174', '1', '0');
INSERT INTO `tab_user` VALUES ('91', 'qwerqq', '39911438e70353fcd2f8585c763bf577', '4', 'daniel0857', '0', 'daniel0857', '1', '神武2', 'qwerqq', '0', '', '', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470968701', '1470968701', '42.84.71.123', '42.84.71.123', '1', '0');
INSERT INTO `tab_user` VALUES ('92', '130456', '01c53b1d9bc2392a7632e61230b5f6e1', '4', 'daniel0857', '0', 'daniel0857', '1', '神武2', '130456', '0', '', '', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470968783', '1470974555', '117.38.155.212', '117.38.155.212', '1', '0');
INSERT INTO `tab_user` VALUES ('93', '397385', 'f714e22d958eb5fe42829a9c737ca0af', '3', 'test1234', '0', 'test1234', '1', '神武2BT', '397385', '0', '', '', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470968814', '1470968814', '218.19.138.137', '218.19.138.137', '1', '0');
INSERT INTO `tab_user` VALUES ('94', '237815', 'f714e22d958eb5fe42829a9c737ca0af', '0', '自然注册', '0', '', '12', '决战中洲', '237815', '0', '', '', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470968845', '1470969315', '153.36.68.155', '153.36.68.155', '1', '0');
INSERT INTO `tab_user` VALUES ('95', '1933951700', '20b2cd367213906c0141463d2ff49cf1', '4', 'daniel0857', '0', 'daniel0857', '1', '神武2', '1933951700', '0', '', '', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470968890', '1470968890', '125.70.80.38', '125.70.80.38', '1', '0');
INSERT INTO `tab_user` VALUES ('96', 'wq930411', '669f1108b55875ee6859e6b8a47eae51', '4', 'daniel0857', '0', 'daniel0857', '1', '神武2', 'wq930411', '0', '', '', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470969141', '1470969141', '42.48.104.66', '42.48.104.66', '1', '0');
INSERT INTO `tab_user` VALUES ('97', 'motion', '4b999baaabe5457d9f335230e44a7c6d', '4', 'daniel0857', '0', 'daniel0857', '1', '神武2', 'motion', '0', '', '', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470969146', '1470976776', '113.71.248.39', '113.71.248.39', '1', '0');
INSERT INTO `tab_user` VALUES ('98', '821541', '8b30be6161cfab3fe30b5e0006f79a0f', '4', 'daniel0857', '0', 'daniel0857', '1', '神武2', '821541', '0', '', '', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470969147', '1470976696', '112.97.61.200', '112.97.61.200', '1', '0');
INSERT INTO `tab_user` VALUES ('99', '1173580004', 'd08c203363d7b6c85bac18ade83282aa', '4', 'daniel0857', '0', 'daniel0857', '1', '神武2', '1173580004', '0', '', '', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470969300', '1470982623', '112.240.97.162', '112.240.97.162', '1', '0');
INSERT INTO `tab_user` VALUES ('100', 'zhixi5436', 'ffa238c242954bd21488bf8ead680c22', '4', 'daniel0857', '0', 'daniel0857', '1', '神武2', 'zhixi5436', '0', '', '', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470969679', '1470969679', '124.72.181.162', '124.72.181.162', '1', '0');
INSERT INTO `tab_user` VALUES ('101', '117078124', '53851753112ea977379b799256538a0f', '4', 'daniel0857', '0', 'daniel0857', '1', '神武2', '117078124', '0', '', '', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470969916', '1470969986', '61.161.170.230', '61.161.170.230', '1', '0');
INSERT INTO `tab_user` VALUES ('102', 'qq532371388', '59057b842446ec2ea2b93018341b7ff5', '4', 'daniel0857', '0', 'daniel0857', '1', '神武2', 'qq532371388', '0', '', '', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470970064', '1470973234', '36.62.215.8', '36.62.215.8', '1', '0');
INSERT INTO `tab_user` VALUES ('103', 'lifuchun100', '32b39785c0596501a7bf28778ec39047', '4', 'daniel0857', '0', 'daniel0857', '1', '神武2', 'lifuchun100', '0', '', '', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470970095', '1470970095', '27.9.106.232', '27.9.106.232', '1', '0');
INSERT INTO `tab_user` VALUES ('104', '791455', 'f714e22d958eb5fe42829a9c737ca0af', '0', '自然注册', '0', '', '12', '决战中洲', '791455', '0', '', '', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470970326', '1470970326', '153.36.68.155', '153.36.68.155', '1', '0');
INSERT INTO `tab_user` VALUES ('105', 'qwe415263', '43b54e1bfa09eb9819eb58fdeb34af69', '4', 'daniel0857', '0', 'daniel0857', '1', '神武2', 'qwe415263', '0', '', '', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470970368', '1470970369', '182.244.94.115', '182.244.94.115', '1', '0');
INSERT INTO `tab_user` VALUES ('106', '618693', 'f714e22d958eb5fe42829a9c737ca0af', '0', '自然注册', '0', '', '12', '决战中洲', '618693', '0', '', '', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470970462', '1470970708', '153.36.68.155', '153.36.68.155', '1', '0');
INSERT INTO `tab_user` VALUES ('107', '18634801194', '0f794d871006c655787c2a8461a4ded7', '4', 'daniel0857', '0', 'daniel0857', '1', '神武2', '18634801194', '0', '', '18634801194', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470970503', '1470970503', '123.174.209.81', '123.174.209.81', '1', '0');
INSERT INTO `tab_user` VALUES ('108', '18206220940', '8ff440a9f1eb7397423c351bb815f37e', '4', 'daniel0857', '0', 'daniel0857', '1', '神武2', '18206220940', '0', '', '18206220940', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470970507', '1470970507', '49.72.152.70', '49.72.152.70', '1', '0');
INSERT INTO `tab_user` VALUES ('109', '18237396228', 'fb7bea95f7823052090eae5e5a8d763e', '4', 'daniel0857', '0', 'daniel0857', '1', '神武2', '18237396228', '0', '', '18237396228', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470970550', '1470997774', '115.62.244.45', '115.62.241.10', '1', '0');
INSERT INTO `tab_user` VALUES ('110', '136255', '06bd8ea95351b53abc1c7b2eae7d05ef', '4', 'daniel0857', '0', 'daniel0857', '1', '神武2', '136255', '0', '', '', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470970624', '1470970625', '223.104.13.54', '223.104.13.54', '1', '0');
INSERT INTO `tab_user` VALUES ('111', '621943', 'f714e22d958eb5fe42829a9c737ca0af', '0', '自然注册', '0', '', '12', '决战中洲', '621943', '0', '', '', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470970815', '1470970815', '153.36.68.155', '153.36.68.155', '1', '0');
INSERT INTO `tab_user` VALUES ('112', '700647', 'f714e22d958eb5fe42829a9c737ca0af', '0', '自然注册', '0', '', '12', '决战中洲', '700647', '0', '', '', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470970891', '1470970933', '153.36.68.155', '153.36.68.155', '1', '0');
INSERT INTO `tab_user` VALUES ('113', 'lxy1350', '8c02417f90df6d383cd242d731496e77', '7', 'zlt12345', '0', 'zlt12345', '1', '神武2', 'lxy1350', '0', '', '', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470971073', '1470972034', '223.104.20.200', '223.104.20.200', '1', '0');
INSERT INTO `tab_user` VALUES ('114', '224912', 'f714e22d958eb5fe42829a9c737ca0af', '0', '自然注册', '0', '', '12', '决战中洲', '224912', '0', '', '', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470971363', '1470971363', '153.36.68.155', '153.36.68.155', '1', '0');
INSERT INTO `tab_user` VALUES ('115', '15016205992', '961402e1ca131f76bb35aae41d8ee834', '4', 'daniel0857', '0', 'daniel0857', '1', '神武2', '15016205992', '0', '', '15016205992', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470972146', '1470976610', '103.44.207.39', '121.12.126.249', '1', '0');
INSERT INTO `tab_user` VALUES ('116', '125729', 'ea24b433595dd76036fe46a24daf6756', '7', 'zlt12345', '0', 'zlt12345', '1', '神武2', '125729', '0', '', '', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470972282', '1470972282', '27.210.219.209', '27.210.219.209', '1', '0');
INSERT INTO `tab_user` VALUES ('117', 'wxainngg', '7ec84390055f9e6e84373daa165064f5', '7', 'zlt12345', '0', 'zlt12345', '1', '神武2', 'wxainngg', '0', '', '', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470972317', '1470972317', '122.236.48.12', '122.236.48.12', '1', '0');
INSERT INTO `tab_user` VALUES ('118', '744221', '17be59bcc2a7502f7ace990a4fa00bd4', '7', 'zlt12345', '0', 'zlt12345', '1', '神武2', '744221', '0', '', '', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470972472', '1470972472', '223.104.20.200', '223.104.20.200', '1', '0');
INSERT INTO `tab_user` VALUES ('119', '860830', '4acff40ab5970ac732e299cff4828913', '7', 'zlt12345', '0', 'zlt12345', '1', '神武2', '860830', '0', '', '', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470972477', '1470972477', '223.146.89.219', '223.146.89.219', '1', '0');
INSERT INTO `tab_user` VALUES ('120', '646342', '66c2f4a4cf0b56d2de589d729ef744b6', '4', 'daniel0857', '0', 'daniel0857', '1', '神武2', '646342', '0', '', '', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470972590', '1470997639', '110.82.75.178', '110.82.75.178', '1', '0');
INSERT INTO `tab_user` VALUES ('121', '15201669177', 'a873b3f5c027b467ad3783e98b30383f', '7', 'zlt12345', '0', 'zlt12345', '1', '神武2', '15201669177', '0', '', '15201669177', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470972941', '1470994415', '117.136.0.248', '117.136.0.107', '1', '0');
INSERT INTO `tab_user` VALUES ('122', 'lxf1230', '22d39aedb56834b2caa341a866a4434e', '7', 'zlt12345', '0', 'zlt12345', '1', '神武2', 'lxf1230', '0', '', '', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470973003', '1470998429', '123.7.77.60', '117.136.61.52', '1', '0');
INSERT INTO `tab_user` VALUES ('123', 'novoetoe', 'ca6160d11a5a8cda8c80bd9730d85156', '7', 'zlt12345', '0', 'zlt12345', '1', '神武2', 'novoetoe', '0', '', '', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470973065', '1470975785', '110.228.254.74', '60.0.113.198', '1', '0');
INSERT INTO `tab_user` VALUES ('124', '3235028918', '0c9c52a03effeed105c48770376a0246', '7', 'zlt12345', '0', 'zlt12345', '1', '神武2', '3235028918', '0', '', '', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470973078', '1470973079', '221.196.165.121', '221.196.165.121', '1', '0');
INSERT INTO `tab_user` VALUES ('125', 'xzl123', '43b54e1bfa09eb9819eb58fdeb34af69', '7', 'zlt12345', '0', 'zlt12345', '1', '神武2', 'xzl123', '0', '', '', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470973214', '1470994768', '1.198.177.200', '1.198.177.200', '1', '0');
INSERT INTO `tab_user` VALUES ('126', 'a634788', '70b2fa4ce41b04686f321a61d4a3f1e7', '7', 'zlt12345', '0', 'zlt12345', '1', '神武2', 'a634788', '0', '', '', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470973410', '1470994399', '60.181.150.62', '60.181.150.62', '1', '0');
INSERT INTO `tab_user` VALUES ('127', '537308', 'f714e22d958eb5fe42829a9c737ca0af', '0', '自然注册', '0', '', '12', '决战中洲', '537308', '0', '', '', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470973416', '1470973417', '153.36.68.155', '153.36.68.155', '1', '0');
INSERT INTO `tab_user` VALUES ('128', '149999', '59057b842446ec2ea2b93018341b7ff5', '4', 'daniel0857', '0', 'daniel0857', '1', '神武2', '149999', '0', '', '', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470973452', '1470981848', '36.62.215.8', '36.62.215.8', '1', '0');
INSERT INTO `tab_user` VALUES ('129', 'wjx0503', '43b54e1bfa09eb9819eb58fdeb34af69', '7', 'zlt12345', '0', 'zlt12345', '1', '神武2', 'wjx0503', '0', '', '', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470973662', '1470973662', '106.43.195.157', '106.43.195.157', '1', '0');
INSERT INTO `tab_user` VALUES ('130', 'xing0188', '4f384af1893f848da912f7ec616656b7', '4', 'daniel0857', '0', 'daniel0857', '1', '神武2', 'xing0188', '0', '', '', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470973979', '1470995225', '27.186.208.2', '27.186.208.2', '1', '0');
INSERT INTO `tab_user` VALUES ('131', '976217', 'f714e22d958eb5fe42829a9c737ca0af', '0', '自然注册', '0', '', '12', '决战中洲', '976217', '0', '', '', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470974092', '1470974092', '153.36.68.155', '153.36.68.155', '1', '0');
INSERT INTO `tab_user` VALUES ('132', 'zn2615', '9d47d1985b21c2bd3d529a60986d8990', '7', 'zlt12345', '0', 'zlt12345', '1', '神武2', 'zn2615', '0', '', '', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470974188', '1470974189', '61.153.156.62', '61.153.156.62', '1', '0');
INSERT INTO `tab_user` VALUES ('133', '444807', '48d6be23cc56ef83b12b014e977e29eb', '7', 'zlt12345', '0', 'zlt12345', '1', '神武2', '444807', '0', '', '', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470974217', '1470974218', '1.181.190.12', '1.181.190.12', '1', '0');
INSERT INTO `tab_user` VALUES ('134', '443354', '9e35bdc793eda8b43d9006ec215e8020', '0', '自然注册', '0', '', '12', '决战中洲', '443354', '0', '', '', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470974316', '1470974358', '153.36.68.155', '153.36.68.155', '1', '0');
INSERT INTO `tab_user` VALUES ('135', 'whdonkey', 'e25ba7027337524b10fe7cf001c68667', '7', 'zlt12345', '0', 'zlt12345', '1', '神武2', 'whdonkey', '0', '', '', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470974380', '1470974381', '114.224.59.129', '114.224.59.129', '1', '0');
INSERT INTO `tab_user` VALUES ('136', 'mzhyy888', '3ce573b50dbfc92cc01cbae00b884a76', '7', 'zlt12345', '0', 'zlt12345', '1', '神武2', 'mzhyy888', '0', '', '', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470974454', '1470974454', '58.52.29.74', '58.52.29.74', '1', '0');
INSERT INTO `tab_user` VALUES ('137', 'a857248868', '43b54e1bfa09eb9819eb58fdeb34af69', '7', 'zlt12345', '0', 'zlt12345', '1', '神武2', 'a857248868', '0', '', '', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470974732', '1470987232', '117.136.4.177', '117.136.4.177', '1', '0');
INSERT INTO `tab_user` VALUES ('138', '527764', 'be599818cd98dad0da310947d5c27d37', '7', 'zlt12345', '0', 'zlt12345', '1', '神武2', '527764', '0', '', '', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470974786', '1470978214', '211.150.88.46', '117.136.0.252', '1', '0');
INSERT INTO `tab_user` VALUES ('139', 'wolfkill', '43b54e1bfa09eb9819eb58fdeb34af69', '7', 'zlt12345', '0', 'zlt12345', '1', '神武2', 'wolfkill', '0', '', '', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470974790', '1470974790', '113.76.154.148', '113.76.154.148', '1', '0');
INSERT INTO `tab_user` VALUES ('140', '7484372', '0a76a8d9b1c31bf60597864aec85f744', '7', 'zlt12345', '0', 'zlt12345', '1', '神武2', '7484372', '0', '', '', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470974822', '1470974822', '14.215.54.36', '14.215.54.36', '1', '0');
INSERT INTO `tab_user` VALUES ('141', '15864110597', 'b0fbad09258c96090be271db587ad2a3', '7', 'zlt12345', '0', 'zlt12345', '1', '神武2', '15864110597', '0', '', '15864110597', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470974922', '1470976707', '27.39.225.166', '27.39.225.166', '1', '0');
INSERT INTO `tab_user` VALUES ('142', '428666', '43b54e1bfa09eb9819eb58fdeb34af69', '7', 'zlt12345', '0', 'zlt12345', '1', '神武2', '428666', '0', '', '', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470974945', '1470974945', '183.54.160.150', '183.54.160.150', '1', '0');
INSERT INTO `tab_user` VALUES ('143', '18325505542', 'f33d482690f2ca215f77fd93302a8984', '4', 'daniel0857', '0', 'daniel0857', '1', '神武2', '18325505542', '0', '', '18325505542', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470975018', '1470975018', '114.103.216.149', '114.103.216.149', '1', '0');
INSERT INTO `tab_user` VALUES ('144', 'QQ3075261534', '5e4e8701012871a054910db91d4a753a', '7', 'zlt12345', '0', 'zlt12345', '1', '神武2', 'QQ3075261534', '0', '', '', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470975063', '1470975064', '218.16.170.26', '218.16.170.26', '1', '0');
INSERT INTO `tab_user` VALUES ('145', 'wxy520', '39911438e70353fcd2f8585c763bf577', '7', 'zlt12345', '0', 'zlt12345', '1', '神武2', 'wxy520', '0', '', '', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470975196', '1470975196', '122.139.100.248', '122.139.100.248', '1', '0');
INSERT INTO `tab_user` VALUES ('147', 'q135345', '43b54e1bfa09eb9819eb58fdeb34af69', '4', 'daniel0857', '0', 'daniel0857', '1', '神武2', 'q135345', '0', '', '', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470975436', '1470975436', '219.130.239.40', '219.130.239.40', '1', '0');
INSERT INTO `tab_user` VALUES ('148', '798733', 'a267e3f3686f284742b09a8112227c65', '4', 'daniel0857', '0', 'daniel0857', '1', '神武2', '798733', '0', '', '', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470975740', '', '42.81.43.6', '', '1', '0');
INSERT INTO `tab_user` VALUES ('149', '15156589827', 'a267e3f3686f284742b09a8112227c65', '4', 'daniel0857', '0', 'daniel0857', '1', '神武2', '15156589827', '0', '', '', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470975890', '1470987273', '223.104.18.65', '223.104.18.65', '1', '0');
INSERT INTO `tab_user` VALUES ('150', '847421822', '55fe61864fffe22a6ee54d35263a7796', '7', 'zlt12345', '0', 'zlt12345', '1', '神武2', '847421822', '0', '', '', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470975922', '1470976026', '219.137.118.217', '219.137.118.217', '1', '0');
INSERT INTO `tab_user` VALUES ('151', '500146', '078b76251db81ecf20d129099368ca1c', '7', 'zlt12345', '0', 'zlt12345', '1', '神武2', '500146', '0', '', '', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470975994', '1470975994', '183.46.224.158', '183.46.224.158', '1', '0');
INSERT INTO `tab_user` VALUES ('152', '13533664553', '43b54e1bfa09eb9819eb58fdeb34af69', '7', 'zlt12345', '0', 'zlt12345', '1', '神武2', '13533664553', '0', '', '13533664553', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470976005', '1470976005', '58.62.37.168', '58.62.37.168', '1', '0');
INSERT INTO `tab_user` VALUES ('153', 'kang01', '43b54e1bfa09eb9819eb58fdeb34af69', '4', 'daniel0857', '0', 'daniel0857', '1', '神武2', 'kang01', '0', '', '', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470976079', '1470976079', '218.56.104.114', '218.56.104.114', '1', '0');
INSERT INTO `tab_user` VALUES ('154', 'likulili', 'e69e1911bce47da4b937a8a3a850ff3d', '7', 'zlt12345', '0', 'zlt12345', '1', '神武2', 'likulili', '0', '', '', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470976134', '1470976134', '58.22.113.103', '58.22.113.103', '1', '0');
INSERT INTO `tab_user` VALUES ('155', '826499', '9f3d451adae73142947998bceb11b9b9', '7', 'zlt12345', '0', 'zlt12345', '1', '神武2', '826499', '0', '', '', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470976166', '1470976167', '123.161.99.162', '123.161.99.162', '1', '0');
INSERT INTO `tab_user` VALUES ('156', '13912806950', 'ccfcac5a12debe05f4160611589840dd', '7', 'zlt12345', '0', 'zlt12345', '1', '神武2', '13912806950', '0', '', '', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470976783', '1470976917', '180.118.199.149', '180.118.199.149', '1', '0');
INSERT INTO `tab_user` VALUES ('157', 'alex317', '43b54e1bfa09eb9819eb58fdeb34af69', '7', 'zlt12345', '0', 'zlt12345', '1', '神武2', 'alex317', '0', '', '', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470976923', '1470976923', '125.66.15.197', '125.66.15.197', '1', '0');
INSERT INTO `tab_user` VALUES ('158', 'cxxcxx', '37ee335a2c7d44fa5ba1818286688c96', '7', 'zlt12345', '0', 'zlt12345', '1', '神武2', 'cxxcxx', '0', '', '', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470977123', '1470978381', '61.153.44.110', '61.153.44.110', '1', '0');
INSERT INTO `tab_user` VALUES ('159', '874064170', '91c6821822259f873ee284f06d56baa2', '7', 'zlt12345', '0', 'zlt12345', '1', '神武2', '874064170', '0', '', '', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470977271', '1470977324', '42.236.140.55', '42.236.140.55', '1', '0');
INSERT INTO `tab_user` VALUES ('160', '18873835270', '9b7ea448742e119aeb2e6459fa4b5ab7', '7', 'zlt12345', '0', 'zlt12345', '1', '神武2', '18873835270', '0', '', '18873835270', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470977307', '1470977378', '59.34.43.20', '59.34.43.20', '1', '0');
INSERT INTO `tab_user` VALUES ('161', 'zzz123456', '43b54e1bfa09eb9819eb58fdeb34af69', '7', 'zlt12345', '0', 'zlt12345', '1', '神武2', 'zzz123456', '0', '', '', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470977471', '1470983485', '115.62.221.241', '223.104.19.82', '1', '0');
INSERT INTO `tab_user` VALUES ('162', '13730199076', 'd46bb037e93ab4b83bee3efc8f8d2718', '7', 'zlt12345', '0', 'zlt12345', '1', '神武2', '13730199076', '0', '', '13730199076', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470977479', '1470987350', '180.213.177.87', '180.213.177.87', '1', '0');
INSERT INTO `tab_user` VALUES ('163', 'a154477', '7e0100e72b566beb92ff611a773db7dc', '4', 'daniel0857', '0', 'daniel0857', '1', '神武2', 'a154477', '0', '', '', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470977564', '1470994638', '42.227.88.106', '211.142.189.65', '1', '0');
INSERT INTO `tab_user` VALUES ('164', 'a475285220', '0b1976f04a380e810015ea880aec968a', '7', 'zlt12345', '0', 'zlt12345', '1', '神武2', 'a475285220', '0', '', '', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470977710', '1470977971', '36.249.225.109', '36.249.225.109', '1', '0');
INSERT INTO `tab_user` VALUES ('165', 'zzz123456789', 'bb5903ef6b4cdc708c892beae30dc64d', '4', 'daniel0857', '0', 'daniel0857', '1', '神武2', 'zzz123456789', '0', '', '', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470977730', '1470977730', '113.79.232.42', '113.79.232.42', '1', '0');
INSERT INTO `tab_user` VALUES ('166', '643074', '43b54e1bfa09eb9819eb58fdeb34af69', '4', 'daniel0857', '0', 'daniel0857', '1', '神武2', '643074', '0', '', '', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470977882', '1470977883', '113.235.217.172', '113.235.217.172', '1', '0');
INSERT INTO `tab_user` VALUES ('167', '18504842291', '66c20939c7ecef43f8ae8fb9ed02dcfb', '7', 'zlt12345', '0', 'zlt12345', '1', '神武2', '18504842291', '0', '', '18504842291', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470977926', '1470980460', '116.115.77.217', '116.115.77.217', '1', '0');
INSERT INTO `tab_user` VALUES ('168', '342411', 'e0a3978a65a43a685e3ba056ba1dd4ca', '7', 'zlt12345', '0', 'zlt12345', '1', '神武2', '342411', '0', '', '', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470978071', '1470980924', '114.221.181.84', '180.110.229.32', '1', '0');
INSERT INTO `tab_user` VALUES ('169', 'meng6532745', 'a54941fc149eae78aea7e8a5425734e7', '4', 'daniel0857', '0', 'daniel0857', '1', '神武2', 'meng6532745', '0', '', '', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470978106', '1470988083', '125.77.45.157', '125.77.45.157', '1', '0');
INSERT INTO `tab_user` VALUES ('170', 'liu3653953', '1777473e7685326e363b3c08d3d840f7', '4', 'daniel0857', '0', 'daniel0857', '1', '神武2', 'liu3653953', '0', '', '', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470978211', '1470978211', '42.224.229.86', '42.224.229.86', '1', '0');
INSERT INTO `tab_user` VALUES ('171', '649861', '36845ee91a0ebc02d6645ead5cdd2539', '4', 'daniel0857', '0', 'daniel0857', '1', '神武2', '649861', '0', '', '', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470978459', '1470978459', '106.114.146.253', '106.114.146.253', '1', '0');
INSERT INTO `tab_user` VALUES ('172', 'hang02122015', '01114707aca97a61bdc6ac1c47558feb', '7', 'zlt12345', '0', 'zlt12345', '1', '神武2', 'hang02122015', '0', '', '', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470978650', '1470982008', '124.163.246.203', '124.163.246.203', '1', '0');
INSERT INTO `tab_user` VALUES ('173', '1049668470', 'b865adc256a2e6f3d519129adfbcaedc', '4', 'daniel0857', '0', 'daniel0857', '1', '神武2', '1049668470', '0', '', '', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470978664', '1470997627', '222.209.151.181', '222.209.151.181', '1', '0');
INSERT INTO `tab_user` VALUES ('174', 'bnhjkl2016', '222dd0f5a152b5e0f521035d91b10917', '4', 'daniel0857', '0', 'daniel0857', '1', '神武2', 'bnhjkl2016', '0', '', '', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470978912', '1470978942', '113.128.114.18', '103.44.207.33', '1', '0');
INSERT INTO `tab_user` VALUES ('175', 'aa8549', '43b54e1bfa09eb9819eb58fdeb34af69', '7', 'zlt12345', '0', 'zlt12345', '1', '神武2', 'aa8549', '0', '', '', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470979313', '1470991998', '115.62.221.241', '115.62.221.241', '1', '0');
INSERT INTO `tab_user` VALUES ('176', '345345', '1e42e1b586e1e2756680c2e579378a99', '7', 'zlt12345', '0', 'zlt12345', '1', '神武2', '345345', '0', '', '', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470979344', '1470979344', '60.221.133.203', '60.221.133.203', '1', '0');
INSERT INTO `tab_user` VALUES ('177', '8629131jun', '77989db1c2105e49bf427c9716dfa820', '4', 'daniel0857', '0', 'daniel0857', '1', '神武2', '8629131jun', '0', '', '', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470979852', '1470980016', '125.90.85.0', '125.90.85.0', '1', '0');
INSERT INTO `tab_user` VALUES ('178', 'lty123', '43b54e1bfa09eb9819eb58fdeb34af69', '4', 'daniel0857', '0', 'daniel0857', '1', '神武2', 'lty123', '0', '', '', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470979982', '1470986383', '58.250.117.211', '58.250.117.211', '1', '0');
INSERT INTO `tab_user` VALUES ('179', '368990', 'f714e22d958eb5fe42829a9c737ca0af', '0', '自然注册', '0', '', '12', '决战中洲', '368990', '0', '', '', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470980337', '1470980337', '153.36.68.155', '153.36.68.155', '1', '0');
INSERT INTO `tab_user` VALUES ('180', '777888', 'f714e22d958eb5fe42829a9c737ca0af', '0', '自然注册', '0', '', '12', '决战中洲', '777888', '0', '', '', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470980353', '1470998333', '153.36.68.155', '153.36.68.155', '1', '0');
INSERT INTO `tab_user` VALUES ('181', 'mao5524', '646bd15ecafaa169455fbebf631316f8', '7', 'zlt12345', '0', 'zlt12345', '1', '神武2', 'mao5524', '0', '', '', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470980906', '1470980906', '58.222.216.98', '58.222.216.98', '1', '0');
INSERT INTO `tab_user` VALUES ('182', '1440886144', 'b0c1eb201a46767a55e86302d665550d', '4', 'daniel0857', '0', 'daniel0857', '1', '神武2', '1440886144', '0', '', '', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470981042', '1470981042', '36.5.37.131', '36.5.37.131', '1', '0');
INSERT INTO `tab_user` VALUES ('183', '761207', 'f714e22d958eb5fe42829a9c737ca0af', '0', '自然注册', '0', '', '12', '决战中洲', '761207', '0', '', '', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470981549', '1470981630', '153.36.68.155', '153.36.68.155', '1', '0');
INSERT INTO `tab_user` VALUES ('184', '123456ok', '43b54e1bfa09eb9819eb58fdeb34af69', '4', 'daniel0857', '0', 'daniel0857', '1', '神武2', '123456ok', '0', '', '', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470981555', '1470981555', '117.10.0.98', '117.10.0.98', '1', '0');
INSERT INTO `tab_user` VALUES ('185', '787083', '8d81c961723692a10c9a266172eee5f6', '4', 'daniel0857', '0', 'daniel0857', '1', '神武2', '787083', '0', '', '', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470981831', '1470981857', '59.63.166.141', '61.158.152.197', '1', '0');
INSERT INTO `tab_user` VALUES ('186', 'lzl0227', '55fe61864fffe22a6ee54d35263a7796', '4', 'daniel0857', '0', 'daniel0857', '1', '神武2', 'lzl0227', '0', '', '', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470981896', '1470981896', '125.39.51.250', '125.39.51.250', '1', '0');
INSERT INTO `tab_user` VALUES ('187', '285023', 'abbde285fcdc384aee855e44610058cf', '7', 'zlt12345', '0', 'zlt12345', '1', '神武2', '285023', '0', '', '', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470981994', '1470981995', '61.139.239.227', '61.139.239.227', '1', '0');
INSERT INTO `tab_user` VALUES ('188', 'xiaoquan', '2893d934042701e304b0b5d8a3c13dd4', '7', 'zlt12345', '0', 'zlt12345', '1', '神武2', 'xiaoquan', '0', '', '', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470981995', '1470981995', '116.115.190.218', '116.115.190.218', '1', '0');
INSERT INTO `tab_user` VALUES ('189', 'ko5211314', '4cb876e13cce7e2c19eaca1c8e606fcd', '7', 'zlt12345', '0', 'zlt12345', '1', '神武2', 'ko5211314', '0', '', '', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470982469', '1470982469', '116.216.18.6', '116.216.18.6', '1', '0');
INSERT INTO `tab_user` VALUES ('190', '510409', '43b54e1bfa09eb9819eb58fdeb34af69', '4', 'daniel0857', '0', 'daniel0857', '1', '神武2', '510409', '0', '', '', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470982520', '1470982521', '117.40.228.7', '117.40.228.7', '1', '0');
INSERT INTO `tab_user` VALUES ('191', '18920423096', '8e0751c25a89c45b4d94a741b498ae81', '7', 'zlt12345', '0', 'zlt12345', '1', '神武2', '18920423096', '0', '', '18920423096', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470982773', '1470982773', '106.121.5.200', '106.121.5.200', '1', '0');
INSERT INTO `tab_user` VALUES ('192', '388866', 'f714e22d958eb5fe42829a9c737ca0af', '0', '自然注册', '0', '', '12', '决战中洲', '388866', '0', '', '', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470982927', '1470983575', '153.36.68.155', '153.36.68.155', '1', '0');
INSERT INTO `tab_user` VALUES ('193', 'kangdong84', 'f3e01c4f59b76fa26223a37de1c60ea8', '4', 'daniel0857', '0', 'daniel0857', '1', '神武2', 'kangdong84', '0', '', '', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470983290', '1470993836', '106.114.23.101', '106.114.23.101', '1', '0');
INSERT INTO `tab_user` VALUES ('194', '2738436711', 'c441fa094dff756e773e1b638be853ab', '7', 'zlt12345', '0', 'zlt12345', '1', '神武2', '2738436711', '0', '', '', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470983397', '1470984066', '171.121.165.48', '171.121.165.48', '1', '0');
INSERT INTO `tab_user` VALUES ('195', '609398', 'f76f81d9adbc20ccaab4b84d793b2be7', '7', 'zlt12345', '0', 'zlt12345', '1', '神武2', '609398', '0', '', '', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470983621', '1470983879', '218.82.195.71', '218.82.195.71', '1', '0');
INSERT INTO `tab_user` VALUES ('196', '13002096204', '55fe61864fffe22a6ee54d35263a7796', '7', 'zlt12345', '0', 'zlt12345', '1', '神武2', '13002096204', '0', '', '13002096204', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470983671', '1470983671', '112.5.71.61', '112.5.71.61', '1', '0');
INSERT INTO `tab_user` VALUES ('197', '838725', 'f714e22d958eb5fe42829a9c737ca0af', '0', '自然注册', '0', '', '12', '决战中洲', '838725', '0', '', '', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470983690', '1470983690', '153.36.68.155', '153.36.68.155', '1', '0');
INSERT INTO `tab_user` VALUES ('198', 'a6164282a', '7646771960d3c83c1214b5a8ed660fba', '7', 'zlt12345', '0', 'zlt12345', '1', '神武2', 'a6164282a', '0', '', '', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470983781', '1470983782', '106.226.12.51', '106.226.12.51', '1', '0');
INSERT INTO `tab_user` VALUES ('199', '789390', 'f714e22d958eb5fe42829a9c737ca0af', '0', '自然注册', '0', '', '12', '决战中洲', '789390', '0', '', '', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470983862', '1470984067', '153.36.68.155', '153.36.68.155', '1', '0');
INSERT INTO `tab_user` VALUES ('200', '18121728357', 'a379df3bc3cb57aaf061b3bf3e722cb7', '7', 'zlt12345', '0', 'zlt12345', '1', '神武2', '18121728357', '0', '', '18121728357', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470984205', '1470984205', '49.95.206.184', '49.95.206.184', '1', '0');
INSERT INTO `tab_user` VALUES ('201', 'a07088', 'e681cda3530070948f30f13683e7b38a', '7', 'zlt12345', '0', 'zlt12345', '1', '神武2', 'a07088', '0', '', '', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470984421', '1470984422', '1.82.205.155', '1.82.205.155', '1', '0');
INSERT INTO `tab_user` VALUES ('202', '1247682966', '056e977eca56b5872e73ce4c0b94d1d6', '7', 'zlt12345', '0', 'zlt12345', '1', '神武2', '1247682966', '0', '', '', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470984671', '1470984753', '183.162.46.137', '183.162.46.137', '1', '0');
INSERT INTO `tab_user` VALUES ('203', 'ak9584', 'be4a620da52557d8d74b01db1ee38fd8', '4', 'daniel0857', '0', 'daniel0857', '1', '神武2', 'ak9584', '0', '', '', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470984960', '1470988337', '61.185.133.2', '221.11.61.62', '1', '0');
INSERT INTO `tab_user` VALUES ('204', '271311', '360b11f893cf54d96078463c7e240a11', '7', 'zlt12345', '0', 'zlt12345', '1', '神武2', '271311', '0', '', '', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470984963', '1470984963', '113.84.179.199', '113.84.179.199', '1', '0');
INSERT INTO `tab_user` VALUES ('205', '409059', 'fb7bea95f7823052090eae5e5a8d763e', '4', 'daniel0857', '0', 'daniel0857', '1', '神武2', '409059', '0', '', '', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470985285', '1470985285', '112.192.17.172', '112.192.17.172', '1', '0');
INSERT INTO `tab_user` VALUES ('206', '111383', '1502483c63ec810f175e4c945fad0f4d', '7', 'zlt12345', '0', 'zlt12345', '1', '神武2', '111383', '0', '', '', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470985389', '1470985390', '125.39.51.241', '125.39.51.241', '1', '0');
INSERT INTO `tab_user` VALUES ('207', '448402', 'c70e07b55525091b66cf7e2f032f8b01', '4', 'daniel0857', '0', 'daniel0857', '1', '神武2', '448402', '0', '', '', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470985526', '1470985543', '117.136.69.39', '117.136.69.39', '1', '0');
INSERT INTO `tab_user` VALUES ('208', 'A295334930', '698520c0f946da27eb61a0bcedcfd3b5', '7', 'zlt12345', '0', 'zlt12345', '1', '神武2', 'A295334930', '0', '', '', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470985971', '1470985972', '221.207.37.57', '221.207.37.57', '1', '0');
INSERT INTO `tab_user` VALUES ('209', 'qweasdcdc', 'a57f0e607a25375869fd68467399f2c7', '4', 'daniel0857', '0', 'daniel0857', '1', '神武2', 'qweasdcdc', '0', '', '', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470986031', '1470986031', '113.92.74.88', '113.92.74.88', '1', '0');
INSERT INTO `tab_user` VALUES ('210', 'lty1234', '43b54e1bfa09eb9819eb58fdeb34af69', '4', 'daniel0857', '0', 'daniel0857', '1', '神武2', 'lty1234', '0', '', '', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470986206', '1470986206', '58.250.117.211', '58.250.117.211', '1', '0');
INSERT INTO `tab_user` VALUES ('211', 'kongde0', '21cff016ab98dada3443e8881a14838e', '4', 'daniel0857', '0', 'daniel0857', '1', '神武2', 'kongde0', '0', '', '', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470986211', '1470989957', '27.12.98.38', '27.12.98.38', '1', '0');
INSERT INTO `tab_user` VALUES ('212', '664775410', 'bfd5d806725ba9d420c9c98019b67f41', '4', 'daniel0857', '0', 'daniel0857', '1', '神武2', '664775410', '0', '', '', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470986294', '1470986294', '125.33.169.25', '125.33.169.25', '1', '0');
INSERT INTO `tab_user` VALUES ('213', 'qq532698553', '9a1d710a1db13a61bcee77f28a50552e', '4', 'daniel0857', '0', 'daniel0857', '1', '神武2', 'qq532698553', '0', '', '', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470986468', '1470986469', '171.83.100.64', '171.83.100.64', '1', '0');
INSERT INTO `tab_user` VALUES ('214', 'meizhi1000', '43b54e1bfa09eb9819eb58fdeb34af69', '7', 'zlt12345', '0', 'zlt12345', '1', '神武2', 'meizhi1000', '0', '', '', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470986480', '1470986480', '221.193.58.182', '221.193.58.182', '1', '0');
INSERT INTO `tab_user` VALUES ('215', '15517166851', 'd85912d6ddbac6b163682f6fd382fcbc', '4', 'daniel0857', '0', 'daniel0857', '1', '神武2', '15517166851', '0', '', '15517166851', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470986737', '1470986738', '171.116.23.231', '171.116.23.231', '1', '0');
INSERT INTO `tab_user` VALUES ('216', '929596', 'b58ae200cbb18b19ec307ea73fd1fea6', '7', 'zlt12345', '0', 'zlt12345', '1', '神武2', '929596', '0', '', '', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470986744', '1470991391', '117.136.36.92', '117.136.36.92', '1', '0');
INSERT INTO `tab_user` VALUES ('217', '740804', '8705eda56c3c3ba3a29f4ff1b6aff98a', '7', 'zlt12345', '0', 'zlt12345', '1', '神武2', '740804', '0', '', '', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470986911', '1470996629', '182.246.86.224', '60.160.94.103', '1', '0');
INSERT INTO `tab_user` VALUES ('218', 'jiang123a', '497939ec5e18aca50ce0e8b8446aa3a0', '7', 'zlt12345', '0', 'zlt12345', '1', '神武2', 'jiang123a', '0', '', '', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470987013', '1470995897', '116.114.53.200', '116.114.54.19', '1', '0');
INSERT INTO `tab_user` VALUES ('219', 'liwz5200', 'bfd5d806725ba9d420c9c98019b67f41', '7', 'zlt12345', '0', 'zlt12345', '1', '神武2', 'liwz5200', '0', '', '', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470987059', '1470987059', '183.27.48.106', '183.27.48.106', '1', '0');
INSERT INTO `tab_user` VALUES ('220', 'maxk2010', 'f714e22d958eb5fe42829a9c737ca0af', '4', 'daniel0857', '0', 'daniel0857', '1', '神武2', 'maxk2010', '0', '', '', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470987322', '1470997485', '125.88.171.98', '125.88.171.98', '1', '0');
INSERT INTO `tab_user` VALUES ('221', '192170', 'd001ed7c311fc45136ca14898c13b021', '7', 'zlt12345', '0', 'zlt12345', '1', '神武2', '192170', '0', '', '', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470987323', '1470987324', '123.245.209.132', '123.245.209.132', '1', '0');
INSERT INTO `tab_user` VALUES ('222', '984526', 'f714e22d958eb5fe42829a9c737ca0af', '0', '自然注册', '0', '', '12', '决战中洲', '984526', '0', '', '', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470987436', '1470989244', '153.36.68.155', '153.36.68.155', '1', '0');
INSERT INTO `tab_user` VALUES ('223', '956553', 'bfd5d806725ba9d420c9c98019b67f41', '7', 'zlt12345', '0', 'zlt12345', '1', '神武2', '956553', '0', '', '', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470987766', '1470987766', '106.119.41.30', '106.119.41.30', '1', '0');
INSERT INTO `tab_user` VALUES ('224', '18634541613', '99339c1fa02cc2e55f7d17527c678340', '7', 'zlt12345', '0', 'zlt12345', '1', '神武2', '18634541613', '0', '', '18634541613', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470987862', '1470992975', '223.104.14.92', '1.69.139.35', '1', '0');
INSERT INTO `tab_user` VALUES ('225', '15812881012', 'b4ccf4a50b940333baaab871b022c7dc', '4', 'daniel0857', '0', 'daniel0857', '1', '神武2', '15812881012', '0', '', '', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470988035', '1470994110', '121.35.152.174', '121.35.152.174', '1', '0');
INSERT INTO `tab_user` VALUES ('226', '13241737367', '354f1a7c8a889097715045f225d12139', '7', 'zlt12345', '0', 'zlt12345', '1', '神武2', '13241737367', '0', '', '13241737367', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470988120', '1470988120', '114.254.199.223', '114.254.199.223', '1', '0');
INSERT INTO `tab_user` VALUES ('227', '712242', '43b54e1bfa09eb9819eb58fdeb34af69', '4', 'daniel0857', '0', 'daniel0857', '1', '神武2', '712242', '0', '', '', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470988123', '1470992083', '59.63.166.141', '1.180.237.97', '1', '0');
INSERT INTO `tab_user` VALUES ('228', 'youxi198914', '44f67065916633c66030c6532668f759', '7', 'zlt12345', '0', 'zlt12345', '1', '神武2', 'youxi198914', '0', '', '', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470988424', '1470988424', '222.213.196.198', '222.213.196.198', '1', '0');
INSERT INTO `tab_user` VALUES ('229', '15267836139', 'a453650de0a67ffda95b20be43715e96', '4', 'daniel0857', '0', 'daniel0857', '1', '神武2', '15267836139', '0', '', '15267836139', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470988483', '1470994833', '123.152.136.161', '123.152.136.161', '1', '0');
INSERT INTO `tab_user` VALUES ('230', '7518684', '43b54e1bfa09eb9819eb58fdeb34af69', '7', 'zlt12345', '0', 'zlt12345', '1', '神武2', '7518684', '0', '', '', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470989053', '1470989055', '223.241.47.66', '223.241.47.66', '1', '0');
INSERT INTO `tab_user` VALUES ('231', 'sf1992', '877aa311a108541e1e312931260b73d9', '4', 'daniel0857', '0', 'daniel0857', '1', '神武2', 'sf1992', '0', '', '', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470989185', '1470989185', '223.104.13.224', '223.104.13.224', '1', '0');
INSERT INTO `tab_user` VALUES ('232', '15766224557', '9545d10e838b6371af0d3653930f76f0', '4', 'daniel0857', '0', 'daniel0857', '1', '神武2', '15766224557', '0', '', '15766224557', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470989228', '1470989374', '121.12.126.234', '121.12.105.94', '1', '0');
INSERT INTO `tab_user` VALUES ('233', '1827180733', 'd1d46daa00c6d9743c8ce01ef178429b', '7', 'zlt12345', '0', 'zlt12345', '1', '神武2', '1827180733', '0', '', '', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470989297', '1470992814', '42.81.64.82', '42.81.64.82', '1', '0');
INSERT INTO `tab_user` VALUES ('234', '926123', 'eed4d2e2652690a1734f4cb10a532eef', '7', 'zlt12345', '0', 'zlt12345', '1', '神武2', '926123', '0', '', '', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470989406', '1470989407', '36.44.154.162', '36.44.154.162', '1', '0');
INSERT INTO `tab_user` VALUES ('235', '520480', 'b8f18cc0e92f507f0a9c0cd779f5e183', '7', 'zlt12345', '0', 'zlt12345', '1', '神武2', '520480', '0', '', '', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470989432', '1470989434', '14.215.37.80', '14.215.41.152', '1', '0');
INSERT INTO `tab_user` VALUES ('236', '446974', '43b54e1bfa09eb9819eb58fdeb34af69', '7', 'zlt12345', '0', 'zlt12345', '1', '神武2', '446974', '0', '', '', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470989606', '1470989752', '202.109.166.170', '202.109.166.176', '1', '0');
INSERT INTO `tab_user` VALUES ('237', 'mihao128', 'ce0bf67efbc61be8f0ac34ba390bef3b', '4', 'daniel0857', '0', 'daniel0857', '1', '神武2', 'mihao128', '0', '', '', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470989667', '1470998484', '106.117.77.201', '106.117.77.201', '1', '0');
INSERT INTO `tab_user` VALUES ('238', 'qq1233', 'f7e19ad0604136e9fb929f8bb8ae8f82', '4', 'daniel0857', '0', 'daniel0857', '1', '神武2', 'qq1233', '0', '', '', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470990131', '1470990131', '14.148.45.24', '14.148.45.24', '1', '0');
INSERT INTO `tab_user` VALUES ('239', '20080301', '55fe61864fffe22a6ee54d35263a7796', '4', 'daniel0857', '0', 'daniel0857', '1', '神武2', '20080301', '0', '', '', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470990187', '1470990187', '60.178.31.13', '60.178.31.13', '1', '0');
INSERT INTO `tab_user` VALUES ('240', 'zzza1231', 'fb838c98e5aafac30c967fe33abe680b', '7', 'zlt12345', '0', 'zlt12345', '1', '神武2', 'zzza1231', '0', '', '', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470990475', '1470996481', '113.24.88.141', '113.24.88.141', '1', '0');
INSERT INTO `tab_user` VALUES ('241', '528142', '8462f4753205da5ab48e0476fb958a6e', '7', 'zlt12345', '0', 'zlt12345', '1', '神武2', '528142', '0', '', '', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470990628', '1470990666', '112.96.100.104', '112.96.100.104', '1', '0');
INSERT INTO `tab_user` VALUES ('242', '178995823', '0ec4ed605ba1885bbd45c390691e32ee', '7', 'zlt12345', '0', 'zlt12345', '1', '神武2', '178995823', '0', '', '', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470990629', '1470992276', '110.52.44.10', '110.52.44.10', '1', '0');
INSERT INTO `tab_user` VALUES ('243', '724568', 'ef63fbeb6b8c977ae7eed8e3fa7e7780', '7', 'zlt12345', '0', 'zlt12345', '1', '神武2', '724568', '0', '', '', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470990733', '1470996821', '14.215.37.218', '112.96.188.98', '1', '0');
INSERT INTO `tab_user` VALUES ('244', '265288', '43b54e1bfa09eb9819eb58fdeb34af69', '7', 'zlt12345', '0', 'zlt12345', '1', '神武2', '265288', '0', '', '', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470990751', '1470991179', '115.49.180.154', '115.49.180.154', '1', '0');
INSERT INTO `tab_user` VALUES ('245', 'qq1301510775', 'ff333f55ba0c6c44fb74b9c0f7da120c', '7', 'zlt12345', '0', 'zlt12345', '1', '神武2', 'qq1301510775', '0', '', '', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470990921', '1470991276', '61.178.193.174', '61.178.193.174', '1', '0');
INSERT INTO `tab_user` VALUES ('246', '13072015431', 'b046101dbe09cd01d8e57180f87b32f3', '7', 'zlt12345', '0', 'zlt12345', '1', '神武2', '13072015431', '0', '', '13072015431', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470990939', '1470991042', '111.167.60.62', '111.167.60.62', '1', '0');
INSERT INTO `tab_user` VALUES ('247', '15531434368', '0943e5945c5cd40cdcaef0ca0fbee9b3', '7', 'zlt12345', '0', 'zlt12345', '1', '神武2', '15531434368', '0', '', '15531434368', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470990955', '1470990955', '110.254.197.69', '110.254.197.69', '1', '0');
INSERT INTO `tab_user` VALUES ('248', '808208', '5bd1f9c3e2a8939c41bd41667e907889', '4', 'daniel0857', '0', 'daniel0857', '1', '神武2', '808208', '0', '', '', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470991144', '1470996421', '59.34.43.114', '59.34.43.114', '1', '0');
INSERT INTO `tab_user` VALUES ('249', 'lz3040', '55091b6985f8f9c3bbc7cd18c0434ebf', '4', 'daniel0857', '0', 'daniel0857', '1', '神武2', 'lz3040', '0', '', '', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470991311', '1470993372', '222.216.114.171', '222.216.114.171', '1', '0');
INSERT INTO `tab_user` VALUES ('250', '645098', 'd9cc8c0cb9fd4c585a33b441e76ab991', '7', 'zlt12345', '0', 'zlt12345', '1', '神武2', '645098', '0', '', '', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470991323', '1470991335', '121.12.126.84', '121.12.126.84', '1', '0');
INSERT INTO `tab_user` VALUES ('251', 'yhsdyxzh', 'e9372ad9716571cbef875b3962238e56', '7', 'zlt12345', '0', 'zlt12345', '1', '神武2', 'yhsdyxzh', '0', '', '', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470991354', '1470991355', '120.205.49.26', '120.205.49.26', '1', '0');
INSERT INTO `tab_user` VALUES ('252', '262714', '2f49e8bf6bf7500e6615d52c96069f64', '7', 'zlt12345', '0', 'zlt12345', '1', '神武2', '262714', '0', '', '', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470991500', '1470991500', '121.22.225.105', '121.22.225.105', '1', '0');
INSERT INTO `tab_user` VALUES ('253', '997673', '9f84f27666c5e5c8e21ff6191ac1b886', '7', 'zlt12345', '0', 'zlt12345', '1', '神武2', '997673', '0', '', '', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470991680', '1470991680', '124.88.81.180', '124.88.81.180', '1', '0');
INSERT INTO `tab_user` VALUES ('254', '15821126952', 'f0b52f5c922e5066b15f09a9ef19d880', '7', 'zlt12345', '0', 'zlt12345', '1', '神武2', '15821126952', '0', '', '15821126952', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470991923', '1470991924', '180.152.214.86', '180.152.214.86', '1', '0');
INSERT INTO `tab_user` VALUES ('255', '18370790913', 'ff1d96261afe1eeabd3f691eb0bb1518', '7', 'zlt12345', '0', 'zlt12345', '1', '神武2', '18370790913', '0', '', '18370790913', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470992030', '1470994312', '106.6.80.226', '106.6.80.226', '1', '0');
INSERT INTO `tab_user` VALUES ('256', '1325425890', '68e9f6806185c4dfcbe1e354f2196dff', '4', 'daniel0857', '0', 'daniel0857', '1', '神武2', '1325425890', '0', '', '', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470992068', '1470992069', '112.64.28.153', '112.64.28.153', '1', '0');
INSERT INTO `tab_user` VALUES ('257', '584142', '20632f2fe8017b4fc9cc7389675bea06', '4', 'daniel0857', '0', 'daniel0857', '1', '神武2', '584142', '0', '', '', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470992135', '1470992556', '182.207.216.80', '182.207.216.81', '1', '0');
INSERT INTO `tab_user` VALUES ('258', '0401030', '5f5f5c3e7f8d72c503cab0ef4edb7142', '7', 'zlt12345', '0', 'zlt12345', '1', '神武2', '0401030', '0', '', '', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470992138', '1470992138', '60.10.79.143', '60.10.79.143', '1', '0');
INSERT INTO `tab_user` VALUES ('259', 'q735599563', '453bbcba2718d542714fba0f21ea85df', '7', 'zlt12345', '0', 'zlt12345', '1', '神武2', 'q735599563', '0', '', '', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470992213', '1470992380', '27.223.227.84', '27.223.227.84', '1', '0');
INSERT INTO `tab_user` VALUES ('260', '938071', '3b8ef75d0de85d6fbae40565d307c060', '7', 'zlt12345', '0', 'zlt12345', '1', '神武2', '938071', '0', '', '', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470992247', '1470992248', '122.96.47.92', '122.96.47.92', '1', '0');
INSERT INTO `tab_user` VALUES ('261', 'a2015111', '8bd0f04a1692c262165158fa7f64f043', '7', 'zlt12345', '0', 'zlt12345', '1', '神武2', 'a2015111', '0', '', '', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470992249', '1470992249', '113.5.123.96', '113.5.123.96', '1', '0');
INSERT INTO `tab_user` VALUES ('262', 'tongleione', '3ebad9936ef0930dd527b50dfdb9ec8d', '7', 'zlt12345', '0', 'zlt12345', '1', '神武2', 'tongleione', '0', '', '', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470992366', '1470992366', '180.126.107.218', '180.126.107.218', '1', '0');
INSERT INTO `tab_user` VALUES ('263', 'kidd50', '4cb876e13cce7e2c19eaca1c8e606fcd', '7', 'zlt12345', '0', 'zlt12345', '1', '神武2', 'kidd50', '0', '', '', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470992428', '1470995107', '219.238.188.162', '223.104.3.208', '1', '0');
INSERT INTO `tab_user` VALUES ('264', '891106', 'fa4e3cdea0bf85e75be2a0852d9cc211', '7', 'zlt12345', '0', 'zlt12345', '1', '神武2', '891106', '0', '', '', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470992483', '1470993794', '121.62.61.41', '121.62.61.41', '1', '0');
INSERT INTO `tab_user` VALUES ('265', '214992', 'f85e2cd9a65f4f0ac60f20acf5944567', '7', 'zlt12345', '0', 'zlt12345', '1', '神武2', '214992', '0', '', '', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470992547', '1470992548', '121.22.225.105', '121.22.225.105', '1', '0');
INSERT INTO `tab_user` VALUES ('266', '211992', 'f85e2cd9a65f4f0ac60f20acf5944567', '7', 'zlt12345', '0', 'zlt12345', '1', '神武2', '211992', '0', '', '', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470992584', '1470992705', '121.22.225.105', '121.22.225.105', '1', '0');
INSERT INTO `tab_user` VALUES ('267', 'qq735599563', '453bbcba2718d542714fba0f21ea85df', '7', 'zlt12345', '0', 'zlt12345', '1', '神武2', 'qq735599563', '0', '', '', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470992600', '1470992600', '27.223.227.84', '27.223.227.84', '1', '0');
INSERT INTO `tab_user` VALUES ('268', '562711', '43b54e1bfa09eb9819eb58fdeb34af69', '7', 'zlt12345', '0', 'zlt12345', '1', '神武2', '562711', '0', '', '', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470992643', '1470992643', '223.157.24.165', '223.157.24.165', '1', '0');
INSERT INTO `tab_user` VALUES ('269', 'wu0312', '1cd5ff0edcd1e960b8837340a8023cf6', '7', 'zlt12345', '0', 'zlt12345', '1', '神武2', 'wu0312', '0', '', '', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470992643', '1470994824', '14.215.55.218', '14.215.55.218', '1', '0');
INSERT INTO `tab_user` VALUES ('270', '2733164728', '5ed8ccb1c56b4bbb0cd33c69b73792c9', '7', 'zlt12345', '0', 'zlt12345', '1', '神武2', '2733164728', '0', '', '', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470992967', '1470992967', '112.234.208.244', '112.234.208.244', '1', '0');
INSERT INTO `tab_user` VALUES ('271', 'zx3151629', '68042cf4b2c0f27e59dcacaed660fea6', '4', 'daniel0857', '0', 'daniel0857', '1', '神武2', 'zx3151629', '0', '', '', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470992997', '1470992997', '183.60.228.187', '121.12.126.238', '1', '0');
INSERT INTO `tab_user` VALUES ('272', '720222', 'd6a02a8510979bc6c62b5fea13024ef3', '7', 'zlt12345', '0', 'zlt12345', '1', '神武2', '720222', '0', '', '', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470993206', '1470994434', '121.12.126.41', '121.12.126.41', '1', '0');
INSERT INTO `tab_user` VALUES ('273', '15136668149', '74c3cb33e8e3c10f8395785bcd71bdd5', '7', 'zlt12345', '0', 'zlt12345', '1', '神武2', '15136668149', '0', '', '15136668149', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470993282', '1470993403', '115.49.15.181', '115.49.15.181', '1', '0');
INSERT INTO `tab_user` VALUES ('274', 'hh913194', '58b351d283d4e954f2906f3acc8276e6', '7', 'zlt12345', '0', 'zlt12345', '1', '神武2', 'hh913194', '0', '', '', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470993379', '1470993380', '111.73.137.156', '111.73.137.156', '1', '0');
INSERT INTO `tab_user` VALUES ('275', '464968', '31deadc9325f62e53149e69590d23464', '4', 'daniel0857', '0', 'daniel0857', '1', '神武2', '464968', '0', '', '', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470993424', '1470994950', '113.68.33.54', '113.68.33.54', '1', '0');
INSERT INTO `tab_user` VALUES ('276', 'sf0114', '877aa311a108541e1e312931260b73d9', '4', 'daniel0857', '0', 'daniel0857', '1', '神武2', 'sf0114', '0', '', '', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470993817', '1470993818', '223.104.13.224', '223.104.13.224', '1', '0');
INSERT INTO `tab_user` VALUES ('277', 'qsqs08711', 'f714e22d958eb5fe42829a9c737ca0af', '4', 'daniel0857', '0', 'daniel0857', '1', '神武2', 'qsqs08711', '0', '', '', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470993871', '1470993871', '223.198.70.153', '223.198.70.153', '1', '0');
INSERT INTO `tab_user` VALUES ('278', 'a1006053214', '9de7f41d33e923a82592406de534a512', '4', 'daniel0857', '0', 'daniel0857', '1', '神武2', 'a1006053214', '0', '', '', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470993906', '1470993906', '1.49.118.66', '1.49.118.66', '1', '0');
INSERT INTO `tab_user` VALUES ('279', '470678259', '43b54e1bfa09eb9819eb58fdeb34af69', '4', 'daniel0857', '0', 'daniel0857', '1', '神武2', '470678259', '0', '', '', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470993943', '1470994555', '171.212.135.43', '171.212.135.43', '1', '0');
INSERT INTO `tab_user` VALUES ('280', '889694', '8ec60b10d35182893da74b4704d96fdf', '4', 'daniel0857', '0', 'daniel0857', '1', '神武2', '889694', '0', '', '', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470993988', '1470993989', '182.90.76.147', '182.90.76.147', '1', '0');
INSERT INTO `tab_user` VALUES ('281', 'darling09', 'e4860b07e57a401aca23d793b9bbd53c', '7', 'zlt12345', '0', 'zlt12345', '1', '神武2', 'darling09', '0', '', '', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470994095', '1470998168', '119.126.112.230', '119.126.112.230', '1', '0');
INSERT INTO `tab_user` VALUES ('282', '499999', '3ffa8fd16ed04e9daef66a50d656ff8e', '7', 'zlt12345', '0', 'zlt12345', '1', '神武2', '499999', '0', '', '', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470994486', '1470994486', '139.205.154.93', '139.205.154.93', '1', '0');
INSERT INTO `tab_user` VALUES ('283', '985404', '143c23d891d3d1b7da4ae60c83fe4420', '7', 'zlt12345', '0', 'zlt12345', '1', '神武2', '985404', '0', '', '', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470994619', '1470994619', '116.17.74.4', '116.17.74.4', '1', '0');
INSERT INTO `tab_user` VALUES ('284', '18778781196', 'f003b937724e893b0204437b8e2be176', '7', 'zlt12345', '0', 'zlt12345', '1', '神武2', '18778781196', '0', '', '18778781196', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470994688', '1470994689', '180.140.48.39', '180.140.48.39', '1', '0');
INSERT INTO `tab_user` VALUES ('285', 'a8468729', '77bd1b8673b630cba32dcb156f6a238e', '7', 'zlt12345', '0', 'zlt12345', '1', '神武2', 'a8468729', '0', '', '', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470994780', '1470994851', '182.18.107.33', '182.18.111.46', '1', '0');
INSERT INTO `tab_user` VALUES ('286', 'z67520', '55fe61864fffe22a6ee54d35263a7796', '7', 'zlt12345', '0', 'zlt12345', '1', '神武2', 'z67520', '0', '', '', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470994792', '1470994792', '14.106.143.5', '14.106.143.5', '1', '0');
INSERT INTO `tab_user` VALUES ('287', '740102', '3086398de63192607df5abdd7a21b57f', '4', 'daniel0857', '0', 'daniel0857', '1', '神武2', '740102', '0', '', '', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470994977', '1470994977', '183.41.0.27', '183.41.0.27', '1', '0');
INSERT INTO `tab_user` VALUES ('288', 'aa1500492388', 'd83aa7f5d1e89869cdef628a3bc729fd', '7', 'zlt12345', '0', 'zlt12345', '1', '神武2', 'aa1500492388', '0', '', '', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470995089', '1470995089', '106.46.106.250', '106.46.106.250', '1', '0');
INSERT INTO `tab_user` VALUES ('289', '14763555700', '441956806ae59ced86c3728c5fd3733c', '7', 'zlt12345', '0', 'zlt12345', '1', '神武2', '14763555700', '0', '', '', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470995133', '1470995293', '119.189.70.199', '119.189.70.199', '1', '0');
INSERT INTO `tab_user` VALUES ('290', '15915514152', '3644bc2f09d94d7138e432779dc1c94e', '4', 'daniel0857', '0', 'daniel0857', '1', '神武2', '15915514152', '0', '', '15915514152', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470995274', '1470996783', '163.204.2.120', '163.204.2.120', '1', '0');
INSERT INTO `tab_user` VALUES ('291', '18700605571', '958638497499f316167bf20caf81f92c', '7', 'zlt12345', '0', 'zlt12345', '1', '神武2', '18700605571', '0', '', '18700605571', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470995304', '1470997960', '222.187.239.226', '223.104.11.49', '1', '0');
INSERT INTO `tab_user` VALUES ('292', 'hong888', '43b54e1bfa09eb9819eb58fdeb34af69', '7', 'zlt12345', '0', 'zlt12345', '1', '神武2', 'hong888', '0', '', '', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470995345', '1470996512', '111.193.75.67', '111.193.75.67', '1', '0');
INSERT INTO `tab_user` VALUES ('293', '13275383606', '97eeb7ba54142f41680ba07d643c35a3', '7', 'zlt12345', '0', 'zlt12345', '1', '神武2', '13275383606', '0', '', '13275383606', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470995648', '1470995649', '39.68.232.64', '39.68.232.64', '1', '0');
INSERT INTO `tab_user` VALUES ('294', 'pop866211', 'a3eb2a527cca9fefc37f90ca78c90ef4', '4', 'daniel0857', '0', 'daniel0857', '1', '神武2', 'pop866211', '0', '', '', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470995670', '1470995670', '123.171.4.17', '123.171.4.17', '1', '0');
INSERT INTO `tab_user` VALUES ('295', 'qqa147258', 'fb7bea95f7823052090eae5e5a8d763e', '7', 'zlt12345', '0', 'zlt12345', '1', '神武2', 'qqa147258', '0', '', '', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470995967', '1470995968', '36.162.182.173', '36.162.182.173', '1', '0');
INSERT INTO `tab_user` VALUES ('296', '416459306', '6f961790835696431ab6bda8d6771a64', '7', 'zlt12345', '0', 'zlt12345', '1', '神武2', '416459306', '0', '', '', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470996016', '1470996016', '183.60.175.217', '183.60.175.217', '1', '0');
INSERT INTO `tab_user` VALUES ('297', '13504994340', '2050677218f8836236e8c34f7242713f', '4', 'daniel0857', '0', 'daniel0857', '1', '神武2', '13504994340', '0', '', '13504994340', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470996256', '1470996256', '113.231.224.50', '113.231.224.50', '1', '0');
INSERT INTO `tab_user` VALUES ('298', '582458', '03c3a79359ebf664e151b3e7781799ce', '4', 'daniel0857', '0', 'daniel0857', '1', '神武2', '582458', '0', '', '', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470996339', '1470996340', '221.1.157.113', '221.1.157.113', '1', '0');
INSERT INTO `tab_user` VALUES ('299', '416468216', '1b453536722ae7f1b7765e3e78bcef3f', '4', 'daniel0857', '0', 'daniel0857', '1', '神武2', '416468216', '0', '', '', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470996382', '1470996390', '103.44.207.43', '113.128.131.41', '1', '0');
INSERT INTO `tab_user` VALUES ('300', '15181739702', '680a98f47534d075161ec2d9e8c38083', '4', 'daniel0857', '0', 'daniel0857', '1', '神武2', '15181739702', '0', '', '15181739702', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470996521', '1470996521', '125.66.93.221', '125.66.93.221', '1', '0');
INSERT INTO `tab_user` VALUES ('301', '998433', '203ffed4ac678a665cbbc48bfac27a1c', '4', 'daniel0857', '0', 'daniel0857', '1', '神武2', '998433', '0', '', '', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470996664', '1470996667', '36.57.32.173', '36.57.32.173', '1', '0');
INSERT INTO `tab_user` VALUES ('302', 'qq1363508033', '0647dd441be23c5c35a93021593077cf', '7', 'zlt12345', '0', 'zlt12345', '1', '神武2', 'qq1363508033', '0', '', '', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470996890', '1470996891', '116.53.168.83', '116.53.168.83', '1', '0');
INSERT INTO `tab_user` VALUES ('303', 'zhangbin', '74344763ad7fcb03a0c02c800a4c22dd', '7', 'zlt12345', '0', 'zlt12345', '1', '神武2', 'zhangbin', '0', '', '', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470997426', '1470997635', '1.180.237.97', '1.180.237.97', '1', '0');
INSERT INTO `tab_user` VALUES ('304', 'ey1314251', '3afc24a9173f3cd2b95f924e6e708b1f', '7', 'zlt12345', '0', 'zlt12345', '1', '神武2', 'ey1314251', '0', '', '', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470997497', '1470997497', '59.173.215.68', '59.173.215.68', '1', '0');
INSERT INTO `tab_user` VALUES ('305', '15220943549', '27d6fbcd24b33384c6cfcf34e93cb947', '4', 'daniel0857', '0', 'daniel0857', '1', '神武2', '15220943549', '0', '', '15220943549', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470997614', '1470997614', '14.144.201.217', '14.144.201.217', '1', '0');
INSERT INTO `tab_user` VALUES ('306', '498750600', 'b813f31f2bbe5f69b9b83a65eb200b11', '4', 'daniel0857', '0', 'daniel0857', '1', '神武2', '498750600', '0', '', '', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470997988', '1470997989', '43.225.237.10', '43.225.237.10', '1', '0');
INSERT INTO `tab_user` VALUES ('307', 't321753988', 'e341e8fdb27f8c9a9c3e1bc078181b33', '7', 'zlt12345', '0', 'zlt12345', '1', '神武2', 't321753988', '0', '', '', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470998103', '1470998130', '113.185.54.4', '113.185.54.4', '1', '0');
INSERT INTO `tab_user` VALUES ('308', '803493', '5eb767375ef8bdca779ad6abf438b05e', '4', 'daniel0857', '0', 'daniel0857', '1', '神武2', '803493', '0', '', '', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470998367', '1470998367', '39.73.16.60', '39.73.16.60', '1', '0');
INSERT INTO `tab_user` VALUES ('309', '15984306325', '1ae93e825fba38ca8dc440add117f4b7', '4', 'daniel0857', '0', 'daniel0857', '1', '神武2', '15984306325', '0', '', '15984306325', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470998367', '1470998367', '42.81.64.80', '42.81.64.82', '1', '0');
INSERT INTO `tab_user` VALUES ('310', '4514210', '3d0a9a50cb7307b125dcb6308f727e8d', '4', 'daniel0857', '0', 'daniel0857', '1', '神武2', '4514210', '0', '', '', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470998385', '1470998386', '222.82.88.233', '222.82.88.233', '1', '0');
INSERT INTO `tab_user` VALUES ('311', '6676424', '3e23f6c4faa74c1ab02ca3c5e95b0d10', '7', 'zlt12345', '0', 'zlt12345', '1', '神武2', '6676424', '0', '', '', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470998400', '1470998400', '218.22.60.2', '218.22.60.2', '1', '0');
INSERT INTO `tab_user` VALUES ('312', 'aisi30', 'a429fb78164cd18399c4273f8152a9be', '7', 'zlt12345', '0', 'zlt12345', '1', '神武2', 'aisi30', '0', '', '', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470998482', '1470998483', '58.210.233.226', '58.210.233.226', '1', '0');
INSERT INTO `tab_user` VALUES ('313', '249982171', 'eff552bdc187a2693c6685e740d375c0', '7', 'zlt12345', '0', 'zlt12345', '1', '神武2', '249982171', '0', '', '', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470998511', '1470998511', '180.156.158.211', '180.156.158.211', '1', '0');
INSERT INTO `tab_user` VALUES ('314', '1968185726', '4f93e8b8281ef07d6ab7029b3ba80a48', '4', 'daniel0857', '0', 'daniel0857', '1', '神武2', '1968185726', '0', '', '', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470998577', '1470998577', '58.217.250.195', '58.217.250.195', '1', '0');
INSERT INTO `tab_user` VALUES ('315', '357661', '14604c1de86360d6cb142195a12fb226', '4', 'daniel0857', '0', 'daniel0857', '1', '神武2', '357661', '0', '', '', '', '', '0', '0.00', '0.00', '0', '1', '1', '1470998578', '1470998578', '59.56.7.42', '59.56.7.42', '1', '0');

-- -----------------------------
-- Table structure for `tab_user_login_record`
-- -----------------------------
DROP TABLE IF EXISTS `tab_user_login_record`;
CREATE TABLE `tab_user_login_record` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '自增主键',
  `game_id` int(11) DEFAULT NULL COMMENT '游戏id',
  `game_name` varchar(30) DEFAULT NULL COMMENT ' 游戏名称',
  `server_id` int(11) DEFAULT NULL COMMENT '区服id',
  `server_name` varchar(30) DEFAULT NULL COMMENT '区服名称',
  `user_id` int(11) DEFAULT NULL COMMENT '用户ID',
  `user_account` varchar(30) DEFAULT NULL COMMENT '用户账号',
  `user_nickname` varchar(30) DEFAULT NULL COMMENT '用户昵称',
  `login_time` int(11) DEFAULT NULL COMMENT '登陆时间',
  `login_ip` varchar(20) DEFAULT NULL COMMENT '登陆ip',
  `type` tinyint(2) DEFAULT '1' COMMENT '类型(1:游戏登陆,2:PC登陆)',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=843 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `tab_user_login_record`
-- -----------------------------
INSERT INTO `tab_user_login_record` VALUES ('1', '12', '决战中洲', '', '', '1', '316046', '316046', '1470641940', '153.36.68.207', '1');
INSERT INTO `tab_user_login_record` VALUES ('2', '12', '决战中洲', '', '', '2', '674640', '674640', '1470652774', '153.36.68.207', '1');
INSERT INTO `tab_user_login_record` VALUES ('3', '12', '决战中洲', '', '', '1', '316046', '316046', '1470652996', '153.36.68.207', '1');
INSERT INTO `tab_user_login_record` VALUES ('4', '12', '决战中洲', '', '', '2', '674640', '674640', '1470653100', '153.36.68.207', '1');
INSERT INTO `tab_user_login_record` VALUES ('5', '12', '决战中洲', '', '', '2', '674640', '674640', '1470653146', '153.36.68.207', '1');
INSERT INTO `tab_user_login_record` VALUES ('6', '12', '决战中洲', '', '', '2', '674640', '674640', '1470653266', '153.36.68.207', '1');
INSERT INTO `tab_user_login_record` VALUES ('7', '12', '决战中洲', '', '', '1', '316046', '316046', '1470654477', '153.36.68.207', '1');
INSERT INTO `tab_user_login_record` VALUES ('8', '12', '决战中洲', '', '', '1', '316046', '316046', '1470654540', '153.36.68.207', '1');
INSERT INTO `tab_user_login_record` VALUES ('9', '12', '决战中洲', '', '', '1', '316046', '316046', '1470654598', '153.36.68.207', '1');
INSERT INTO `tab_user_login_record` VALUES ('10', '12', '决战中洲', '', '', '2', '674640', '674640', '1470655594', '153.36.68.207', '1');
INSERT INTO `tab_user_login_record` VALUES ('11', '12', '决战中洲', '', '', '1', '316046', '316046', '1470656700', '153.36.68.207', '1');
INSERT INTO `tab_user_login_record` VALUES ('12', '12', '决战中洲', '', '', '1', '316046', '316046', '1470656825', '153.36.68.207', '1');
INSERT INTO `tab_user_login_record` VALUES ('13', '12', '决战中洲', '', '', '2', '674640', '674640', '1470657016', '153.36.68.207', '1');
INSERT INTO `tab_user_login_record` VALUES ('14', '12', '决战中洲', '', '', '2', '674640', '674640', '1470657189', '153.36.68.207', '1');
INSERT INTO `tab_user_login_record` VALUES ('15', '12', '决战中洲', '', '', '2', '674640', '674640', '1470657935', '153.36.68.207', '1');
INSERT INTO `tab_user_login_record` VALUES ('16', '12', '决战中洲', '', '', '1', '316046', '316046', '1470657958', '153.36.68.207', '1');
INSERT INTO `tab_user_login_record` VALUES ('17', '12', '决战中洲', '', '', '1', '316046', '316046', '1470658135', '153.36.68.207', '1');
INSERT INTO `tab_user_login_record` VALUES ('18', '12', '决战中洲', '', '', '1', '316046', '316046', '1470658268', '153.36.68.207', '1');
INSERT INTO `tab_user_login_record` VALUES ('19', '12', '决战中洲', '', '', '2', '674640', '674640', '1470659926', '153.36.68.207', '1');
INSERT INTO `tab_user_login_record` VALUES ('20', '12', '决战中洲', '', '', '2', '674640', '674640', '1470660413', '153.36.68.207', '1');
INSERT INTO `tab_user_login_record` VALUES ('21', '12', '决战中洲', '', '', '2', '674640', '674640', '1470660891', '153.36.68.207', '1');
INSERT INTO `tab_user_login_record` VALUES ('22', '12', '决战中洲', '', '', '3', '564942', '564942', '1470661272', '153.36.68.207', '1');
INSERT INTO `tab_user_login_record` VALUES ('23', '12', '决战中洲', '', '', '4', '563000', '563000', '1470661374', '153.36.68.207', '1');
INSERT INTO `tab_user_login_record` VALUES ('24', '12', '决战中洲', '', '', '4', '563000', '563000', '1470661629', '153.36.68.207', '1');
INSERT INTO `tab_user_login_record` VALUES ('25', '12', '决战中洲', '', '', '4', '563000', '563000', '1470661652', '153.36.68.207', '1');
INSERT INTO `tab_user_login_record` VALUES ('26', '12', '决战中洲', '', '', '2', '674640', '674640', '1470704531', '153.36.161.180', '1');
INSERT INTO `tab_user_login_record` VALUES ('27', '12', '决战中洲', '', '', '2', '674640', '674640', '1470713650', '153.36.161.180', '1');
INSERT INTO `tab_user_login_record` VALUES ('28', '1', '梦幻西游BT', '', '', '8', '231149', '231149', '1470732503', '218.19.136.119', '1');
INSERT INTO `tab_user_login_record` VALUES ('29', '1', '梦幻西游BT', '', '', '8', '231149', '231149', '1470732510', '218.19.136.119', '1');
INSERT INTO `tab_user_login_record` VALUES ('30', '1', '梦幻西游BT', '', '', '8', '231149', '231149', '1470732540', '218.19.136.119', '1');
INSERT INTO `tab_user_login_record` VALUES ('31', '1', '梦幻西游BT', '', '', '8', '231149', '231149', '1470732614', '218.19.136.119', '1');
INSERT INTO `tab_user_login_record` VALUES ('32', '1', '梦幻西游BT', '', '', '8', '231149', '231149', '1470733675', '218.19.136.119', '1');
INSERT INTO `tab_user_login_record` VALUES ('33', '1', '梦幻西游BT', '', '', '8', '231149', '231149', '1470733696', '218.19.136.119', '1');
INSERT INTO `tab_user_login_record` VALUES ('34', '1', '梦幻西游BT', '', '', '8', '231149', '231149', '1470734052', '218.19.136.119', '1');
INSERT INTO `tab_user_login_record` VALUES ('35', '1', '梦幻西游BT', '', '', '8', '231149', '231149', '1470734054', '218.19.136.119', '1');
INSERT INTO `tab_user_login_record` VALUES ('36', '1', '梦幻西游BT', '', '', '9', '871103', '871103', '1470734559', '218.19.136.119', '1');
INSERT INTO `tab_user_login_record` VALUES ('37', '1', '梦幻西游BT', '', '', '8', '231149', '231149', '1470735092', '218.19.136.119', '1');
INSERT INTO `tab_user_login_record` VALUES ('38', '1', '梦幻西游BT', '', '', '10', '471341', '471341', '1470736304', '218.19.136.119', '1');
INSERT INTO `tab_user_login_record` VALUES ('39', '1', '梦幻西游BT', '', '', '10', '471341', '471341', '1470736304', '218.19.136.119', '1');
INSERT INTO `tab_user_login_record` VALUES ('40', '1', '梦幻西游BT', '', '', '10', '471341', '471341', '1470736345', '218.19.136.119', '1');
INSERT INTO `tab_user_login_record` VALUES ('41', '1', '梦幻西游BT', '', '', '12', '356596', '356596', '1470737114', '218.19.136.119', '1');
INSERT INTO `tab_user_login_record` VALUES ('42', '1', '梦幻西游BT', '', '', '10', '471341', '471341', '1470794766', '218.19.136.119', '1');
INSERT INTO `tab_user_login_record` VALUES ('43', '1', '梦幻西游BT', '', '', '13', '682928', '682928', '1470794990', '218.19.136.119', '1');
INSERT INTO `tab_user_login_record` VALUES ('44', '1', '梦幻西游BT', '', '', '14', '962674', '962674', '1470796133', '112.96.115.97', '1');
INSERT INTO `tab_user_login_record` VALUES ('45', '1', '梦幻西游BT', '', '', '15', '710020', '710020', '1470796150', '112.96.115.97', '1');
INSERT INTO `tab_user_login_record` VALUES ('46', '1', '梦幻西游BT', '', '', '15', '710020', '710020', '1470796185', '112.96.115.97', '1');
INSERT INTO `tab_user_login_record` VALUES ('47', '1', '梦幻西游BT', '', '', '15', '710020', '710020', '1470796302', '218.19.136.119', '1');
INSERT INTO `tab_user_login_record` VALUES ('48', '1', '梦幻西游BT', '', '', '16', '472800', '472800', '1470796678', '218.19.136.119', '1');
INSERT INTO `tab_user_login_record` VALUES ('49', '1', '梦幻西游BT', '', '', '17', '346367', '346367', '1470796870', '218.19.136.119', '1');
INSERT INTO `tab_user_login_record` VALUES ('50', '1', '梦幻西游BT', '', '', '18', '415399', '415399', '1470820664', '218.19.136.119', '1');
INSERT INTO `tab_user_login_record` VALUES ('51', '1', '梦幻西游BT', '', '', '18', '415399', '415399', '1470821021', '218.19.136.119', '1');
INSERT INTO `tab_user_login_record` VALUES ('52', '1', '梦幻西游BT', '', '', '19', '15505437898', '15505437898', '1470827326', '60.248.238.175', '1');
INSERT INTO `tab_user_login_record` VALUES ('53', '12', '决战中洲', '', '', '19', '15505437898', '15505437898', '1470856944', '60.248.238.175', '1');
INSERT INTO `tab_user_login_record` VALUES ('54', '12', '决战中洲', '', '', '19', '15505437898', '15505437898', '1470857109', '60.248.238.175', '1');
INSERT INTO `tab_user_login_record` VALUES ('55', '1', '神武2BT', '', '', '20', '868327', '868327', '1470888937', '218.19.136.119', '1');
INSERT INTO `tab_user_login_record` VALUES ('56', '1', '神武2BT', '', '', '21', '161510', '161510', '1470893281', '218.19.136.119', '1');
INSERT INTO `tab_user_login_record` VALUES ('57', '1', '神武2BT', '', '', '22', '371180', '371180', '1470894213', '218.19.136.119', '1');
INSERT INTO `tab_user_login_record` VALUES ('58', '1', '神武2BT', '', '', '22', '371180', '371180', '1470894338', '218.19.136.119', '1');
INSERT INTO `tab_user_login_record` VALUES ('59', '1', '神武2BT', '', '', '23', '513248', '513248', '1470894955', '218.19.136.119', '1');
INSERT INTO `tab_user_login_record` VALUES ('60', '12', '决战中洲', '', '', '19', '15505437898', '15505437898', '1470895097', '60.248.238.175', '1');
INSERT INTO `tab_user_login_record` VALUES ('61', '12', '决战中洲', '', '', '24', '781352', '781352', '1470895110', '157.0.226.72', '1');
INSERT INTO `tab_user_login_record` VALUES ('62', '12', '决战中洲', '', '', '25', '424842', '424842', '1470895559', '157.0.226.72', '1');
INSERT INTO `tab_user_login_record` VALUES ('63', '1', '神武2BT', '', '', '26', '772794', '772794', '1470896417', '218.19.136.119', '1');
INSERT INTO `tab_user_login_record` VALUES ('64', '12', '决战中洲', '', '', '27', '322187', '322187', '1470897327', '157.0.226.72', '1');
INSERT INTO `tab_user_login_record` VALUES ('65', '1', '神武2BT', '', '', '26', '772794', '772794', '1470897907', '218.19.136.119', '1');
INSERT INTO `tab_user_login_record` VALUES ('66', '1', '神武2BT', '', '', '26', '772794', '772794', '1470898041', '218.19.136.119', '1');
INSERT INTO `tab_user_login_record` VALUES ('67', '1', '神武2BT', '', '', '26', '772794', '772794', '1470898172', '112.96.128.124', '1');
INSERT INTO `tab_user_login_record` VALUES ('68', '1', '神武2BT', '', '', '28', '210926', '210926', '1470898498', '218.19.136.119', '1');
INSERT INTO `tab_user_login_record` VALUES ('69', '1', '神武2BT', '', '', '23', '513248', '513248', '1470898814', '218.19.136.119', '1');
INSERT INTO `tab_user_login_record` VALUES ('70', '12', '决战中洲', '', '', '29', '374925', '374925', '1470899079', '157.0.226.72', '1');
INSERT INTO `tab_user_login_record` VALUES ('71', '12', '决战中洲', '', '', '30', '252341', '252341', '1470899495', '157.0.226.72', '1');
INSERT INTO `tab_user_login_record` VALUES ('72', '12', '决战中洲', '', '', '31', '147043', '147043', '1470900063', '157.0.226.72', '1');
INSERT INTO `tab_user_login_record` VALUES ('73', '1', '神武2BT', '', '', '19', '15505437898', '15505437898', '1470900596', '60.248.238.175', '1');
INSERT INTO `tab_user_login_record` VALUES ('74', '1', '神武2BT', '', '', '28', '210926', '210926', '1470900829', '218.19.136.119', '1');
INSERT INTO `tab_user_login_record` VALUES ('75', '12', '决战中洲', '', '', '31', '147043', '147043', '1470903397', '157.0.226.72', '1');
INSERT INTO `tab_user_login_record` VALUES ('76', '12', '决战中洲', '', '', '31', '147043', '147043', '1470903953', '157.0.226.72', '1');
INSERT INTO `tab_user_login_record` VALUES ('77', '12', '决战中洲', '', '', '31', '147043', '147043', '1470904299', '157.0.226.72', '1');
INSERT INTO `tab_user_login_record` VALUES ('78', '12', '决战中洲', '', '', '31', '147043', '147043', '1470904583', '157.0.226.72', '1');
INSERT INTO `tab_user_login_record` VALUES ('79', '12', '决战中洲', '', '', '31', '147043', '147043', '1470904933', '157.0.226.72', '1');
INSERT INTO `tab_user_login_record` VALUES ('80', '12', '决战中洲', '', '', '31', '147043', '147043', '1470905012', '157.0.226.72', '1');
INSERT INTO `tab_user_login_record` VALUES ('81', '12', '决战中洲', '', '', '31', '147043', '147043', '1470905287', '157.0.226.72', '1');
INSERT INTO `tab_user_login_record` VALUES ('82', '12', '决战中洲', '', '', '31', '147043', '147043', '1470905465', '157.0.226.72', '1');
INSERT INTO `tab_user_login_record` VALUES ('83', '1', '神武2BT', '', '', '32', '550135', '550135', '1470907461', '218.19.138.137', '1');
INSERT INTO `tab_user_login_record` VALUES ('84', '1', '神武2BT', '', '', '33', '896852', '896852', '1470907798', '218.19.138.137', '1');
INSERT INTO `tab_user_login_record` VALUES ('85', '1', '神武2BT', '', '', '34', '861130', '861130', '1470908119', '218.19.138.137', '1');
INSERT INTO `tab_user_login_record` VALUES ('86', '1', '神武2BT', '', '', '34', '861130', '861130', '1470908225', '218.19.138.137', '1');
INSERT INTO `tab_user_login_record` VALUES ('87', '1', '神武2BT', '', '', '35', '592371', '592371', '1470908584', '218.19.138.137', '1');
INSERT INTO `tab_user_login_record` VALUES ('88', '1', '神武2BT', '', '', '36', '955710', '955710', '1470908939', '218.19.138.137', '1');
INSERT INTO `tab_user_login_record` VALUES ('89', '1', '神武2BT', '', '', '35', '592371', '592371', '1470909014', '218.19.138.137', '1');
INSERT INTO `tab_user_login_record` VALUES ('90', '1', '神武2BT', '', '', '35', '592371', '592371', '1470911480', '218.19.138.137', '1');
INSERT INTO `tab_user_login_record` VALUES ('91', '1', '神武2BT', '', '', '35', '592371', '592371', '1470911483', '218.19.138.137', '1');
INSERT INTO `tab_user_login_record` VALUES ('92', '1', '神武2', '', '', '38', '183383', '183383', '1470927841', '60.248.238.175', '1');
INSERT INTO `tab_user_login_record` VALUES ('93', '1', '神武2', '', '', '38', '183383', '183383', '1470928017', '60.248.238.175', '1');
INSERT INTO `tab_user_login_record` VALUES ('94', '1', '神武2', '', '', '39', '6225540', '6225540', '1470928539', '139.201.153.110', '1');
INSERT INTO `tab_user_login_record` VALUES ('95', '1', '神武2', '', '', '40', 'd123456', 'd123456', '1470928784', '60.222.97.42', '1');
INSERT INTO `tab_user_login_record` VALUES ('96', '1', '神武2', '', '', '41', 'aa5587831', 'aa5587831', '1470928810', '171.107.17.200', '1');
INSERT INTO `tab_user_login_record` VALUES ('97', '1', '神武2', '', '', '42', 'caomengyao1636', 'caomengyao1636', '1470928818', '123.138.186.99', '1');
INSERT INTO `tab_user_login_record` VALUES ('98', '1', '神武2', '', '', '43', 'zlt123456', 'zlt123456', '1470928870', '125.71.115.129', '1');
INSERT INTO `tab_user_login_record` VALUES ('99', '1', '神武2', '', '', '44', 'ycxinpeng0911', 'ycxinpeng0911', '1470928934', '27.207.77.40', '1');
INSERT INTO `tab_user_login_record` VALUES ('100', '1', '神武2', '', '', '42', 'caomengyao1636', 'caomengyao1636', '1470929070', '113.200.204.105', '1');
INSERT INTO `tab_user_login_record` VALUES ('101', '1', '神武2', '', '', '42', 'caomengyao1636', 'caomengyao1636', '1470929128', '113.200.204.105', '1');
INSERT INTO `tab_user_login_record` VALUES ('102', '1', '神武2', '', '', '45', '20998526', '20998526', '1470929366', '117.28.181.145', '1');
INSERT INTO `tab_user_login_record` VALUES ('103', '1', '神武2', '', '', '46', 'wei320781', 'wei320781', '1470929699', '183.67.175.34', '1');
INSERT INTO `tab_user_login_record` VALUES ('104', '1', '神武2', '', '', '43', 'zlt123456', 'zlt123456', '1470929828', '125.71.115.129', '1');
INSERT INTO `tab_user_login_record` VALUES ('105', '1', '神武2', '', '', '47', 'yuan123', 'yuan123', '1470930212', '59.59.231.95', '1');
INSERT INTO `tab_user_login_record` VALUES ('106', '1', '神武2', '', '', '48', '182073a', '182073a', '1470930224', '123.139.44.221', '1');
INSERT INTO `tab_user_login_record` VALUES ('107', '1', '神武2', '', '', '49', 'loklok', 'loklok', '1470930254', '60.52.22.96', '1');
INSERT INTO `tab_user_login_record` VALUES ('108', '1', '神武2', '', '', '50', '13406351617', '13406351617', '1470930314', '218.56.31.82', '1');
INSERT INTO `tab_user_login_record` VALUES ('109', '1', '神武2', '', '', '51', '15117861717', '15117861717', '1470930351', '114.139.104.39', '1');
INSERT INTO `tab_user_login_record` VALUES ('110', '1', '神武2', '', '', '52', 'xm332418', 'xm332418', '1470930355', '111.77.37.130', '1');
INSERT INTO `tab_user_login_record` VALUES ('111', '1', '神武2', '', '', '53', '102549', '102549', '1470930365', '171.115.93.135', '1');
INSERT INTO `tab_user_login_record` VALUES ('112', '1', '神武2', '', '', '51', '15117861717', '15117861717', '1470930489', '114.139.104.39', '1');
INSERT INTO `tab_user_login_record` VALUES ('113', '1', '神武2', '', '', '49', 'loklok', 'loklok', '1470930529', '60.52.22.96', '1');
INSERT INTO `tab_user_login_record` VALUES ('114', '1', '神武2', '', '', '54', '15260363578', '15260363578', '1470930566', '171.12.124.117', '1');
INSERT INTO `tab_user_login_record` VALUES ('115', '1', '神武2', '', '', '53', '102549', '102549', '1470930603', '171.115.93.135', '1');
INSERT INTO `tab_user_login_record` VALUES ('116', '1', '神武2', '', '', '55', '1196135202', '1196135202', '1470930712', '117.136.94.246', '1');
INSERT INTO `tab_user_login_record` VALUES ('117', '1', '神武2', '', '', '56', 'smw888', 'smw888', '1470930725', '111.74.215.4', '1');
INSERT INTO `tab_user_login_record` VALUES ('118', '1', '神武2', '', '', '57', 'qq8684253', 'qq8684253', '1470930767', '183.186.136.239', '1');
INSERT INTO `tab_user_login_record` VALUES ('119', '1', '神武2', '', '', '58', 'xxs8822', 'xxs8822', '1470930777', '120.85.69.181', '1');
INSERT INTO `tab_user_login_record` VALUES ('120', '1', '神武2', '', '', '42', 'caomengyao1636', 'caomengyao1636', '1470930855', '113.200.204.105', '1');
INSERT INTO `tab_user_login_record` VALUES ('121', '1', '神武2', '', '', '59', '141115', '141115', '1470930859', '218.68.71.145', '1');
INSERT INTO `tab_user_login_record` VALUES ('122', '1', '神武2', '', '', '55', '1196135202', '1196135202', '1470930871', '223.104.2.174', '1');
INSERT INTO `tab_user_login_record` VALUES ('123', '1', '神武2', '', '', '60', 'q11250', 'q11250', '1470931036', '218.93.206.199', '1');
INSERT INTO `tab_user_login_record` VALUES ('124', '1', '神武2', '', '', '55', '1196135202', '1196135202', '1470931225', '223.104.2.174', '1');
INSERT INTO `tab_user_login_record` VALUES ('125', '1', '神武2', '', '', '61', 'x2192831197', 'x2192831197', '1470932197', '36.101.77.134', '1');
INSERT INTO `tab_user_login_record` VALUES ('126', '1', '神武2', '', '', '61', 'x2192831197', 'x2192831197', '1470932259', '36.101.77.134', '1');
INSERT INTO `tab_user_login_record` VALUES ('127', '1', '神武2', '', '', '45', '20998526', '20998526', '1470932566', '117.28.181.145', '1');
INSERT INTO `tab_user_login_record` VALUES ('128', '1', '神武2', '', '', '62', '13750584020', '13750584020', '1470932789', '183.52.0.194', '1');
INSERT INTO `tab_user_login_record` VALUES ('129', '1', '神武2', '', '', '63', '8989290', '8989290', '1470933553', '220.194.71.56', '1');
INSERT INTO `tab_user_login_record` VALUES ('130', '1', '神武2', '', '', '64', 'zyxztt', 'zyxztt', '1470933720', '113.128.131.41', '1');
INSERT INTO `tab_user_login_record` VALUES ('131', '1', '神武2', '', '', '64', 'zyxztt', 'zyxztt', '1470933721', '182.18.105.248', '1');
INSERT INTO `tab_user_login_record` VALUES ('132', '1', '神武2', '', '', '64', 'zyxztt', 'zyxztt', '1470933730', '113.128.89.62', '1');
INSERT INTO `tab_user_login_record` VALUES ('133', '1', '神武2', '', '', '65', '921937277', '921937277', '1470934482', '110.167.164.10', '1');
INSERT INTO `tab_user_login_record` VALUES ('134', '1', '神武2', '', '', '45', '20998526', '20998526', '1470934582', '117.28.181.145', '1');
INSERT INTO `tab_user_login_record` VALUES ('135', '1', '神武2', '', '', '45', '20998526', '20998526', '1470934620', '117.28.181.145', '1');
INSERT INTO `tab_user_login_record` VALUES ('136', '1', '神武2', '', '', '45', '20998526', '20998526', '1470934887', '117.28.181.145', '1');
INSERT INTO `tab_user_login_record` VALUES ('137', '1', '神武2', '', '', '45', '20998526', '20998526', '1470934887', '117.28.181.145', '1');
INSERT INTO `tab_user_login_record` VALUES ('138', '1', '神武2', '', '', '45', '20998526', '20998526', '1470934887', '117.28.181.145', '1');
INSERT INTO `tab_user_login_record` VALUES ('139', '1', '神武2', '', '', '45', '20998526', '20998526', '1470934887', '117.28.181.145', '1');
INSERT INTO `tab_user_login_record` VALUES ('140', '1', '神武2', '', '', '45', '20998526', '20998526', '1470934888', '117.28.181.145', '1');
INSERT INTO `tab_user_login_record` VALUES ('141', '1', '神武2', '', '', '45', '20998526', '20998526', '1470934888', '117.28.181.145', '1');
INSERT INTO `tab_user_login_record` VALUES ('142', '1', '神武2', '', '', '66', '18771660262', '18771660262', '1470934989', '223.104.63.57', '1');
INSERT INTO `tab_user_login_record` VALUES ('143', '1', '神武2', '', '', '45', '20998526', '20998526', '1470935424', '117.28.181.145', '1');
INSERT INTO `tab_user_login_record` VALUES ('144', '1', '神武2', '', '', '38', '183383', '183383', '1470935904', '60.248.238.175', '1');
INSERT INTO `tab_user_login_record` VALUES ('145', '1', '神武2', '', '', '38', '183383', '183383', '1470935905', '60.248.238.175', '1');
INSERT INTO `tab_user_login_record` VALUES ('146', '1', '神武2', '', '', '38', '183383', '183383', '1470935905', '60.248.238.175', '1');
INSERT INTO `tab_user_login_record` VALUES ('147', '1', '神武2', '', '', '38', '183383', '183383', '1470935905', '60.248.238.175', '1');
INSERT INTO `tab_user_login_record` VALUES ('148', '1', '神武2', '', '', '38', '183383', '183383', '1470935905', '60.248.238.175', '1');
INSERT INTO `tab_user_login_record` VALUES ('149', '1', '神武2', '', '', '38', '183383', '183383', '1470935906', '60.248.238.175', '1');
INSERT INTO `tab_user_login_record` VALUES ('150', '1', '神武2', '', '', '38', '183383', '183383', '1470935906', '60.248.238.175', '1');
INSERT INTO `tab_user_login_record` VALUES ('151', '1', '神武2', '', '', '38', '183383', '183383', '1470935906', '60.248.238.175', '1');
INSERT INTO `tab_user_login_record` VALUES ('152', '1', '神武2', '', '', '38', '183383', '183383', '1470935906', '60.248.238.175', '1');
INSERT INTO `tab_user_login_record` VALUES ('153', '1', '神武2', '', '', '38', '183383', '183383', '1470935906', '60.248.238.175', '1');
INSERT INTO `tab_user_login_record` VALUES ('154', '1', '神武2', '', '', '51', '15117861717', '15117861717', '1470936603', '114.139.104.39', '1');
INSERT INTO `tab_user_login_record` VALUES ('155', '1', '神武2', '', '', '38', '183383', '183383', '1470937147', '60.248.238.175', '1');
INSERT INTO `tab_user_login_record` VALUES ('156', '1', '神武2', '', '', '67', 'ys779235950', 'ys779235950', '1470937485', '222.85.11.220', '1');
INSERT INTO `tab_user_login_record` VALUES ('157', '1', '神武2', '', '', '38', '183383', '183383', '1470937966', '60.248.238.175', '1');
INSERT INTO `tab_user_login_record` VALUES ('158', '1', '神武2', '', '', '68', '277740768', '277740768', '1470938404', '182.124.103.95', '1');
INSERT INTO `tab_user_login_record` VALUES ('159', '1', '神武2', '', '', '67', 'ys779235950', 'ys779235950', '1470938925', '222.85.11.220', '1');
INSERT INTO `tab_user_login_record` VALUES ('160', '1', '神武2', '', '', '69', 'abc123', 'abc123', '1470938972', '125.71.115.129', '1');
INSERT INTO `tab_user_login_record` VALUES ('161', '1', '神武2', '', '', '69', 'abc123', 'abc123', '1470939042', '125.71.115.129', '1');
INSERT INTO `tab_user_login_record` VALUES ('162', '1', '神武2', '', '', '55', '1196135202', '1196135202', '1470939101', '223.104.2.174', '1');
INSERT INTO `tab_user_login_record` VALUES ('163', '1', '神武2', '', '', '69', 'abc123', 'abc123', '1470939218', '125.71.115.129', '1');
INSERT INTO `tab_user_login_record` VALUES ('164', '1', '神武2', '', '', '69', 'abc123', 'abc123', '1470939300', '125.71.115.129', '1');
INSERT INTO `tab_user_login_record` VALUES ('165', '1', '神武2', '', '', '69', 'abc123', 'abc123', '1470939454', '125.71.115.129', '1');
INSERT INTO `tab_user_login_record` VALUES ('166', '1', '神武2', '', '', '38', '183383', '183383', '1470939621', '60.248.238.175', '1');
INSERT INTO `tab_user_login_record` VALUES ('167', '1', '神武2BT', '', '', '38', '183383', '183383', '1470939842', '60.248.238.175', '1');
INSERT INTO `tab_user_login_record` VALUES ('168', '1', '神武2', '', '', '69', 'abc123', 'abc123', '1470939979', '125.71.115.129', '1');
INSERT INTO `tab_user_login_record` VALUES ('169', '1', '神武2', '', '', '69', 'abc123', 'abc123', '1470940085', '125.71.115.129', '1');
INSERT INTO `tab_user_login_record` VALUES ('170', '1', '神武2', '', '', '69', 'abc123', 'abc123', '1470940240', '125.71.115.129', '1');
INSERT INTO `tab_user_login_record` VALUES ('171', '1', '神武2', '', '', '69', 'abc123', 'abc123', '1470941470', '125.71.115.129', '1');
INSERT INTO `tab_user_login_record` VALUES ('172', '1', '神武2', '', '', '69', 'abc123', 'abc123', '1470941607', '125.71.115.129', '1');
INSERT INTO `tab_user_login_record` VALUES ('173', '1', '神武2', '', '', '69', 'abc123', 'abc123', '1470941654', '125.71.115.129', '1');
INSERT INTO `tab_user_login_record` VALUES ('174', '1', '神武2', '', '', '69', 'abc123', 'abc123', '1470941717', '125.71.115.129', '1');
INSERT INTO `tab_user_login_record` VALUES ('175', '1', '神武2', '', '', '69', 'abc123', 'abc123', '1470941831', '125.71.115.129', '1');
INSERT INTO `tab_user_login_record` VALUES ('176', '1', '神武2BT', '', '', '38', '183383', '183383', '1470941856', '60.248.238.175', '1');
INSERT INTO `tab_user_login_record` VALUES ('177', '1', '神武2', '', '', '69', 'abc123', 'abc123', '1470941885', '125.71.115.129', '1');
INSERT INTO `tab_user_login_record` VALUES ('178', '1', '神武2', '', '', '69', 'abc123', 'abc123', '1470942414', '125.71.115.129', '1');
INSERT INTO `tab_user_login_record` VALUES ('179', '1', '神武2', '', '', '69', 'abc123', 'abc123', '1470942502', '125.71.115.129', '1');
INSERT INTO `tab_user_login_record` VALUES ('180', '1', '神武2', '', '', '69', 'abc123', 'abc123', '1470942640', '125.71.115.129', '1');
INSERT INTO `tab_user_login_record` VALUES ('181', '1', '神武2', '', '', '38', '183383', '183383', '1470942697', '60.248.238.175', '1');
INSERT INTO `tab_user_login_record` VALUES ('182', '1', '神武2', '', '', '69', 'abc123', 'abc123', '1470942786', '125.71.115.129', '1');
INSERT INTO `tab_user_login_record` VALUES ('183', '1', '神武2', '', '', '38', '183383', '183383', '1470942786', '60.248.238.175', '1');
INSERT INTO `tab_user_login_record` VALUES ('184', '1', '神武2', '', '', '38', '183383', '183383', '1470942849', '60.248.238.175', '1');
INSERT INTO `tab_user_login_record` VALUES ('185', '1', '神武2', '', '', '70', '608493', '608493', '1470942978', '125.71.115.129', '1');
INSERT INTO `tab_user_login_record` VALUES ('186', '1', '神武2', '', '', '70', '608493', '608493', '1470943076', '125.71.115.129', '1');
INSERT INTO `tab_user_login_record` VALUES ('187', '1', '神武2', '', '', '71', '332171', '332171', '1470943286', '60.248.238.175', '1');
INSERT INTO `tab_user_login_record` VALUES ('188', '1', '神武2', '', '', '72', '928412', '928412', '1470943348', '60.248.238.175', '1');
INSERT INTO `tab_user_login_record` VALUES ('189', '1', '神武2', '', '', '73', '650265', '650265', '1470943502', '60.248.238.175', '1');
INSERT INTO `tab_user_login_record` VALUES ('190', '1', '神武2', '', '', '74', '926990', '926990', '1470943844', '60.248.238.175', '1');
INSERT INTO `tab_user_login_record` VALUES ('191', '1', '神武2', '', '', '75', '236496', '236496', '1470944037', '60.248.238.175', '1');
INSERT INTO `tab_user_login_record` VALUES ('192', '1', '神武2', '', '', '70', '608493', '608493', '1470944104', '125.71.115.129', '1');
INSERT INTO `tab_user_login_record` VALUES ('193', '1', '神武2', '', '', '75', '236496', '236496', '1470944126', '60.248.238.175', '1');
INSERT INTO `tab_user_login_record` VALUES ('194', '1', '神武2', '', '', '38', '183383', '183383', '1470944353', '60.248.238.175', '1');
INSERT INTO `tab_user_login_record` VALUES ('195', '1', '神武2', '', '', '70', '608493', '608493', '1470944556', '125.71.115.129', '1');
INSERT INTO `tab_user_login_record` VALUES ('196', '1', '神武2', '', '', '69', 'abc123', 'abc123', '1470944570', '125.71.115.129', '1');
INSERT INTO `tab_user_login_record` VALUES ('197', '1', '神武2', '', '', '38', '183383', '183383', '1470945882', '60.248.238.175', '1');
INSERT INTO `tab_user_login_record` VALUES ('198', '1', '神武2', '', '', '38', '183383', '183383', '1470946327', '60.248.238.175', '1');
INSERT INTO `tab_user_login_record` VALUES ('199', '1', '神武2', '', '', '76', '937795', '937795', '1470952553', '117.136.0.187', '1');
INSERT INTO `tab_user_login_record` VALUES ('200', '1', '神武2', '', '', '77', '974778761', '974778761', '1470954891', '113.105.139.212', '1');
INSERT INTO `tab_user_login_record` VALUES ('201', '1', '神武2', '', '', '78', 'lixian1992', 'lixian1992', '1470955286', '1.191.46.93', '1');
INSERT INTO `tab_user_login_record` VALUES ('202', '1', '神武2', '', '', '42', 'caomengyao1636', 'caomengyao1636', '1470955721', '123.138.186.123', '1');
INSERT INTO `tab_user_login_record` VALUES ('203', '1', '神武2', '', '', '67', 'ys779235950', 'ys779235950', '1470955777', '222.85.11.220', '1');
INSERT INTO `tab_user_login_record` VALUES ('204', '1', '神武2', '', '', '67', 'ys779235950', 'ys779235950', '1470955778', '222.85.11.220', '1');
INSERT INTO `tab_user_login_record` VALUES ('205', '1', '神武2', '', '', '67', 'ys779235950', 'ys779235950', '1470955778', '222.85.11.220', '1');
INSERT INTO `tab_user_login_record` VALUES ('206', '1', '神武2', '', '', '67', 'ys779235950', 'ys779235950', '1470955778', '222.85.11.220', '1');
INSERT INTO `tab_user_login_record` VALUES ('207', '1', '神武2', '', '', '67', 'ys779235950', 'ys779235950', '1470955778', '222.85.11.220', '1');
INSERT INTO `tab_user_login_record` VALUES ('208', '1', '神武2', '', '', '67', 'ys779235950', 'ys779235950', '1470955779', '222.85.11.220', '1');
INSERT INTO `tab_user_login_record` VALUES ('209', '1', '神武2', '', '', '67', 'ys779235950', 'ys779235950', '1470955779', '222.85.11.220', '1');
INSERT INTO `tab_user_login_record` VALUES ('210', '1', '神武2', '', '', '78', 'lixian1992', 'lixian1992', '1470955971', '1.191.46.93', '1');
INSERT INTO `tab_user_login_record` VALUES ('211', '1', '神武2', '', '', '79', '18368889337', '18368889337', '1470956536', '122.235.168.55', '1');
INSERT INTO `tab_user_login_record` VALUES ('212', '1', '神武2', '', '', '80', '424022', '424022', '1470957291', '123.206.94.240', '1');
INSERT INTO `tab_user_login_record` VALUES ('213', '1', '神武2', '', '', '80', '424022', '424022', '1470957757', '123.206.94.240', '1');
INSERT INTO `tab_user_login_record` VALUES ('214', '1', '神武2', '', '', '81', 'q7745092', 'q7745092', '1470958017', '113.228.56.194', '1');
INSERT INTO `tab_user_login_record` VALUES ('215', '1', '神武2', '', '', '82', '18503840163', '18503840163', '1470958052', '125.41.160.15', '1');
INSERT INTO `tab_user_login_record` VALUES ('216', '1', '神武2', '', '', '83', '369258', '369258', '1470958278', '175.2.62.1', '1');
INSERT INTO `tab_user_login_record` VALUES ('217', '1', '神武2', '', '', '76', '937795', '937795', '1470959065', '223.104.38.226', '1');
INSERT INTO `tab_user_login_record` VALUES ('218', '1', '神武2', '', '', '84', '123456', '123456', '1470959191', '183.253.130.14', '1');
INSERT INTO `tab_user_login_record` VALUES ('219', '1', '神武2', '', '', '38', '183383', '183383', '1470966710', '60.248.238.175', '1');
INSERT INTO `tab_user_login_record` VALUES ('220', '1', '神武2', '', '', '69', 'abc123', 'abc123', '1470966710', '125.71.115.129', '1');
INSERT INTO `tab_user_login_record` VALUES ('221', '1', '神武2', '', '', '38', '183383', '183383', '1470966711', '60.248.238.175', '1');
INSERT INTO `tab_user_login_record` VALUES ('222', '1', '神武2', '', '', '38', '183383', '183383', '1470966711', '60.248.238.175', '1');
INSERT INTO `tab_user_login_record` VALUES ('223', '1', '神武2', '', '', '38', '183383', '183383', '1470966711', '60.248.238.175', '1');
INSERT INTO `tab_user_login_record` VALUES ('224', '1', '神武2', '', '', '38', '183383', '183383', '1470966711', '60.248.238.175', '1');
INSERT INTO `tab_user_login_record` VALUES ('225', '1', '神武2', '', '', '51', '15117861717', '15117861717', '1470966712', '114.139.104.39', '1');
INSERT INTO `tab_user_login_record` VALUES ('226', '1', '神武2', '', '', '51', '15117861717', '15117861717', '1470966712', '114.139.104.39', '1');
INSERT INTO `tab_user_login_record` VALUES ('227', '1', '神武2', '', '', '51', '15117861717', '15117861717', '1470966712', '114.139.104.39', '1');
INSERT INTO `tab_user_login_record` VALUES ('228', '1', '神武2', '', '', '51', '15117861717', '15117861717', '1470966713', '114.139.104.39', '1');
INSERT INTO `tab_user_login_record` VALUES ('229', '1', '神武2', '', '', '49', 'loklok', 'loklok', '1470966735', '60.52.22.96', '1');
INSERT INTO `tab_user_login_record` VALUES ('230', '1', '神武2', '', '', '85', 'qzqzqz1', 'qzqzqz1', '1470966766', '223.104.19.13', '1');
INSERT INTO `tab_user_login_record` VALUES ('231', '1', '神武2', '', '', '39', '6225540', '6225540', '1470966879', '139.201.153.110', '1');
INSERT INTO `tab_user_login_record` VALUES ('232', '1', '神武2', '', '', '85', 'qzqzqz1', 'qzqzqz1', '1470966881', '223.104.19.13', '1');
INSERT INTO `tab_user_login_record` VALUES ('233', '1', '神武2', '', '', '44', 'ycxinpeng0911', 'ycxinpeng0911', '1470966888', '112.242.19.172', '1');
INSERT INTO `tab_user_login_record` VALUES ('234', '1', '神武2', '', '', '51', '15117861717', '15117861717', '1470966926', '114.139.104.39', '1');
INSERT INTO `tab_user_login_record` VALUES ('235', '1', '神武2', '', '', '45', '20998526', '20998526', '1470967066', '117.28.181.145', '1');
INSERT INTO `tab_user_login_record` VALUES ('236', '1', '神武2', '', '', '85', 'qzqzqz1', 'qzqzqz1', '1470967138', '223.104.19.13', '1');
INSERT INTO `tab_user_login_record` VALUES ('237', '1', '神武2', '', '', '40', 'd123456', 'd123456', '1470967170', '60.222.65.78', '1');
INSERT INTO `tab_user_login_record` VALUES ('238', '1', '神武2', '', '', '86', 'liziang16', 'liziang16', '1470967227', '123.121.135.56', '1');
INSERT INTO `tab_user_login_record` VALUES ('239', '1', '神武2', '', '', '40', 'd123456', 'd123456', '1470967307', '60.222.65.78', '1');
INSERT INTO `tab_user_login_record` VALUES ('240', '1', '神武2', '', '', '51', '15117861717', '15117861717', '1470967602', '114.139.104.39', '1');
INSERT INTO `tab_user_login_record` VALUES ('241', '1', '神武2', '', '', '87', 'feijihao1', 'feijihao1', '1470967830', '59.41.129.50', '1');
INSERT INTO `tab_user_login_record` VALUES ('242', '1', '神武2', '', '', '78', 'lixian1992', 'lixian1992', '1470967831', '1.191.46.93', '1');
INSERT INTO `tab_user_login_record` VALUES ('243', '1', '神武2', '', '', '85', 'qzqzqz1', 'qzqzqz1', '1470967974', '223.104.19.13', '1');
INSERT INTO `tab_user_login_record` VALUES ('244', '1', '神武2', '', '', '85', 'qzqzqz1', 'qzqzqz1', '1470968026', '223.104.19.13', '1');
INSERT INTO `tab_user_login_record` VALUES ('245', '1', '神武2', '', '', '88', '991214', '991214', '1470968174', '101.69.195.140', '1');
INSERT INTO `tab_user_login_record` VALUES ('246', '1', '神武2', '', '', '88', '991214', '991214', '1470968186', '153.99.182.14', '1');
INSERT INTO `tab_user_login_record` VALUES ('247', '1', '神武2', '', '', '88', '991214', '991214', '1470968353', '101.69.195.136', '1');
INSERT INTO `tab_user_login_record` VALUES ('248', '1', '神武2', '', '', '89', '15099889223', '15099889223', '1470968441', '119.127.54.11', '1');
INSERT INTO `tab_user_login_record` VALUES ('249', '1', '神武2', '', '', '89', '15099889223', '15099889223', '1470968671', '119.127.54.11', '1');
INSERT INTO `tab_user_login_record` VALUES ('250', '1', '神武2', '', '', '91', 'qwerqq', 'qwerqq', '1470968701', '42.84.71.123', '1');
INSERT INTO `tab_user_login_record` VALUES ('251', '1', '神武2', '', '', '90', 'q962056', 'q962056', '1470968702', '222.90.70.82', '1');
INSERT INTO `tab_user_login_record` VALUES ('252', '1', '神武2', '', '', '54', '15260363578', '15260363578', '1470968730', '171.12.124.117', '1');
INSERT INTO `tab_user_login_record` VALUES ('253', '1', '神武2', '', '', '92', '130456', '130456', '1470968785', '117.38.155.212', '1');
INSERT INTO `tab_user_login_record` VALUES ('254', '1', '神武2BT', '', '', '93', '397385', '397385', '1470968814', '218.19.138.137', '1');
INSERT INTO `tab_user_login_record` VALUES ('255', '12', '决战中洲', '', '', '94', '237815', '237815', '1470968845', '153.36.68.155', '1');
INSERT INTO `tab_user_login_record` VALUES ('256', '1', '神武2', '', '', '95', '1933951700', '1933951700', '1470968890', '125.70.80.38', '1');
INSERT INTO `tab_user_login_record` VALUES ('257', '12', '决战中洲', '', '', '94', '237815', '237815', '1470968982', '153.36.68.155', '1');
INSERT INTO `tab_user_login_record` VALUES ('258', '1', '神武2', '', '', '44', 'ycxinpeng0911', 'ycxinpeng0911', '1470968997', '112.242.19.172', '1');
INSERT INTO `tab_user_login_record` VALUES ('259', '12', '决战中洲', '', '', '94', '237815', '237815', '1470969112', '153.36.68.155', '1');
INSERT INTO `tab_user_login_record` VALUES ('260', '1', '神武2', '', '', '96', 'wq930411', 'wq930411', '1470969141', '42.48.104.66', '1');
INSERT INTO `tab_user_login_record` VALUES ('261', '1', '神武2', '', '', '97', 'motion', 'motion', '1470969146', '113.71.248.39', '1');
INSERT INTO `tab_user_login_record` VALUES ('262', '1', '神武2', '', '', '98', '821541', '821541', '1470969147', '112.97.61.200', '1');
INSERT INTO `tab_user_login_record` VALUES ('263', '1', '神武2', '', '', '89', '15099889223', '15099889223', '1470969211', '119.127.54.11', '1');
INSERT INTO `tab_user_login_record` VALUES ('264', '1', '神武2', '', '', '89', '15099889223', '15099889223', '1470969220', '119.127.54.11', '1');
INSERT INTO `tab_user_login_record` VALUES ('265', '12', '决战中洲', '', '', '94', '237815', '237815', '1470969249', '153.36.68.155', '1');
INSERT INTO `tab_user_login_record` VALUES ('266', '1', '神武2', '', '', '99', '1173580004', '1173580004', '1470969300', '112.240.97.162', '1');
INSERT INTO `tab_user_login_record` VALUES ('267', '12', '决战中洲', '', '', '94', '237815', '237815', '1470969315', '153.36.68.155', '1');
INSERT INTO `tab_user_login_record` VALUES ('268', '1', '神武2', '', '', '80', '424022', '424022', '1470969605', '123.57.36.242', '1');
INSERT INTO `tab_user_login_record` VALUES ('269', '1', '神武2', '', '', '100', 'zhixi5436', 'zhixi5436', '1470969679', '124.72.181.162', '1');
INSERT INTO `tab_user_login_record` VALUES ('270', '1', '神武2', '', '', '89', '15099889223', '15099889223', '1470969780', '14.215.62.78', '1');
INSERT INTO `tab_user_login_record` VALUES ('271', '1', '神武2', '', '', '38', '183383', '183383', '1470969883', '60.248.238.175', '1');
INSERT INTO `tab_user_login_record` VALUES ('272', '1', '神武2', '', '', '101', '117078124', '117078124', '1470969916', '61.161.170.230', '1');
INSERT INTO `tab_user_login_record` VALUES ('273', '1', '神武2', '', '', '101', '117078124', '117078124', '1470969986', '61.161.170.230', '1');
INSERT INTO `tab_user_login_record` VALUES ('274', '1', '神武2', '', '', '38', '183383', '183383', '1470970020', '60.248.238.175', '1');
INSERT INTO `tab_user_login_record` VALUES ('275', '1', '神武2', '', '', '102', 'qq532371388', 'qq532371388', '1470970064', '36.62.215.8', '1');
INSERT INTO `tab_user_login_record` VALUES ('276', '1', '神武2', '', '', '103', 'lifuchun100', 'lifuchun100', '1470970095', '27.9.106.232', '1');
INSERT INTO `tab_user_login_record` VALUES ('277', '1', '神武2', '', '', '89', '15099889223', '15099889223', '1470970206', '14.215.62.78', '1');
INSERT INTO `tab_user_login_record` VALUES ('278', '12', '决战中洲', '', '', '104', '791455', '791455', '1470970326', '153.36.68.155', '1');
INSERT INTO `tab_user_login_record` VALUES ('279', '1', '神武2', '', '', '105', 'qwe415263', 'qwe415263', '1470970369', '182.244.94.115', '1');
INSERT INTO `tab_user_login_record` VALUES ('280', '12', '决战中洲', '', '', '106', '618693', '618693', '1470970462', '153.36.68.155', '1');
INSERT INTO `tab_user_login_record` VALUES ('281', '12', '决战中洲', '', '', '106', '618693', '618693', '1470970488', '153.36.68.155', '1');
INSERT INTO `tab_user_login_record` VALUES ('282', '1', '神武2', '', '', '107', '18634801194', '18634801194', '1470970503', '123.174.209.81', '1');
INSERT INTO `tab_user_login_record` VALUES ('283', '1', '神武2', '', '', '108', '18206220940', '18206220940', '1470970507', '49.72.152.70', '1');
INSERT INTO `tab_user_login_record` VALUES ('284', '1', '神武2', '', '', '102', 'qq532371388', 'qq532371388', '1470970529', '36.62.215.8', '1');
INSERT INTO `tab_user_login_record` VALUES ('285', '1', '神武2', '', '', '109', '18237396228', '18237396228', '1470970550', '115.62.244.45', '1');
INSERT INTO `tab_user_login_record` VALUES ('286', '12', '决战中洲', '', '', '106', '618693', '618693', '1470970555', '153.36.68.155', '1');
INSERT INTO `tab_user_login_record` VALUES ('287', '1', '神武2', '', '', '110', '136255', '136255', '1470970625', '223.104.13.54', '1');
INSERT INTO `tab_user_login_record` VALUES ('288', '12', '决战中洲', '', '', '106', '618693', '618693', '1470970708', '153.36.68.155', '1');
INSERT INTO `tab_user_login_record` VALUES ('289', '12', '决战中洲', '', '', '111', '621943', '621943', '1470970815', '153.36.68.155', '1');
INSERT INTO `tab_user_login_record` VALUES ('290', '12', '决战中洲', '', '', '112', '700647', '700647', '1470970892', '153.36.68.155', '1');
INSERT INTO `tab_user_login_record` VALUES ('291', '12', '决战中洲', '', '', '112', '700647', '700647', '1470970933', '153.36.68.155', '1');
INSERT INTO `tab_user_login_record` VALUES ('292', '1', '神武2', '', '', '41', 'aa5587831', 'aa5587831', '1470971024', '171.107.17.200', '1');
INSERT INTO `tab_user_login_record` VALUES ('293', '1', '神武2', '', '', '113', 'lxy1350', 'lxy1350', '1470971073', '223.104.20.200', '1');
INSERT INTO `tab_user_login_record` VALUES ('294', '1', '神武2', '', '', '88', '991214', '991214', '1470971088', '180.155.4.156', '1');
INSERT INTO `tab_user_login_record` VALUES ('295', '1', '神武2', '', '', '99', '1173580004', '1173580004', '1470971201', '112.240.97.162', '1');
INSERT INTO `tab_user_login_record` VALUES ('296', '1', '神武2', '', '', '109', '18237396228', '18237396228', '1470971206', '115.62.244.45', '1');
INSERT INTO `tab_user_login_record` VALUES ('297', '1', '神武2', '', '', '98', '821541', '821541', '1470971208', '112.97.61.200', '1');
INSERT INTO `tab_user_login_record` VALUES ('298', '1', '神武2', '', '', '88', '991214', '991214', '1470971251', '180.155.4.156', '1');
INSERT INTO `tab_user_login_record` VALUES ('299', '1', '神武2', '', '', '88', '991214', '991214', '1470971260', '180.155.4.156', '1');
INSERT INTO `tab_user_login_record` VALUES ('300', '12', '决战中洲', '', '', '114', '224912', '224912', '1470971363', '153.36.68.155', '1');
INSERT INTO `tab_user_login_record` VALUES ('301', '1', '神武2', '', '', '89', '15099889223', '15099889223', '1470971658', '119.127.54.11', '1');
INSERT INTO `tab_user_login_record` VALUES ('302', '1', '神武2', '', '', '51', '15117861717', '15117861717', '1470971689', '114.139.104.39', '1');
INSERT INTO `tab_user_login_record` VALUES ('303', '1', '神武2', '', '', '88', '991214', '991214', '1470971885', '120.52.27.125', '1');
INSERT INTO `tab_user_login_record` VALUES ('304', '1', '神武2', '', '', '88', '991214', '991214', '1470971887', '120.52.27.124', '1');
INSERT INTO `tab_user_login_record` VALUES ('305', '1', '神武2', '', '', '88', '991214', '991214', '1470971889', '120.52.27.124', '1');
INSERT INTO `tab_user_login_record` VALUES ('306', '1', '神武2', '', '', '88', '991214', '991214', '1470971890', '120.52.27.124', '1');
INSERT INTO `tab_user_login_record` VALUES ('307', '1', '神武2', '', '', '113', 'lxy1350', 'lxy1350', '1470972034', '223.104.20.200', '1');
INSERT INTO `tab_user_login_record` VALUES ('308', '1', '神武2', '', '', '115', '15016205992', '15016205992', '1470972146', '121.12.126.249', '1');
INSERT INTO `tab_user_login_record` VALUES ('309', '1', '神武2', '', '', '88', '991214', '991214', '1470972237', '120.52.27.125', '1');
INSERT INTO `tab_user_login_record` VALUES ('310', '1', '神武2', '', '', '116', '125729', '125729', '1470972282', '27.210.219.209', '1');
INSERT INTO `tab_user_login_record` VALUES ('311', '1', '神武2', '', '', '117', 'wxainngg', 'wxainngg', '1470972317', '122.236.48.12', '1');
INSERT INTO `tab_user_login_record` VALUES ('312', '1', '神武2', '', '', '109', '18237396228', '18237396228', '1470972356', '115.62.244.45', '1');
INSERT INTO `tab_user_login_record` VALUES ('313', '1', '神武2', '', '', '118', '744221', '744221', '1470972472', '223.104.20.200', '1');
INSERT INTO `tab_user_login_record` VALUES ('314', '1', '神武2', '', '', '119', '860830', '860830', '1470972477', '223.146.89.219', '1');
INSERT INTO `tab_user_login_record` VALUES ('315', '1', '神武2', '', '', '120', '646342', '646342', '1470972590', '110.82.75.178', '1');
INSERT INTO `tab_user_login_record` VALUES ('316', '1', '神武2', '', '', '121', '15201669177', '15201669177', '1470972942', '117.136.0.248', '1');
INSERT INTO `tab_user_login_record` VALUES ('317', '1', '神武2', '', '', '122', 'lxf1230', 'lxf1230', '1470973005', '123.7.77.60', '1');
INSERT INTO `tab_user_login_record` VALUES ('318', '1', '神武2', '', '', '123', 'novoetoe', 'novoetoe', '1470973065', '110.228.254.74', '1');
INSERT INTO `tab_user_login_record` VALUES ('319', '1', '神武2', '', '', '87', 'feijihao1', 'feijihao1', '1470973073', '59.41.129.50', '1');
INSERT INTO `tab_user_login_record` VALUES ('320', '1', '神武2', '', '', '87', 'feijihao1', 'feijihao1', '1470973074', '59.41.129.50', '1');
INSERT INTO `tab_user_login_record` VALUES ('321', '1', '神武2', '', '', '124', '3235028918', '3235028918', '1470973079', '221.196.165.121', '1');
INSERT INTO `tab_user_login_record` VALUES ('322', '1', '神武2', '', '', '123', 'novoetoe', 'novoetoe', '1470973156', '110.228.254.74', '1');
INSERT INTO `tab_user_login_record` VALUES ('323', '1', '神武2', '', '', '125', 'xzl123', 'xzl123', '1470973215', '1.198.177.200', '1');
INSERT INTO `tab_user_login_record` VALUES ('324', '1', '神武2', '', '', '102', 'qq532371388', 'qq532371388', '1470973234', '36.62.215.8', '1');
INSERT INTO `tab_user_login_record` VALUES ('325', '1', '神武2', '', '', '121', '15201669177', '15201669177', '1470973393', '117.136.0.248', '1');
INSERT INTO `tab_user_login_record` VALUES ('326', '1', '神武2', '', '', '126', 'a634788', 'a634788', '1470973410', '60.181.150.62', '1');
INSERT INTO `tab_user_login_record` VALUES ('327', '12', '决战中洲', '', '', '127', '537308', '537308', '1470973417', '153.36.68.155', '1');
INSERT INTO `tab_user_login_record` VALUES ('328', '1', '神武2', '', '', '115', '15016205992', '15016205992', '1470973451', '113.105.169.18', '1');
INSERT INTO `tab_user_login_record` VALUES ('329', '1', '神武2', '', '', '128', '149999', '149999', '1470973452', '36.62.215.8', '1');
INSERT INTO `tab_user_login_record` VALUES ('330', '1', '神武2', '', '', '125', 'xzl123', 'xzl123', '1470973532', '1.198.177.200', '1');
INSERT INTO `tab_user_login_record` VALUES ('331', '1', '神武2', '', '', '128', '149999', '149999', '1470973640', '36.62.215.8', '1');
INSERT INTO `tab_user_login_record` VALUES ('332', '1', '神武2', '', '', '129', 'wjx0503', 'wjx0503', '1470973662', '106.43.195.157', '1');
INSERT INTO `tab_user_login_record` VALUES ('333', '1', '神武2', '', '', '128', '149999', '149999', '1470973792', '36.62.215.8', '1');
INSERT INTO `tab_user_login_record` VALUES ('334', '1', '神武2', '', '', '130', 'xing0188', 'xing0188', '1470973979', '27.186.208.2', '1');
INSERT INTO `tab_user_login_record` VALUES ('335', '1', '神武2', '', '', '121', '15201669177', '15201669177', '1470973995', '117.136.0.248', '1');
INSERT INTO `tab_user_login_record` VALUES ('336', '12', '决战中洲', '', '', '131', '976217', '976217', '1470974092', '153.36.68.155', '1');
INSERT INTO `tab_user_login_record` VALUES ('337', '1', '神武2', '', '', '132', 'zn2615', 'zn2615', '1470974189', '61.153.156.62', '1');
INSERT INTO `tab_user_login_record` VALUES ('338', '1', '神武2', '', '', '133', '444807', '444807', '1470974218', '1.181.190.12', '1');
INSERT INTO `tab_user_login_record` VALUES ('339', '12', '决战中洲', '', '', '134', '443354', '443354', '1470974316', '153.36.68.155', '1');
INSERT INTO `tab_user_login_record` VALUES ('340', '12', '决战中洲', '', '', '134', '443354', '443354', '1470974358', '153.36.68.155', '1');
INSERT INTO `tab_user_login_record` VALUES ('341', '1', '神武2', '', '', '135', 'whdonkey', 'whdonkey', '1470974381', '114.224.59.129', '1');
INSERT INTO `tab_user_login_record` VALUES ('342', '1', '神武2', '', '', '136', 'mzhyy888', 'mzhyy888', '1470974454', '58.52.29.74', '1');
INSERT INTO `tab_user_login_record` VALUES ('343', '1', '神武2', '', '', '92', '130456', '130456', '1470974555', '117.38.155.212', '1');
INSERT INTO `tab_user_login_record` VALUES ('344', '1', '神武2', '', '', '137', 'a857248868', 'a857248868', '1470974732', '117.136.4.177', '1');
INSERT INTO `tab_user_login_record` VALUES ('345', '1', '神武2', '', '', '138', '527764', '527764', '1470974787', '211.150.88.46', '1');
INSERT INTO `tab_user_login_record` VALUES ('346', '1', '神武2', '', '', '139', 'wolfkill', 'wolfkill', '1470974790', '113.76.154.148', '1');
INSERT INTO `tab_user_login_record` VALUES ('347', '1', '神武2', '', '', '97', 'motion', 'motion', '1470974803', '113.71.248.39', '1');
INSERT INTO `tab_user_login_record` VALUES ('348', '1', '神武2', '', '', '140', '7484372', '7484372', '1470974822', '14.215.54.36', '1');
INSERT INTO `tab_user_login_record` VALUES ('349', '1', '神武2', '', '', '141', '15864110597', '15864110597', '1470974923', '27.39.225.166', '1');
INSERT INTO `tab_user_login_record` VALUES ('350', '1', '神武2', '', '', '142', '428666', '428666', '1470974945', '183.54.160.150', '1');
INSERT INTO `tab_user_login_record` VALUES ('351', '1', '神武2', '', '', '143', '18325505542', '18325505542', '1470975018', '114.103.216.149', '1');
INSERT INTO `tab_user_login_record` VALUES ('352', '1', '神武2', '', '', '99', '1173580004', '1173580004', '1470975055', '112.240.97.162', '1');
INSERT INTO `tab_user_login_record` VALUES ('353', '1', '神武2', '', '', '144', 'QQ3075261534', 'QQ3075261534', '1470975064', '218.16.170.26', '1');
INSERT INTO `tab_user_login_record` VALUES ('354', '1', '神武2', '', '', '123', 'novoetoe', 'novoetoe', '1470975133', '223.104.13.4', '1');
INSERT INTO `tab_user_login_record` VALUES ('355', '1', '神武2', '', '', '145', 'wxy520', 'wxy520', '1470975196', '122.139.100.248', '1');
INSERT INTO `tab_user_login_record` VALUES ('356', '1', '神武2', '', '', '98', '821541', '821541', '1470975219', '112.97.61.200', '1');
INSERT INTO `tab_user_login_record` VALUES ('357', '1', '神武2', '', '', '137', 'a857248868', 'a857248868', '1470975327', '117.136.4.177', '1');
INSERT INTO `tab_user_login_record` VALUES ('358', '1', '神武2', '', '', '44', 'ycxinpeng0911', 'ycxinpeng0911', '1470975361', '27.207.77.40', '1');
INSERT INTO `tab_user_login_record` VALUES ('359', '1', '神武2', '', '', '146', 'alv369', 'alv369', '1470975390', '113.138.166.116', '1');
INSERT INTO `tab_user_login_record` VALUES ('360', '1', '神武2', '', '', '147', 'q135345', 'q135345', '1470975436', '219.130.239.40', '1');
INSERT INTO `tab_user_login_record` VALUES ('361', '1', '神武2', '', '', '123', 'novoetoe', 'novoetoe', '1470975602', '60.0.113.198', '1');
INSERT INTO `tab_user_login_record` VALUES ('362', '1', '神武2', '', '', '123', 'novoetoe', 'novoetoe', '1470975785', '60.0.113.198', '1');
INSERT INTO `tab_user_login_record` VALUES ('363', '1', '神武2', '', '', '149', '15156589827', '15156589827', '1470975890', '223.104.18.65', '1');
INSERT INTO `tab_user_login_record` VALUES ('364', '1', '神武2', '', '', '150', '847421822', '847421822', '1470975922', '219.137.118.217', '1');
INSERT INTO `tab_user_login_record` VALUES ('365', '1', '神武2', '', '', '151', '500146', '500146', '1470975994', '183.46.224.158', '1');
INSERT INTO `tab_user_login_record` VALUES ('366', '1', '神武2', '', '', '152', '13533664553', '13533664553', '1470976005', '58.62.37.168', '1');
INSERT INTO `tab_user_login_record` VALUES ('367', '1', '神武2', '', '', '150', '847421822', '847421822', '1470976026', '219.137.118.217', '1');
INSERT INTO `tab_user_login_record` VALUES ('368', '1', '神武2', '', '', '153', 'kang01', 'kang01', '1470976079', '218.56.104.114', '1');
INSERT INTO `tab_user_login_record` VALUES ('369', '1', '神武2', '', '', '154', 'likulili', 'likulili', '1470976134', '58.22.113.103', '1');
INSERT INTO `tab_user_login_record` VALUES ('370', '1', '神武2', '', '', '38', '183383', '183383', '1470976165', '60.248.238.175', '1');
INSERT INTO `tab_user_login_record` VALUES ('371', '1', '神武2', '', '', '155', '826499', '826499', '1470976167', '123.161.99.162', '1');
INSERT INTO `tab_user_login_record` VALUES ('372', '1', '神武2', '', '', '137', 'a857248868', 'a857248868', '1470976340', '117.136.4.177', '1');
INSERT INTO `tab_user_login_record` VALUES ('373', '1', '神武2', '', '', '115', '15016205992', '15016205992', '1470976610', '121.12.126.249', '1');
INSERT INTO `tab_user_login_record` VALUES ('374', '1', '神武2', '', '', '98', '821541', '821541', '1470976696', '112.97.61.200', '1');
INSERT INTO `tab_user_login_record` VALUES ('375', '1', '神武2', '', '', '141', '15864110597', '15864110597', '1470976707', '27.39.225.166', '1');
INSERT INTO `tab_user_login_record` VALUES ('376', '1', '神武2', '', '', '69', 'abc123', 'abc123', '1470976751', '125.71.115.129', '1');
INSERT INTO `tab_user_login_record` VALUES ('377', '1', '神武2', '', '', '97', 'motion', 'motion', '1470976776', '113.71.248.39', '1');
INSERT INTO `tab_user_login_record` VALUES ('378', '1', '神武2', '', '', '156', '13912806950', '13912806950', '1470976784', '180.118.199.149', '1');
INSERT INTO `tab_user_login_record` VALUES ('379', '1', '神武2', '', '', '156', '13912806950', '13912806950', '1470976917', '180.118.199.149', '1');
INSERT INTO `tab_user_login_record` VALUES ('380', '1', '神武2', '', '', '157', 'alex317', 'alex317', '1470976923', '125.66.15.197', '1');
INSERT INTO `tab_user_login_record` VALUES ('381', '1', '神武2', '', '', '158', 'cxxcxx', 'cxxcxx', '1470977123', '61.153.44.110', '1');
INSERT INTO `tab_user_login_record` VALUES ('382', '1', '神武2', '', '', '149', '15156589827', '15156589827', '1470977252', '223.104.18.65', '1');
INSERT INTO `tab_user_login_record` VALUES ('383', '1', '神武2', '', '', '159', '874064170', '874064170', '1470977271', '42.236.140.55', '1');
INSERT INTO `tab_user_login_record` VALUES ('384', '1', '神武2', '', '', '160', '18873835270', '18873835270', '1470977307', '59.34.43.20', '1');
INSERT INTO `tab_user_login_record` VALUES ('385', '1', '神武2', '', '', '159', '874064170', '874064170', '1470977324', '42.236.140.55', '1');
INSERT INTO `tab_user_login_record` VALUES ('386', '1', '神武2', '', '', '160', '18873835270', '18873835270', '1470977378', '59.34.43.20', '1');
INSERT INTO `tab_user_login_record` VALUES ('387', '1', '神武2', '', '', '44', 'ycxinpeng0911', 'ycxinpeng0911', '1470977412', '27.207.77.40', '1');
INSERT INTO `tab_user_login_record` VALUES ('388', '1', '神武2', '', '', '161', 'zzz123456', 'zzz123456', '1470977471', '115.62.221.241', '1');
INSERT INTO `tab_user_login_record` VALUES ('389', '1', '神武2', '', '', '162', '13730199076', '13730199076', '1470977479', '180.213.177.87', '1');
INSERT INTO `tab_user_login_record` VALUES ('390', '1', '神武2', '', '', '163', 'a154477', 'a154477', '1470977565', '42.227.88.106', '1');
INSERT INTO `tab_user_login_record` VALUES ('391', '1', '神武2', '', '', '158', 'cxxcxx', 'cxxcxx', '1470977597', '61.153.44.110', '1');
INSERT INTO `tab_user_login_record` VALUES ('392', '1', '神武2', '', '', '162', '13730199076', '13730199076', '1470977689', '180.213.177.87', '1');
INSERT INTO `tab_user_login_record` VALUES ('393', '1', '神武2', '', '', '164', 'a475285220', 'a475285220', '1470977710', '36.249.225.109', '1');
INSERT INTO `tab_user_login_record` VALUES ('394', '1', '神武2', '', '', '165', 'zzz123456789', 'zzz123456789', '1470977730', '113.79.232.42', '1');
INSERT INTO `tab_user_login_record` VALUES ('395', '1', '神武2', '', '', '162', '13730199076', '13730199076', '1470977734', '180.213.177.87', '1');
INSERT INTO `tab_user_login_record` VALUES ('396', '1', '神武2', '', '', '149', '15156589827', '15156589827', '1470977840', '223.104.18.65', '1');
INSERT INTO `tab_user_login_record` VALUES ('397', '1', '神武2', '', '', '166', '643074', '643074', '1470977883', '113.235.217.172', '1');
INSERT INTO `tab_user_login_record` VALUES ('398', '1', '神武2', '', '', '167', '18504842291', '18504842291', '1470977926', '116.115.77.217', '1');
INSERT INTO `tab_user_login_record` VALUES ('399', '1', '神武2', '', '', '120', '646342', '646342', '1470977940', '117.136.75.111', '1');
INSERT INTO `tab_user_login_record` VALUES ('400', '1', '神武2', '', '', '164', 'a475285220', 'a475285220', '1470977971', '36.249.225.109', '1');
INSERT INTO `tab_user_login_record` VALUES ('401', '1', '神武2', '', '', '125', 'xzl123', 'xzl123', '1470978010', '1.198.177.200', '1');
INSERT INTO `tab_user_login_record` VALUES ('402', '1', '神武2', '', '', '167', '18504842291', '18504842291', '1470978028', '116.115.77.217', '1');
INSERT INTO `tab_user_login_record` VALUES ('403', '1', '神武2', '', '', '168', '342411', '342411', '1470978073', '114.221.181.84', '1');
INSERT INTO `tab_user_login_record` VALUES ('404', '1', '神武2', '', '', '169', 'meng6532745', 'meng6532745', '1470978106', '125.77.45.157', '1');
INSERT INTO `tab_user_login_record` VALUES ('405', '1', '神武2', '', '', '39', '6225540', '6225540', '1470978152', '139.201.153.110', '1');
INSERT INTO `tab_user_login_record` VALUES ('406', '1', '神武2', '', '', '170', 'liu3653953', 'liu3653953', '1470978211', '42.224.229.86', '1');
INSERT INTO `tab_user_login_record` VALUES ('407', '1', '神武2', '', '', '138', '527764', '527764', '1470978214', '117.136.0.252', '1');
INSERT INTO `tab_user_login_record` VALUES ('408', '1', '神武2', '', '', '158', 'cxxcxx', 'cxxcxx', '1470978381', '61.153.44.110', '1');
INSERT INTO `tab_user_login_record` VALUES ('409', '1', '神武2', '', '', '171', '649861', '649861', '1470978459', '106.114.146.253', '1');
INSERT INTO `tab_user_login_record` VALUES ('410', '1', '神武2', '', '', '172', 'hang02122015', 'hang02122015', '1470978650', '124.163.246.203', '1');
INSERT INTO `tab_user_login_record` VALUES ('411', '1', '神武2', '', '', '173', '1049668470', '1049668470', '1470978664', '222.209.151.181', '1');
INSERT INTO `tab_user_login_record` VALUES ('412', '1', '神武2', '', '', '174', 'bnhjkl2016', 'bnhjkl2016', '1470978929', '103.44.207.33', '1');
INSERT INTO `tab_user_login_record` VALUES ('413', '1', '神武2', '', '', '174', 'bnhjkl2016', 'bnhjkl2016', '1470978942', '103.44.207.33', '1');
INSERT INTO `tab_user_login_record` VALUES ('414', '1', '神武2', '', '', '173', '1049668470', '1049668470', '1470978955', '222.209.151.181', '1');
INSERT INTO `tab_user_login_record` VALUES ('415', '1', '神武2', '', '', '169', 'meng6532745', 'meng6532745', '1470979304', '125.77.45.157', '1');
INSERT INTO `tab_user_login_record` VALUES ('416', '1', '神武2', '', '', '175', 'aa8549', 'aa8549', '1470979314', '115.62.221.241', '1');
INSERT INTO `tab_user_login_record` VALUES ('417', '1', '神武2', '', '', '176', '345345', '345345', '1470979344', '60.221.133.203', '1');
INSERT INTO `tab_user_login_record` VALUES ('418', '1', '神武2', '', '', '175', 'aa8549', 'aa8549', '1470979507', '115.62.221.241', '1');
INSERT INTO `tab_user_login_record` VALUES ('419', '1', '神武2', '', '', '175', 'aa8549', 'aa8549', '1470979675', '115.62.221.241', '1');
INSERT INTO `tab_user_login_record` VALUES ('420', '1', '神武2', '', '', '175', 'aa8549', 'aa8549', '1470979750', '115.62.221.241', '1');
INSERT INTO `tab_user_login_record` VALUES ('421', '1', '神武2', '', '', '177', '8629131jun', '8629131jun', '1470979853', '125.90.85.0', '1');
INSERT INTO `tab_user_login_record` VALUES ('422', '1', '神武2', '', '', '177', '8629131jun', '8629131jun', '1470979966', '125.90.85.0', '1');
INSERT INTO `tab_user_login_record` VALUES ('423', '1', '神武2', '', '', '161', 'zzz123456', 'zzz123456', '1470979982', '115.62.221.241', '1');
INSERT INTO `tab_user_login_record` VALUES ('424', '1', '神武2', '', '', '178', 'lty123', 'lty123', '1470979983', '58.250.117.211', '1');
INSERT INTO `tab_user_login_record` VALUES ('425', '1', '神武2', '', '', '177', '8629131jun', '8629131jun', '1470980016', '125.90.85.0', '1');
INSERT INTO `tab_user_login_record` VALUES ('426', '12', '决战中洲', '', '', '179', '368990', '368990', '1470980337', '153.36.68.155', '1');
INSERT INTO `tab_user_login_record` VALUES ('427', '12', '决战中洲', '', '', '180', '777888', '777888', '1470980354', '153.36.68.155', '1');
INSERT INTO `tab_user_login_record` VALUES ('428', '1', '神武2', '', '', '167', '18504842291', '18504842291', '1470980460', '116.115.77.217', '1');
INSERT INTO `tab_user_login_record` VALUES ('429', '1', '神武2', '', '', '180', '777888', '777888', '1470980534', '153.36.68.155', '1');
INSERT INTO `tab_user_login_record` VALUES ('430', '1', '神武2', '', '', '180', '777888', '777888', '1470980574', '153.36.68.155', '1');
INSERT INTO `tab_user_login_record` VALUES ('431', '1', '神武2', '', '', '180', '777888', '777888', '1470980583', '153.36.68.155', '1');
INSERT INTO `tab_user_login_record` VALUES ('432', '1', '神武2', '', '', '181', 'mao5524', 'mao5524', '1470980906', '58.222.216.98', '1');
INSERT INTO `tab_user_login_record` VALUES ('433', '1', '神武2', '', '', '180', '777888', '777888', '1470980908', '153.36.68.155', '1');
INSERT INTO `tab_user_login_record` VALUES ('434', '1', '神武2', '', '', '168', '342411', '342411', '1470980924', '180.110.229.32', '1');
INSERT INTO `tab_user_login_record` VALUES ('435', '1', '神武2', '', '', '182', '1440886144', '1440886144', '1470981042', '36.5.37.131', '1');
INSERT INTO `tab_user_login_record` VALUES ('436', '1', '神武2', '', '', '180', '777888', '777888', '1470981112', '153.36.68.155', '1');
INSERT INTO `tab_user_login_record` VALUES ('437', '1', '神武2', '', '', '180', '777888', '777888', '1470981164', '153.36.68.155', '1');
INSERT INTO `tab_user_login_record` VALUES ('438', '1', '神武2', '', '', '88', '991214', '991214', '1470981206', '101.69.195.146', '1');
INSERT INTO `tab_user_login_record` VALUES ('439', '12', '决战中洲', '', '', '180', '777888', '777888', '1470981327', '153.36.68.155', '1');
INSERT INTO `tab_user_login_record` VALUES ('440', '12', '决战中洲', '', '', '183', '761207', '761207', '1470981549', '153.36.68.155', '1');
INSERT INTO `tab_user_login_record` VALUES ('441', '1', '神武2', '', '', '184', '123456ok', '123456ok', '1470981555', '117.10.0.98', '1');
INSERT INTO `tab_user_login_record` VALUES ('442', '12', '决战中洲', '', '', '183', '761207', '761207', '1470981630', '153.36.68.155', '1');
INSERT INTO `tab_user_login_record` VALUES ('443', '1', '神武2', '', '', '88', '991214', '991214', '1470981640', '120.52.27.124', '1');
INSERT INTO `tab_user_login_record` VALUES ('444', '1', '神武2', '', '', '120', '646342', '646342', '1470981844', '117.136.75.111', '1');
INSERT INTO `tab_user_login_record` VALUES ('445', '1', '神武2', '', '', '128', '149999', '149999', '1470981848', '36.62.215.8', '1');
INSERT INTO `tab_user_login_record` VALUES ('446', '1', '神武2', '', '', '178', 'lty123', 'lty123', '1470981852', '58.250.117.211', '1');
INSERT INTO `tab_user_login_record` VALUES ('447', '1', '神武2', '', '', '185', '787083', '787083', '1470981853', '61.158.152.197', '1');
INSERT INTO `tab_user_login_record` VALUES ('448', '1', '神武2', '', '', '185', '787083', '787083', '1470981857', '61.158.152.197', '1');
INSERT INTO `tab_user_login_record` VALUES ('449', '1', '神武2', '', '', '186', 'lzl0227', 'lzl0227', '1470981896', '125.39.51.250', '1');
INSERT INTO `tab_user_login_record` VALUES ('450', '1', '神武2', '', '', '68', '277740768', '277740768', '1470981899', '182.124.103.95', '1');
INSERT INTO `tab_user_login_record` VALUES ('451', '1', '神武2', '', '', '187', '285023', '285023', '1470981995', '61.139.239.227', '1');
INSERT INTO `tab_user_login_record` VALUES ('452', '1', '神武2', '', '', '188', 'xiaoquan', 'xiaoquan', '1470981995', '116.115.190.218', '1');
INSERT INTO `tab_user_login_record` VALUES ('453', '1', '神武2', '', '', '172', 'hang02122015', 'hang02122015', '1470982008', '124.163.246.203', '1');
INSERT INTO `tab_user_login_record` VALUES ('454', '1', '神武2', '', '', '189', 'ko5211314', 'ko5211314', '1470982469', '116.216.18.6', '1');
INSERT INTO `tab_user_login_record` VALUES ('455', '1', '神武2', '', '', '190', '510409', '510409', '1470982521', '117.40.228.7', '1');
INSERT INTO `tab_user_login_record` VALUES ('456', '1', '神武2', '', '', '161', 'zzz123456', 'zzz123456', '1470982611', '115.62.221.241', '1');
INSERT INTO `tab_user_login_record` VALUES ('457', '1', '神武2', '', '', '161', 'zzz123456', 'zzz123456', '1470982612', '115.62.221.241', '1');
INSERT INTO `tab_user_login_record` VALUES ('458', '1', '神武2', '', '', '99', '1173580004', '1173580004', '1470982623', '112.240.97.162', '1');
INSERT INTO `tab_user_login_record` VALUES ('459', '1', '神武2', '', '', '173', '1049668470', '1049668470', '1470982714', '222.209.151.181', '1');
INSERT INTO `tab_user_login_record` VALUES ('460', '1', '神武2', '', '', '191', '18920423096', '18920423096', '1470982773', '106.121.5.200', '1');
INSERT INTO `tab_user_login_record` VALUES ('461', '12', '决战中洲', '', '', '192', '388866', '388866', '1470982927', '153.36.68.155', '1');
INSERT INTO `tab_user_login_record` VALUES ('462', '1', '神武2', '', '', '45', '20998526', '20998526', '1470982966', '117.28.181.145', '1');
INSERT INTO `tab_user_login_record` VALUES ('463', '12', '决战中洲', '', '', '192', '388866', '388866', '1470982973', '153.36.68.155', '1');
INSERT INTO `tab_user_login_record` VALUES ('464', '12', '决战中洲', '', '', '192', '388866', '388866', '1470982983', '153.36.68.155', '1');
INSERT INTO `tab_user_login_record` VALUES ('465', '1', '神武2', '', '', '193', 'kangdong84', 'kangdong84', '1470983290', '106.114.23.101', '1');
INSERT INTO `tab_user_login_record` VALUES ('466', '1', '神武2', '', '', '194', '2738436711', '2738436711', '1470983398', '171.121.165.48', '1');
INSERT INTO `tab_user_login_record` VALUES ('467', '1', '神武2', '', '', '161', 'zzz123456', 'zzz123456', '1470983485', '223.104.19.82', '1');
INSERT INTO `tab_user_login_record` VALUES ('468', '1', '神武2', '', '', '162', '13730199076', '13730199076', '1470983518', '117.136.54.43', '1');
INSERT INTO `tab_user_login_record` VALUES ('469', '1', '神武2', '', '', '87', 'feijihao1', 'feijihao1', '1470983527', '59.41.129.50', '1');
INSERT INTO `tab_user_login_record` VALUES ('470', '12', '决战中洲', '', '', '192', '388866', '388866', '1470983575', '153.36.68.155', '1');
INSERT INTO `tab_user_login_record` VALUES ('471', '1', '神武2', '', '', '193', 'kangdong84', 'kangdong84', '1470983594', '106.114.23.101', '1');
INSERT INTO `tab_user_login_record` VALUES ('472', '1', '神武2', '', '', '195', '609398', '609398', '1470983621', '218.82.195.71', '1');
INSERT INTO `tab_user_login_record` VALUES ('473', '1', '神武2', '', '', '196', '13002096204', '13002096204', '1470983671', '112.5.71.61', '1');
INSERT INTO `tab_user_login_record` VALUES ('474', '12', '决战中洲', '', '', '197', '838725', '838725', '1470983690', '153.36.68.155', '1');
INSERT INTO `tab_user_login_record` VALUES ('475', '1', '神武2', '', '', '198', 'a6164282a', 'a6164282a', '1470983782', '106.226.12.51', '1');
INSERT INTO `tab_user_login_record` VALUES ('476', '12', '决战中洲', '', '', '199', '789390', '789390', '1470983862', '153.36.68.155', '1');
INSERT INTO `tab_user_login_record` VALUES ('477', '1', '神武2', '', '', '195', '609398', '609398', '1470983879', '218.82.195.71', '1');
INSERT INTO `tab_user_login_record` VALUES ('478', '12', '决战中洲', '', '', '199', '789390', '789390', '1470983925', '153.36.68.155', '1');
INSERT INTO `tab_user_login_record` VALUES ('479', '1', '神武2', '', '', '194', '2738436711', '2738436711', '1470984066', '171.121.165.48', '1');
INSERT INTO `tab_user_login_record` VALUES ('480', '12', '决战中洲', '', '', '199', '789390', '789390', '1470984067', '153.36.68.155', '1');
INSERT INTO `tab_user_login_record` VALUES ('481', '12', '决战中洲', '', '', '180', '777888', '777888', '1470984201', '153.36.68.155', '1');
INSERT INTO `tab_user_login_record` VALUES ('482', '1', '神武2', '', '', '200', '18121728357', '18121728357', '1470984205', '49.95.206.184', '1');
INSERT INTO `tab_user_login_record` VALUES ('483', '1', '神武2', '', '', '193', 'kangdong84', 'kangdong84', '1470984227', '106.114.23.101', '1');
INSERT INTO `tab_user_login_record` VALUES ('484', '12', '决战中洲', '', '', '180', '777888', '777888', '1470984277', '153.36.68.155', '1');
INSERT INTO `tab_user_login_record` VALUES ('485', '12', '决战中洲', '', '', '180', '777888', '777888', '1470984295', '153.36.68.155', '1');
INSERT INTO `tab_user_login_record` VALUES ('486', '12', '决战中洲', '', '', '180', '777888', '777888', '1470984332', '153.36.68.155', '1');
INSERT INTO `tab_user_login_record` VALUES ('487', '12', '决战中洲', '', '', '180', '777888', '777888', '1470984398', '153.36.68.155', '1');
INSERT INTO `tab_user_login_record` VALUES ('488', '1', '神武2', '', '', '201', 'a07088', 'a07088', '1470984422', '1.82.205.155', '1');
INSERT INTO `tab_user_login_record` VALUES ('489', '1', '神武2', '', '', '178', 'lty123', 'lty123', '1470984507', '58.250.117.211', '1');
INSERT INTO `tab_user_login_record` VALUES ('490', '12', '决战中洲', '', '', '180', '777888', '777888', '1470984578', '153.36.68.155', '1');
INSERT INTO `tab_user_login_record` VALUES ('491', '12', '决战中洲', '', '', '180', '777888', '777888', '1470984622', '153.36.68.155', '1');
INSERT INTO `tab_user_login_record` VALUES ('492', '12', '决战中洲', '', '', '180', '777888', '777888', '1470984665', '153.36.68.155', '1');
INSERT INTO `tab_user_login_record` VALUES ('493', '1', '神武2', '', '', '202', '1247682966', '1247682966', '1470984675', '183.162.46.137', '1');
INSERT INTO `tab_user_login_record` VALUES ('494', '1', '神武2', '', '', '202', '1247682966', '1247682966', '1470984689', '183.162.46.137', '1');
INSERT INTO `tab_user_login_record` VALUES ('495', '12', '决战中洲', '', '', '180', '777888', '777888', '1470984705', '153.36.68.155', '1');
INSERT INTO `tab_user_login_record` VALUES ('496', '1', '神武2', '', '', '202', '1247682966', '1247682966', '1470984753', '183.162.46.137', '1');
INSERT INTO `tab_user_login_record` VALUES ('497', '1', '神武2', '', '', '126', 'a634788', 'a634788', '1470984763', '60.181.150.62', '1');
INSERT INTO `tab_user_login_record` VALUES ('498', '12', '决战中洲', '', '', '180', '777888', '777888', '1470984802', '153.36.68.155', '1');
INSERT INTO `tab_user_login_record` VALUES ('499', '1', '神武2', '', '', '203', 'ak9584', 'ak9584', '1470984960', '61.185.133.2', '1');
INSERT INTO `tab_user_login_record` VALUES ('500', '1', '神武2', '', '', '204', '271311', '271311', '1470984963', '113.84.179.199', '1');
INSERT INTO `tab_user_login_record` VALUES ('501', '12', '决战中洲', '', '', '180', '777888', '777888', '1470984966', '153.36.68.155', '1');
INSERT INTO `tab_user_login_record` VALUES ('502', '1', '神武2', '', '', '41', 'aa5587831', 'aa5587831', '1470985195', '171.107.17.200', '1');
INSERT INTO `tab_user_login_record` VALUES ('503', '1', '神武2', '', '', '205', '409059', '409059', '1470985285', '112.192.17.172', '1');
INSERT INTO `tab_user_login_record` VALUES ('504', '1', '神武2', '', '', '206', '111383', '111383', '1470985390', '125.39.51.241', '1');
INSERT INTO `tab_user_login_record` VALUES ('505', '12', '决战中洲', '', '', '180', '777888', '777888', '1470985508', '153.36.68.155', '1');
INSERT INTO `tab_user_login_record` VALUES ('506', '1', '神武2', '', '', '207', '448402', '448402', '1470985530', '117.136.69.39', '1');
INSERT INTO `tab_user_login_record` VALUES ('507', '1', '神武2', '', '', '207', '448402', '448402', '1470985543', '117.136.69.39', '1');
INSERT INTO `tab_user_login_record` VALUES ('508', '1', '神武2', '', '', '178', 'lty123', 'lty123', '1470985546', '58.250.117.211', '1');
INSERT INTO `tab_user_login_record` VALUES ('509', '1', '神武2', '', '', '90', 'q962056', 'q962056', '1470985582', '124.114.123.174', '1');
INSERT INTO `tab_user_login_record` VALUES ('510', '12', '决战中洲', '', '', '180', '777888', '777888', '1470985668', '153.36.68.155', '1');
INSERT INTO `tab_user_login_record` VALUES ('511', '1', '神武2', '', '', '203', 'ak9584', 'ak9584', '1470985706', '61.185.133.2', '1');
INSERT INTO `tab_user_login_record` VALUES ('512', '12', '决战中洲', '', '', '180', '777888', '777888', '1470985721', '153.36.68.155', '1');
INSERT INTO `tab_user_login_record` VALUES ('513', '1', '神武2', '', '', '126', 'a634788', 'a634788', '1470985736', '60.181.150.62', '1');
INSERT INTO `tab_user_login_record` VALUES ('514', '1', '神武2', '', '', '178', 'lty123', 'lty123', '1470985766', '58.250.117.211', '1');
INSERT INTO `tab_user_login_record` VALUES ('515', '1', '神武2', '', '', '208', 'A295334930', 'A295334930', '1470985972', '221.207.37.57', '1');
INSERT INTO `tab_user_login_record` VALUES ('516', '12', '决战中洲', '', '', '180', '777888', '777888', '1470986001', '153.36.68.155', '1');
INSERT INTO `tab_user_login_record` VALUES ('517', '12', '决战中洲', '', '', '180', '777888', '777888', '1470986002', '153.36.68.155', '1');
INSERT INTO `tab_user_login_record` VALUES ('518', '12', '决战中洲', '', '', '180', '777888', '777888', '1470986008', '153.36.68.155', '1');
INSERT INTO `tab_user_login_record` VALUES ('519', '12', '决战中洲', '', '', '180', '777888', '777888', '1470986014', '153.36.68.155', '1');
INSERT INTO `tab_user_login_record` VALUES ('520', '1', '神武2', '', '', '51', '15117861717', '15117861717', '1470986019', '114.139.104.39', '1');
INSERT INTO `tab_user_login_record` VALUES ('521', '1', '神武2', '', '', '209', 'qweasdcdc', 'qweasdcdc', '1470986031', '113.92.74.88', '1');
INSERT INTO `tab_user_login_record` VALUES ('522', '1', '神武2', '', '', '162', '13730199076', '13730199076', '1470986140', '180.213.177.87', '1');
INSERT INTO `tab_user_login_record` VALUES ('523', '1', '神武2', '', '', '178', 'lty123', 'lty123', '1470986180', '58.250.117.211', '1');
INSERT INTO `tab_user_login_record` VALUES ('524', '1', '神武2', '', '', '210', 'lty1234', 'lty1234', '1470986206', '58.250.117.211', '1');
INSERT INTO `tab_user_login_record` VALUES ('525', '1', '神武2', '', '', '211', 'kongde0', 'kongde0', '1470986213', '27.12.98.38', '1');
INSERT INTO `tab_user_login_record` VALUES ('526', '1', '神武2', '', '', '211', 'kongde0', 'kongde0', '1470986219', '27.12.175.89', '1');
INSERT INTO `tab_user_login_record` VALUES ('527', '1', '神武2', '', '', '212', '664775410', '664775410', '1470986294', '125.33.169.25', '1');
INSERT INTO `tab_user_login_record` VALUES ('528', '1', '神武2', '', '', '41', 'aa5587831', 'aa5587831', '1470986328', '171.107.17.200', '1');
INSERT INTO `tab_user_login_record` VALUES ('529', '1', '神武2', '', '', '178', 'lty123', 'lty123', '1470986383', '58.250.117.211', '1');
INSERT INTO `tab_user_login_record` VALUES ('530', '1', '神武2', '', '', '78', 'lixian1992', 'lixian1992', '1470986468', '1.191.46.93', '1');
INSERT INTO `tab_user_login_record` VALUES ('531', '1', '神武2', '', '', '213', 'qq532698553', 'qq532698553', '1470986469', '171.83.100.64', '1');
INSERT INTO `tab_user_login_record` VALUES ('532', '1', '神武2', '', '', '214', 'meizhi1000', 'meizhi1000', '1470986480', '221.193.58.182', '1');
INSERT INTO `tab_user_login_record` VALUES ('533', '1', '神武2', '', '', '173', '1049668470', '1049668470', '1470986539', '222.209.151.181', '1');
INSERT INTO `tab_user_login_record` VALUES ('534', '1', '神武2', '', '', '173', '1049668470', '1049668470', '1470986539', '222.209.151.181', '1');
INSERT INTO `tab_user_login_record` VALUES ('535', '1', '神武2', '', '', '173', '1049668470', '1049668470', '1470986540', '222.209.151.181', '1');
INSERT INTO `tab_user_login_record` VALUES ('536', '12', '决战中洲', '', '', '180', '777888', '777888', '1470986547', '153.36.68.155', '1');
INSERT INTO `tab_user_login_record` VALUES ('537', '1', '神武2', '', '', '173', '1049668470', '1049668470', '1470986583', '222.209.151.181', '1');
INSERT INTO `tab_user_login_record` VALUES ('538', '12', '决战中洲', '', '', '180', '777888', '777888', '1470986607', '153.36.68.155', '1');
INSERT INTO `tab_user_login_record` VALUES ('539', '12', '决战中洲', '', '', '180', '777888', '777888', '1470986682', '153.36.68.155', '1');
INSERT INTO `tab_user_login_record` VALUES ('540', '12', '决战中洲', '', '', '180', '777888', '777888', '1470986715', '153.36.68.155', '1');
INSERT INTO `tab_user_login_record` VALUES ('541', '1', '神武2', '', '', '130', 'xing0188', 'xing0188', '1470986733', '27.186.208.2', '1');
INSERT INTO `tab_user_login_record` VALUES ('542', '1', '神武2', '', '', '215', '15517166851', '15517166851', '1470986738', '171.116.23.231', '1');
INSERT INTO `tab_user_login_record` VALUES ('543', '1', '神武2', '', '', '216', '929596', '929596', '1470986745', '117.136.36.92', '1');
INSERT INTO `tab_user_login_record` VALUES ('544', '12', '决战中洲', '', '', '180', '777888', '777888', '1470986851', '153.36.68.155', '1');
INSERT INTO `tab_user_login_record` VALUES ('545', '1', '神武2', '', '', '217', '740804', '740804', '1470986916', '182.246.86.224', '1');
INSERT INTO `tab_user_login_record` VALUES ('546', '1', '神武2', '', '', '88', '991214', '991214', '1470986981', '124.78.180.71', '1');
INSERT INTO `tab_user_login_record` VALUES ('547', '1', '神武2', '', '', '218', 'jiang123a', 'jiang123a', '1470987013', '116.114.53.200', '1');
INSERT INTO `tab_user_login_record` VALUES ('548', '1', '神武2', '', '', '193', 'kangdong84', 'kangdong84', '1470987028', '106.114.23.101', '1');
INSERT INTO `tab_user_login_record` VALUES ('549', '1', '神武2', '', '', '175', 'aa8549', 'aa8549', '1470987040', '115.62.221.241', '1');
INSERT INTO `tab_user_login_record` VALUES ('550', '1', '神武2', '', '', '219', 'liwz5200', 'liwz5200', '1470987059', '183.27.48.106', '1');
INSERT INTO `tab_user_login_record` VALUES ('551', '1', '神武2', '', '', '41', 'aa5587831', 'aa5587831', '1470987178', '171.107.17.200', '1');
INSERT INTO `tab_user_login_record` VALUES ('552', '1', '神武2', '', '', '137', 'a857248868', 'a857248868', '1470987232', '117.136.4.177', '1');
INSERT INTO `tab_user_login_record` VALUES ('553', '12', '决战中洲', '', '', '180', '777888', '777888', '1470987253', '153.36.68.155', '1');
INSERT INTO `tab_user_login_record` VALUES ('554', '12', '决战中洲', '', '', '180', '777888', '777888', '1470987270', '153.36.68.155', '1');
INSERT INTO `tab_user_login_record` VALUES ('555', '1', '神武2', '', '', '149', '15156589827', '15156589827', '1470987273', '223.104.18.65', '1');
INSERT INTO `tab_user_login_record` VALUES ('556', '1', '神武2', '', '', '149', '15156589827', '15156589827', '1470987273', '223.104.18.65', '1');
INSERT INTO `tab_user_login_record` VALUES ('557', '1', '神武2', '', '', '162', '13730199076', '13730199076', '1470987292', '180.213.177.87', '1');
INSERT INTO `tab_user_login_record` VALUES ('558', '1', '神武2', '', '', '162', '13730199076', '13730199076', '1470987292', '180.213.177.87', '1');
INSERT INTO `tab_user_login_record` VALUES ('559', '1', '神武2', '', '', '162', '13730199076', '13730199076', '1470987295', '180.213.177.87', '1');
INSERT INTO `tab_user_login_record` VALUES ('560', '12', '决战中洲', '', '', '180', '777888', '777888', '1470987311', '153.36.68.155', '1');
INSERT INTO `tab_user_login_record` VALUES ('561', '1', '神武2', '', '', '220', 'maxk2010', 'maxk2010', '1470987322', '125.88.171.98', '1');
INSERT INTO `tab_user_login_record` VALUES ('562', '1', '神武2', '', '', '221', '192170', '192170', '1470987324', '123.245.209.132', '1');
INSERT INTO `tab_user_login_record` VALUES ('563', '1', '神武2', '', '', '162', '13730199076', '13730199076', '1470987350', '180.213.177.87', '1');
INSERT INTO `tab_user_login_record` VALUES ('564', '1', '神武2', '', '', '51', '15117861717', '15117861717', '1470987361', '114.139.104.39', '1');
INSERT INTO `tab_user_login_record` VALUES ('565', '12', '决战中洲', '', '', '222', '984526', '984526', '1470987436', '153.36.68.155', '1');
INSERT INTO `tab_user_login_record` VALUES ('566', '1', '神武2', '', '', '169', 'meng6532745', 'meng6532745', '1470987550', '125.77.45.157', '1');
INSERT INTO `tab_user_login_record` VALUES ('567', '1', '神武2', '', '', '169', 'meng6532745', 'meng6532745', '1470987550', '125.77.45.157', '1');
INSERT INTO `tab_user_login_record` VALUES ('568', '1', '神武2', '', '', '169', 'meng6532745', 'meng6532745', '1470987550', '125.77.45.157', '1');
INSERT INTO `tab_user_login_record` VALUES ('569', '1', '神武2', '', '', '169', 'meng6532745', 'meng6532745', '1470987551', '125.77.45.157', '1');
INSERT INTO `tab_user_login_record` VALUES ('570', '1', '神武2', '', '', '169', 'meng6532745', 'meng6532745', '1470987551', '125.77.45.157', '1');
INSERT INTO `tab_user_login_record` VALUES ('571', '1', '神武2', '', '', '169', 'meng6532745', 'meng6532745', '1470987551', '125.77.45.157', '1');
INSERT INTO `tab_user_login_record` VALUES ('572', '1', '神武2', '', '', '169', 'meng6532745', 'meng6532745', '1470987552', '125.77.45.157', '1');
INSERT INTO `tab_user_login_record` VALUES ('573', '1', '神武2', '', '', '169', 'meng6532745', 'meng6532745', '1470987552', '125.77.45.157', '1');
INSERT INTO `tab_user_login_record` VALUES ('574', '1', '神武2', '', '', '45', '20998526', '20998526', '1470987569', '117.28.181.145', '1');
INSERT INTO `tab_user_login_record` VALUES ('575', '12', '决战中洲', '', '', '180', '777888', '777888', '1470987587', '153.36.68.155', '1');
INSERT INTO `tab_user_login_record` VALUES ('576', '1', '神武2', '', '', '80', '424022', '424022', '1470987682', '123.206.94.240', '1');
INSERT INTO `tab_user_login_record` VALUES ('577', '12', '决战中洲', '', '', '222', '984526', '984526', '1470987686', '153.36.68.155', '1');
INSERT INTO `tab_user_login_record` VALUES ('578', '12', '决战中洲', '', '', '180', '777888', '777888', '1470987705', '153.36.68.155', '1');
INSERT INTO `tab_user_login_record` VALUES ('579', '12', '决战中洲', '', '', '180', '777888', '777888', '1470987734', '153.36.68.155', '1');
INSERT INTO `tab_user_login_record` VALUES ('580', '1', '神武2', '', '', '203', 'ak9584', 'ak9584', '1470987744', '61.185.133.2', '1');
INSERT INTO `tab_user_login_record` VALUES ('581', '1', '神武2', '', '', '203', 'ak9584', 'ak9584', '1470987744', '61.185.133.2', '1');
INSERT INTO `tab_user_login_record` VALUES ('582', '1', '神武2', '', '', '203', 'ak9584', 'ak9584', '1470987744', '61.185.133.2', '1');
INSERT INTO `tab_user_login_record` VALUES ('583', '1', '神武2', '', '', '203', 'ak9584', 'ak9584', '1470987745', '61.185.133.2', '1');
INSERT INTO `tab_user_login_record` VALUES ('584', '1', '神武2', '', '', '203', 'ak9584', 'ak9584', '1470987745', '61.185.133.2', '1');
INSERT INTO `tab_user_login_record` VALUES ('585', '12', '决战中洲', '', '', '180', '777888', '777888', '1470987746', '153.36.68.155', '1');
INSERT INTO `tab_user_login_record` VALUES ('586', '1', '神武2', '', '', '169', 'meng6532745', 'meng6532745', '1470987757', '125.77.45.157', '1');
INSERT INTO `tab_user_login_record` VALUES ('587', '1', '神武2', '', '', '223', '956553', '956553', '1470987766', '106.119.41.30', '1');
INSERT INTO `tab_user_login_record` VALUES ('588', '1', '神武2', '', '', '203', 'ak9584', 'ak9584', '1470987775', '221.11.61.62', '1');
INSERT INTO `tab_user_login_record` VALUES ('589', '1', '神武2', '', '', '224', '18634541613', '18634541613', '1470987862', '223.104.14.92', '1');
INSERT INTO `tab_user_login_record` VALUES ('590', '1', '神武2', '', '', '224', '18634541613', '18634541613', '1470987991', '223.104.14.92', '1');
INSERT INTO `tab_user_login_record` VALUES ('591', '1', '神武2', '', '', '225', '15812881012', '15812881012', '1470988035', '121.35.152.174', '1');
INSERT INTO `tab_user_login_record` VALUES ('592', '12', '决战中洲', '', '', '180', '777888', '777888', '1470988053', '153.36.68.155', '1');
INSERT INTO `tab_user_login_record` VALUES ('593', '12', '决战中洲', '', '', '222', '984526', '984526', '1470988079', '153.36.68.155', '1');
INSERT INTO `tab_user_login_record` VALUES ('594', '1', '神武2', '', '', '169', 'meng6532745', 'meng6532745', '1470988081', '125.77.45.157', '1');
INSERT INTO `tab_user_login_record` VALUES ('595', '1', '神武2', '', '', '169', 'meng6532745', 'meng6532745', '1470988082', '125.77.45.157', '1');
INSERT INTO `tab_user_login_record` VALUES ('596', '1', '神武2', '', '', '169', 'meng6532745', 'meng6532745', '1470988082', '125.77.45.157', '1');
INSERT INTO `tab_user_login_record` VALUES ('597', '1', '神武2', '', '', '169', 'meng6532745', 'meng6532745', '1470988082', '125.77.45.157', '1');
INSERT INTO `tab_user_login_record` VALUES ('598', '1', '神武2', '', '', '169', 'meng6532745', 'meng6532745', '1470988082', '125.77.45.157', '1');
INSERT INTO `tab_user_login_record` VALUES ('599', '1', '神武2', '', '', '169', 'meng6532745', 'meng6532745', '1470988082', '125.77.45.157', '1');
INSERT INTO `tab_user_login_record` VALUES ('600', '1', '神武2', '', '', '169', 'meng6532745', 'meng6532745', '1470988082', '125.77.45.157', '1');
INSERT INTO `tab_user_login_record` VALUES ('601', '1', '神武2', '', '', '169', 'meng6532745', 'meng6532745', '1470988082', '125.77.45.157', '1');
INSERT INTO `tab_user_login_record` VALUES ('602', '1', '神武2', '', '', '169', 'meng6532745', 'meng6532745', '1470988083', '125.77.45.157', '1');
INSERT INTO `tab_user_login_record` VALUES ('603', '12', '决战中洲', '', '', '180', '777888', '777888', '1470988115', '153.36.68.155', '1');
INSERT INTO `tab_user_login_record` VALUES ('604', '1', '神武2', '', '', '226', '13241737367', '13241737367', '1470988120', '114.254.199.223', '1');
INSERT INTO `tab_user_login_record` VALUES ('605', '1', '神武2', '', '', '227', '712242', '712242', '1470988191', '113.128.147.221', '1');
INSERT INTO `tab_user_login_record` VALUES ('606', '1', '神武2', '', '', '85', 'qzqzqz1', 'qzqzqz1', '1470988191', '183.245.147.126', '1');
INSERT INTO `tab_user_login_record` VALUES ('607', '1', '神武2', '', '', '227', '712242', '712242', '1470988191', '1.180.237.97', '1');
INSERT INTO `tab_user_login_record` VALUES ('608', '1', '神武2', '', '', '80', '424022', '424022', '1470988240', '123.206.94.240', '1');
INSERT INTO `tab_user_login_record` VALUES ('609', '1', '神武2', '', '', '85', 'qzqzqz1', 'qzqzqz1', '1470988266', '183.245.147.126', '1');
INSERT INTO `tab_user_login_record` VALUES ('610', '1', '神武2', '', '', '227', '712242', '712242', '1470988327', '59.63.166.141', '1');
INSERT INTO `tab_user_login_record` VALUES ('611', '1', '神武2', '', '', '203', 'ak9584', 'ak9584', '1470988337', '221.11.61.62', '1');
INSERT INTO `tab_user_login_record` VALUES ('612', '1', '神武2', '', '', '227', '712242', '712242', '1470988340', '1.180.237.97', '1');
INSERT INTO `tab_user_login_record` VALUES ('613', '1', '神武2', '', '', '227', '712242', '712242', '1470988342', '103.44.207.46', '1');
INSERT INTO `tab_user_login_record` VALUES ('614', '1', '神武2', '', '', '227', '712242', '712242', '1470988346', '59.63.166.141', '1');
INSERT INTO `tab_user_login_record` VALUES ('615', '1', '神武2', '', '', '228', 'youxi198914', 'youxi198914', '1470988424', '222.213.196.198', '1');
INSERT INTO `tab_user_login_record` VALUES ('616', '1', '神武2', '', '', '229', '15267836139', '15267836139', '1470988483', '123.152.136.161', '1');
INSERT INTO `tab_user_login_record` VALUES ('617', '1', '神武2', '', '', '229', '15267836139', '15267836139', '1470988492', '123.152.136.161', '1');
INSERT INTO `tab_user_login_record` VALUES ('618', '1', '神武2', '', '', '39', '6225540', '6225540', '1470988603', '139.201.153.110', '1');
INSERT INTO `tab_user_login_record` VALUES ('619', '1', '神武2', '', '', '126', 'a634788', 'a634788', '1470988682', '60.181.150.62', '1');
INSERT INTO `tab_user_login_record` VALUES ('620', '1', '神武2', '', '', '80', '424022', '424022', '1470988691', '123.206.94.240', '1');
INSERT INTO `tab_user_login_record` VALUES ('621', '1', '神武2', '', '', '175', 'aa8549', 'aa8549', '1470988827', '61.158.152.222', '1');
INSERT INTO `tab_user_login_record` VALUES ('622', '1', '神武2', '', '', '163', 'a154477', 'a154477', '1470988864', '211.138.16.228', '1');
INSERT INTO `tab_user_login_record` VALUES ('623', '1', '神武2', '', '', '45', '20998526', '20998526', '1470989020', '117.28.181.145', '1');
INSERT INTO `tab_user_login_record` VALUES ('624', '1', '神武2', '', '', '230', '7518684', '7518684', '1470989055', '223.241.47.66', '1');
INSERT INTO `tab_user_login_record` VALUES ('625', '12', '决战中洲', '', '', '180', '777888', '777888', '1470989093', '153.36.68.155', '1');
INSERT INTO `tab_user_login_record` VALUES ('626', '12', '决战中洲', '', '', '180', '777888', '777888', '1470989101', '153.36.68.155', '1');
INSERT INTO `tab_user_login_record` VALUES ('627', '1', '神武2', '', '', '231', 'sf1992', 'sf1992', '1470989185', '223.104.13.224', '1');
INSERT INTO `tab_user_login_record` VALUES ('628', '1', '神武2', '', '', '232', '15766224557', '15766224557', '1470989229', '121.12.126.234', '1');
INSERT INTO `tab_user_login_record` VALUES ('629', '12', '决战中洲', '', '', '222', '984526', '984526', '1470989244', '153.36.68.155', '1');
INSERT INTO `tab_user_login_record` VALUES ('630', '12', '决战中洲', '', '', '180', '777888', '777888', '1470989264', '153.36.68.155', '1');
INSERT INTO `tab_user_login_record` VALUES ('631', '1', '神武2', '', '', '233', '1827180733', '1827180733', '1470989297', '42.81.64.80', '1');
INSERT INTO `tab_user_login_record` VALUES ('632', '1', '神武2', '', '', '233', '1827180733', '1827180733', '1470989331', '42.81.64.80', '1');
INSERT INTO `tab_user_login_record` VALUES ('633', '1', '神武2', '', '', '232', '15766224557', '15766224557', '1470989374', '121.12.105.94', '1');
INSERT INTO `tab_user_login_record` VALUES ('634', '1', '神武2', '', '', '234', '926123', '926123', '1470989407', '36.44.154.162', '1');
INSERT INTO `tab_user_login_record` VALUES ('635', '12', '决战中洲', '', '', '180', '777888', '777888', '1470989433', '153.36.68.155', '1');
INSERT INTO `tab_user_login_record` VALUES ('636', '1', '神武2', '', '', '235', '520480', '520480', '1470989434', '14.215.41.152', '1');
INSERT INTO `tab_user_login_record` VALUES ('637', '12', '决战中洲', '', '', '180', '777888', '777888', '1470989471', '153.36.68.155', '1');
INSERT INTO `tab_user_login_record` VALUES ('638', '12', '决战中洲', '', '', '180', '777888', '777888', '1470989488', '153.36.68.155', '1');
INSERT INTO `tab_user_login_record` VALUES ('639', '1', '神武2', '', '', '233', '1827180733', '1827180733', '1470989573', '42.81.64.82', '1');
INSERT INTO `tab_user_login_record` VALUES ('640', '1', '神武2', '', '', '125', 'xzl123', 'xzl123', '1470989590', '1.198.177.200', '1');
INSERT INTO `tab_user_login_record` VALUES ('641', '1', '神武2', '', '', '236', '446974', '446974', '1470989606', '202.109.166.160', '1');
INSERT INTO `tab_user_login_record` VALUES ('642', '1', '神武2', '', '', '237', 'mihao128', 'mihao128', '1470989668', '106.117.77.201', '1');
INSERT INTO `tab_user_login_record` VALUES ('643', '1', '神武2', '', '', '236', '446974', '446974', '1470989752', '202.109.166.176', '1');
INSERT INTO `tab_user_login_record` VALUES ('644', '12', '决战中洲', '', '', '180', '777888', '777888', '1470989806', '153.36.68.155', '1');
INSERT INTO `tab_user_login_record` VALUES ('645', '1', '神武2', '', '', '211', 'kongde0', 'kongde0', '1470989957', '27.12.98.38', '1');
INSERT INTO `tab_user_login_record` VALUES ('646', '12', '决战中洲', '', '', '180', '777888', '777888', '1470990043', '153.36.68.155', '1');
INSERT INTO `tab_user_login_record` VALUES ('647', '12', '决战中洲', '', '', '180', '777888', '777888', '1470990064', '153.36.68.155', '1');
INSERT INTO `tab_user_login_record` VALUES ('648', '1', '神武2', '', '', '238', 'qq1233', 'qq1233', '1470990131', '14.148.45.24', '1');
INSERT INTO `tab_user_login_record` VALUES ('649', '1', '神武2', '', '', '239', '20080301', '20080301', '1470990187', '60.178.31.13', '1');
INSERT INTO `tab_user_login_record` VALUES ('650', '1', '神武2', '', '', '39', '6225540', '6225540', '1470990270', '139.201.153.110', '1');
INSERT INTO `tab_user_login_record` VALUES ('651', '1', '神武2', '', '', '44', 'ycxinpeng0911', 'ycxinpeng0911', '1470990362', '27.207.77.40', '1');
INSERT INTO `tab_user_login_record` VALUES ('652', '1', '神武2', '', '', '224', '18634541613', '18634541613', '1470990431', '1.69.139.35', '1');
INSERT INTO `tab_user_login_record` VALUES ('653', '1', '神武2', '', '', '240', 'zzza1231', 'zzza1231', '1470990475', '113.24.88.141', '1');
INSERT INTO `tab_user_login_record` VALUES ('654', '1', '神武2', '', '', '80', '424022', '424022', '1470990580', '123.206.94.240', '1');
INSERT INTO `tab_user_login_record` VALUES ('655', '1', '神武2', '', '', '88', '991214', '991214', '1470990602', '101.69.195.143', '1');
INSERT INTO `tab_user_login_record` VALUES ('656', '1', '神武2', '', '', '241', '528142', '528142', '1470990628', '112.96.100.104', '1');
INSERT INTO `tab_user_login_record` VALUES ('657', '1', '神武2', '', '', '242', '178995823', '178995823', '1470990630', '110.52.44.10', '1');
INSERT INTO `tab_user_login_record` VALUES ('658', '1', '神武2', '', '', '241', '528142', '528142', '1470990666', '112.96.100.104', '1');
INSERT INTO `tab_user_login_record` VALUES ('659', '1', '神武2', '', '', '243', '724568', '724568', '1470990734', '14.215.37.218', '1');
INSERT INTO `tab_user_login_record` VALUES ('660', '1', '神武2', '', '', '244', '265288', '265288', '1470990751', '115.49.180.154', '1');
INSERT INTO `tab_user_login_record` VALUES ('661', '1', '神武2', '', '', '245', 'qq1301510775', 'qq1301510775', '1470990922', '61.178.193.174', '1');
INSERT INTO `tab_user_login_record` VALUES ('662', '1', '神武2', '', '', '80', '424022', '424022', '1470990931', '123.206.94.240', '1');
INSERT INTO `tab_user_login_record` VALUES ('663', '1', '神武2', '', '', '246', '13072015431', '13072015431', '1470990940', '111.167.60.62', '1');
INSERT INTO `tab_user_login_record` VALUES ('664', '1', '神武2', '', '', '247', '15531434368', '15531434368', '1470990955', '110.254.197.69', '1');
INSERT INTO `tab_user_login_record` VALUES ('665', '1', '神武2', '', '', '240', 'zzza1231', 'zzza1231', '1470991040', '113.24.88.141', '1');
INSERT INTO `tab_user_login_record` VALUES ('666', '1', '神武2', '', '', '246', '13072015431', '13072015431', '1470991042', '111.167.60.62', '1');
INSERT INTO `tab_user_login_record` VALUES ('667', '1', '神武2', '', '', '242', '178995823', '178995823', '1470991050', '110.52.44.10', '1');
INSERT INTO `tab_user_login_record` VALUES ('668', '1', '神武2', '', '', '242', '178995823', '178995823', '1470991101', '110.52.44.10', '1');
INSERT INTO `tab_user_login_record` VALUES ('669', '1', '神武2', '', '', '248', '808208', '808208', '1470991144', '59.34.43.114', '1');
INSERT INTO `tab_user_login_record` VALUES ('670', '1', '神武2', '', '', '244', '265288', '265288', '1470991179', '115.49.180.154', '1');
INSERT INTO `tab_user_login_record` VALUES ('671', '1', '神武2', '', '', '245', 'qq1301510775', 'qq1301510775', '1470991276', '61.178.193.174', '1');
INSERT INTO `tab_user_login_record` VALUES ('672', '1', '神武2', '', '', '249', 'lz3040', 'lz3040', '1470991311', '222.216.114.171', '1');
INSERT INTO `tab_user_login_record` VALUES ('673', '1', '神武2', '', '', '250', '645098', '645098', '1470991335', '121.12.126.84', '1');
INSERT INTO `tab_user_login_record` VALUES ('674', '1', '神武2', '', '', '251', 'yhsdyxzh', 'yhsdyxzh', '1470991355', '120.205.49.26', '1');
INSERT INTO `tab_user_login_record` VALUES ('675', '1', '神武2', '', '', '216', '929596', '929596', '1470991391', '117.136.36.92', '1');
INSERT INTO `tab_user_login_record` VALUES ('676', '1', '神武2', '', '', '175', 'aa8549', 'aa8549', '1470991404', '61.158.152.222', '1');
INSERT INTO `tab_user_login_record` VALUES ('677', '1', '神武2', '', '', '120', '646342', '646342', '1470991411', '110.82.75.178', '1');
INSERT INTO `tab_user_login_record` VALUES ('678', '1', '神武2', '', '', '252', '262714', '262714', '1470991500', '121.22.225.105', '1');
INSERT INTO `tab_user_login_record` VALUES ('679', '1', '神武2', '', '', '253', '997673', '997673', '1470991680', '124.88.81.180', '1');
INSERT INTO `tab_user_login_record` VALUES ('680', '1', '神武2', '', '', '242', '178995823', '178995823', '1470991730', '110.52.44.10', '1');
INSERT INTO `tab_user_login_record` VALUES ('681', '1', '神武2', '', '', '224', '18634541613', '18634541613', '1470991917', '1.69.139.35', '1');
INSERT INTO `tab_user_login_record` VALUES ('682', '1', '神武2', '', '', '173', '1049668470', '1049668470', '1470991917', '222.209.151.181', '1');
INSERT INTO `tab_user_login_record` VALUES ('683', '1', '神武2', '', '', '254', '15821126952', '15821126952', '1470991924', '180.152.214.86', '1');
INSERT INTO `tab_user_login_record` VALUES ('684', '1', '神武2', '', '', '175', 'aa8549', 'aa8549', '1470991998', '115.62.221.241', '1');
INSERT INTO `tab_user_login_record` VALUES ('685', '1', '神武2', '', '', '255', '18370790913', '18370790913', '1470992031', '106.6.80.226', '1');
INSERT INTO `tab_user_login_record` VALUES ('686', '1', '神武2', '', '', '256', '1325425890', '1325425890', '1470992069', '112.64.28.153', '1');
INSERT INTO `tab_user_login_record` VALUES ('687', '1', '神武2', '', '', '227', '712242', '712242', '1470992083', '1.180.237.97', '1');
INSERT INTO `tab_user_login_record` VALUES ('688', '1', '神武2', '', '', '257', '584142', '584142', '1470992135', '182.207.216.81', '1');
INSERT INTO `tab_user_login_record` VALUES ('689', '1', '神武2', '', '', '258', '0401030', '0401030', '1470992138', '60.10.79.143', '1');
INSERT INTO `tab_user_login_record` VALUES ('690', '1', '神武2', '', '', '259', 'q735599563', 'q735599563', '1470992214', '27.223.227.84', '1');
INSERT INTO `tab_user_login_record` VALUES ('691', '1', '神武2', '', '', '260', '938071', '938071', '1470992248', '122.96.47.92', '1');
INSERT INTO `tab_user_login_record` VALUES ('692', '1', '神武2', '', '', '261', 'a2015111', 'a2015111', '1470992249', '113.5.123.96', '1');
INSERT INTO `tab_user_login_record` VALUES ('693', '1', '神武2', '', '', '242', '178995823', '178995823', '1470992276', '110.52.44.10', '1');
INSERT INTO `tab_user_login_record` VALUES ('694', '1', '神武2', '', '', '120', '646342', '646342', '1470992357', '110.82.75.178', '1');
INSERT INTO `tab_user_login_record` VALUES ('695', '1', '神武2', '', '', '262', 'tongleione', 'tongleione', '1470992366', '180.126.107.218', '1');
INSERT INTO `tab_user_login_record` VALUES ('696', '1', '神武2', '', '', '224', '18634541613', '18634541613', '1470992374', '1.69.139.35', '1');
INSERT INTO `tab_user_login_record` VALUES ('697', '1', '神武2', '', '', '259', 'q735599563', 'q735599563', '1470992380', '27.223.227.84', '1');
INSERT INTO `tab_user_login_record` VALUES ('698', '1', '神武2', '', '', '263', 'kidd50', 'kidd50', '1470992429', '219.238.188.162', '1');
INSERT INTO `tab_user_login_record` VALUES ('699', '1', '神武2', '', '', '264', '891106', '891106', '1470992483', '121.62.61.41', '1');
INSERT INTO `tab_user_login_record` VALUES ('700', '1', '神武2', '', '', '265', '214992', '214992', '1470992548', '121.22.225.105', '1');
INSERT INTO `tab_user_login_record` VALUES ('701', '1', '神武2', '', '', '257', '584142', '584142', '1470992556', '182.207.216.81', '1');
INSERT INTO `tab_user_login_record` VALUES ('702', '1', '神武2', '', '', '266', '211992', '211992', '1470992584', '121.22.225.105', '1');
INSERT INTO `tab_user_login_record` VALUES ('703', '1', '神武2', '', '', '267', 'qq735599563', 'qq735599563', '1470992600', '27.223.227.84', '1');
INSERT INTO `tab_user_login_record` VALUES ('704', '1', '神武2', '', '', '268', '562711', '562711', '1470992643', '223.157.24.165', '1');
INSERT INTO `tab_user_login_record` VALUES ('705', '1', '神武2', '', '', '269', 'wu0312', 'wu0312', '1470992644', '14.215.55.218', '1');
INSERT INTO `tab_user_login_record` VALUES ('706', '1', '神武2', '', '', '266', '211992', '211992', '1470992705', '121.22.225.105', '1');
INSERT INTO `tab_user_login_record` VALUES ('707', '1', '神武2', '', '', '233', '1827180733', '1827180733', '1470992814', '42.81.64.82', '1');
INSERT INTO `tab_user_login_record` VALUES ('708', '1', '神武2', '', '', '126', 'a634788', 'a634788', '1470992952', '60.181.150.62', '1');
INSERT INTO `tab_user_login_record` VALUES ('709', '1', '神武2', '', '', '270', '2733164728', '2733164728', '1470992967', '112.234.208.244', '1');
INSERT INTO `tab_user_login_record` VALUES ('710', '1', '神武2', '', '', '224', '18634541613', '18634541613', '1470992975', '1.69.139.35', '1');
INSERT INTO `tab_user_login_record` VALUES ('711', '1', '神武2', '', '', '271', 'zx3151629', 'zx3151629', '1470992997', '121.12.126.238', '1');
INSERT INTO `tab_user_login_record` VALUES ('712', '1', '神武2', '', '', '243', '724568', '724568', '1470993059', '112.96.106.54', '1');
INSERT INTO `tab_user_login_record` VALUES ('713', '1', '神武2', '', '', '173', '1049668470', '1049668470', '1470993090', '222.209.151.181', '1');
INSERT INTO `tab_user_login_record` VALUES ('714', '1', '神武2', '', '', '272', '720222', '720222', '1470993206', '121.12.126.41', '1');
INSERT INTO `tab_user_login_record` VALUES ('715', '1', '神武2', '', '', '272', '720222', '720222', '1470993251', '121.12.126.41', '1');
INSERT INTO `tab_user_login_record` VALUES ('716', '1', '神武2', '', '', '273', '15136668149', '15136668149', '1470993282', '115.49.15.181', '1');
INSERT INTO `tab_user_login_record` VALUES ('717', '1', '神武2', '', '', '249', 'lz3040', 'lz3040', '1470993368', '222.216.114.171', '1');
INSERT INTO `tab_user_login_record` VALUES ('718', '1', '神武2', '', '', '249', 'lz3040', 'lz3040', '1470993372', '222.216.114.171', '1');
INSERT INTO `tab_user_login_record` VALUES ('719', '1', '神武2', '', '', '274', 'hh913194', 'hh913194', '1470993380', '111.73.137.156', '1');
INSERT INTO `tab_user_login_record` VALUES ('720', '1', '神武2', '', '', '273', '15136668149', '15136668149', '1470993403', '115.49.15.181', '1');
INSERT INTO `tab_user_login_record` VALUES ('721', '1', '神武2', '', '', '275', '464968', '464968', '1470993424', '113.68.33.54', '1');
INSERT INTO `tab_user_login_record` VALUES ('722', '1', '神武2', '', '', '275', '464968', '464968', '1470993604', '113.68.33.54', '1');
INSERT INTO `tab_user_login_record` VALUES ('723', '1', '神武2', '', '', '264', '891106', '891106', '1470993794', '121.62.61.41', '1');
INSERT INTO `tab_user_login_record` VALUES ('724', '1', '神武2', '', '', '272', '720222', '720222', '1470993807', '121.12.126.41', '1');
INSERT INTO `tab_user_login_record` VALUES ('725', '1', '神武2', '', '', '276', 'sf0114', 'sf0114', '1470993818', '223.104.13.224', '1');
INSERT INTO `tab_user_login_record` VALUES ('726', '1', '神武2', '', '', '193', 'kangdong84', 'kangdong84', '1470993836', '106.114.23.101', '1');
INSERT INTO `tab_user_login_record` VALUES ('728', '1', '神武2', '', '', '278', 'a1006053214', 'a1006053214', '1470993906', '1.49.118.66', '1');
INSERT INTO `tab_user_login_record` VALUES ('729', '1', '神武2', '', '', '279', '470678259', '470678259', '1470993943', '171.212.135.43', '1');
INSERT INTO `tab_user_login_record` VALUES ('730', '1', '神武2', '', '', '255', '18370790913', '18370790913', '1470993971', '106.6.80.226', '1');
INSERT INTO `tab_user_login_record` VALUES ('731', '1', '神武2', '', '', '280', '889694', '889694', '1470993989', '182.90.76.147', '1');
INSERT INTO `tab_user_login_record` VALUES ('732', '1', '神武2', '', '', '281', 'darling09', 'darling09', '1470994095', '119.126.112.230', '1');
INSERT INTO `tab_user_login_record` VALUES ('733', '1', '神武2', '', '', '225', '15812881012', '15812881012', '1470994110', '121.35.152.174', '1');
INSERT INTO `tab_user_login_record` VALUES ('734', '1', '神武2', '', '', '255', '18370790913', '18370790913', '1470994312', '106.6.80.226', '1');
INSERT INTO `tab_user_login_record` VALUES ('735', '1', '神武2', '', '', '248', '808208', '808208', '1470994390', '59.34.43.114', '1');
INSERT INTO `tab_user_login_record` VALUES ('736', '1', '神武2', '', '', '126', 'a634788', 'a634788', '1470994399', '60.181.150.62', '1');
INSERT INTO `tab_user_login_record` VALUES ('737', '1', '神武2', '', '', '240', 'zzza1231', 'zzza1231', '1470994408', '113.24.88.141', '1');
INSERT INTO `tab_user_login_record` VALUES ('738', '1', '神武2', '', '', '121', '15201669177', '15201669177', '1470994415', '117.136.0.107', '1');
INSERT INTO `tab_user_login_record` VALUES ('739', '1', '神武2', '', '', '272', '720222', '720222', '1470994434', '121.12.126.41', '1');
INSERT INTO `tab_user_login_record` VALUES ('740', '1', '神武2', '', '', '163', 'a154477', 'a154477', '1470994468', '211.142.189.65', '1');
INSERT INTO `tab_user_login_record` VALUES ('741', '1', '神武2', '', '', '282', '499999', '499999', '1470994486', '139.205.154.93', '1');
INSERT INTO `tab_user_login_record` VALUES ('742', '1', '神武2', '', '', '279', '470678259', '470678259', '1470994555', '171.212.135.43', '1');
INSERT INTO `tab_user_login_record` VALUES ('743', '1', '神武2', '', '', '283', '985404', '985404', '1470994619', '116.17.74.4', '1');
INSERT INTO `tab_user_login_record` VALUES ('744', '1', '神武2', '', '', '163', 'a154477', 'a154477', '1470994638', '211.142.189.65', '1');
INSERT INTO `tab_user_login_record` VALUES ('745', '1', '神武2', '', '', '284', '18778781196', '18778781196', '1470994689', '180.140.48.39', '1');
INSERT INTO `tab_user_login_record` VALUES ('746', '1', '神武2', '', '', '269', 'wu0312', 'wu0312', '1470994712', '14.215.55.218', '1');
INSERT INTO `tab_user_login_record` VALUES ('747', '1', '神武2', '', '', '125', 'xzl123', 'xzl123', '1470994768', '1.198.177.200', '1');
INSERT INTO `tab_user_login_record` VALUES ('748', '1', '神武2', '', '', '286', 'z67520', 'z67520', '1470994792', '14.106.143.5', '1');
INSERT INTO `tab_user_login_record` VALUES ('749', '1', '神武2', '', '', '269', 'wu0312', 'wu0312', '1470994824', '14.215.55.218', '1');
INSERT INTO `tab_user_login_record` VALUES ('750', '1', '神武2', '', '', '229', '15267836139', '15267836139', '1470994833', '123.152.136.161', '1');
INSERT INTO `tab_user_login_record` VALUES ('751', '1', '神武2', '', '', '285', 'a8468729', 'a8468729', '1470994849', '182.18.111.88', '1');
INSERT INTO `tab_user_login_record` VALUES ('752', '1', '神武2', '', '', '285', 'a8468729', 'a8468729', '1470994851', '182.18.111.46', '1');
INSERT INTO `tab_user_login_record` VALUES ('753', '1', '神武2', '', '', '281', 'darling09', 'darling09', '1470994926', '119.126.112.230', '1');
INSERT INTO `tab_user_login_record` VALUES ('754', '1', '神武2', '', '', '281', 'darling09', 'darling09', '1470994928', '119.126.112.230', '1');
INSERT INTO `tab_user_login_record` VALUES ('755', '1', '神武2', '', '', '243', '724568', '724568', '1470994933', '112.96.106.54', '1');
INSERT INTO `tab_user_login_record` VALUES ('756', '1', '神武2', '', '', '275', '464968', '464968', '1470994950', '113.68.33.54', '1');
INSERT INTO `tab_user_login_record` VALUES ('757', '1', '神武2', '', '', '287', '740102', '740102', '1470994977', '183.41.0.27', '1');
INSERT INTO `tab_user_login_record` VALUES ('758', '1', '神武2', '', '', '243', '724568', '724568', '1470995036', '112.96.106.54', '1');
INSERT INTO `tab_user_login_record` VALUES ('759', '1', '神武2', '', '', '288', 'aa1500492388', 'aa1500492388', '1470995089', '106.46.106.250', '1');
INSERT INTO `tab_user_login_record` VALUES ('760', '1', '神武2', '', '', '263', 'kidd50', 'kidd50', '1470995107', '223.104.3.208', '1');
INSERT INTO `tab_user_login_record` VALUES ('761', '1', '神武2', '', '', '289', '14763555700', '14763555700', '1470995133', '119.189.70.199', '1');
INSERT INTO `tab_user_login_record` VALUES ('762', '1', '神武2', '', '', '237', 'mihao128', 'mihao128', '1470995149', '106.117.77.201', '1');
INSERT INTO `tab_user_login_record` VALUES ('763', '1', '神武2', '', '', '248', '808208', '808208', '1470995191', '59.34.43.114', '1');
INSERT INTO `tab_user_login_record` VALUES ('764', '1', '神武2', '', '', '130', 'xing0188', 'xing0188', '1470995225', '27.186.208.2', '1');
INSERT INTO `tab_user_login_record` VALUES ('765', '1', '神武2', '', '', '290', '15915514152', '15915514152', '1470995275', '163.204.2.120', '1');
INSERT INTO `tab_user_login_record` VALUES ('766', '1', '神武2', '', '', '289', '14763555700', '14763555700', '1470995293', '119.189.70.199', '1');
INSERT INTO `tab_user_login_record` VALUES ('767', '1', '神武2', '', '', '291', '18700605571', '18700605571', '1470995304', '222.187.239.226', '1');
INSERT INTO `tab_user_login_record` VALUES ('768', '1', '神武2', '', '', '292', 'hong888', 'hong888', '1470995345', '111.193.75.67', '1');
INSERT INTO `tab_user_login_record` VALUES ('769', '1', '神武2', '', '', '240', 'zzza1231', 'zzza1231', '1470995373', '113.24.88.141', '1');
INSERT INTO `tab_user_login_record` VALUES ('770', '1', '神武2', '', '', '248', '808208', '808208', '1470995503', '59.34.43.114', '1');
INSERT INTO `tab_user_login_record` VALUES ('771', '1', '神武2', '', '', '292', 'hong888', 'hong888', '1470995597', '111.193.75.67', '1');
INSERT INTO `tab_user_login_record` VALUES ('772', '1', '神武2', '', '', '281', 'darling09', 'darling09', '1470995613', '119.126.112.230', '1');
INSERT INTO `tab_user_login_record` VALUES ('773', '1', '神武2', '', '', '293', '13275383606', '13275383606', '1470995649', '39.68.232.64', '1');
INSERT INTO `tab_user_login_record` VALUES ('774', '1', '神武2', '', '', '294', 'pop866211', 'pop866211', '1470995670', '123.171.4.17', '1');
INSERT INTO `tab_user_login_record` VALUES ('775', '1', '神武2', '', '', '237', 'mihao128', 'mihao128', '1470995831', '106.117.77.201', '1');
INSERT INTO `tab_user_login_record` VALUES ('776', '1', '神武2', '', '', '218', 'jiang123a', 'jiang123a', '1470995897', '116.114.54.19', '1');
INSERT INTO `tab_user_login_record` VALUES ('777', '1', '神武2', '', '', '295', 'qqa147258', 'qqa147258', '1470995968', '36.162.182.173', '1');
INSERT INTO `tab_user_login_record` VALUES ('778', '1', '神武2', '', '', '296', '416459306', '416459306', '1470996016', '183.60.175.217', '1');
INSERT INTO `tab_user_login_record` VALUES ('779', '1', '神武2', '', '', '281', 'darling09', 'darling09', '1470996077', '119.126.112.230', '1');
INSERT INTO `tab_user_login_record` VALUES ('780', '1', '神武2', '', '', '290', '15915514152', '15915514152', '1470996193', '163.204.2.120', '1');
INSERT INTO `tab_user_login_record` VALUES ('781', '1', '神武2', '', '', '297', '13504994340', '13504994340', '1470996256', '113.231.224.50', '1');
INSERT INTO `tab_user_login_record` VALUES ('782', '1', '神武2', '', '', '298', '582458', '582458', '1470996340', '221.1.157.113', '1');
INSERT INTO `tab_user_login_record` VALUES ('783', '1', '神武2', '', '', '299', '416468216', '416468216', '1470996390', '113.128.131.41', '1');
INSERT INTO `tab_user_login_record` VALUES ('784', '1', '神武2', '', '', '248', '808208', '808208', '1470996421', '59.34.43.114', '1');
INSERT INTO `tab_user_login_record` VALUES ('785', '1', '神武2', '', '', '281', 'darling09', 'darling09', '1470996436', '119.126.112.230', '1');
INSERT INTO `tab_user_login_record` VALUES ('786', '1', '神武2', '', '', '240', 'zzza1231', 'zzza1231', '1470996481', '113.24.88.141', '1');
INSERT INTO `tab_user_login_record` VALUES ('787', '1', '神武2', '', '', '292', 'hong888', 'hong888', '1470996512', '111.193.75.67', '1');
INSERT INTO `tab_user_login_record` VALUES ('788', '1', '神武2', '', '', '300', '15181739702', '15181739702', '1470996521', '125.66.93.221', '1');
INSERT INTO `tab_user_login_record` VALUES ('789', '1', '神武2', '', '', '237', 'mihao128', 'mihao128', '1470996594', '106.117.77.201', '1');
INSERT INTO `tab_user_login_record` VALUES ('790', '1', '神武2', '', '', '217', '740804', '740804', '1470996618', '60.160.94.103', '1');
INSERT INTO `tab_user_login_record` VALUES ('791', '1', '神武2', '', '', '217', '740804', '740804', '1470996619', '60.160.94.103', '1');
INSERT INTO `tab_user_login_record` VALUES ('792', '1', '神武2', '', '', '217', '740804', '740804', '1470996619', '60.160.94.103', '1');
INSERT INTO `tab_user_login_record` VALUES ('793', '1', '神武2', '', '', '217', '740804', '740804', '1470996620', '60.160.94.103', '1');
INSERT INTO `tab_user_login_record` VALUES ('794', '1', '神武2', '', '', '217', '740804', '740804', '1470996620', '60.160.94.103', '1');
INSERT INTO `tab_user_login_record` VALUES ('795', '1', '神武2', '', '', '217', '740804', '740804', '1470996621', '60.160.94.103', '1');
INSERT INTO `tab_user_login_record` VALUES ('796', '1', '神武2', '', '', '217', '740804', '740804', '1470996621', '60.160.94.103', '1');
INSERT INTO `tab_user_login_record` VALUES ('797', '1', '神武2', '', '', '217', '740804', '740804', '1470996622', '60.160.94.103', '1');
INSERT INTO `tab_user_login_record` VALUES ('798', '1', '神武2', '', '', '217', '740804', '740804', '1470996623', '60.160.94.103', '1');
INSERT INTO `tab_user_login_record` VALUES ('799', '1', '神武2', '', '', '217', '740804', '740804', '1470996625', '60.160.94.103', '1');
INSERT INTO `tab_user_login_record` VALUES ('800', '1', '神武2', '', '', '217', '740804', '740804', '1470996625', '60.160.94.103', '1');
INSERT INTO `tab_user_login_record` VALUES ('801', '1', '神武2', '', '', '217', '740804', '740804', '1470996626', '60.160.94.103', '1');
INSERT INTO `tab_user_login_record` VALUES ('802', '1', '神武2', '', '', '217', '740804', '740804', '1470996626', '60.160.94.103', '1');
INSERT INTO `tab_user_login_record` VALUES ('803', '1', '神武2', '', '', '217', '740804', '740804', '1470996627', '60.160.94.103', '1');
INSERT INTO `tab_user_login_record` VALUES ('804', '1', '神武2', '', '', '217', '740804', '740804', '1470996628', '60.160.94.103', '1');
INSERT INTO `tab_user_login_record` VALUES ('805', '1', '神武2', '', '', '217', '740804', '740804', '1470996628', '60.160.94.103', '1');
INSERT INTO `tab_user_login_record` VALUES ('806', '1', '神武2', '', '', '217', '740804', '740804', '1470996628', '60.160.94.103', '1');
INSERT INTO `tab_user_login_record` VALUES ('807', '1', '神武2', '', '', '217', '740804', '740804', '1470996629', '60.160.94.103', '1');
INSERT INTO `tab_user_login_record` VALUES ('808', '1', '神武2', '', '', '217', '740804', '740804', '1470996629', '60.160.94.103', '1');
INSERT INTO `tab_user_login_record` VALUES ('809', '1', '神武2', '', '', '217', '740804', '740804', '1470996629', '60.160.94.103', '1');
INSERT INTO `tab_user_login_record` VALUES ('810', '1', '神武2', '', '', '301', '998433', '998433', '1470996667', '36.57.32.173', '1');
INSERT INTO `tab_user_login_record` VALUES ('811', '1', '神武2', '', '', '237', 'mihao128', 'mihao128', '1470996771', '106.117.77.201', '1');
INSERT INTO `tab_user_login_record` VALUES ('812', '1', '神武2', '', '', '290', '15915514152', '15915514152', '1470996783', '163.204.2.120', '1');
INSERT INTO `tab_user_login_record` VALUES ('813', '1', '神武2', '', '', '243', '724568', '724568', '1470996821', '112.96.188.98', '1');
INSERT INTO `tab_user_login_record` VALUES ('814', '1', '神武2', '', '', '302', 'qq1363508033', 'qq1363508033', '1470996891', '116.53.168.83', '1');
INSERT INTO `tab_user_login_record` VALUES ('815', '1', '神武2', '', '', '291', '18700605571', '18700605571', '1470996943', '222.187.239.226', '1');
INSERT INTO `tab_user_login_record` VALUES ('816', '1', '神武2', '', '', '303', 'zhangbin', 'zhangbin', '1470997427', '113.128.73.29', '1');
INSERT INTO `tab_user_login_record` VALUES ('817', '1', '神武2', '', '', '220', 'maxk2010', 'maxk2010', '1470997485', '125.88.171.98', '1');
INSERT INTO `tab_user_login_record` VALUES ('818', '1', '神武2', '', '', '304', 'ey1314251', 'ey1314251', '1470997497', '59.173.215.68', '1');
INSERT INTO `tab_user_login_record` VALUES ('819', '1', '神武2', '', '', '305', '15220943549', '15220943549', '1470997614', '14.144.201.217', '1');
INSERT INTO `tab_user_login_record` VALUES ('820', '1', '神武2', '', '', '173', '1049668470', '1049668470', '1470997627', '222.209.151.181', '1');
INSERT INTO `tab_user_login_record` VALUES ('821', '1', '神武2', '', '', '303', 'zhangbin', 'zhangbin', '1470997635', '1.180.237.97', '1');
INSERT INTO `tab_user_login_record` VALUES ('822', '1', '神武2', '', '', '120', '646342', '646342', '1470997639', '110.82.75.178', '1');
INSERT INTO `tab_user_login_record` VALUES ('823', '1', '神武2', '', '', '237', 'mihao128', 'mihao128', '1470997722', '106.117.77.201', '1');
INSERT INTO `tab_user_login_record` VALUES ('824', '1', '神武2', '', '', '109', '18237396228', '18237396228', '1470997774', '115.62.241.10', '1');
INSERT INTO `tab_user_login_record` VALUES ('825', '1', '神武2', '', '', '109', '18237396228', '18237396228', '1470997774', '115.62.241.10', '1');
INSERT INTO `tab_user_login_record` VALUES ('826', '1', '神武2', '', '', '291', '18700605571', '18700605571', '1470997960', '223.104.11.49', '1');
INSERT INTO `tab_user_login_record` VALUES ('827', '1', '神武2', '', '', '306', '498750600', '498750600', '1470997989', '43.225.237.10', '1');
INSERT INTO `tab_user_login_record` VALUES ('828', '1', '神武2', '', '', '307', 't321753988', 't321753988', '1470998109', '113.185.54.4', '1');
INSERT INTO `tab_user_login_record` VALUES ('829', '1', '神武2', '', '', '307', 't321753988', 't321753988', '1470998130', '113.185.54.4', '1');
INSERT INTO `tab_user_login_record` VALUES ('830', '1', '神武2', '', '', '281', 'darling09', 'darling09', '1470998167', '119.126.112.230', '1');
INSERT INTO `tab_user_login_record` VALUES ('831', '1', '神武2', '', '', '281', 'darling09', 'darling09', '1470998168', '119.126.112.230', '1');
INSERT INTO `tab_user_login_record` VALUES ('832', '12', '决战中洲', '', '', '180', '777888', '777888', '1470998333', '153.36.68.155', '1');
INSERT INTO `tab_user_login_record` VALUES ('833', '1', '神武2', '', '', '308', '803493', '803493', '1470998367', '39.73.16.60', '1');
INSERT INTO `tab_user_login_record` VALUES ('834', '1', '神武2', '', '', '309', '15984306325', '15984306325', '1470998367', '42.81.64.82', '1');
INSERT INTO `tab_user_login_record` VALUES ('835', '1', '神武2', '', '', '310', '4514210', '4514210', '1470998386', '222.82.88.233', '1');
INSERT INTO `tab_user_login_record` VALUES ('836', '1', '神武2', '', '', '311', '6676424', '6676424', '1470998400', '218.22.60.2', '1');
INSERT INTO `tab_user_login_record` VALUES ('837', '1', '神武2', '', '', '122', 'lxf1230', 'lxf1230', '1470998429', '117.136.61.52', '1');
INSERT INTO `tab_user_login_record` VALUES ('838', '1', '神武2', '', '', '312', 'aisi30', 'aisi30', '1470998483', '58.210.233.226', '1');
INSERT INTO `tab_user_login_record` VALUES ('839', '1', '神武2', '', '', '237', 'mihao128', 'mihao128', '1470998484', '106.117.77.201', '1');
INSERT INTO `tab_user_login_record` VALUES ('840', '1', '神武2', '', '', '313', '249982171', '249982171', '1470998511', '180.156.158.211', '1');
INSERT INTO `tab_user_login_record` VALUES ('841', '1', '神武2', '', '', '314', '1968185726', '1968185726', '1470998577', '58.217.250.195', '1');
INSERT INTO `tab_user_login_record` VALUES ('842', '1', '神武2', '', '', '315', '357661', '357661', '1470998578', '59.56.7.42', '1');

-- -----------------------------
-- Table structure for `tab_user_play`
-- -----------------------------
DROP TABLE IF EXISTS `tab_user_play`;
CREATE TABLE `tab_user_play` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '自增主键',
  `user_id` int(11) DEFAULT NULL COMMENT '用户ID',
  `user_account` varchar(30) DEFAULT NULL COMMENT '用户账号',
  `user_nickname` varchar(30) DEFAULT NULL COMMENT '用户昵称',
  `game_id` int(11) NOT NULL COMMENT '游戏id',
  `game_name` varchar(30) DEFAULT NULL COMMENT '游戏名称',
  `game_appid` varchar(32) DEFAULT NULL COMMENT '游戏appid',
  `server_id` int(11) NOT NULL COMMENT '区服id',
  `server_name` varchar(30) DEFAULT NULL COMMENT '区服名称',
  `role_id` int(11) DEFAULT '0' COMMENT '角色',
  `bind_balance` double(10,2) DEFAULT '0.00' COMMENT '绑定平台币',
  `role_name` varchar(20) DEFAULT NULL COMMENT '角色名称',
  `role_level` int(3) DEFAULT '0' COMMENT '等级',
  `promote_id` int(11) DEFAULT '0' COMMENT '推广员id',
  `promote_account` varchar(30) DEFAULT NULL COMMENT '推广员账号',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=312 DEFAULT CHARSET=utf8 COMMENT='玩家表';

-- -----------------------------
-- Records of `tab_user_play`
-- -----------------------------
INSERT INTO `tab_user_play` VALUES ('1', '1', '316046', '316046', '12', '决战中洲', '520D9380CF1B71E89', '0', '', '0', '0.00', '', '0', '0', '自然注册');
INSERT INTO `tab_user_play` VALUES ('2', '2', '674640', '674640', '12', '决战中洲', '520D9380CF1B71E89', '0', '', '0', '0.00', '', '0', '0', '自然注册');
INSERT INTO `tab_user_play` VALUES ('3', '3', '564942', '564942', '12', '决战中洲', '520D9380CF1B71E89', '0', '', '0', '0.00', '', '0', '0', '自然注册');
INSERT INTO `tab_user_play` VALUES ('4', '4', '563000', '563000', '12', '决战中洲', '520D9380CF1B71E89', '0', '', '0', '0.00', '', '0', '0', '自然注册');
INSERT INTO `tab_user_play` VALUES ('5', '8', '231149', '231149', '1', '梦幻西游BT', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '3', 'test1234');
INSERT INTO `tab_user_play` VALUES ('6', '9', '871103', '871103', '1', '梦幻西游BT', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '3', 'test1234');
INSERT INTO `tab_user_play` VALUES ('7', '10', '471341', '471341', '1', '梦幻西游BT', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '3', 'test1234');
INSERT INTO `tab_user_play` VALUES ('8', '12', '356596', '356596', '1', '梦幻西游BT', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '3', 'test1234');
INSERT INTO `tab_user_play` VALUES ('9', '13', '682928', '682928', '1', '梦幻西游BT', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '3', 'test1234');
INSERT INTO `tab_user_play` VALUES ('10', '14', '962674', '962674', '1', '梦幻西游BT', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '3', 'test1234');
INSERT INTO `tab_user_play` VALUES ('11', '15', '710020', '710020', '1', '梦幻西游BT', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '3', 'test1234');
INSERT INTO `tab_user_play` VALUES ('12', '16', '472800', '472800', '1', '梦幻西游BT', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '3', 'test1234');
INSERT INTO `tab_user_play` VALUES ('13', '17', '346367', '346367', '1', '梦幻西游BT', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '3', 'test1234');
INSERT INTO `tab_user_play` VALUES ('14', '18', '415399', '415399', '1', '梦幻西游BT', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '3', 'test1234');
INSERT INTO `tab_user_play` VALUES ('15', '19', '15505437898', '15505437898', '1', '梦幻西游BT', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '3', 'test1234');
INSERT INTO `tab_user_play` VALUES ('16', '19', '15505437898', '15505437898', '12', '决战中洲', '520D9380CF1B71E89', '0', '', '0', '0.00', '', '0', '3', 'test1234');
INSERT INTO `tab_user_play` VALUES ('17', '20', '868327', '868327', '1', '神武2BT', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '3', 'test1234');
INSERT INTO `tab_user_play` VALUES ('18', '21', '161510', '161510', '1', '神武2BT', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '3', 'test1234');
INSERT INTO `tab_user_play` VALUES ('19', '22', '371180', '371180', '1', '神武2BT', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '3', 'test1234');
INSERT INTO `tab_user_play` VALUES ('20', '23', '513248', '513248', '1', '神武2BT', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '3', 'test1234');
INSERT INTO `tab_user_play` VALUES ('21', '24', '781352', '781352', '12', '决战中洲', '520D9380CF1B71E89', '0', '', '0', '0.00', '', '0', '0', '自然注册');
INSERT INTO `tab_user_play` VALUES ('22', '25', '424842', '424842', '12', '决战中洲', '520D9380CF1B71E89', '0', '', '0', '0.00', '', '0', '0', '自然注册');
INSERT INTO `tab_user_play` VALUES ('23', '26', '772794', '772794', '1', '神武2BT', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '3', 'test1234');
INSERT INTO `tab_user_play` VALUES ('24', '27', '322187', '322187', '12', '决战中洲', '520D9380CF1B71E89', '0', '', '0', '0.00', '', '0', '0', '自然注册');
INSERT INTO `tab_user_play` VALUES ('25', '28', '210926', '210926', '1', '神武2BT', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '3', 'test1234');
INSERT INTO `tab_user_play` VALUES ('26', '29', '374925', '374925', '12', '决战中洲', '520D9380CF1B71E89', '0', '', '0', '0.00', '', '0', '0', '自然注册');
INSERT INTO `tab_user_play` VALUES ('27', '30', '252341', '252341', '12', '决战中洲', '520D9380CF1B71E89', '0', '', '0', '0.00', '', '0', '0', '自然注册');
INSERT INTO `tab_user_play` VALUES ('28', '31', '147043', '147043', '12', '决战中洲', '520D9380CF1B71E89', '0', '', '0', '0.00', '', '0', '0', '自然注册');
INSERT INTO `tab_user_play` VALUES ('29', '32', '550135', '550135', '1', '神武2BT', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '3', 'test1234');
INSERT INTO `tab_user_play` VALUES ('30', '33', '896852', '896852', '1', '神武2BT', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '3', 'test1234');
INSERT INTO `tab_user_play` VALUES ('31', '34', '861130', '861130', '1', '神武2BT', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '3', 'test1234');
INSERT INTO `tab_user_play` VALUES ('32', '35', '592371', '592371', '1', '神武2BT', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '3', 'test1234');
INSERT INTO `tab_user_play` VALUES ('33', '36', '955710', '955710', '1', '神武2BT', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '3', 'test1234');
INSERT INTO `tab_user_play` VALUES ('34', '38', '183383', '183383', '1', '神武2', 'CC44E9A9FDC231C00', '0', '', '0', '102.00', '', '0', '4', 'daniel0857');
INSERT INTO `tab_user_play` VALUES ('35', '39', '6225540', '6225540', '1', '神武2', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '4', 'daniel0857');
INSERT INTO `tab_user_play` VALUES ('36', '40', 'd123456', 'd123456', '1', '神武2', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '4', 'daniel0857');
INSERT INTO `tab_user_play` VALUES ('37', '41', 'aa5587831', 'aa5587831', '1', '神武2', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '4', 'daniel0857');
INSERT INTO `tab_user_play` VALUES ('38', '42', 'caomengyao1636', 'caomengyao1636', '1', '神武2', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '4', 'daniel0857');
INSERT INTO `tab_user_play` VALUES ('39', '43', 'zlt123456', 'zlt123456', '1', '神武2', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '4', 'daniel0857');
INSERT INTO `tab_user_play` VALUES ('40', '44', 'ycxinpeng0911', 'ycxinpeng0911', '1', '神武2', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '4', 'daniel0857');
INSERT INTO `tab_user_play` VALUES ('41', '45', '20998526', '20998526', '1', '神武2', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '4', 'daniel0857');
INSERT INTO `tab_user_play` VALUES ('42', '46', 'wei320781', 'wei320781', '1', '神武2', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '4', 'daniel0857');
INSERT INTO `tab_user_play` VALUES ('43', '47', 'yuan123', 'yuan123', '1', '神武2', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '4', 'daniel0857');
INSERT INTO `tab_user_play` VALUES ('44', '48', '182073a', '182073a', '1', '神武2', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '4', 'daniel0857');
INSERT INTO `tab_user_play` VALUES ('45', '49', 'loklok', 'loklok', '1', '神武2', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '4', 'daniel0857');
INSERT INTO `tab_user_play` VALUES ('46', '50', '13406351617', '13406351617', '1', '神武2', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '4', 'daniel0857');
INSERT INTO `tab_user_play` VALUES ('47', '51', '15117861717', '15117861717', '1', '神武2', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '4', 'daniel0857');
INSERT INTO `tab_user_play` VALUES ('48', '52', 'xm332418', 'xm332418', '1', '神武2', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '4', 'daniel0857');
INSERT INTO `tab_user_play` VALUES ('49', '53', '102549', '102549', '1', '神武2', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '4', 'daniel0857');
INSERT INTO `tab_user_play` VALUES ('50', '54', '15260363578', '15260363578', '1', '神武2', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '4', 'daniel0857');
INSERT INTO `tab_user_play` VALUES ('51', '55', '1196135202', '1196135202', '1', '神武2', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '4', 'daniel0857');
INSERT INTO `tab_user_play` VALUES ('52', '56', 'smw888', 'smw888', '1', '神武2', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '4', 'daniel0857');
INSERT INTO `tab_user_play` VALUES ('53', '57', 'qq8684253', 'qq8684253', '1', '神武2', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '4', 'daniel0857');
INSERT INTO `tab_user_play` VALUES ('54', '58', 'xxs8822', 'xxs8822', '1', '神武2', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '4', 'daniel0857');
INSERT INTO `tab_user_play` VALUES ('55', '59', '141115', '141115', '1', '神武2', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '4', 'daniel0857');
INSERT INTO `tab_user_play` VALUES ('56', '60', 'q11250', 'q11250', '1', '神武2', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '4', 'daniel0857');
INSERT INTO `tab_user_play` VALUES ('57', '61', 'x2192831197', 'x2192831197', '1', '神武2', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '4', 'daniel0857');
INSERT INTO `tab_user_play` VALUES ('58', '62', '13750584020', '13750584020', '1', '神武2', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '4', 'daniel0857');
INSERT INTO `tab_user_play` VALUES ('59', '63', '8989290', '8989290', '1', '神武2', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '4', 'daniel0857');
INSERT INTO `tab_user_play` VALUES ('60', '64', 'zyxztt', 'zyxztt', '1', '神武2', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '4', 'daniel0857');
INSERT INTO `tab_user_play` VALUES ('61', '65', '921937277', '921937277', '1', '神武2', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '4', 'daniel0857');
INSERT INTO `tab_user_play` VALUES ('62', '66', '18771660262', '18771660262', '1', '神武2', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '4', 'daniel0857');
INSERT INTO `tab_user_play` VALUES ('63', '67', 'ys779235950', 'ys779235950', '1', '神武2', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '4', 'daniel0857');
INSERT INTO `tab_user_play` VALUES ('64', '68', '277740768', '277740768', '1', '神武2', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '4', 'daniel0857');
INSERT INTO `tab_user_play` VALUES ('65', '69', 'abc123', 'abc123', '1', '神武2', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '7', 'zlt12345');
INSERT INTO `tab_user_play` VALUES ('66', '70', '608493', '608493', '1', '神武2', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '7', 'zlt12345');
INSERT INTO `tab_user_play` VALUES ('67', '71', '332171', '332171', '1', '神武2', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '4', 'daniel0857');
INSERT INTO `tab_user_play` VALUES ('68', '72', '928412', '928412', '1', '神武2', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '4', 'daniel0857');
INSERT INTO `tab_user_play` VALUES ('69', '73', '650265', '650265', '1', '神武2', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '4', 'daniel0857');
INSERT INTO `tab_user_play` VALUES ('70', '74', '926990', '926990', '1', '神武2', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '4', 'daniel0857');
INSERT INTO `tab_user_play` VALUES ('71', '75', '236496', '236496', '1', '神武2', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '4', 'daniel0857');
INSERT INTO `tab_user_play` VALUES ('72', '76', '937795', '937795', '1', '神武2', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '4', 'daniel0857');
INSERT INTO `tab_user_play` VALUES ('73', '77', '974778761', '974778761', '1', '神武2', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '4', 'daniel0857');
INSERT INTO `tab_user_play` VALUES ('74', '78', 'lixian1992', 'lixian1992', '1', '神武2', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '4', 'daniel0857');
INSERT INTO `tab_user_play` VALUES ('75', '79', '18368889337', '18368889337', '1', '神武2', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '4', 'daniel0857');
INSERT INTO `tab_user_play` VALUES ('76', '80', '424022', '424022', '1', '神武2', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '4', 'daniel0857');
INSERT INTO `tab_user_play` VALUES ('77', '81', 'q7745092', 'q7745092', '1', '神武2', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '4', 'daniel0857');
INSERT INTO `tab_user_play` VALUES ('78', '82', '18503840163', '18503840163', '1', '神武2', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '4', 'daniel0857');
INSERT INTO `tab_user_play` VALUES ('79', '83', '369258', '369258', '1', '神武2', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '4', 'daniel0857');
INSERT INTO `tab_user_play` VALUES ('80', '84', '123456', '123456', '1', '神武2', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '4', 'daniel0857');
INSERT INTO `tab_user_play` VALUES ('81', '85', 'qzqzqz1', 'qzqzqz1', '1', '神武2', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '4', 'daniel0857');
INSERT INTO `tab_user_play` VALUES ('82', '86', 'liziang16', 'liziang16', '1', '神武2', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '4', 'daniel0857');
INSERT INTO `tab_user_play` VALUES ('83', '87', 'feijihao1', 'feijihao1', '1', '神武2', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '4', 'daniel0857');
INSERT INTO `tab_user_play` VALUES ('84', '88', '991214', '991214', '1', '神武2', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '4', 'daniel0857');
INSERT INTO `tab_user_play` VALUES ('85', '89', '15099889223', '15099889223', '1', '神武2', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '4', 'daniel0857');
INSERT INTO `tab_user_play` VALUES ('86', '91', 'qwerqq', 'qwerqq', '1', '神武2', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '4', 'daniel0857');
INSERT INTO `tab_user_play` VALUES ('87', '90', 'q962056', 'q962056', '1', '神武2', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '4', 'daniel0857');
INSERT INTO `tab_user_play` VALUES ('88', '92', '130456', '130456', '1', '神武2', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '4', 'daniel0857');
INSERT INTO `tab_user_play` VALUES ('89', '93', '397385', '397385', '1', '神武2BT', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '3', 'test1234');
INSERT INTO `tab_user_play` VALUES ('90', '94', '237815', '237815', '12', '决战中洲', '520D9380CF1B71E89', '0', '', '0', '0.00', '', '0', '0', '自然注册');
INSERT INTO `tab_user_play` VALUES ('91', '95', '1933951700', '1933951700', '1', '神武2', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '4', 'daniel0857');
INSERT INTO `tab_user_play` VALUES ('92', '96', 'wq930411', 'wq930411', '1', '神武2', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '4', 'daniel0857');
INSERT INTO `tab_user_play` VALUES ('93', '97', 'motion', 'motion', '1', '神武2', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '4', 'daniel0857');
INSERT INTO `tab_user_play` VALUES ('94', '98', '821541', '821541', '1', '神武2', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '4', 'daniel0857');
INSERT INTO `tab_user_play` VALUES ('95', '99', '1173580004', '1173580004', '1', '神武2', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '4', 'daniel0857');
INSERT INTO `tab_user_play` VALUES ('96', '100', 'zhixi5436', 'zhixi5436', '1', '神武2', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '4', 'daniel0857');
INSERT INTO `tab_user_play` VALUES ('97', '101', '117078124', '117078124', '1', '神武2', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '4', 'daniel0857');
INSERT INTO `tab_user_play` VALUES ('98', '102', 'qq532371388', 'qq532371388', '1', '神武2', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '4', 'daniel0857');
INSERT INTO `tab_user_play` VALUES ('99', '103', 'lifuchun100', 'lifuchun100', '1', '神武2', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '4', 'daniel0857');
INSERT INTO `tab_user_play` VALUES ('100', '104', '791455', '791455', '12', '决战中洲', '520D9380CF1B71E89', '0', '', '0', '0.00', '', '0', '0', '自然注册');
INSERT INTO `tab_user_play` VALUES ('101', '105', 'qwe415263', 'qwe415263', '1', '神武2', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '4', 'daniel0857');
INSERT INTO `tab_user_play` VALUES ('102', '106', '618693', '618693', '12', '决战中洲', '520D9380CF1B71E89', '0', '', '0', '0.00', '', '0', '0', '自然注册');
INSERT INTO `tab_user_play` VALUES ('103', '107', '18634801194', '18634801194', '1', '神武2', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '4', 'daniel0857');
INSERT INTO `tab_user_play` VALUES ('104', '108', '18206220940', '18206220940', '1', '神武2', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '4', 'daniel0857');
INSERT INTO `tab_user_play` VALUES ('105', '109', '18237396228', '18237396228', '1', '神武2', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '4', 'daniel0857');
INSERT INTO `tab_user_play` VALUES ('106', '110', '136255', '136255', '1', '神武2', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '4', 'daniel0857');
INSERT INTO `tab_user_play` VALUES ('107', '111', '621943', '621943', '12', '决战中洲', '520D9380CF1B71E89', '0', '', '0', '0.00', '', '0', '0', '自然注册');
INSERT INTO `tab_user_play` VALUES ('108', '112', '700647', '700647', '12', '决战中洲', '520D9380CF1B71E89', '0', '', '0', '0.00', '', '0', '0', '自然注册');
INSERT INTO `tab_user_play` VALUES ('109', '113', 'lxy1350', 'lxy1350', '1', '神武2', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '7', 'zlt12345');
INSERT INTO `tab_user_play` VALUES ('110', '114', '224912', '224912', '12', '决战中洲', '520D9380CF1B71E89', '0', '', '0', '0.00', '', '0', '0', '自然注册');
INSERT INTO `tab_user_play` VALUES ('111', '115', '15016205992', '15016205992', '1', '神武2', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '4', 'daniel0857');
INSERT INTO `tab_user_play` VALUES ('112', '116', '125729', '125729', '1', '神武2', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '7', 'zlt12345');
INSERT INTO `tab_user_play` VALUES ('113', '117', 'wxainngg', 'wxainngg', '1', '神武2', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '7', 'zlt12345');
INSERT INTO `tab_user_play` VALUES ('114', '118', '744221', '744221', '1', '神武2', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '7', 'zlt12345');
INSERT INTO `tab_user_play` VALUES ('115', '119', '860830', '860830', '1', '神武2', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '7', 'zlt12345');
INSERT INTO `tab_user_play` VALUES ('116', '120', '646342', '646342', '1', '神武2', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '4', 'daniel0857');
INSERT INTO `tab_user_play` VALUES ('117', '121', '15201669177', '15201669177', '1', '神武2', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '7', 'zlt12345');
INSERT INTO `tab_user_play` VALUES ('118', '122', 'lxf1230', 'lxf1230', '1', '神武2', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '7', 'zlt12345');
INSERT INTO `tab_user_play` VALUES ('119', '123', 'novoetoe', 'novoetoe', '1', '神武2', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '7', 'zlt12345');
INSERT INTO `tab_user_play` VALUES ('120', '124', '3235028918', '3235028918', '1', '神武2', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '7', 'zlt12345');
INSERT INTO `tab_user_play` VALUES ('121', '125', 'xzl123', 'xzl123', '1', '神武2', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '7', 'zlt12345');
INSERT INTO `tab_user_play` VALUES ('122', '126', 'a634788', 'a634788', '1', '神武2', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '7', 'zlt12345');
INSERT INTO `tab_user_play` VALUES ('123', '127', '537308', '537308', '12', '决战中洲', '520D9380CF1B71E89', '0', '', '0', '0.00', '', '0', '0', '自然注册');
INSERT INTO `tab_user_play` VALUES ('124', '128', '149999', '149999', '1', '神武2', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '4', 'daniel0857');
INSERT INTO `tab_user_play` VALUES ('125', '129', 'wjx0503', 'wjx0503', '1', '神武2', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '7', 'zlt12345');
INSERT INTO `tab_user_play` VALUES ('126', '130', 'xing0188', 'xing0188', '1', '神武2', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '4', 'daniel0857');
INSERT INTO `tab_user_play` VALUES ('127', '131', '976217', '976217', '12', '决战中洲', '520D9380CF1B71E89', '0', '', '0', '0.00', '', '0', '0', '自然注册');
INSERT INTO `tab_user_play` VALUES ('128', '132', 'zn2615', 'zn2615', '1', '神武2', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '7', 'zlt12345');
INSERT INTO `tab_user_play` VALUES ('129', '133', '444807', '444807', '1', '神武2', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '7', 'zlt12345');
INSERT INTO `tab_user_play` VALUES ('130', '134', '443354', '443354', '12', '决战中洲', '520D9380CF1B71E89', '0', '', '0', '0.00', '', '0', '0', '自然注册');
INSERT INTO `tab_user_play` VALUES ('131', '135', 'whdonkey', 'whdonkey', '1', '神武2', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '7', 'zlt12345');
INSERT INTO `tab_user_play` VALUES ('132', '136', 'mzhyy888', 'mzhyy888', '1', '神武2', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '7', 'zlt12345');
INSERT INTO `tab_user_play` VALUES ('133', '137', 'a857248868', 'a857248868', '1', '神武2', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '7', 'zlt12345');
INSERT INTO `tab_user_play` VALUES ('134', '138', '527764', '527764', '1', '神武2', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '7', 'zlt12345');
INSERT INTO `tab_user_play` VALUES ('135', '139', 'wolfkill', 'wolfkill', '1', '神武2', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '7', 'zlt12345');
INSERT INTO `tab_user_play` VALUES ('136', '140', '7484372', '7484372', '1', '神武2', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '7', 'zlt12345');
INSERT INTO `tab_user_play` VALUES ('137', '141', '15864110597', '15864110597', '1', '神武2', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '7', 'zlt12345');
INSERT INTO `tab_user_play` VALUES ('138', '142', '428666', '428666', '1', '神武2', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '7', 'zlt12345');
INSERT INTO `tab_user_play` VALUES ('139', '143', '18325505542', '18325505542', '1', '神武2', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '4', 'daniel0857');
INSERT INTO `tab_user_play` VALUES ('140', '144', 'QQ3075261534', 'QQ3075261534', '1', '神武2', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '7', 'zlt12345');
INSERT INTO `tab_user_play` VALUES ('141', '145', 'wxy520', 'wxy520', '1', '神武2', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '7', 'zlt12345');
INSERT INTO `tab_user_play` VALUES ('142', '146', 'alv369', 'alv369', '1', '神武2', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '7', 'zlt12345');
INSERT INTO `tab_user_play` VALUES ('143', '147', 'q135345', 'q135345', '1', '神武2', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '4', 'daniel0857');
INSERT INTO `tab_user_play` VALUES ('144', '149', '15156589827', '15156589827', '1', '神武2', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '4', 'daniel0857');
INSERT INTO `tab_user_play` VALUES ('145', '150', '847421822', '847421822', '1', '神武2', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '7', 'zlt12345');
INSERT INTO `tab_user_play` VALUES ('146', '151', '500146', '500146', '1', '神武2', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '7', 'zlt12345');
INSERT INTO `tab_user_play` VALUES ('147', '152', '13533664553', '13533664553', '1', '神武2', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '7', 'zlt12345');
INSERT INTO `tab_user_play` VALUES ('148', '153', 'kang01', 'kang01', '1', '神武2', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '4', 'daniel0857');
INSERT INTO `tab_user_play` VALUES ('149', '154', 'likulili', 'likulili', '1', '神武2', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '7', 'zlt12345');
INSERT INTO `tab_user_play` VALUES ('150', '155', '826499', '826499', '1', '神武2', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '7', 'zlt12345');
INSERT INTO `tab_user_play` VALUES ('151', '156', '13912806950', '13912806950', '1', '神武2', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '7', 'zlt12345');
INSERT INTO `tab_user_play` VALUES ('152', '157', 'alex317', 'alex317', '1', '神武2', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '7', 'zlt12345');
INSERT INTO `tab_user_play` VALUES ('153', '158', 'cxxcxx', 'cxxcxx', '1', '神武2', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '7', 'zlt12345');
INSERT INTO `tab_user_play` VALUES ('154', '159', '874064170', '874064170', '1', '神武2', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '7', 'zlt12345');
INSERT INTO `tab_user_play` VALUES ('155', '160', '18873835270', '18873835270', '1', '神武2', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '7', 'zlt12345');
INSERT INTO `tab_user_play` VALUES ('156', '161', 'zzz123456', 'zzz123456', '1', '神武2', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '7', 'zlt12345');
INSERT INTO `tab_user_play` VALUES ('157', '162', '13730199076', '13730199076', '1', '神武2', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '7', 'zlt12345');
INSERT INTO `tab_user_play` VALUES ('158', '163', 'a154477', 'a154477', '1', '神武2', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '4', 'daniel0857');
INSERT INTO `tab_user_play` VALUES ('159', '164', 'a475285220', 'a475285220', '1', '神武2', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '7', 'zlt12345');
INSERT INTO `tab_user_play` VALUES ('160', '165', 'zzz123456789', 'zzz123456789', '1', '神武2', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '4', 'daniel0857');
INSERT INTO `tab_user_play` VALUES ('161', '166', '643074', '643074', '1', '神武2', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '4', 'daniel0857');
INSERT INTO `tab_user_play` VALUES ('162', '167', '18504842291', '18504842291', '1', '神武2', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '7', 'zlt12345');
INSERT INTO `tab_user_play` VALUES ('163', '168', '342411', '342411', '1', '神武2', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '7', 'zlt12345');
INSERT INTO `tab_user_play` VALUES ('164', '169', 'meng6532745', 'meng6532745', '1', '神武2', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '4', 'daniel0857');
INSERT INTO `tab_user_play` VALUES ('165', '170', 'liu3653953', 'liu3653953', '1', '神武2', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '4', 'daniel0857');
INSERT INTO `tab_user_play` VALUES ('166', '171', '649861', '649861', '1', '神武2', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '4', 'daniel0857');
INSERT INTO `tab_user_play` VALUES ('167', '172', 'hang02122015', 'hang02122015', '1', '神武2', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '7', 'zlt12345');
INSERT INTO `tab_user_play` VALUES ('168', '173', '1049668470', '1049668470', '1', '神武2', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '4', 'daniel0857');
INSERT INTO `tab_user_play` VALUES ('169', '174', 'bnhjkl2016', 'bnhjkl2016', '1', '神武2', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '4', 'daniel0857');
INSERT INTO `tab_user_play` VALUES ('170', '175', 'aa8549', 'aa8549', '1', '神武2', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '7', 'zlt12345');
INSERT INTO `tab_user_play` VALUES ('171', '176', '345345', '345345', '1', '神武2', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '7', 'zlt12345');
INSERT INTO `tab_user_play` VALUES ('172', '177', '8629131jun', '8629131jun', '1', '神武2', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '4', 'daniel0857');
INSERT INTO `tab_user_play` VALUES ('173', '178', 'lty123', 'lty123', '1', '神武2', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '4', 'daniel0857');
INSERT INTO `tab_user_play` VALUES ('174', '179', '368990', '368990', '12', '决战中洲', '520D9380CF1B71E89', '0', '', '0', '0.00', '', '0', '0', '自然注册');
INSERT INTO `tab_user_play` VALUES ('175', '180', '777888', '777888', '12', '决战中洲', '520D9380CF1B71E89', '0', '', '0', '0.00', '', '0', '0', '自然注册');
INSERT INTO `tab_user_play` VALUES ('176', '180', '777888', '777888', '1', '神武2', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '0', '自然注册');
INSERT INTO `tab_user_play` VALUES ('177', '181', 'mao5524', 'mao5524', '1', '神武2', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '7', 'zlt12345');
INSERT INTO `tab_user_play` VALUES ('178', '182', '1440886144', '1440886144', '1', '神武2', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '4', 'daniel0857');
INSERT INTO `tab_user_play` VALUES ('179', '183', '761207', '761207', '12', '决战中洲', '520D9380CF1B71E89', '0', '', '0', '0.00', '', '0', '0', '自然注册');
INSERT INTO `tab_user_play` VALUES ('180', '184', '123456ok', '123456ok', '1', '神武2', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '4', 'daniel0857');
INSERT INTO `tab_user_play` VALUES ('181', '185', '787083', '787083', '1', '神武2', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '4', 'daniel0857');
INSERT INTO `tab_user_play` VALUES ('182', '186', 'lzl0227', 'lzl0227', '1', '神武2', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '4', 'daniel0857');
INSERT INTO `tab_user_play` VALUES ('183', '187', '285023', '285023', '1', '神武2', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '7', 'zlt12345');
INSERT INTO `tab_user_play` VALUES ('184', '188', 'xiaoquan', 'xiaoquan', '1', '神武2', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '7', 'zlt12345');
INSERT INTO `tab_user_play` VALUES ('185', '189', 'ko5211314', 'ko5211314', '1', '神武2', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '7', 'zlt12345');
INSERT INTO `tab_user_play` VALUES ('186', '190', '510409', '510409', '1', '神武2', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '4', 'daniel0857');
INSERT INTO `tab_user_play` VALUES ('187', '191', '18920423096', '18920423096', '1', '神武2', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '7', 'zlt12345');
INSERT INTO `tab_user_play` VALUES ('188', '192', '388866', '388866', '12', '决战中洲', '520D9380CF1B71E89', '0', '', '0', '0.00', '', '0', '0', '自然注册');
INSERT INTO `tab_user_play` VALUES ('189', '193', 'kangdong84', 'kangdong84', '1', '神武2', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '4', 'daniel0857');
INSERT INTO `tab_user_play` VALUES ('190', '194', '2738436711', '2738436711', '1', '神武2', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '7', 'zlt12345');
INSERT INTO `tab_user_play` VALUES ('191', '195', '609398', '609398', '1', '神武2', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '7', 'zlt12345');
INSERT INTO `tab_user_play` VALUES ('192', '196', '13002096204', '13002096204', '1', '神武2', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '7', 'zlt12345');
INSERT INTO `tab_user_play` VALUES ('193', '197', '838725', '838725', '12', '决战中洲', '520D9380CF1B71E89', '0', '', '0', '0.00', '', '0', '0', '自然注册');
INSERT INTO `tab_user_play` VALUES ('194', '198', 'a6164282a', 'a6164282a', '1', '神武2', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '7', 'zlt12345');
INSERT INTO `tab_user_play` VALUES ('195', '199', '789390', '789390', '12', '决战中洲', '520D9380CF1B71E89', '0', '', '0', '0.00', '', '0', '0', '自然注册');
INSERT INTO `tab_user_play` VALUES ('196', '200', '18121728357', '18121728357', '1', '神武2', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '7', 'zlt12345');
INSERT INTO `tab_user_play` VALUES ('197', '201', 'a07088', 'a07088', '1', '神武2', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '7', 'zlt12345');
INSERT INTO `tab_user_play` VALUES ('198', '202', '1247682966', '1247682966', '1', '神武2', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '7', 'zlt12345');
INSERT INTO `tab_user_play` VALUES ('199', '203', 'ak9584', 'ak9584', '1', '神武2', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '4', 'daniel0857');
INSERT INTO `tab_user_play` VALUES ('200', '204', '271311', '271311', '1', '神武2', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '7', 'zlt12345');
INSERT INTO `tab_user_play` VALUES ('201', '205', '409059', '409059', '1', '神武2', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '4', 'daniel0857');
INSERT INTO `tab_user_play` VALUES ('202', '206', '111383', '111383', '1', '神武2', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '7', 'zlt12345');
INSERT INTO `tab_user_play` VALUES ('203', '207', '448402', '448402', '1', '神武2', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '4', 'daniel0857');
INSERT INTO `tab_user_play` VALUES ('204', '208', 'A295334930', 'A295334930', '1', '神武2', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '7', 'zlt12345');
INSERT INTO `tab_user_play` VALUES ('205', '209', 'qweasdcdc', 'qweasdcdc', '1', '神武2', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '4', 'daniel0857');
INSERT INTO `tab_user_play` VALUES ('206', '210', 'lty1234', 'lty1234', '1', '神武2', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '4', 'daniel0857');
INSERT INTO `tab_user_play` VALUES ('207', '211', 'kongde0', 'kongde0', '1', '神武2', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '4', 'daniel0857');
INSERT INTO `tab_user_play` VALUES ('208', '212', '664775410', '664775410', '1', '神武2', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '4', 'daniel0857');
INSERT INTO `tab_user_play` VALUES ('209', '213', 'qq532698553', 'qq532698553', '1', '神武2', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '4', 'daniel0857');
INSERT INTO `tab_user_play` VALUES ('210', '214', 'meizhi1000', 'meizhi1000', '1', '神武2', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '7', 'zlt12345');
INSERT INTO `tab_user_play` VALUES ('211', '215', '15517166851', '15517166851', '1', '神武2', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '4', 'daniel0857');
INSERT INTO `tab_user_play` VALUES ('212', '216', '929596', '929596', '1', '神武2', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '7', 'zlt12345');
INSERT INTO `tab_user_play` VALUES ('213', '217', '740804', '740804', '1', '神武2', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '7', 'zlt12345');
INSERT INTO `tab_user_play` VALUES ('214', '218', 'jiang123a', 'jiang123a', '1', '神武2', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '7', 'zlt12345');
INSERT INTO `tab_user_play` VALUES ('215', '219', 'liwz5200', 'liwz5200', '1', '神武2', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '7', 'zlt12345');
INSERT INTO `tab_user_play` VALUES ('216', '220', 'maxk2010', 'maxk2010', '1', '神武2', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '4', 'daniel0857');
INSERT INTO `tab_user_play` VALUES ('217', '221', '192170', '192170', '1', '神武2', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '7', 'zlt12345');
INSERT INTO `tab_user_play` VALUES ('218', '222', '984526', '984526', '12', '决战中洲', '520D9380CF1B71E89', '0', '', '0', '0.00', '', '0', '0', '自然注册');
INSERT INTO `tab_user_play` VALUES ('219', '223', '956553', '956553', '1', '神武2', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '7', 'zlt12345');
INSERT INTO `tab_user_play` VALUES ('220', '224', '18634541613', '18634541613', '1', '神武2', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '7', 'zlt12345');
INSERT INTO `tab_user_play` VALUES ('221', '225', '15812881012', '15812881012', '1', '神武2', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '4', 'daniel0857');
INSERT INTO `tab_user_play` VALUES ('222', '226', '13241737367', '13241737367', '1', '神武2', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '7', 'zlt12345');
INSERT INTO `tab_user_play` VALUES ('223', '227', '712242', '712242', '1', '神武2', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '4', 'daniel0857');
INSERT INTO `tab_user_play` VALUES ('224', '228', 'youxi198914', 'youxi198914', '1', '神武2', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '7', 'zlt12345');
INSERT INTO `tab_user_play` VALUES ('225', '229', '15267836139', '15267836139', '1', '神武2', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '4', 'daniel0857');
INSERT INTO `tab_user_play` VALUES ('226', '230', '7518684', '7518684', '1', '神武2', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '7', 'zlt12345');
INSERT INTO `tab_user_play` VALUES ('227', '231', 'sf1992', 'sf1992', '1', '神武2', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '4', 'daniel0857');
INSERT INTO `tab_user_play` VALUES ('228', '232', '15766224557', '15766224557', '1', '神武2', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '4', 'daniel0857');
INSERT INTO `tab_user_play` VALUES ('229', '233', '1827180733', '1827180733', '1', '神武2', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '7', 'zlt12345');
INSERT INTO `tab_user_play` VALUES ('230', '234', '926123', '926123', '1', '神武2', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '7', 'zlt12345');
INSERT INTO `tab_user_play` VALUES ('231', '235', '520480', '520480', '1', '神武2', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '7', 'zlt12345');
INSERT INTO `tab_user_play` VALUES ('232', '236', '446974', '446974', '1', '神武2', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '7', 'zlt12345');
INSERT INTO `tab_user_play` VALUES ('233', '237', 'mihao128', 'mihao128', '1', '神武2', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '4', 'daniel0857');
INSERT INTO `tab_user_play` VALUES ('234', '238', 'qq1233', 'qq1233', '1', '神武2', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '4', 'daniel0857');
INSERT INTO `tab_user_play` VALUES ('235', '239', '20080301', '20080301', '1', '神武2', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '4', 'daniel0857');
INSERT INTO `tab_user_play` VALUES ('236', '240', 'zzza1231', 'zzza1231', '1', '神武2', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '7', 'zlt12345');
INSERT INTO `tab_user_play` VALUES ('237', '241', '528142', '528142', '1', '神武2', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '7', 'zlt12345');
INSERT INTO `tab_user_play` VALUES ('238', '242', '178995823', '178995823', '1', '神武2', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '7', 'zlt12345');
INSERT INTO `tab_user_play` VALUES ('239', '243', '724568', '724568', '1', '神武2', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '7', 'zlt12345');
INSERT INTO `tab_user_play` VALUES ('240', '244', '265288', '265288', '1', '神武2', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '7', 'zlt12345');
INSERT INTO `tab_user_play` VALUES ('241', '245', 'qq1301510775', 'qq1301510775', '1', '神武2', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '7', 'zlt12345');
INSERT INTO `tab_user_play` VALUES ('242', '246', '13072015431', '13072015431', '1', '神武2', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '7', 'zlt12345');
INSERT INTO `tab_user_play` VALUES ('243', '247', '15531434368', '15531434368', '1', '神武2', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '7', 'zlt12345');
INSERT INTO `tab_user_play` VALUES ('244', '248', '808208', '808208', '1', '神武2', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '4', 'daniel0857');
INSERT INTO `tab_user_play` VALUES ('245', '249', 'lz3040', 'lz3040', '1', '神武2', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '4', 'daniel0857');
INSERT INTO `tab_user_play` VALUES ('246', '250', '645098', '645098', '1', '神武2', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '7', 'zlt12345');
INSERT INTO `tab_user_play` VALUES ('247', '251', 'yhsdyxzh', 'yhsdyxzh', '1', '神武2', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '7', 'zlt12345');
INSERT INTO `tab_user_play` VALUES ('248', '252', '262714', '262714', '1', '神武2', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '7', 'zlt12345');
INSERT INTO `tab_user_play` VALUES ('249', '253', '997673', '997673', '1', '神武2', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '7', 'zlt12345');
INSERT INTO `tab_user_play` VALUES ('250', '254', '15821126952', '15821126952', '1', '神武2', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '7', 'zlt12345');
INSERT INTO `tab_user_play` VALUES ('251', '255', '18370790913', '18370790913', '1', '神武2', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '7', 'zlt12345');
INSERT INTO `tab_user_play` VALUES ('252', '256', '1325425890', '1325425890', '1', '神武2', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '4', 'daniel0857');
INSERT INTO `tab_user_play` VALUES ('253', '257', '584142', '584142', '1', '神武2', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '4', 'daniel0857');
INSERT INTO `tab_user_play` VALUES ('254', '258', '0401030', '0401030', '1', '神武2', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '7', 'zlt12345');
INSERT INTO `tab_user_play` VALUES ('255', '259', 'q735599563', 'q735599563', '1', '神武2', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '7', 'zlt12345');
INSERT INTO `tab_user_play` VALUES ('256', '260', '938071', '938071', '1', '神武2', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '7', 'zlt12345');
INSERT INTO `tab_user_play` VALUES ('257', '261', 'a2015111', 'a2015111', '1', '神武2', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '7', 'zlt12345');
INSERT INTO `tab_user_play` VALUES ('258', '262', 'tongleione', 'tongleione', '1', '神武2', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '7', 'zlt12345');
INSERT INTO `tab_user_play` VALUES ('259', '263', 'kidd50', 'kidd50', '1', '神武2', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '7', 'zlt12345');
INSERT INTO `tab_user_play` VALUES ('260', '264', '891106', '891106', '1', '神武2', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '7', 'zlt12345');
INSERT INTO `tab_user_play` VALUES ('261', '265', '214992', '214992', '1', '神武2', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '7', 'zlt12345');
INSERT INTO `tab_user_play` VALUES ('262', '266', '211992', '211992', '1', '神武2', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '7', 'zlt12345');
INSERT INTO `tab_user_play` VALUES ('263', '267', 'qq735599563', 'qq735599563', '1', '神武2', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '7', 'zlt12345');
INSERT INTO `tab_user_play` VALUES ('264', '268', '562711', '562711', '1', '神武2', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '7', 'zlt12345');
INSERT INTO `tab_user_play` VALUES ('265', '269', 'wu0312', 'wu0312', '1', '神武2', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '7', 'zlt12345');
INSERT INTO `tab_user_play` VALUES ('266', '270', '2733164728', '2733164728', '1', '神武2', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '7', 'zlt12345');
INSERT INTO `tab_user_play` VALUES ('267', '271', 'zx3151629', 'zx3151629', '1', '神武2', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '4', 'daniel0857');
INSERT INTO `tab_user_play` VALUES ('268', '272', '720222', '720222', '1', '神武2', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '7', 'zlt12345');
INSERT INTO `tab_user_play` VALUES ('269', '273', '15136668149', '15136668149', '1', '神武2', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '7', 'zlt12345');
INSERT INTO `tab_user_play` VALUES ('270', '274', 'hh913194', 'hh913194', '1', '神武2', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '7', 'zlt12345');
INSERT INTO `tab_user_play` VALUES ('271', '275', '464968', '464968', '1', '神武2', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '4', 'daniel0857');
INSERT INTO `tab_user_play` VALUES ('272', '276', 'sf0114', 'sf0114', '1', '神武2', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '4', 'daniel0857');
INSERT INTO `tab_user_play` VALUES ('273', '277', 'qsqs08711', 'qsqs08711', '1', '神武2', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '4', 'daniel0857');
INSERT INTO `tab_user_play` VALUES ('274', '278', 'a1006053214', 'a1006053214', '1', '神武2', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '4', 'daniel0857');
INSERT INTO `tab_user_play` VALUES ('275', '279', '470678259', '470678259', '1', '神武2', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '4', 'daniel0857');
INSERT INTO `tab_user_play` VALUES ('276', '280', '889694', '889694', '1', '神武2', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '4', 'daniel0857');
INSERT INTO `tab_user_play` VALUES ('277', '281', 'darling09', 'darling09', '1', '神武2', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '7', 'zlt12345');
INSERT INTO `tab_user_play` VALUES ('278', '282', '499999', '499999', '1', '神武2', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '7', 'zlt12345');
INSERT INTO `tab_user_play` VALUES ('279', '283', '985404', '985404', '1', '神武2', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '7', 'zlt12345');
INSERT INTO `tab_user_play` VALUES ('280', '284', '18778781196', '18778781196', '1', '神武2', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '7', 'zlt12345');
INSERT INTO `tab_user_play` VALUES ('281', '286', 'z67520', 'z67520', '1', '神武2', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '7', 'zlt12345');
INSERT INTO `tab_user_play` VALUES ('282', '285', 'a8468729', 'a8468729', '1', '神武2', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '7', 'zlt12345');
INSERT INTO `tab_user_play` VALUES ('283', '287', '740102', '740102', '1', '神武2', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '4', 'daniel0857');
INSERT INTO `tab_user_play` VALUES ('284', '288', 'aa1500492388', 'aa1500492388', '1', '神武2', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '7', 'zlt12345');
INSERT INTO `tab_user_play` VALUES ('285', '289', '14763555700', '14763555700', '1', '神武2', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '7', 'zlt12345');
INSERT INTO `tab_user_play` VALUES ('286', '290', '15915514152', '15915514152', '1', '神武2', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '4', 'daniel0857');
INSERT INTO `tab_user_play` VALUES ('287', '291', '18700605571', '18700605571', '1', '神武2', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '7', 'zlt12345');
INSERT INTO `tab_user_play` VALUES ('288', '292', 'hong888', 'hong888', '1', '神武2', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '7', 'zlt12345');
INSERT INTO `tab_user_play` VALUES ('289', '293', '13275383606', '13275383606', '1', '神武2', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '7', 'zlt12345');
INSERT INTO `tab_user_play` VALUES ('290', '294', 'pop866211', 'pop866211', '1', '神武2', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '4', 'daniel0857');
INSERT INTO `tab_user_play` VALUES ('291', '295', 'qqa147258', 'qqa147258', '1', '神武2', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '7', 'zlt12345');
INSERT INTO `tab_user_play` VALUES ('292', '296', '416459306', '416459306', '1', '神武2', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '7', 'zlt12345');
INSERT INTO `tab_user_play` VALUES ('293', '297', '13504994340', '13504994340', '1', '神武2', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '4', 'daniel0857');
INSERT INTO `tab_user_play` VALUES ('294', '298', '582458', '582458', '1', '神武2', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '4', 'daniel0857');
INSERT INTO `tab_user_play` VALUES ('295', '299', '416468216', '416468216', '1', '神武2', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '4', 'daniel0857');
INSERT INTO `tab_user_play` VALUES ('296', '300', '15181739702', '15181739702', '1', '神武2', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '4', 'daniel0857');
INSERT INTO `tab_user_play` VALUES ('297', '301', '998433', '998433', '1', '神武2', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '4', 'daniel0857');
INSERT INTO `tab_user_play` VALUES ('298', '302', 'qq1363508033', 'qq1363508033', '1', '神武2', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '7', 'zlt12345');
INSERT INTO `tab_user_play` VALUES ('299', '303', 'zhangbin', 'zhangbin', '1', '神武2', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '7', 'zlt12345');
INSERT INTO `tab_user_play` VALUES ('300', '304', 'ey1314251', 'ey1314251', '1', '神武2', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '7', 'zlt12345');
INSERT INTO `tab_user_play` VALUES ('301', '305', '15220943549', '15220943549', '1', '神武2', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '4', 'daniel0857');
INSERT INTO `tab_user_play` VALUES ('302', '306', '498750600', '498750600', '1', '神武2', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '4', 'daniel0857');
INSERT INTO `tab_user_play` VALUES ('303', '307', 't321753988', 't321753988', '1', '神武2', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '7', 'zlt12345');
INSERT INTO `tab_user_play` VALUES ('304', '308', '803493', '803493', '1', '神武2', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '4', 'daniel0857');
INSERT INTO `tab_user_play` VALUES ('305', '309', '15984306325', '15984306325', '1', '神武2', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '4', 'daniel0857');
INSERT INTO `tab_user_play` VALUES ('306', '310', '4514210', '4514210', '1', '神武2', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '4', 'daniel0857');
INSERT INTO `tab_user_play` VALUES ('307', '311', '6676424', '6676424', '1', '神武2', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '7', 'zlt12345');
INSERT INTO `tab_user_play` VALUES ('308', '312', 'aisi30', 'aisi30', '1', '神武2', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '7', 'zlt12345');
INSERT INTO `tab_user_play` VALUES ('309', '313', '249982171', '249982171', '1', '神武2', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '7', 'zlt12345');
INSERT INTO `tab_user_play` VALUES ('310', '314', '1968185726', '1968185726', '1', '神武2', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '4', 'daniel0857');
INSERT INTO `tab_user_play` VALUES ('311', '315', '357661', '357661', '1', '神武2', 'CC44E9A9FDC231C00', '0', '', '0', '0.00', '', '0', '4', 'daniel0857');

-- -----------------------------
-- Table structure for `tab_withdraw`
-- -----------------------------
DROP TABLE IF EXISTS `tab_withdraw`;
CREATE TABLE `tab_withdraw` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '自增主键',
  `settlement_number` varchar(50) DEFAULT NULL COMMENT '结算单号',
  `sum_money` double DEFAULT NULL COMMENT '结算金额',
  `promote_id` int(11) DEFAULT NULL COMMENT '推广员id',
  `promote_account` varchar(30) DEFAULT NULL COMMENT '推广姓名',
  `create_time` int(11) DEFAULT NULL COMMENT '申请时间',
  `end_time` int(11) DEFAULT NULL COMMENT '完成时间',
  `status` int(11) DEFAULT '0' COMMENT '提现状态(-1未申请 0 申请中 1 已通过 2 已驳回)',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='结算表';

